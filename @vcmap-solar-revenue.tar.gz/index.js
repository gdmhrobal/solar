
function loadCss(href) {
  const base64url = href
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  return new Promise((resolve, reject) => {
    const elem = document.createElement('link');
    elem.rel = 'stylesheet';
    elem.href = base64url;
    elem.defer = false;
    elem.async = false;
    elem.onload = resolve;
    elem.onerror = reject;
    document.head.appendChild(elem);
  });
} await loadCss('data:text/css;base64,LmJvcmRlckNhcmQudi1zaGVldC52LWNhcmRbZGF0YS12LWU2NjU1ZWVjXSwuYm9yZGVyQ2FyZC52LXNoZWV0LnYtY2FyZFtkYXRhLXYtNTI0YjZkYzNdLC5ib3JkZXJDYXJkLnYtc2hlZXQudi1jYXJkW2RhdGEtdi03YzRiYzQ4MV17Ym9yZGVyLXdpZHRoOjJweDtib3JkZXItY29sb3I6dmFyKC0tdi1wcmltYXJ5LWJhc2UpfS5kLWdyaWRbZGF0YS12LTU4MmE0MzIxXXtkaXNwbGF5OmdyaWQ7Z3JpZC10ZW1wbGF0ZS1jb2x1bW5zOjFmciAxZnJ9Cg');var Ls = Object.defineProperty;
var Ms = (v, n, l) => n in v ? Ls(v, n, { enumerable: !0, configurable: !0, writable: !0, value: l }) : v[n] = l;
var Ve = (v, n, l) => (Ms(v, typeof n != "symbol" ? n + "" : n, l), l);
import { NotificationType as ki, VcsSlider as Es, VcsCheckbox as Ta, VcsLabel as gt, VcsFormButton as Ra, VcsWizard as Is, VcsWizardStep as Ts, VcsTextField as _a, VcsFormattedNumber as Rt, VcsButton as Ut, getColorByKey as Fe, VcsSelect as Oa, VcsDataTable as Ai, VcsFormSection as za, VcsActionButtonList as Rs, createToggleAction as _s, WindowSlot as Os, ButtonLocation as zs, ToolboxType as Fa, AbstractConfigEditor as Fs, vuetify as $i } from "../../../assets/ui.js";
import { defineComponent as ft, inject as Zt, ref as Pe, computed as be, watch as dt, getCurrentInstance as Pi, onUnmounted as Da } from "../../../assets/vue.js";
import { Feature as Ct, ol$geom$Polygon as Li, ol$geom$LineString as Ds, ol$style$Style as Vt, ol$style$Stroke as Gt, ol$geom$Point as qi } from "../../../assets/ol.js";
import { Projection as kt, cartesianToMercator as ut, mercatorToCartesian as ot, CesiumMap as Xa, AbstractInteraction as Xs, EventType as Ys, VectorStyleItem as Ui, VectorLayer as Zi, mercatorProjection as Ns, maxZIndex as Hs, markVolatile as Bs, startCreateFeatureSession as Ws, GeometryType as Vs } from "../../../assets/core.js";
import { VRow as pt, VCol as xt, VDialog as _t, VCard as Ot, VContainer as mt, VDivider as Mi, VSwitch as Gs, VIcon as Pt, VSheet as Ya, VTooltip as Na, VProgressLinear as js } from "../../../assets/vuetify.js";
import { Cartesian3 as we, Ray as $s, Camera as qs, Plane as Ji, Matrix3 as Ha, Cesium3DTileFeature as Us } from "../../../assets/cesium.js";
const At = "@vcmap/solar-revenue", Zs = "1.0.6", Js = "^5.2", Ks = {
  name: "Solar Wirtschaftlichkeitsrechner",
  tooltip: "Solar Wirtschaftlichkeitsrechner",
  nasa: "Der Kalibrierungsdienst der NASA ist nicht erreichbar",
  profitability: {
    selectFeature: "Selektieren Sie ein oder mehrere Objekte"
  },
  solarSelector: {
    noVCSolar: "Diese Fläche wurde über VC Solar nicht vorgerechnet. Verwenden Sie die Option Flächen Zeichnen",
    recalculate: "Neu berechnen",
    remove: "Entfernen",
    calculate: "Solarertrag berechnen",
    method: "Schritt 1 - Potentialflächen erfassen",
    selectArea: "Flächen selektieren",
    drawArea: "Flächen zeichnen",
    helpMethod: "Wählen Sie eine Methode für die Berechnung der solaren  Einstrahlung in der Toolbar aus.",
    helpMethod2: "Sie können entweder eine bereits berechnete Fläche selektieren oder eine Freifläche zeichnen.",
    helpMethodArea: "Für die Berechnung der solaren Einstrahlung auf eine Fläche aktivieren Sie den Zeichnungsmodus in der Toolbar und zeichnen eine beliebige Fläche.",
    modulesList: "Schritt 2 - Ertrag der Flächen berechnen",
    helpModulesList: "Hier werden alle selektierten oder gezeichneten Flächen angezeigt. Bei gezeichneten Flächen muss die solare Einstrahlung über den Button (Solarertrag berechnen) berechnet werden.",
    total: "Gesamt",
    results: "Schritt 3 - Verbrauchsdaten anpassen / Ergebnisse",
    helpResults: "Nachdem Sie eine oder mehrere Flächen selektiert bzw. gezeichnet haben und für freie Flächen den Solarertrag berechnet haben, können Sie ihre Verbrauchsdaten anpassen. Die Ergebnisse werden direkt an Ihre Eingaben angepasst.",
    coTwoSavings: "CO2-Einsparung",
    revenueCalculation: "Wirtschaftlichkeitsberechnung",
    finance: "Finanzierungsplan",
    keyData: "Kennzahlenbericht",
    table: {
      area: "Fläche",
      id: "Id",
      yield: "Ertrag",
      calculated: "Berechnet",
      actions: "Aktionen"
    },
    selection: "Selektion aufheben"
  },
  revenue: {
    help: {
      demand: "In diesem Bereich können Sie die Angaben über Ihren persönlichen Strombedarf vornehmen. Der errechnete Strombedarf passt sich dabei automatisch an Ihre Eingaben an. Sollten Sie Ihren Strombedarf jedoch exakt kennen, können Sie diesen direkt in das entsprechende Feld eingeben.",
      consumption: "Abhängig von Ihrem Verbrauchverhalten kann mehr Strom aus der Solaranlage direkt genutzt werden. Verbrauchen Sie beispielsweise tagsüber mehr Strom wird der Direktverbrauchsanteil steigen. Gleiches gilt für den Speicherverbrauch. Hier können Sie nun angeben, welchen Anteil am Solarstrom Sie direkt verbrauchen. Die voreingestellten Werte spiegeln einen durchschnittlichen Haushalt wider.",
      costs: "In diesem Bereich können Sie Angaben über die Energiekosten machen. Dazu geben Sie die aktuellen Stromkosten von Ihrem Anbieter an. Zusätzlich können Sie eine prognostizierte Strompreissteigerung berücksichtigen.",
      finance: "In diesem Bereich können Sie auswählen, ob Sie die Solaranlage finanzieren möchten. Dazu können Sie Angaben über das Eigenkapital, die Laufzeit und den Zinssatz machen."
    },
    title: "Wirtschaftlichkeitsrechner",
    button: "Verbrauchsdaten anpassen",
    demand: {
      title: "Strombedarf",
      person: "Haushaltsgröße",
      isHeatPump: "Wärmepumpe vorhanden",
      livingSpace: "Wohnraumgröße",
      isCar: "E-Auto vorhanden",
      distance: "Strecke / Jahr",
      demand: "Errechneter Strombedarf",
      demandUnit: "kWh/Jahr"
    },
    consumption: {
      title: "Eigenverbrauch",
      directConsumption: "Direktverbrauch",
      storageConsumption: "Speicherverbrauch",
      isStorageConsumption: "Stromspeicher einbeziehen"
    },
    costs: {
      title: "Energiekosten",
      consumption: "Bezugskosten pro kWh",
      supply: "Vergütung pro kWh",
      isIncrease: "Strompreissteigerung anpassen",
      increase: "Strompreissteigerung pro Jahr"
    },
    finance: {
      title: "Finanzierung",
      isFinance: "Finanzierung",
      invest: "Investitionskosten",
      credit: "Kreditbetrag",
      equity: "Eigenkapital",
      duration: "Laufzeit",
      durationUnit: "Jahre",
      interest: "Zinsen"
    }
  },
  cotwo: {
    title: "Einsparung",
    totalEmission: "Herstellungsemissionen, gesamt",
    totalSavings: "CO2-Einsparung, gesamt",
    text1: "Eine Solaranlage stößt bei der Erzeugung von Strom kein CO2 aus. Lediglich bei der Produktion von Solarmodulen wird CO2 durch die benötigte Herstellungsenergie ausgestoßen.",
    text2: "Der CO2-Ausstoß amortisiert sich in Ihrem individuellen Fall nach einer Laufzeit von:",
    unit: "Jahren",
    text3: "Die Herstellungsemissionen der Solarmodule übersteigen die potentielle C02-Einsparung",
    text4: "Die CO2-Einsparung entspricht dem rechnerischen Vergleich mit der CO2-Emission, welche durch Bezug der gleichen Strommenge aus dem deutschen Strommix (Stand: %{germanPowerMixYear}) entstehen würde. ",
    chart: {
      yUnit: "Jahr",
      xUnit: "kg",
      seriesEmission: "Herstellungsemission",
      seriesSavings: "Einsparung"
    }
  },
  prof: {
    title: "Wirtschaftlichkeit",
    description: "Der Einnahmen- und Ausgabenplan stellt die jährlichen Einnahmen und Ausgaben über eine angenommene Laufzeit der PV-Anlage von %{lifeTime} Jahren gegenüber.",
    typeLabel: "Wählen Sie das gewünschte Ergebnis:",
    type: {
      liquidity: "Liquiditätsverlauf",
      revenue: "Einnahmen-/Ausgabenplan"
    },
    chart: {
      yUnit: "Jahr",
      liquidity: {
        series: "Liquidität"
      },
      plan: {
        maintenanceCosts: "Betriebskosten",
        gridConsumptionPrice: "Bezugskosten",
        repaymentRate: "Tilgung",
        interestAmount: "Zinsen",
        directConsumptionPrice: "Direktverbrauch",
        storageConsumptionPrice: "Speicherverbrauch",
        gridSupplyPrice: "Netzeinspeisung"
      }
    }
  },
  finance: {
    title: "Finanzierungsplan",
    creditAmount: "Kreditbetrag",
    creditInterest: "Zinssatz",
    creditPeriod: "Laufzeit",
    creditPeriodUnit: "Jahre",
    creditTotal: "Kreditkosten, gesamt",
    text: "Neben einer Finanzierung über ein Kreditinstitut bestehen weitere Fördermöglichkeiten von staatlicher Seite. Weitere Informationen finden Sie bei der KfW",
    header: {
      year: "Jahr",
      annuity: "Annuität",
      repaymentRate: "Tilgung",
      remainingDept: "Restschuld",
      interestAmount: "Zinsanteil"
    }
  },
  keydata: {
    title: "Kennzahlenbericht",
    description: "Der Kennzahlenbericht umfasst jeweils eine tabellarische Übersicht der Energiebilanz (in kWh), der Energiekostenbilanz (in €) sowie eine Umweltbilanz (CO2 in kg). Die Angegebenen Werte errechnen sich aus dem Energieertrag der Potentialflächen sowie den personalisierten Verbrauchs- und Energiekostenangaben.",
    typeLabel: "Wählen Sie das gewünschte Ergebnis:",
    hint: "* Bitte Beachten Sie: ",
    hintText: "Die Gesamtsumme ergibt sich aus den Einträgen aller Seiten der Tabelle.",
    total: "Gesamt",
    type: {
      energyCosts: "Energiekostenbilanz",
      energy: "Energiebilanz",
      environmentalBalance: "Umweltbilanz"
    },
    energyPriceHeader: {
      year: "Jahr",
      maintenanceCosts: "Betriebskosten",
      gridConsumptionPrice: "Netzbezug",
      directConsumptionPrice: "Direktverbrauch",
      storageConsumptionPrice: "Speicherverbrauch",
      gridSupplyPrice: "Netzeinspeisung",
      liquidity: "kum. Liquidität"
    },
    energyHeader: {
      year: "Jahr",
      solarPowerYield: "Energieertrag",
      electricityDemand: "Energiebedarf",
      storageLosses: "Speicherverluste",
      directConsumption: "Direktverbrauch",
      storageConsumption: "Speicherverbrauch",
      gridConsumption: "Netzbezug",
      gridSupply: "Netzeinspeisung"
    },
    environmentalBalanceHeader: {
      year: "Jahr",
      coTwoSavings: "CO2-Einsparung"
    }
  },
  config: {
    admin: {
      germanPowerMix: "Deutscher Strommix",
      germanPowerMixYear: "Deutscher Strommix Stand",
      solarManufacture: "Herstellungskosten Modul",
      electricityDemandPerPerson: "Strombedarf pro Person",
      electricityDemandHeatPump: "Strombedarf Wärmepumpe",
      electricityDemandCar: "Strombedarf E-Auto",
      storageDegradation: "Speicherdegradation",
      storageLosses: "Speicherverluste",
      amortizationPeriod: "Amortisierungszeitraum",
      maintenancePortion: "Anteil Betriebskosten"
    },
    user: {
      numberOfPersons: "Personen im Haushalt",
      livingSpace: "Wohnraumgröße",
      annualDrivingDistance: "Jährliche Fahrstrecke",
      directConsumptionPortion: "Direktverbrauchsanteil",
      storageConsumptionPortion: "Speicherverbrauchsanteil",
      gridPurchaseCosts: "Netzbezugskosten",
      feedInTariff: "Einspeisetarif",
      electricityPriceIncrease: "Strompreissteigerung",
      equityCapital: "Eigenkapital",
      creditPeriod: "Kreditlaufzeit",
      creditInterest: "Kreditzinsrate",
      electricityDemand: "Strombedarf"
    },
    global: {
      solarLayerName: "Solar Layer Name",
      isVcSolar: "VC Solar Layer vorhanden",
      isDebug: "Debug Feature erzeugen"
    },
    vcSolar: {
      efficiency: "Effizienz",
      costs: "Kosten",
      degradation: "Degradation",
      kwpPerArea: "kWp pro m²"
    }
  }
}, Qs = {
  solarRevenue: Ks
}, er = {
  name: "Solar Revenue Calculator",
  tooltip: "Solar Revenue Calculator",
  nasa: "The NASA calibration service is not available",
  profitability: {
    selectFeature: "Select one or more objects"
  },
  solarSelector: {
    noVCSolar: "This surface was not pre-calculated via VC Solar. Use the draw areas option",
    recalculate: "recalculate",
    remove: "remove",
    calculate: "Calculate solar yield",
    method: "Step 1 - Register potential areas",
    selectArea: "select areas",
    drawArea: "draw areas",
    helpMethod: "Select a method for calculating the solar irradiation in the toolbar.",
    helpMethod2: "You can either select an area that has already been calculated or draw a free area.",
    helpMethodArea: "To calculate the solar irradiation on a surface, activate the drawing mode in the toolbar and draw an arbitrary surface.",
    modulesList: "Step 2 - Calculate yield of the areas",
    helpModulesList: "All selected or drawn areas are displayed here. For drawn areas, the solar irradiation must be calculated using the (Calculate solar yield) button.",
    total: "Total",
    results: "Step 3 - Adjust consumption data / results",
    helpResults: "After you have selected or drawn one or more areas and calculated the solar yield for drawn areas, you can customize your consumption data. The results are adapted directly to your inputs.",
    coTwoSavings: "CO2 savings",
    revenueCalculation: "Profitability calculation",
    finance: "Financing plan",
    keyData: "Key data report",
    table: {
      area: "Area",
      id: "Id",
      yield: "Yield",
      calculated: "Calculated",
      actions: "Actions"
    },
    selection: "Deselect all"
  },
  revenue: {
    help: {
      demand: "In this section, you can specify your personal electricity demand. The calculated electricity demand is automatically adjusted to your inputs. However, if you know your exact electricity demand, you can type it directly into the corresponding field.",
      consumption: "Depending on your consumption behavior, more electricity from the solar system can be used directly. For example, if you consume more electricity during the day, the proportion of direct consumption will increase. The same applies to storage consumption. You can now specify the proportion of solar power that you consume directly. The default values reflect an average household.",
      costs: "In this section, you can specify your energy costs. To do this, you need to provide the current electricity costs from your supplier. You can also take into account a forecast increase in electricity prices.",
      finance: "In this section you can choose whether you would like to finance the solar system. You can enter details about the equity capital, the duration and the interest rate."
    },
    title: "Profitability calculator",
    button: "Customize consumption data",
    demand: {
      title: "Electricity demand",
      person: "Household size",
      isHeatPump: "Heat pump available",
      livingSpace: "Living space size",
      isCar: "E-car available",
      distance: "Distance / year",
      demand: "Calculated electricity demand",
      demandUnit: "kWh/year"
    },
    consumption: {
      title: "Self-consumption",
      directConsumption: "Direct consumption",
      storageConsumption: "Storage consumption",
      isStorageConsumption: "Include power storage"
    },
    costs: {
      title: "Energy costs",
      consumption: "Purchase costs per kWh",
      supply: "Repayment per kWh",
      isIncrease: "Adjust electricity price increase",
      increase: "Electricity price increase per year"
    },
    finance: {
      title: "Financing",
      isFinance: "Financing",
      invest: "Investment costs",
      credit: "Credit amount",
      equity: "Equity capital",
      duration: "Duration",
      durationUnit: "years",
      interest: "Interest rate"
    }
  },
  cotwo: {
    title: "Savings",
    totalEmission: "Manufacturing emissions, total",
    totalSavings: "CO2 savings, total",
    text1: "A solar system does not emit any CO2 when generating electricity. CO2 is only emitted during the production of solar modules due to the energy required to manufacture them.",
    text2: "In your individual case, the CO2 emissions are amortized after a period of:",
    unit: "years",
    text3: "The manufacturing emissions of the solar modules exceed the potential C02 savings",
    text4: "The CO2 savings correspond to the calculated comparison with the CO2 emissions that would result from purchasing the same amount of electricity from the German electricity mix (as of %{germanPowerMixYear}).",
    chart: {
      yUnit: "Year",
      xUnit: "kg",
      seriesEmission: "Manufacturing emissions",
      seriesSavings: "Savings"
    }
  },
  prof: {
    title: "Profitability",
    description: "The income and expense plan compares the annual income and expenses over an assumed lifetime of the PV systems of %{lifeTime} years.",
    typeLabel: "Select the desired result:",
    type: {
      liquidity: "Liquidity trend",
      revenue: "Revenue/expenditure plan"
    },
    chart: {
      yUnit: "Year",
      liquidity: {
        series: "Liquidity"
      },
      plan: {
        maintenanceCosts: "Operating costs",
        gridConsumptionPrice: "Purchase costs",
        repaymentRate: "Repayment",
        interestAmount: "Interest",
        directConsumptionPrice: "Direct consumption",
        storageConsumptionPrice: "Storage consumption",
        gridSupplyPrice: "Grid feed-in"
      }
    }
  },
  finance: {
    title: "Financing plan",
    creditAmount: "Credit amount",
    creditInterest: "Interest rate",
    creditPeriod: "Duration",
    creditPeriodUnit: "Years",
    creditTotal: "Credit costs, total",
    text: "In addition to financing via a credit institution, there are other funding options from the state. Further information can be found at KfW",
    header: {
      year: "Years",
      annuity: "Annuity",
      repaymentRate: "Repayment",
      remainingDept: "Remaining debt",
      interestAmount: "Interest portion"
    }
  },
  keydata: {
    title: "Key data report",
    description: "The key data report includes a spreadsheet overview of the energy balance (in kWh), the energy cost balance (in €) and an environmental balance (CO2 in kg). The values given are based on the energy yield of the potential surfaces and the personalized consumption and energy cost data.",
    typeLabel: "Select the desired result:",
    hint: "* Please notice: ",
    hintText: "The total sum results from the entries of all pages in the table.",
    total: "Total",
    type: {
      energyCosts: "Energy cost balance",
      energy: "Energy balance",
      environmentalBalance: "Environmental balance"
    },
    energyPriceHeader: {
      year: "Year",
      maintenanceCosts: "Operating costs",
      gridConsumptionPrice: "Grid consumption",
      directConsumptionPrice: "Direct consumption",
      storageConsumptionPrice: "Storage consumption",
      gridSupplyPrice: "Grid feed-in",
      liquidity: "Liquidity"
    },
    energyHeader: {
      year: "Year",
      solarPowerYield: "Energy yield",
      electricityDemand: "Energy demand",
      storageLosses: "Storage losses",
      directConsumption: "Direct consumption",
      storageConsumption: "Storage consumption",
      gridConsumption: "Grid consumption",
      gridSupply: "Grid supply"
    },
    environmentalBalanceHeader: {
      year: "Year",
      coTwoSavings: "CO2 savings"
    }
  },
  config: {
    admin: {
      germanPowerMix: "german power mix",
      germanPowerMixYear: "german power mix (year)",
      solarManufacture: "manufacture costs modul",
      electricityDemandPerPerson: "electricity demand per person",
      electricityDemandHeatPump: "electricity demand heat pump",
      electricityDemandCar: "electricity demand car",
      storageDegradation: "storage degradation",
      storageLosses: "storage losses",
      amortizationPeriod: "amortization periode",
      maintenancePortion: "maintenance portion"
    },
    user: {
      numberOfPersons: "number of persons",
      livingSpace: "living space",
      annualDrivingDistance: "annual driving distance",
      directConsumptionPortion: "direct consumption portion",
      storageConsumptionPortion: "storage consumption portion",
      gridPurchaseCosts: "grid purchase costs",
      feedInTariff: "feed in tariff",
      electricityPriceIncrease: "electricity prise increase",
      equityCapital: "equity capital",
      creditPeriod: "credit periode",
      creditInterest: "credit interest",
      electricityDemand: "electricity demand"
    },
    global: {
      solarLayerName: "solar layer name",
      isVcSolar: "VC Solar Layer available",
      isDebug: "Create debug features"
    },
    vcSolar: {
      efficiency: "efficiency",
      costs: "costs",
      degradation: "degradation",
      kwpPerArea: "kWp per area"
    }
  }
}, tr = {
  solarRevenue: er
}, Et = () => ({
  adminOptions: {
    germanPowerMix: 0.434,
    germanPowerMixYear: 2022,
    solarManufacture: 500,
    electricityDemandPerPerson: 1300,
    electricityDemandHeatPump: 35,
    electricityDemandCar: 15,
    storageDegradation: 1,
    storageLosses: 20,
    amortizationPeriod: 20,
    maintenancePortion: 2
  },
  userOptions: {
    numberOfPersons: 3,
    livingSpace: 100,
    annualDrivingDistance: 1e4,
    directConsumptionPortion: 30,
    storageConsumptionPortion: 30,
    gridPurchaseCosts: 0.29,
    feedInTariff: 0.082,
    electricityPriceIncrease: 2,
    equityCapital: 3e3,
    creditPeriod: 10,
    creditInterest: 4,
    electricityDemand: 0
  },
  globalSettings: {
    isVcSolar: !1,
    solarLayerName: "SolarBuildings",
    isDebug: !1
  },
  vcSolarOptions: {
    efficiency: 20,
    costs: 1200,
    degradation: 0.5,
    kwpPerArea: 0.215
  }
});
var Je = 63710088e-1, ir = {
  centimeters: Je * 100,
  centimetres: Je * 100,
  degrees: Je / 111325,
  feet: Je * 3.28084,
  inches: Je * 39.37,
  kilometers: Je / 1e3,
  kilometres: Je / 1e3,
  meters: Je,
  metres: Je,
  miles: Je / 1609.344,
  millimeters: Je * 1e3,
  millimetres: Je * 1e3,
  nauticalmiles: Je / 1852,
  radians: 1,
  yards: Je * 1.0936
};
function Ei(v, n, l) {
  l === void 0 && (l = {});
  var u = { type: "Feature" };
  return (l.id === 0 || l.id) && (u.id = l.id), l.bbox && (u.bbox = l.bbox), u.properties = n || {}, u.geometry = v, u;
}
function pi(v, n, l) {
  if (l === void 0 && (l = {}), !v)
    throw new Error("coordinates is required");
  if (!Array.isArray(v))
    throw new Error("coordinates must be an Array");
  if (v.length < 2)
    throw new Error("coordinates must be at least 2 numbers long");
  if (!Ki(v[0]) || !Ki(v[1]))
    throw new Error("coordinates must contain numbers");
  var u = {
    type: "Point",
    coordinates: v
  };
  return Ei(u, n, l);
}
function Lt(v, n, l) {
  l === void 0 && (l = {});
  for (var u = 0, b = v; u < b.length; u++) {
    var y = b[u];
    if (y.length < 4)
      throw new Error("Each LinearRing of a Polygon must have 4 or more Positions.");
    for (var I = 0; I < y[y.length - 1].length; I++)
      if (y[y.length - 1][I] !== y[0][I])
        throw new Error("First and last Position are not equivalent.");
  }
  var A = {
    type: "Polygon",
    coordinates: v
  };
  return Ei(A, n, l);
}
function ar(v, n) {
  n === void 0 && (n = {});
  var l = { type: "FeatureCollection" };
  return n.id && (l.id = n.id), n.bbox && (l.bbox = n.bbox), l.features = v, l;
}
function sr(v, n, l) {
  l === void 0 && (l = {});
  var u = {
    type: "MultiPolygon",
    coordinates: v
  };
  return Ei(u, n, l);
}
function rr(v, n) {
  n === void 0 && (n = "kilometers");
  var l = ir[n];
  if (!l)
    throw new Error(n + " units is invalid");
  return v * l;
}
function Yt(v) {
  var n = v % 360;
  return n * Math.PI / 180;
}
function Ki(v) {
  return !isNaN(v) && v !== null && !Array.isArray(v);
}
function Jt(v, n, l) {
  if (v !== null)
    for (var u, b, y, I, A, T, z, H = 0, F = 0, D, W = v.type, B = W === "FeatureCollection", j = W === "Feature", ee = B ? v.features.length : 1, te = 0; te < ee; te++) {
      z = B ? v.features[te].geometry : j ? v.geometry : v, D = z ? z.type === "GeometryCollection" : !1, A = D ? z.geometries.length : 1;
      for (var M = 0; M < A; M++) {
        var V = 0, G = 0;
        if (I = D ? z.geometries[M] : z, I !== null) {
          T = I.coordinates;
          var X = I.type;
          switch (H = l && (X === "Polygon" || X === "MultiPolygon") ? 1 : 0, X) {
            case null:
              break;
            case "Point":
              if (n(
                T,
                F,
                te,
                V,
                G
              ) === !1)
                return !1;
              F++, V++;
              break;
            case "LineString":
            case "MultiPoint":
              for (u = 0; u < T.length; u++) {
                if (n(
                  T[u],
                  F,
                  te,
                  V,
                  G
                ) === !1)
                  return !1;
                F++, X === "MultiPoint" && V++;
              }
              X === "LineString" && V++;
              break;
            case "Polygon":
            case "MultiLineString":
              for (u = 0; u < T.length; u++) {
                for (b = 0; b < T[u].length - H; b++) {
                  if (n(
                    T[u][b],
                    F,
                    te,
                    V,
                    G
                  ) === !1)
                    return !1;
                  F++;
                }
                X === "MultiLineString" && V++, X === "Polygon" && G++;
              }
              X === "Polygon" && V++;
              break;
            case "MultiPolygon":
              for (u = 0; u < T.length; u++) {
                for (G = 0, b = 0; b < T[u].length; b++) {
                  for (y = 0; y < T[u][b].length - H; y++) {
                    if (n(
                      T[u][b][y],
                      F,
                      te,
                      V,
                      G
                    ) === !1)
                      return !1;
                    F++;
                  }
                  G++;
                }
                V++;
              }
              break;
            case "GeometryCollection":
              for (u = 0; u < I.geometries.length; u++)
                if (Jt(I.geometries[u], n, l) === !1)
                  return !1;
              break;
            default:
              throw new Error("Unknown Geometry Type");
          }
        }
      }
    }
}
function nr(v, n) {
  var l, u, b, y, I, A, T, z, H, F, D = 0, W = v.type === "FeatureCollection", B = v.type === "Feature", j = W ? v.features.length : 1;
  for (l = 0; l < j; l++) {
    for (A = W ? v.features[l].geometry : B ? v.geometry : v, z = W ? v.features[l].properties : B ? v.properties : {}, H = W ? v.features[l].bbox : B ? v.bbox : void 0, F = W ? v.features[l].id : B ? v.id : void 0, T = A ? A.type === "GeometryCollection" : !1, I = T ? A.geometries.length : 1, b = 0; b < I; b++) {
      if (y = T ? A.geometries[b] : A, y === null) {
        if (n(
          null,
          D,
          z,
          H,
          F
        ) === !1)
          return !1;
        continue;
      }
      switch (y.type) {
        case "Point":
        case "LineString":
        case "MultiPoint":
        case "Polygon":
        case "MultiLineString":
        case "MultiPolygon": {
          if (n(
            y,
            D,
            z,
            H,
            F
          ) === !1)
            return !1;
          break;
        }
        case "GeometryCollection": {
          for (u = 0; u < y.geometries.length; u++)
            if (n(
              y.geometries[u],
              D,
              z,
              H,
              F
            ) === !1)
              return !1;
          break;
        }
        default:
          throw new Error("Unknown Geometry Type");
      }
    }
    D++;
  }
}
function or(v, n, l) {
  var u = l;
  return nr(
    v,
    function(b, y, I, A, T) {
      y === 0 && l === void 0 ? u = b : u = n(
        u,
        b,
        y,
        I,
        A,
        T
      );
    }
  ), u;
}
function jt(v) {
  if (!v)
    throw new Error("coord is required");
  if (!Array.isArray(v)) {
    if (v.type === "Feature" && v.geometry !== null && v.geometry.type === "Point")
      return v.geometry.coordinates;
    if (v.type === "Point")
      return v.coordinates;
  }
  if (Array.isArray(v) && v.length >= 2 && !Array.isArray(v[0]) && !Array.isArray(v[1]))
    return v;
  throw new Error("coord must be GeoJSON Point or an Array of numbers");
}
function xi(v) {
  return v.type === "Feature" ? v.geometry : v;
}
function lr(v, n) {
  return v.type === "FeatureCollection" ? "FeatureCollection" : v.type === "GeometryCollection" ? "GeometryCollection" : v.type === "Feature" && v.geometry !== null ? v.geometry.type : v.type;
}
var Kt = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Ii(v) {
  return v && v.__esModule && Object.prototype.hasOwnProperty.call(v, "default") ? v.default : v;
}
function cr(v) {
  if (v.__esModule)
    return v;
  var n = v.default;
  if (typeof n == "function") {
    var l = function u() {
      return this instanceof u ? Reflect.construct(n, arguments, this.constructor) : n.apply(this, arguments);
    };
    l.prototype = n.prototype;
  } else
    l = {};
  return Object.defineProperty(l, "__esModule", { value: !0 }), Object.keys(v).forEach(function(u) {
    var b = Object.getOwnPropertyDescriptor(v, u);
    Object.defineProperty(l, u, b.get ? b : {
      enumerable: !0,
      get: function() {
        return v[u];
      }
    });
  }), l;
}
var Ti = { exports: {} }, Ba = { exports: {} };
(function(v, n) {
  (function(l, u) {
    v.exports = u();
  })(Kt, function() {
    function l(M, V, G, X, $) {
      (function K(J, ie, re, ne, ce) {
        for (; ne > re; ) {
          if (ne - re > 600) {
            var ge = ne - re + 1, ue = ie - re + 1, Le = Math.log(ge), ke = 0.5 * Math.exp(2 * Le / 3), Ae = 0.5 * Math.sqrt(Le * ke * (ge - ke) / ge) * (ue - ge / 2 < 0 ? -1 : 1), Me = Math.max(re, Math.floor(ie - ue * ke / ge + Ae)), Te = Math.min(ne, Math.floor(ie + (ge - ue) * ke / ge + Ae));
            K(J, ie, Me, Te, ce);
          }
          var oe = J[ie], Q = re, ae = ne;
          for (u(J, re, ie), ce(J[ne], oe) > 0 && u(J, re, ne); Q < ae; ) {
            for (u(J, Q, ae), Q++, ae--; ce(J[Q], oe) < 0; )
              Q++;
            for (; ce(J[ae], oe) > 0; )
              ae--;
          }
          ce(J[re], oe) === 0 ? u(J, re, ae) : u(J, ++ae, ne), ae <= ie && (re = ae + 1), ie <= ae && (ne = ae - 1);
        }
      })(M, V, G || 0, X || M.length - 1, $ || b);
    }
    function u(M, V, G) {
      var X = M[V];
      M[V] = M[G], M[G] = X;
    }
    function b(M, V) {
      return M < V ? -1 : M > V ? 1 : 0;
    }
    var y = function(M) {
      M === void 0 && (M = 9), this._maxEntries = Math.max(4, M), this._minEntries = Math.max(2, Math.ceil(0.4 * this._maxEntries)), this.clear();
    };
    function I(M, V, G) {
      if (!G)
        return V.indexOf(M);
      for (var X = 0; X < V.length; X++)
        if (G(M, V[X]))
          return X;
      return -1;
    }
    function A(M, V) {
      T(M, 0, M.children.length, V, M);
    }
    function T(M, V, G, X, $) {
      $ || ($ = ee(null)), $.minX = 1 / 0, $.minY = 1 / 0, $.maxX = -1 / 0, $.maxY = -1 / 0;
      for (var K = V; K < G; K++) {
        var J = M.children[K];
        z($, M.leaf ? X(J) : J);
      }
      return $;
    }
    function z(M, V) {
      return M.minX = Math.min(M.minX, V.minX), M.minY = Math.min(M.minY, V.minY), M.maxX = Math.max(M.maxX, V.maxX), M.maxY = Math.max(M.maxY, V.maxY), M;
    }
    function H(M, V) {
      return M.minX - V.minX;
    }
    function F(M, V) {
      return M.minY - V.minY;
    }
    function D(M) {
      return (M.maxX - M.minX) * (M.maxY - M.minY);
    }
    function W(M) {
      return M.maxX - M.minX + (M.maxY - M.minY);
    }
    function B(M, V) {
      return M.minX <= V.minX && M.minY <= V.minY && V.maxX <= M.maxX && V.maxY <= M.maxY;
    }
    function j(M, V) {
      return V.minX <= M.maxX && V.minY <= M.maxY && V.maxX >= M.minX && V.maxY >= M.minY;
    }
    function ee(M) {
      return { children: M, height: 1, leaf: !0, minX: 1 / 0, minY: 1 / 0, maxX: -1 / 0, maxY: -1 / 0 };
    }
    function te(M, V, G, X, $) {
      for (var K = [V, G]; K.length; )
        if (!((G = K.pop()) - (V = K.pop()) <= X)) {
          var J = V + Math.ceil((G - V) / X / 2) * X;
          l(M, J, V, G, $), K.push(V, J, J, G);
        }
    }
    return y.prototype.all = function() {
      return this._all(this.data, []);
    }, y.prototype.search = function(M) {
      var V = this.data, G = [];
      if (!j(M, V))
        return G;
      for (var X = this.toBBox, $ = []; V; ) {
        for (var K = 0; K < V.children.length; K++) {
          var J = V.children[K], ie = V.leaf ? X(J) : J;
          j(M, ie) && (V.leaf ? G.push(J) : B(M, ie) ? this._all(J, G) : $.push(J));
        }
        V = $.pop();
      }
      return G;
    }, y.prototype.collides = function(M) {
      var V = this.data;
      if (!j(M, V))
        return !1;
      for (var G = []; V; ) {
        for (var X = 0; X < V.children.length; X++) {
          var $ = V.children[X], K = V.leaf ? this.toBBox($) : $;
          if (j(M, K)) {
            if (V.leaf || B(M, K))
              return !0;
            G.push($);
          }
        }
        V = G.pop();
      }
      return !1;
    }, y.prototype.load = function(M) {
      if (!M || !M.length)
        return this;
      if (M.length < this._minEntries) {
        for (var V = 0; V < M.length; V++)
          this.insert(M[V]);
        return this;
      }
      var G = this._build(M.slice(), 0, M.length - 1, 0);
      if (this.data.children.length)
        if (this.data.height === G.height)
          this._splitRoot(this.data, G);
        else {
          if (this.data.height < G.height) {
            var X = this.data;
            this.data = G, G = X;
          }
          this._insert(G, this.data.height - G.height - 1, !0);
        }
      else
        this.data = G;
      return this;
    }, y.prototype.insert = function(M) {
      return M && this._insert(M, this.data.height - 1), this;
    }, y.prototype.clear = function() {
      return this.data = ee([]), this;
    }, y.prototype.remove = function(M, V) {
      if (!M)
        return this;
      for (var G, X, $, K = this.data, J = this.toBBox(M), ie = [], re = []; K || ie.length; ) {
        if (K || (K = ie.pop(), X = ie[ie.length - 1], G = re.pop(), $ = !0), K.leaf) {
          var ne = I(M, K.children, V);
          if (ne !== -1)
            return K.children.splice(ne, 1), ie.push(K), this._condense(ie), this;
        }
        $ || K.leaf || !B(K, J) ? X ? (G++, K = X.children[G], $ = !1) : K = null : (ie.push(K), re.push(G), G = 0, X = K, K = K.children[0]);
      }
      return this;
    }, y.prototype.toBBox = function(M) {
      return M;
    }, y.prototype.compareMinX = function(M, V) {
      return M.minX - V.minX;
    }, y.prototype.compareMinY = function(M, V) {
      return M.minY - V.minY;
    }, y.prototype.toJSON = function() {
      return this.data;
    }, y.prototype.fromJSON = function(M) {
      return this.data = M, this;
    }, y.prototype._all = function(M, V) {
      for (var G = []; M; )
        M.leaf ? V.push.apply(V, M.children) : G.push.apply(G, M.children), M = G.pop();
      return V;
    }, y.prototype._build = function(M, V, G, X) {
      var $, K = G - V + 1, J = this._maxEntries;
      if (K <= J)
        return A($ = ee(M.slice(V, G + 1)), this.toBBox), $;
      X || (X = Math.ceil(Math.log(K) / Math.log(J)), J = Math.ceil(K / Math.pow(J, X - 1))), ($ = ee([])).leaf = !1, $.height = X;
      var ie = Math.ceil(K / J), re = ie * Math.ceil(Math.sqrt(J));
      te(M, V, G, re, this.compareMinX);
      for (var ne = V; ne <= G; ne += re) {
        var ce = Math.min(ne + re - 1, G);
        te(M, ne, ce, ie, this.compareMinY);
        for (var ge = ne; ge <= ce; ge += ie) {
          var ue = Math.min(ge + ie - 1, ce);
          $.children.push(this._build(M, ge, ue, X - 1));
        }
      }
      return A($, this.toBBox), $;
    }, y.prototype._chooseSubtree = function(M, V, G, X) {
      for (; X.push(V), !V.leaf && X.length - 1 !== G; ) {
        for (var $ = 1 / 0, K = 1 / 0, J = void 0, ie = 0; ie < V.children.length; ie++) {
          var re = V.children[ie], ne = D(re), ce = (ge = M, ue = re, (Math.max(ue.maxX, ge.maxX) - Math.min(ue.minX, ge.minX)) * (Math.max(ue.maxY, ge.maxY) - Math.min(ue.minY, ge.minY)) - ne);
          ce < K ? (K = ce, $ = ne < $ ? ne : $, J = re) : ce === K && ne < $ && ($ = ne, J = re);
        }
        V = J || V.children[0];
      }
      var ge, ue;
      return V;
    }, y.prototype._insert = function(M, V, G) {
      var X = G ? M : this.toBBox(M), $ = [], K = this._chooseSubtree(X, this.data, V, $);
      for (K.children.push(M), z(K, X); V >= 0 && $[V].children.length > this._maxEntries; )
        this._split($, V), V--;
      this._adjustParentBBoxes(X, $, V);
    }, y.prototype._split = function(M, V) {
      var G = M[V], X = G.children.length, $ = this._minEntries;
      this._chooseSplitAxis(G, $, X);
      var K = this._chooseSplitIndex(G, $, X), J = ee(G.children.splice(K, G.children.length - K));
      J.height = G.height, J.leaf = G.leaf, A(G, this.toBBox), A(J, this.toBBox), V ? M[V - 1].children.push(J) : this._splitRoot(G, J);
    }, y.prototype._splitRoot = function(M, V) {
      this.data = ee([M, V]), this.data.height = M.height + 1, this.data.leaf = !1, A(this.data, this.toBBox);
    }, y.prototype._chooseSplitIndex = function(M, V, G) {
      for (var X, $, K, J, ie, re, ne, ce = 1 / 0, ge = 1 / 0, ue = V; ue <= G - V; ue++) {
        var Le = T(M, 0, ue, this.toBBox), ke = T(M, ue, G, this.toBBox), Ae = ($ = Le, K = ke, J = void 0, ie = void 0, re = void 0, ne = void 0, J = Math.max($.minX, K.minX), ie = Math.max($.minY, K.minY), re = Math.min($.maxX, K.maxX), ne = Math.min($.maxY, K.maxY), Math.max(0, re - J) * Math.max(0, ne - ie)), Me = D(Le) + D(ke);
        Ae < ce ? (ce = Ae, X = ue, ge = Me < ge ? Me : ge) : Ae === ce && Me < ge && (ge = Me, X = ue);
      }
      return X || G - V;
    }, y.prototype._chooseSplitAxis = function(M, V, G) {
      var X = M.leaf ? this.compareMinX : H, $ = M.leaf ? this.compareMinY : F;
      this._allDistMargin(M, V, G, X) < this._allDistMargin(M, V, G, $) && M.children.sort(X);
    }, y.prototype._allDistMargin = function(M, V, G, X) {
      M.children.sort(X);
      for (var $ = this.toBBox, K = T(M, 0, V, $), J = T(M, G - V, G, $), ie = W(K) + W(J), re = V; re < G - V; re++) {
        var ne = M.children[re];
        z(K, M.leaf ? $(ne) : ne), ie += W(K);
      }
      for (var ce = G - V - 1; ce >= V; ce--) {
        var ge = M.children[ce];
        z(J, M.leaf ? $(ge) : ge), ie += W(J);
      }
      return ie;
    }, y.prototype._adjustParentBBoxes = function(M, V, G) {
      for (var X = G; X >= 0; X--)
        z(V[X], M);
    }, y.prototype._condense = function(M) {
      for (var V = M.length - 1, G = void 0; V >= 0; V--)
        M[V].children.length === 0 ? V > 0 ? (G = M[V - 1].children).splice(G.indexOf(M[V]), 1) : this.clear() : A(M[V], this.toBBox);
    }, y;
  });
})(Ba);
var hr = Ba.exports;
class dr {
  constructor(n = [], l = ur) {
    if (this.data = n, this.length = this.data.length, this.compare = l, this.length > 0)
      for (let u = (this.length >> 1) - 1; u >= 0; u--)
        this._down(u);
  }
  push(n) {
    this.data.push(n), this.length++, this._up(this.length - 1);
  }
  pop() {
    if (this.length === 0)
      return;
    const n = this.data[0], l = this.data.pop();
    return this.length--, this.length > 0 && (this.data[0] = l, this._down(0)), n;
  }
  peek() {
    return this.data[0];
  }
  _up(n) {
    const { data: l, compare: u } = this, b = l[n];
    for (; n > 0; ) {
      const y = n - 1 >> 1, I = l[y];
      if (u(b, I) >= 0)
        break;
      l[n] = I, n = y;
    }
    l[n] = b;
  }
  _down(n) {
    const { data: l, compare: u } = this, b = this.length >> 1, y = l[n];
    for (; n < b; ) {
      let I = (n << 1) + 1, A = l[I];
      const T = I + 1;
      if (T < this.length && u(l[T], A) < 0 && (I = T, A = l[T]), u(A, y) >= 0)
        break;
      l[n] = A, n = I;
    }
    l[n] = y;
  }
}
function ur(v, n) {
  return v < n ? -1 : v > n ? 1 : 0;
}
const gr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: dr
}, Symbol.toStringTag, { value: "Module" })), fr = /* @__PURE__ */ cr(gr);
var Qt = { exports: {} }, pr = function(n, l, u, b) {
  var y = n[0], I = n[1], A = !1;
  u === void 0 && (u = 0), b === void 0 && (b = l.length);
  for (var T = (b - u) / 2, z = 0, H = T - 1; z < T; H = z++) {
    var F = l[u + z * 2 + 0], D = l[u + z * 2 + 1], W = l[u + H * 2 + 0], B = l[u + H * 2 + 1], j = D > I != B > I && y < (W - F) * (I - D) / (B - D) + F;
    j && (A = !A);
  }
  return A;
}, xr = function(n, l, u, b) {
  var y = n[0], I = n[1], A = !1;
  u === void 0 && (u = 0), b === void 0 && (b = l.length);
  for (var T = b - u, z = 0, H = T - 1; z < T; H = z++) {
    var F = l[z + u][0], D = l[z + u][1], W = l[H + u][0], B = l[H + u][1], j = D > I != B > I && y < (W - F) * (I - D) / (B - D) + F;
    j && (A = !A);
  }
  return A;
}, Wa = pr, Va = xr;
Qt.exports = function(n, l, u, b) {
  return l.length > 0 && Array.isArray(l[0]) ? Va(n, l, u, b) : Wa(n, l, u, b);
};
Qt.exports.nested = Va;
Qt.exports.flat = Wa;
var mr = Qt.exports, mi = { exports: {} };
(function(v, n) {
  (function(l, u) {
    u(n);
  })(Kt, function(l) {
    const b = 33306690738754706e-32;
    function y(j, ee, te, M, V) {
      let G, X, $, K, J = ee[0], ie = M[0], re = 0, ne = 0;
      ie > J == ie > -J ? (G = J, J = ee[++re]) : (G = ie, ie = M[++ne]);
      let ce = 0;
      if (re < j && ne < te)
        for (ie > J == ie > -J ? ($ = G - ((X = J + G) - J), J = ee[++re]) : ($ = G - ((X = ie + G) - ie), ie = M[++ne]), G = X, $ !== 0 && (V[ce++] = $); re < j && ne < te; )
          ie > J == ie > -J ? ($ = G - ((X = G + J) - (K = X - G)) + (J - K), J = ee[++re]) : ($ = G - ((X = G + ie) - (K = X - G)) + (ie - K), ie = M[++ne]), G = X, $ !== 0 && (V[ce++] = $);
      for (; re < j; )
        $ = G - ((X = G + J) - (K = X - G)) + (J - K), J = ee[++re], G = X, $ !== 0 && (V[ce++] = $);
      for (; ne < te; )
        $ = G - ((X = G + ie) - (K = X - G)) + (ie - K), ie = M[++ne], G = X, $ !== 0 && (V[ce++] = $);
      return G === 0 && ce !== 0 || (V[ce++] = G), ce;
    }
    function I(j) {
      return new Float64Array(j);
    }
    const A = 33306690738754716e-32, T = 22204460492503146e-32, z = 11093356479670487e-47, H = I(4), F = I(8), D = I(12), W = I(16), B = I(4);
    l.orient2d = function(j, ee, te, M, V, G) {
      const X = (ee - G) * (te - V), $ = (j - V) * (M - G), K = X - $;
      if (X === 0 || $ === 0 || X > 0 != $ > 0)
        return K;
      const J = Math.abs(X + $);
      return Math.abs(K) >= A * J ? K : -function(ie, re, ne, ce, ge, ue, Le) {
        let ke, Ae, Me, Te, oe, Q, ae, le, pe, xe, de, ve, ye, Se, Ee, Re, ze, De;
        const _e = ie - ge, He = ne - ge, Be = re - ue, Xe = ce - ue;
        oe = (Ee = (le = _e - (ae = (Q = 134217729 * _e) - (Q - _e))) * (xe = Xe - (pe = (Q = 134217729 * Xe) - (Q - Xe))) - ((Se = _e * Xe) - ae * pe - le * pe - ae * xe)) - (de = Ee - (ze = (le = Be - (ae = (Q = 134217729 * Be) - (Q - Be))) * (xe = He - (pe = (Q = 134217729 * He) - (Q - He))) - ((Re = Be * He) - ae * pe - le * pe - ae * xe))), H[0] = Ee - (de + oe) + (oe - ze), oe = (ye = Se - ((ve = Se + de) - (oe = ve - Se)) + (de - oe)) - (de = ye - Re), H[1] = ye - (de + oe) + (oe - Re), oe = (De = ve + de) - ve, H[2] = ve - (De - oe) + (de - oe), H[3] = De;
        let Ye = function(ei, Ft) {
          let Dt = Ft[0];
          for (let st = 1; st < ei; st++)
            Dt += Ft[st];
          return Dt;
        }(4, H), We = T * Le;
        if (Ye >= We || -Ye >= We || (ke = ie - (_e + (oe = ie - _e)) + (oe - ge), Me = ne - (He + (oe = ne - He)) + (oe - ge), Ae = re - (Be + (oe = re - Be)) + (oe - ue), Te = ce - (Xe + (oe = ce - Xe)) + (oe - ue), ke === 0 && Ae === 0 && Me === 0 && Te === 0) || (We = z * Le + b * Math.abs(Ye), (Ye += _e * Te + Xe * ke - (Be * Me + He * Ae)) >= We || -Ye >= We))
          return Ye;
        oe = (Ee = (le = ke - (ae = (Q = 134217729 * ke) - (Q - ke))) * (xe = Xe - (pe = (Q = 134217729 * Xe) - (Q - Xe))) - ((Se = ke * Xe) - ae * pe - le * pe - ae * xe)) - (de = Ee - (ze = (le = Ae - (ae = (Q = 134217729 * Ae) - (Q - Ae))) * (xe = He - (pe = (Q = 134217729 * He) - (Q - He))) - ((Re = Ae * He) - ae * pe - le * pe - ae * xe))), B[0] = Ee - (de + oe) + (oe - ze), oe = (ye = Se - ((ve = Se + de) - (oe = ve - Se)) + (de - oe)) - (de = ye - Re), B[1] = ye - (de + oe) + (oe - Re), oe = (De = ve + de) - ve, B[2] = ve - (De - oe) + (de - oe), B[3] = De;
        const tt = y(4, H, 4, B, F);
        oe = (Ee = (le = _e - (ae = (Q = 134217729 * _e) - (Q - _e))) * (xe = Te - (pe = (Q = 134217729 * Te) - (Q - Te))) - ((Se = _e * Te) - ae * pe - le * pe - ae * xe)) - (de = Ee - (ze = (le = Be - (ae = (Q = 134217729 * Be) - (Q - Be))) * (xe = Me - (pe = (Q = 134217729 * Me) - (Q - Me))) - ((Re = Be * Me) - ae * pe - le * pe - ae * xe))), B[0] = Ee - (de + oe) + (oe - ze), oe = (ye = Se - ((ve = Se + de) - (oe = ve - Se)) + (de - oe)) - (de = ye - Re), B[1] = ye - (de + oe) + (oe - Re), oe = (De = ve + de) - ve, B[2] = ve - (De - oe) + (de - oe), B[3] = De;
        const Ge = y(tt, F, 4, B, D);
        oe = (Ee = (le = ke - (ae = (Q = 134217729 * ke) - (Q - ke))) * (xe = Te - (pe = (Q = 134217729 * Te) - (Q - Te))) - ((Se = ke * Te) - ae * pe - le * pe - ae * xe)) - (de = Ee - (ze = (le = Ae - (ae = (Q = 134217729 * Ae) - (Q - Ae))) * (xe = Me - (pe = (Q = 134217729 * Me) - (Q - Me))) - ((Re = Ae * Me) - ae * pe - le * pe - ae * xe))), B[0] = Ee - (de + oe) + (oe - ze), oe = (ye = Se - ((ve = Se + de) - (oe = ve - Se)) + (de - oe)) - (de = ye - Re), B[1] = ye - (de + oe) + (oe - Re), oe = (De = ve + de) - ve, B[2] = ve - (De - oe) + (de - oe), B[3] = De;
        const at = y(Ge, D, 4, B, W);
        return W[at - 1];
      }(j, ee, te, M, V, G, J);
    }, l.orient2dfast = function(j, ee, te, M, V, G) {
      return (ee - G) * (te - V) - (j - V) * (M - G);
    }, Object.defineProperty(l, "__esModule", { value: !0 });
  });
})(mi, mi.exports);
var vr = mi.exports, Qi = hr, Bt = fr, br = mr, yr = vr.orient2d;
Bt.default && (Bt = Bt.default);
Ti.exports = Ga;
Ti.exports.default = Ga;
function Ga(v, n, l) {
  n = Math.max(0, n === void 0 ? 2 : n), l = l || 0;
  var u = Ar(v), b = new Qi(16);
  b.toBBox = function(M) {
    return {
      minX: M[0],
      minY: M[1],
      maxX: M[0],
      maxY: M[1]
    };
  }, b.compareMinX = function(M, V) {
    return M[0] - V[0];
  }, b.compareMinY = function(M, V) {
    return M[1] - V[1];
  }, b.load(v);
  for (var y = [], I = 0, A; I < u.length; I++) {
    var T = u[I];
    b.remove(T), A = ia(T, A), y.push(A);
  }
  var z = new Qi(16);
  for (I = 0; I < y.length; I++)
    z.insert(oi(y[I]));
  for (var H = n * n, F = l * l; y.length; ) {
    var D = y.shift(), W = D.p, B = D.next.p, j = li(W, B);
    if (!(j < F)) {
      var ee = j / H;
      T = wr(b, D.prev.p, W, B, D.next.next.p, ee, z), T && Math.min(li(T, W), li(T, B)) <= ee && (y.push(D), y.push(ia(T, D)), b.remove(T), z.remove(D), z.insert(oi(D)), z.insert(oi(D.next)));
    }
  }
  D = A;
  var te = [];
  do
    te.push(D.p), D = D.next;
  while (D !== A);
  return te.push(D.p), te;
}
function wr(v, n, l, u, b, y, I) {
  for (var A = new Bt([], Sr), T = v.data; T; ) {
    for (var z = 0; z < T.children.length; z++) {
      var H = T.children[z], F = T.leaf ? ci(H, l, u) : Cr(l, u, H);
      F > y || A.push({
        node: H,
        dist: F
      });
    }
    for (; A.length && !A.peek().node.children; ) {
      var D = A.pop(), W = D.node, B = ci(W, n, l), j = ci(W, u, b);
      if (D.dist < B && D.dist < j && ta(l, W, I) && ta(u, W, I))
        return W;
    }
    T = A.pop(), T && (T = T.node);
  }
  return null;
}
function Sr(v, n) {
  return v.dist - n.dist;
}
function Cr(v, n, l) {
  if (ea(v, l) || ea(n, l))
    return 0;
  var u = Nt(v[0], v[1], n[0], n[1], l.minX, l.minY, l.maxX, l.minY);
  if (u === 0)
    return 0;
  var b = Nt(v[0], v[1], n[0], n[1], l.minX, l.minY, l.minX, l.maxY);
  if (b === 0)
    return 0;
  var y = Nt(v[0], v[1], n[0], n[1], l.maxX, l.minY, l.maxX, l.maxY);
  if (y === 0)
    return 0;
  var I = Nt(v[0], v[1], n[0], n[1], l.minX, l.maxY, l.maxX, l.maxY);
  return I === 0 ? 0 : Math.min(u, b, y, I);
}
function ea(v, n) {
  return v[0] >= n.minX && v[0] <= n.maxX && v[1] >= n.minY && v[1] <= n.maxY;
}
function ta(v, n, l) {
  for (var u = Math.min(v[0], n[0]), b = Math.min(v[1], n[1]), y = Math.max(v[0], n[0]), I = Math.max(v[1], n[1]), A = l.search({ minX: u, minY: b, maxX: y, maxY: I }), T = 0; T < A.length; T++)
    if (kr(A[T].p, A[T].next.p, v, n))
      return !1;
  return !0;
}
function St(v, n, l) {
  return yr(v[0], v[1], n[0], n[1], l[0], l[1]);
}
function kr(v, n, l, u) {
  return v !== u && n !== l && St(v, n, l) > 0 != St(v, n, u) > 0 && St(l, u, v) > 0 != St(l, u, n) > 0;
}
function oi(v) {
  var n = v.p, l = v.next.p;
  return v.minX = Math.min(n[0], l[0]), v.minY = Math.min(n[1], l[1]), v.maxX = Math.max(n[0], l[0]), v.maxY = Math.max(n[1], l[1]), v;
}
function Ar(v) {
  for (var n = v[0], l = v[0], u = v[0], b = v[0], y = 0; y < v.length; y++) {
    var I = v[y];
    I[0] < n[0] && (n = I), I[0] > u[0] && (u = I), I[1] < l[1] && (l = I), I[1] > b[1] && (b = I);
  }
  var A = [n, l, u, b], T = A.slice();
  for (y = 0; y < v.length; y++)
    br(v[y], A) || T.push(v[y]);
  return Lr(T);
}
function ia(v, n) {
  var l = {
    p: v,
    prev: null,
    next: null,
    minX: 0,
    minY: 0,
    maxX: 0,
    maxY: 0
  };
  return n ? (l.next = n.next, l.prev = n, n.next.prev = l, n.next = l) : (l.prev = l, l.next = l), l;
}
function li(v, n) {
  var l = v[0] - n[0], u = v[1] - n[1];
  return l * l + u * u;
}
function ci(v, n, l) {
  var u = n[0], b = n[1], y = l[0] - u, I = l[1] - b;
  if (y !== 0 || I !== 0) {
    var A = ((v[0] - u) * y + (v[1] - b) * I) / (y * y + I * I);
    A > 1 ? (u = l[0], b = l[1]) : A > 0 && (u += y * A, b += I * A);
  }
  return y = v[0] - u, I = v[1] - b, y * y + I * I;
}
function Nt(v, n, l, u, b, y, I, A) {
  var T = l - v, z = u - n, H = I - b, F = A - y, D = v - b, W = n - y, B = T * T + z * z, j = T * H + z * F, ee = H * H + F * F, te = T * D + z * W, M = H * D + F * W, V = B * ee - j * j, G, X, $, K, J = V, ie = V;
  V === 0 ? (X = 0, J = 1, K = M, ie = ee) : (X = j * M - ee * te, K = B * M - j * te, X < 0 ? (X = 0, K = M, ie = ee) : X > J && (X = J, K = M + j, ie = ee)), K < 0 ? (K = 0, -te < 0 ? X = 0 : -te > B ? X = J : (X = -te, J = B)) : K > ie && (K = ie, -te + j < 0 ? X = 0 : -te + j > B ? X = J : (X = -te + j, J = B)), G = X === 0 ? 0 : X / J, $ = K === 0 ? 0 : K / ie;
  var re = (1 - G) * v + G * l, ne = (1 - G) * n + G * u, ce = (1 - $) * b + $ * I, ge = (1 - $) * y + $ * A, ue = ce - re, Le = ge - ne;
  return ue * ue + Le * Le;
}
function Pr(v, n) {
  return v[0] === n[0] ? v[1] - n[1] : v[0] - n[0];
}
function Lr(v) {
  v.sort(Pr);
  for (var n = [], l = 0; l < v.length; l++) {
    for (; n.length >= 2 && St(n[n.length - 2], n[n.length - 1], v[l]) <= 0; )
      n.pop();
    n.push(v[l]);
  }
  for (var u = [], b = v.length - 1; b >= 0; b--) {
    for (; u.length >= 2 && St(u[u.length - 2], u[u.length - 1], v[b]) <= 0; )
      u.pop();
    u.push(v[b]);
  }
  return u.pop(), n.pop(), n.concat(u);
}
var Mr = Ti.exports;
const Er = /* @__PURE__ */ Ii(Mr);
function Ir(v, n) {
  n === void 0 && (n = {}), n.concavity = n.concavity || 1 / 0;
  var l = [];
  if (Jt(v, function(b) {
    l.push([b[0], b[1]]);
  }), !l.length)
    return null;
  var u = Er(l, n.concavity);
  return u.length > 3 ? Lt([u]) : null;
}
function Tr(v, n, l) {
  if (l === void 0 && (l = {}), !v)
    throw new Error("point is required");
  if (!n)
    throw new Error("polygon is required");
  var u = jt(v), b = xi(n), y = b.type, I = n.bbox, A = b.coordinates;
  if (I && Rr(u, I) === !1)
    return !1;
  y === "Polygon" && (A = [A]);
  for (var T = !1, z = 0; z < A.length && !T; z++)
    if (aa(u, A[z][0], l.ignoreBoundary)) {
      for (var H = !1, F = 1; F < A[z].length && !H; )
        aa(u, A[z][F], !l.ignoreBoundary) && (H = !0), F++;
      H || (T = !0);
    }
  return T;
}
function aa(v, n, l) {
  var u = !1;
  n[0][0] === n[n.length - 1][0] && n[0][1] === n[n.length - 1][1] && (n = n.slice(0, n.length - 1));
  for (var b = 0, y = n.length - 1; b < n.length; y = b++) {
    var I = n[b][0], A = n[b][1], T = n[y][0], z = n[y][1], H = v[1] * (I - T) + A * (T - v[0]) + z * (v[0] - I) === 0 && (I - v[0]) * (T - v[0]) <= 0 && (A - v[1]) * (z - v[1]) <= 0;
    if (H)
      return !l;
    var F = A > v[1] != z > v[1] && v[0] < (T - I) * (v[1] - A) / (z - A) + I;
    F && (u = !u);
  }
  return u;
}
function Rr(v, n) {
  return n[0] <= v[0] && n[1] <= v[1] && n[2] >= v[0] && n[3] >= v[1];
}
function sa(v, n, l) {
  l === void 0 && (l = {});
  var u = jt(v), b = jt(n), y = Yt(b[1] - u[1]), I = Yt(b[0] - u[0]), A = Yt(u[1]), T = Yt(b[1]), z = Math.pow(Math.sin(y / 2), 2) + Math.pow(Math.sin(I / 2), 2) * Math.cos(A) * Math.cos(T);
  return rr(2 * Math.atan2(Math.sqrt(z), Math.sqrt(1 - z)), l.units);
}
function ra(v, n) {
  n === void 0 && (n = {});
  var l = 0, u = 0, b = 0;
  return Jt(v, function(y) {
    l += y[0], u += y[1], b++;
  }, !0), pi([l / b, u / b], n.properties);
}
function ja(v, n) {
  switch (n === void 0 && (n = {}), lr(v)) {
    case "Point":
      return pi(jt(v), n.properties);
    case "Polygon":
      var l = [];
      Jt(v, function(G) {
        l.push(G);
      });
      var u = ra(v, { properties: n.properties }), b = u.geometry.coordinates, y = 0, I = 0, A = 0, T, z, H, F, D, W, B, j, ee = l.map(function(G) {
        return [G[0] - b[0], G[1] - b[1]];
      });
      for (T = 0; T < l.length - 1; T++)
        z = ee[T], F = z[0], W = z[1], H = ee[T + 1], D = H[0], B = H[1], j = F * B - D * W, A += j, y += (F + D) * j, I += (W + B) * j;
      if (A === 0)
        return u;
      var te = A * 0.5, M = 1 / (6 * te);
      return pi([b[0] + M * y, b[1] + M * I], n.properties);
    default:
      var V = Ir(v);
      return V ? ja(V, { properties: n.properties }) : ra(v, { properties: n.properties });
  }
}
var na = 6378137;
function _r(v) {
  return or(v, function(n, l) {
    return n + Or(l);
  }, 0);
}
function Or(v) {
  var n = 0, l;
  switch (v.type) {
    case "Polygon":
      return oa(v.coordinates);
    case "MultiPolygon":
      for (l = 0; l < v.coordinates.length; l++)
        n += oa(v.coordinates[l]);
      return n;
    case "Point":
    case "MultiPoint":
    case "LineString":
    case "MultiLineString":
      return 0;
  }
  return 0;
}
function oa(v) {
  var n = 0;
  if (v && v.length > 0) {
    n += Math.abs(la(v[0]));
    for (var l = 1; l < v.length; l++)
      n -= Math.abs(la(v[l]));
  }
  return n;
}
function la(v) {
  var n, l, u, b, y, I, A, T = 0, z = v.length;
  if (z > 2) {
    for (A = 0; A < z; A++)
      A === z - 2 ? (b = z - 2, y = z - 1, I = 0) : A === z - 1 ? (b = z - 1, y = 0, I = 1) : (b = A, y = A + 1, I = A + 2), n = v[b], l = v[y], u = v[I], T += (hi(u[0]) - hi(n[0])) * Math.sin(hi(l[1]));
    T = T * na * na / 2;
  }
  return T;
}
function hi(v) {
  return v * Math.PI / 180;
}
/**
 * splaytree v3.1.2
 * Fast Splay tree for Node and browser
 *
 * @author Alexander Milevski <info@w8r.name>
 * @license MIT
 * @preserve
 */
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
function zr(v, n) {
  var l = { label: 0, sent: function() {
    if (y[0] & 1)
      throw y[1];
    return y[1];
  }, trys: [], ops: [] }, u, b, y, I;
  return I = { next: A(0), throw: A(1), return: A(2) }, typeof Symbol == "function" && (I[Symbol.iterator] = function() {
    return this;
  }), I;
  function A(z) {
    return function(H) {
      return T([z, H]);
    };
  }
  function T(z) {
    if (u)
      throw new TypeError("Generator is already executing.");
    for (; l; )
      try {
        if (u = 1, b && (y = z[0] & 2 ? b.return : z[0] ? b.throw || ((y = b.return) && y.call(b), 0) : b.next) && !(y = y.call(b, z[1])).done)
          return y;
        switch (b = 0, y && (z = [z[0] & 2, y.value]), z[0]) {
          case 0:
          case 1:
            y = z;
            break;
          case 4:
            return l.label++, { value: z[1], done: !1 };
          case 5:
            l.label++, b = z[1], z = [0];
            continue;
          case 7:
            z = l.ops.pop(), l.trys.pop();
            continue;
          default:
            if (y = l.trys, !(y = y.length > 0 && y[y.length - 1]) && (z[0] === 6 || z[0] === 2)) {
              l = 0;
              continue;
            }
            if (z[0] === 3 && (!y || z[1] > y[0] && z[1] < y[3])) {
              l.label = z[1];
              break;
            }
            if (z[0] === 6 && l.label < y[1]) {
              l.label = y[1], y = z;
              break;
            }
            if (y && l.label < y[2]) {
              l.label = y[2], l.ops.push(z);
              break;
            }
            y[2] && l.ops.pop(), l.trys.pop();
            continue;
        }
        z = n.call(v, l);
      } catch (H) {
        z = [6, H], b = 0;
      } finally {
        u = y = 0;
      }
    if (z[0] & 5)
      throw z[1];
    return { value: z[0] ? z[1] : void 0, done: !0 };
  }
}
var ct = (
  /** @class */
  function() {
    function v(n, l) {
      this.next = null, this.key = n, this.data = l, this.left = null, this.right = null;
    }
    return v;
  }()
);
function Fr(v, n) {
  return v > n ? 1 : v < n ? -1 : 0;
}
function rt(v, n, l) {
  for (var u = new ct(null, null), b = u, y = u; ; ) {
    var I = l(v, n.key);
    if (I < 0) {
      if (n.left === null)
        break;
      if (l(v, n.left.key) < 0) {
        var A = n.left;
        if (n.left = A.right, A.right = n, n = A, n.left === null)
          break;
      }
      y.left = n, y = n, n = n.left;
    } else if (I > 0) {
      if (n.right === null)
        break;
      if (l(v, n.right.key) > 0) {
        var A = n.right;
        if (n.right = A.left, A.left = n, n = A, n.right === null)
          break;
      }
      b.right = n, b = n, n = n.right;
    } else
      break;
  }
  return b.right = n.left, y.left = n.right, n.left = u.right, n.right = u.left, n;
}
function di(v, n, l, u) {
  var b = new ct(v, n);
  if (l === null)
    return b.left = b.right = null, b;
  l = rt(v, l, u);
  var y = u(v, l.key);
  return y < 0 ? (b.left = l.left, b.right = l, l.left = null) : y >= 0 && (b.right = l.right, b.left = l, l.right = null), b;
}
function ca(v, n, l) {
  var u = null, b = null;
  if (n) {
    n = rt(v, n, l);
    var y = l(n.key, v);
    y === 0 ? (u = n.left, b = n.right) : y < 0 ? (b = n.right, n.right = null, u = n) : (u = n.left, n.left = null, b = n);
  }
  return { left: u, right: b };
}
function Dr(v, n, l) {
  return n === null ? v : (v === null || (n = rt(v.key, n, l), n.left = v), n);
}
function vi(v, n, l, u, b) {
  if (v) {
    u("" + n + (l ? "└── " : "├── ") + b(v) + `
`);
    var y = n + (l ? "    " : "│   ");
    v.left && vi(v.left, y, !1, u, b), v.right && vi(v.right, y, !0, u, b);
  }
}
var Ri = (
  /** @class */
  function() {
    function v(n) {
      n === void 0 && (n = Fr), this._root = null, this._size = 0, this._comparator = n;
    }
    return v.prototype.insert = function(n, l) {
      return this._size++, this._root = di(n, l, this._root, this._comparator);
    }, v.prototype.add = function(n, l) {
      var u = new ct(n, l);
      this._root === null && (u.left = u.right = null, this._size++, this._root = u);
      var b = this._comparator, y = rt(n, this._root, b), I = b(n, y.key);
      return I === 0 ? this._root = y : (I < 0 ? (u.left = y.left, u.right = y, y.left = null) : I > 0 && (u.right = y.right, u.left = y, y.right = null), this._size++, this._root = u), this._root;
    }, v.prototype.remove = function(n) {
      this._root = this._remove(n, this._root, this._comparator);
    }, v.prototype._remove = function(n, l, u) {
      var b;
      if (l === null)
        return null;
      l = rt(n, l, u);
      var y = u(n, l.key);
      return y === 0 ? (l.left === null ? b = l.right : (b = rt(n, l.left, u), b.right = l.right), this._size--, b) : l;
    }, v.prototype.pop = function() {
      var n = this._root;
      if (n) {
        for (; n.left; )
          n = n.left;
        return this._root = rt(n.key, this._root, this._comparator), this._root = this._remove(n.key, this._root, this._comparator), { key: n.key, data: n.data };
      }
      return null;
    }, v.prototype.findStatic = function(n) {
      for (var l = this._root, u = this._comparator; l; ) {
        var b = u(n, l.key);
        if (b === 0)
          return l;
        b < 0 ? l = l.left : l = l.right;
      }
      return null;
    }, v.prototype.find = function(n) {
      return this._root && (this._root = rt(n, this._root, this._comparator), this._comparator(n, this._root.key) !== 0) ? null : this._root;
    }, v.prototype.contains = function(n) {
      for (var l = this._root, u = this._comparator; l; ) {
        var b = u(n, l.key);
        if (b === 0)
          return !0;
        b < 0 ? l = l.left : l = l.right;
      }
      return !1;
    }, v.prototype.forEach = function(n, l) {
      for (var u = this._root, b = [], y = !1; !y; )
        u !== null ? (b.push(u), u = u.left) : b.length !== 0 ? (u = b.pop(), n.call(l, u), u = u.right) : y = !0;
      return this;
    }, v.prototype.range = function(n, l, u, b) {
      for (var y = [], I = this._comparator, A = this._root, T; y.length !== 0 || A; )
        if (A)
          y.push(A), A = A.left;
        else {
          if (A = y.pop(), T = I(A.key, l), T > 0)
            break;
          if (I(A.key, n) >= 0 && u.call(b, A))
            return this;
          A = A.right;
        }
      return this;
    }, v.prototype.keys = function() {
      var n = [];
      return this.forEach(function(l) {
        var u = l.key;
        return n.push(u);
      }), n;
    }, v.prototype.values = function() {
      var n = [];
      return this.forEach(function(l) {
        var u = l.data;
        return n.push(u);
      }), n;
    }, v.prototype.min = function() {
      return this._root ? this.minNode(this._root).key : null;
    }, v.prototype.max = function() {
      return this._root ? this.maxNode(this._root).key : null;
    }, v.prototype.minNode = function(n) {
      if (n === void 0 && (n = this._root), n)
        for (; n.left; )
          n = n.left;
      return n;
    }, v.prototype.maxNode = function(n) {
      if (n === void 0 && (n = this._root), n)
        for (; n.right; )
          n = n.right;
      return n;
    }, v.prototype.at = function(n) {
      for (var l = this._root, u = !1, b = 0, y = []; !u; )
        if (l)
          y.push(l), l = l.left;
        else if (y.length > 0) {
          if (l = y.pop(), b === n)
            return l;
          b++, l = l.right;
        } else
          u = !0;
      return null;
    }, v.prototype.next = function(n) {
      var l = this._root, u = null;
      if (n.right) {
        for (u = n.right; u.left; )
          u = u.left;
        return u;
      }
      for (var b = this._comparator; l; ) {
        var y = b(n.key, l.key);
        if (y === 0)
          break;
        y < 0 ? (u = l, l = l.left) : l = l.right;
      }
      return u;
    }, v.prototype.prev = function(n) {
      var l = this._root, u = null;
      if (n.left !== null) {
        for (u = n.left; u.right; )
          u = u.right;
        return u;
      }
      for (var b = this._comparator; l; ) {
        var y = b(n.key, l.key);
        if (y === 0)
          break;
        y < 0 ? l = l.left : (u = l, l = l.right);
      }
      return u;
    }, v.prototype.clear = function() {
      return this._root = null, this._size = 0, this;
    }, v.prototype.toList = function() {
      return Yr(this._root);
    }, v.prototype.load = function(n, l, u) {
      l === void 0 && (l = []), u === void 0 && (u = !1);
      var b = n.length, y = this._comparator;
      if (u && wi(n, l, 0, b - 1, y), this._root === null)
        this._root = bi(n, l, 0, b), this._size = b;
      else {
        var I = Nr(this.toList(), Xr(n, l), y);
        b = this._size + b, this._root = yi({ head: I }, 0, b);
      }
      return this;
    }, v.prototype.isEmpty = function() {
      return this._root === null;
    }, Object.defineProperty(v.prototype, "size", {
      get: function() {
        return this._size;
      },
      enumerable: !0,
      configurable: !0
    }), Object.defineProperty(v.prototype, "root", {
      get: function() {
        return this._root;
      },
      enumerable: !0,
      configurable: !0
    }), v.prototype.toString = function(n) {
      n === void 0 && (n = function(u) {
        return String(u.key);
      });
      var l = [];
      return vi(this._root, "", !0, function(u) {
        return l.push(u);
      }, n), l.join("");
    }, v.prototype.update = function(n, l, u) {
      var b = this._comparator, y = ca(n, this._root, b), I = y.left, A = y.right;
      b(n, l) < 0 ? A = di(l, u, A, b) : I = di(l, u, I, b), this._root = Dr(I, A, b);
    }, v.prototype.split = function(n) {
      return ca(n, this._root, this._comparator);
    }, v.prototype[Symbol.iterator] = function() {
      var n, l, u;
      return zr(this, function(b) {
        switch (b.label) {
          case 0:
            n = this._root, l = [], u = !1, b.label = 1;
          case 1:
            return u ? [3, 6] : n === null ? [3, 2] : (l.push(n), n = n.left, [3, 5]);
          case 2:
            return l.length === 0 ? [3, 4] : (n = l.pop(), [4, n]);
          case 3:
            return b.sent(), n = n.right, [3, 5];
          case 4:
            u = !0, b.label = 5;
          case 5:
            return [3, 1];
          case 6:
            return [
              2
              /*return*/
            ];
        }
      });
    }, v;
  }()
);
function bi(v, n, l, u) {
  var b = u - l;
  if (b > 0) {
    var y = l + Math.floor(b / 2), I = v[y], A = n[y], T = new ct(I, A);
    return T.left = bi(v, n, l, y), T.right = bi(v, n, y + 1, u), T;
  }
  return null;
}
function Xr(v, n) {
  for (var l = new ct(null, null), u = l, b = 0; b < v.length; b++)
    u = u.next = new ct(v[b], n[b]);
  return u.next = null, l.next;
}
function Yr(v) {
  for (var n = v, l = [], u = !1, b = new ct(null, null), y = b; !u; )
    n ? (l.push(n), n = n.left) : l.length > 0 ? (n = y = y.next = l.pop(), n = n.right) : u = !0;
  return y.next = null, b.next;
}
function yi(v, n, l) {
  var u = l - n;
  if (u > 0) {
    var b = n + Math.floor(u / 2), y = yi(v, n, b), I = v.head;
    return I.left = y, v.head = v.head.next, I.right = yi(v, b + 1, l), I;
  }
  return null;
}
function Nr(v, n, l) {
  for (var u = new ct(null, null), b = u, y = v, I = n; y !== null && I !== null; )
    l(y.key, I.key) < 0 ? (b.next = y, y = y.next) : (b.next = I, I = I.next), b = b.next;
  return y !== null ? b.next = y : I !== null && (b.next = I), u.next;
}
function wi(v, n, l, u, b) {
  if (!(l >= u)) {
    for (var y = v[l + u >> 1], I = l - 1, A = u + 1; ; ) {
      do
        I++;
      while (b(v[I], y) < 0);
      do
        A--;
      while (b(v[A], y) > 0);
      if (I >= A)
        break;
      var T = v[I];
      v[I] = v[A], v[A] = T, T = n[I], n[I] = n[A], n[A] = T;
    }
    wi(v, n, l, A, b), wi(v, n, A + 1, u, b);
  }
}
const it = 11102230246251565e-32, $e = 134217729, Hr = (3 + 8 * it) * it;
function ui(v, n, l, u, b) {
  let y, I, A, T, z = n[0], H = u[0], F = 0, D = 0;
  H > z == H > -z ? (y = z, z = n[++F]) : (y = H, H = u[++D]);
  let W = 0;
  if (F < v && D < l)
    for (H > z == H > -z ? (I = z + y, A = y - (I - z), z = n[++F]) : (I = H + y, A = y - (I - H), H = u[++D]), y = I, A !== 0 && (b[W++] = A); F < v && D < l; )
      H > z == H > -z ? (I = y + z, T = I - y, A = y - (I - T) + (z - T), z = n[++F]) : (I = y + H, T = I - y, A = y - (I - T) + (H - T), H = u[++D]), y = I, A !== 0 && (b[W++] = A);
  for (; F < v; )
    I = y + z, T = I - y, A = y - (I - T) + (z - T), z = n[++F], y = I, A !== 0 && (b[W++] = A);
  for (; D < l; )
    I = y + H, T = I - y, A = y - (I - T) + (H - T), H = u[++D], y = I, A !== 0 && (b[W++] = A);
  return (y !== 0 || W === 0) && (b[W++] = y), W;
}
function Br(v, n) {
  let l = n[0];
  for (let u = 1; u < v; u++)
    l += n[u];
  return l;
}
function zt(v) {
  return new Float64Array(v);
}
const Wr = (3 + 16 * it) * it, Vr = (2 + 12 * it) * it, Gr = (9 + 64 * it) * it * it, wt = zt(4), ha = zt(8), da = zt(12), ua = zt(16), qe = zt(4);
function jr(v, n, l, u, b, y, I) {
  let A, T, z, H, F, D, W, B, j, ee, te, M, V, G, X, $, K, J;
  const ie = v - b, re = l - b, ne = n - y, ce = u - y;
  G = ie * ce, D = $e * ie, W = D - (D - ie), B = ie - W, D = $e * ce, j = D - (D - ce), ee = ce - j, X = B * ee - (G - W * j - B * j - W * ee), $ = ne * re, D = $e * ne, W = D - (D - ne), B = ne - W, D = $e * re, j = D - (D - re), ee = re - j, K = B * ee - ($ - W * j - B * j - W * ee), te = X - K, F = X - te, wt[0] = X - (te + F) + (F - K), M = G + te, F = M - G, V = G - (M - F) + (te - F), te = V - $, F = V - te, wt[1] = V - (te + F) + (F - $), J = M + te, F = J - M, wt[2] = M - (J - F) + (te - F), wt[3] = J;
  let ge = Br(4, wt), ue = Vr * I;
  if (ge >= ue || -ge >= ue || (F = v - ie, A = v - (ie + F) + (F - b), F = l - re, z = l - (re + F) + (F - b), F = n - ne, T = n - (ne + F) + (F - y), F = u - ce, H = u - (ce + F) + (F - y), A === 0 && T === 0 && z === 0 && H === 0) || (ue = Gr * I + Hr * Math.abs(ge), ge += ie * H + ce * A - (ne * z + re * T), ge >= ue || -ge >= ue))
    return ge;
  G = A * ce, D = $e * A, W = D - (D - A), B = A - W, D = $e * ce, j = D - (D - ce), ee = ce - j, X = B * ee - (G - W * j - B * j - W * ee), $ = T * re, D = $e * T, W = D - (D - T), B = T - W, D = $e * re, j = D - (D - re), ee = re - j, K = B * ee - ($ - W * j - B * j - W * ee), te = X - K, F = X - te, qe[0] = X - (te + F) + (F - K), M = G + te, F = M - G, V = G - (M - F) + (te - F), te = V - $, F = V - te, qe[1] = V - (te + F) + (F - $), J = M + te, F = J - M, qe[2] = M - (J - F) + (te - F), qe[3] = J;
  const Le = ui(4, wt, 4, qe, ha);
  G = ie * H, D = $e * ie, W = D - (D - ie), B = ie - W, D = $e * H, j = D - (D - H), ee = H - j, X = B * ee - (G - W * j - B * j - W * ee), $ = ne * z, D = $e * ne, W = D - (D - ne), B = ne - W, D = $e * z, j = D - (D - z), ee = z - j, K = B * ee - ($ - W * j - B * j - W * ee), te = X - K, F = X - te, qe[0] = X - (te + F) + (F - K), M = G + te, F = M - G, V = G - (M - F) + (te - F), te = V - $, F = V - te, qe[1] = V - (te + F) + (F - $), J = M + te, F = J - M, qe[2] = M - (J - F) + (te - F), qe[3] = J;
  const ke = ui(Le, ha, 4, qe, da);
  G = A * H, D = $e * A, W = D - (D - A), B = A - W, D = $e * H, j = D - (D - H), ee = H - j, X = B * ee - (G - W * j - B * j - W * ee), $ = T * z, D = $e * T, W = D - (D - T), B = T - W, D = $e * z, j = D - (D - z), ee = z - j, K = B * ee - ($ - W * j - B * j - W * ee), te = X - K, F = X - te, qe[0] = X - (te + F) + (F - K), M = G + te, F = M - G, V = G - (M - F) + (te - F), te = V - $, F = V - te, qe[1] = V - (te + F) + (F - $), J = M + te, F = J - M, qe[2] = M - (J - F) + (te - F), qe[3] = J;
  const Ae = ui(ke, da, 4, qe, ua);
  return ua[Ae - 1];
}
function $r(v, n, l, u, b, y) {
  const I = (n - y) * (l - b), A = (v - b) * (u - y), T = I - A, z = Math.abs(I + A);
  return Math.abs(T) >= Wr * z ? T : -jr(v, n, l, u, b, y, z);
}
const Mt = (v, n) => v.ll.x <= n.x && n.x <= v.ur.x && v.ll.y <= n.y && n.y <= v.ur.y, Si = (v, n) => {
  if (n.ur.x < v.ll.x || v.ur.x < n.ll.x || n.ur.y < v.ll.y || v.ur.y < n.ll.y)
    return null;
  const l = v.ll.x < n.ll.x ? n.ll.x : v.ll.x, u = v.ur.x < n.ur.x ? v.ur.x : n.ur.x, b = v.ll.y < n.ll.y ? n.ll.y : v.ll.y, y = v.ur.y < n.ur.y ? v.ur.y : n.ur.y;
  return {
    ll: {
      x: l,
      y: b
    },
    ur: {
      x: u,
      y
    }
  };
};
let nt = Number.EPSILON;
nt === void 0 && (nt = Math.pow(2, -52));
const qr = nt * nt, ga = (v, n) => {
  if (-nt < v && v < nt && -nt < n && n < nt)
    return 0;
  const l = v - n;
  return l * l < qr * v * n ? 0 : v < n ? -1 : 1;
};
class Ur {
  constructor() {
    this.reset();
  }
  reset() {
    this.xRounder = new fa(), this.yRounder = new fa();
  }
  round(n, l) {
    return {
      x: this.xRounder.round(n),
      y: this.yRounder.round(l)
    };
  }
}
class fa {
  constructor() {
    this.tree = new Ri(), this.round(0);
  }
  // Note: this can rounds input values backwards or forwards.
  //       You might ask, why not restrict this to just rounding
  //       forwards? Wouldn't that allow left endpoints to always
  //       remain left endpoints during splitting (never change to
  //       right). No - it wouldn't, because we snap intersections
  //       to endpoints (to establish independence from the segment
  //       angle for t-intersections).
  round(n) {
    const l = this.tree.add(n), u = this.tree.prev(l);
    if (u !== null && ga(l.key, u.key) === 0)
      return this.tree.remove(n), u.key;
    const b = this.tree.next(l);
    return b !== null && ga(l.key, b.key) === 0 ? (this.tree.remove(n), b.key) : n;
  }
}
const Tt = new Ur(), Wt = (v, n) => v.x * n.y - v.y * n.x, $a = (v, n) => v.x * n.x + v.y * n.y, pa = (v, n, l) => {
  const u = $r(v.x, v.y, n.x, n.y, l.x, l.y);
  return u > 0 ? -1 : u < 0 ? 1 : 0;
}, $t = (v) => Math.sqrt($a(v, v)), Zr = (v, n, l) => {
  const u = {
    x: n.x - v.x,
    y: n.y - v.y
  }, b = {
    x: l.x - v.x,
    y: l.y - v.y
  };
  return Wt(b, u) / $t(b) / $t(u);
}, Jr = (v, n, l) => {
  const u = {
    x: n.x - v.x,
    y: n.y - v.y
  }, b = {
    x: l.x - v.x,
    y: l.y - v.y
  };
  return $a(b, u) / $t(b) / $t(u);
}, xa = (v, n, l) => n.y === 0 ? null : {
  x: v.x + n.x / n.y * (l - v.y),
  y: l
}, ma = (v, n, l) => n.x === 0 ? null : {
  x: l,
  y: v.y + n.y / n.x * (l - v.x)
}, Kr = (v, n, l, u) => {
  if (n.x === 0)
    return ma(l, u, v.x);
  if (u.x === 0)
    return ma(v, n, l.x);
  if (n.y === 0)
    return xa(l, u, v.y);
  if (u.y === 0)
    return xa(v, n, l.y);
  const b = Wt(n, u);
  if (b == 0)
    return null;
  const y = {
    x: l.x - v.x,
    y: l.y - v.y
  }, I = Wt(y, n) / b, A = Wt(y, u) / b, T = v.x + A * n.x, z = l.x + I * u.x, H = v.y + A * n.y, F = l.y + I * u.y, D = (T + z) / 2, W = (H + F) / 2;
  return {
    x: D,
    y: W
  };
};
class Qe {
  // for ordering sweep events in the sweep event queue
  static compare(n, l) {
    const u = Qe.comparePoints(n.point, l.point);
    return u !== 0 ? u : (n.point !== l.point && n.link(l), n.isLeft !== l.isLeft ? n.isLeft ? 1 : -1 : lt.compare(n.segment, l.segment));
  }
  // for ordering points in sweep line order
  static comparePoints(n, l) {
    return n.x < l.x ? -1 : n.x > l.x ? 1 : n.y < l.y ? -1 : n.y > l.y ? 1 : 0;
  }
  // Warning: 'point' input will be modified and re-used (for performance)
  constructor(n, l) {
    n.events === void 0 ? n.events = [this] : n.events.push(this), this.point = n, this.isLeft = l;
  }
  link(n) {
    if (n.point === this.point)
      throw new Error("Tried to link already linked events");
    const l = n.point.events;
    for (let u = 0, b = l.length; u < b; u++) {
      const y = l[u];
      this.point.events.push(y), y.point = this.point;
    }
    this.checkForConsuming();
  }
  /* Do a pass over our linked events and check to see if any pair
   * of segments match, and should be consumed. */
  checkForConsuming() {
    const n = this.point.events.length;
    for (let l = 0; l < n; l++) {
      const u = this.point.events[l];
      if (u.segment.consumedBy === void 0)
        for (let b = l + 1; b < n; b++) {
          const y = this.point.events[b];
          y.consumedBy === void 0 && u.otherSE.point.events === y.otherSE.point.events && u.segment.consume(y.segment);
        }
    }
  }
  getAvailableLinkedEvents() {
    const n = [];
    for (let l = 0, u = this.point.events.length; l < u; l++) {
      const b = this.point.events[l];
      b !== this && !b.segment.ringOut && b.segment.isInResult() && n.push(b);
    }
    return n;
  }
  /**
   * Returns a comparator function for sorting linked events that will
   * favor the event that will give us the smallest left-side angle.
   * All ring construction starts as low as possible heading to the right,
   * so by always turning left as sharp as possible we'll get polygons
   * without uncessary loops & holes.
   *
   * The comparator function has a compute cache such that it avoids
   * re-computing already-computed values.
   */
  getLeftmostComparator(n) {
    const l = /* @__PURE__ */ new Map(), u = (b) => {
      const y = b.otherSE;
      l.set(b, {
        sine: Zr(this.point, n.point, y.point),
        cosine: Jr(this.point, n.point, y.point)
      });
    };
    return (b, y) => {
      l.has(b) || u(b), l.has(y) || u(y);
      const {
        sine: I,
        cosine: A
      } = l.get(b), {
        sine: T,
        cosine: z
      } = l.get(y);
      return I >= 0 && T >= 0 ? A < z ? 1 : A > z ? -1 : 0 : I < 0 && T < 0 ? A < z ? -1 : A > z ? 1 : 0 : T < I ? -1 : T > I ? 1 : 0;
    };
  }
}
let Qr = 0;
class lt {
  /* This compare() function is for ordering segments in the sweep
   * line tree, and does so according to the following criteria:
   *
   * Consider the vertical line that lies an infinestimal step to the
   * right of the right-more of the two left endpoints of the input
   * segments. Imagine slowly moving a point up from negative infinity
   * in the increasing y direction. Which of the two segments will that
   * point intersect first? That segment comes 'before' the other one.
   *
   * If neither segment would be intersected by such a line, (if one
   * or more of the segments are vertical) then the line to be considered
   * is directly on the right-more of the two left inputs.
   */
  static compare(n, l) {
    const u = n.leftSE.point.x, b = l.leftSE.point.x, y = n.rightSE.point.x, I = l.rightSE.point.x;
    if (I < u)
      return 1;
    if (y < b)
      return -1;
    const A = n.leftSE.point.y, T = l.leftSE.point.y, z = n.rightSE.point.y, H = l.rightSE.point.y;
    if (u < b) {
      if (T < A && T < z)
        return 1;
      if (T > A && T > z)
        return -1;
      const F = n.comparePoint(l.leftSE.point);
      if (F < 0)
        return 1;
      if (F > 0)
        return -1;
      const D = l.comparePoint(n.rightSE.point);
      return D !== 0 ? D : -1;
    }
    if (u > b) {
      if (A < T && A < H)
        return -1;
      if (A > T && A > H)
        return 1;
      const F = l.comparePoint(n.leftSE.point);
      if (F !== 0)
        return F;
      const D = n.comparePoint(l.rightSE.point);
      return D < 0 ? 1 : D > 0 ? -1 : 1;
    }
    if (A < T)
      return -1;
    if (A > T)
      return 1;
    if (y < I) {
      const F = l.comparePoint(n.rightSE.point);
      if (F !== 0)
        return F;
    }
    if (y > I) {
      const F = n.comparePoint(l.rightSE.point);
      if (F < 0)
        return 1;
      if (F > 0)
        return -1;
    }
    if (y !== I) {
      const F = z - A, D = y - u, W = H - T, B = I - b;
      if (F > D && W < B)
        return 1;
      if (F < D && W > B)
        return -1;
    }
    return y > I ? 1 : y < I || z < H ? -1 : z > H ? 1 : n.id < l.id ? -1 : n.id > l.id ? 1 : 0;
  }
  /* Warning: a reference to ringWindings input will be stored,
   *  and possibly will be later modified */
  constructor(n, l, u, b) {
    this.id = ++Qr, this.leftSE = n, n.segment = this, n.otherSE = l, this.rightSE = l, l.segment = this, l.otherSE = n, this.rings = u, this.windings = b;
  }
  static fromRing(n, l, u) {
    let b, y, I;
    const A = Qe.comparePoints(n, l);
    if (A < 0)
      b = n, y = l, I = 1;
    else if (A > 0)
      b = l, y = n, I = -1;
    else
      throw new Error(`Tried to create degenerate segment at [${n.x}, ${n.y}]`);
    const T = new Qe(b, !0), z = new Qe(y, !1);
    return new lt(T, z, [u], [I]);
  }
  /* When a segment is split, the rightSE is replaced with a new sweep event */
  replaceRightSE(n) {
    this.rightSE = n, this.rightSE.segment = this, this.rightSE.otherSE = this.leftSE, this.leftSE.otherSE = this.rightSE;
  }
  bbox() {
    const n = this.leftSE.point.y, l = this.rightSE.point.y;
    return {
      ll: {
        x: this.leftSE.point.x,
        y: n < l ? n : l
      },
      ur: {
        x: this.rightSE.point.x,
        y: n > l ? n : l
      }
    };
  }
  /* A vector from the left point to the right */
  vector() {
    return {
      x: this.rightSE.point.x - this.leftSE.point.x,
      y: this.rightSE.point.y - this.leftSE.point.y
    };
  }
  isAnEndpoint(n) {
    return n.x === this.leftSE.point.x && n.y === this.leftSE.point.y || n.x === this.rightSE.point.x && n.y === this.rightSE.point.y;
  }
  /* Compare this segment with a point.
   *
   * A point P is considered to be colinear to a segment if there
   * exists a distance D such that if we travel along the segment
   * from one * endpoint towards the other a distance D, we find
   * ourselves at point P.
   *
   * Return value indicates:
   *
   *   1: point lies above the segment (to the left of vertical)
   *   0: point is colinear to segment
   *  -1: point lies below the segment (to the right of vertical)
   */
  comparePoint(n) {
    if (this.isAnEndpoint(n))
      return 0;
    const l = this.leftSE.point, u = this.rightSE.point, b = this.vector();
    if (l.x === u.x)
      return n.x === l.x ? 0 : n.x < l.x ? 1 : -1;
    const y = (n.y - l.y) / b.y, I = l.x + y * b.x;
    if (n.x === I)
      return 0;
    const A = (n.x - l.x) / b.x, T = l.y + A * b.y;
    return n.y === T ? 0 : n.y < T ? -1 : 1;
  }
  /**
   * Given another segment, returns the first non-trivial intersection
   * between the two segments (in terms of sweep line ordering), if it exists.
   *
   * A 'non-trivial' intersection is one that will cause one or both of the
   * segments to be split(). As such, 'trivial' vs. 'non-trivial' intersection:
   *
   *   * endpoint of segA with endpoint of segB --> trivial
   *   * endpoint of segA with point along segB --> non-trivial
   *   * endpoint of segB with point along segA --> non-trivial
   *   * point along segA with point along segB --> non-trivial
   *
   * If no non-trivial intersection exists, return null
   * Else, return null.
   */
  getIntersection(n) {
    const l = this.bbox(), u = n.bbox(), b = Si(l, u);
    if (b === null)
      return null;
    const y = this.leftSE.point, I = this.rightSE.point, A = n.leftSE.point, T = n.rightSE.point, z = Mt(l, A) && this.comparePoint(A) === 0, H = Mt(u, y) && n.comparePoint(y) === 0, F = Mt(l, T) && this.comparePoint(T) === 0, D = Mt(u, I) && n.comparePoint(I) === 0;
    if (H && z)
      return D && !F ? I : !D && F ? T : null;
    if (H)
      return F && y.x === T.x && y.y === T.y ? null : y;
    if (z)
      return D && I.x === A.x && I.y === A.y ? null : A;
    if (D && F)
      return null;
    if (D)
      return I;
    if (F)
      return T;
    const W = Kr(y, this.vector(), A, n.vector());
    return W === null || !Mt(b, W) ? null : Tt.round(W.x, W.y);
  }
  /**
   * Split the given segment into multiple segments on the given points.
   *  * Each existing segment will retain its leftSE and a new rightSE will be
   *    generated for it.
   *  * A new segment will be generated which will adopt the original segment's
   *    rightSE, and a new leftSE will be generated for it.
   *  * If there are more than two points given to split on, new segments
   *    in the middle will be generated with new leftSE and rightSE's.
   *  * An array of the newly generated SweepEvents will be returned.
   *
   * Warning: input array of points is modified
   */
  split(n) {
    const l = [], u = n.events !== void 0, b = new Qe(n, !0), y = new Qe(n, !1), I = this.rightSE;
    this.replaceRightSE(y), l.push(y), l.push(b);
    const A = new lt(b, I, this.rings.slice(), this.windings.slice());
    return Qe.comparePoints(A.leftSE.point, A.rightSE.point) > 0 && A.swapEvents(), Qe.comparePoints(this.leftSE.point, this.rightSE.point) > 0 && this.swapEvents(), u && (b.checkForConsuming(), y.checkForConsuming()), l;
  }
  /* Swap which event is left and right */
  swapEvents() {
    const n = this.rightSE;
    this.rightSE = this.leftSE, this.leftSE = n, this.leftSE.isLeft = !0, this.rightSE.isLeft = !1;
    for (let l = 0, u = this.windings.length; l < u; l++)
      this.windings[l] *= -1;
  }
  /* Consume another segment. We take their rings under our wing
   * and mark them as consumed. Use for perfectly overlapping segments */
  consume(n) {
    let l = this, u = n;
    for (; l.consumedBy; )
      l = l.consumedBy;
    for (; u.consumedBy; )
      u = u.consumedBy;
    const b = lt.compare(l, u);
    if (b !== 0) {
      if (b > 0) {
        const y = l;
        l = u, u = y;
      }
      if (l.prev === u) {
        const y = l;
        l = u, u = y;
      }
      for (let y = 0, I = u.rings.length; y < I; y++) {
        const A = u.rings[y], T = u.windings[y], z = l.rings.indexOf(A);
        z === -1 ? (l.rings.push(A), l.windings.push(T)) : l.windings[z] += T;
      }
      u.rings = null, u.windings = null, u.consumedBy = l, u.leftSE.consumedBy = l.leftSE, u.rightSE.consumedBy = l.rightSE;
    }
  }
  /* The first segment previous segment chain that is in the result */
  prevInResult() {
    return this._prevInResult !== void 0 ? this._prevInResult : (this.prev ? this.prev.isInResult() ? this._prevInResult = this.prev : this._prevInResult = this.prev.prevInResult() : this._prevInResult = null, this._prevInResult);
  }
  beforeState() {
    if (this._beforeState !== void 0)
      return this._beforeState;
    if (!this.prev)
      this._beforeState = {
        rings: [],
        windings: [],
        multiPolys: []
      };
    else {
      const n = this.prev.consumedBy || this.prev;
      this._beforeState = n.afterState();
    }
    return this._beforeState;
  }
  afterState() {
    if (this._afterState !== void 0)
      return this._afterState;
    const n = this.beforeState();
    this._afterState = {
      rings: n.rings.slice(0),
      windings: n.windings.slice(0),
      multiPolys: []
    };
    const l = this._afterState.rings, u = this._afterState.windings, b = this._afterState.multiPolys;
    for (let A = 0, T = this.rings.length; A < T; A++) {
      const z = this.rings[A], H = this.windings[A], F = l.indexOf(z);
      F === -1 ? (l.push(z), u.push(H)) : u[F] += H;
    }
    const y = [], I = [];
    for (let A = 0, T = l.length; A < T; A++) {
      if (u[A] === 0)
        continue;
      const z = l[A], H = z.poly;
      if (I.indexOf(H) === -1)
        if (z.isExterior)
          y.push(H);
        else {
          I.indexOf(H) === -1 && I.push(H);
          const F = y.indexOf(z.poly);
          F !== -1 && y.splice(F, 1);
        }
    }
    for (let A = 0, T = y.length; A < T; A++) {
      const z = y[A].multiPoly;
      b.indexOf(z) === -1 && b.push(z);
    }
    return this._afterState;
  }
  /* Is this segment part of the final result? */
  isInResult() {
    if (this.consumedBy)
      return !1;
    if (this._isInResult !== void 0)
      return this._isInResult;
    const n = this.beforeState().multiPolys, l = this.afterState().multiPolys;
    switch (et.type) {
      case "union": {
        const u = n.length === 0, b = l.length === 0;
        this._isInResult = u !== b;
        break;
      }
      case "intersection": {
        let u, b;
        n.length < l.length ? (u = n.length, b = l.length) : (u = l.length, b = n.length), this._isInResult = b === et.numMultiPolys && u < b;
        break;
      }
      case "xor": {
        const u = Math.abs(n.length - l.length);
        this._isInResult = u % 2 === 1;
        break;
      }
      case "difference": {
        const u = (b) => b.length === 1 && b[0].isSubject;
        this._isInResult = u(n) !== u(l);
        break;
      }
      default:
        throw new Error(`Unrecognized operation type found ${et.type}`);
    }
    return this._isInResult;
  }
}
class va {
  constructor(n, l, u) {
    if (!Array.isArray(n) || n.length === 0)
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    if (this.poly = l, this.isExterior = u, this.segments = [], typeof n[0][0] != "number" || typeof n[0][1] != "number")
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    const b = Tt.round(n[0][0], n[0][1]);
    this.bbox = {
      ll: {
        x: b.x,
        y: b.y
      },
      ur: {
        x: b.x,
        y: b.y
      }
    };
    let y = b;
    for (let I = 1, A = n.length; I < A; I++) {
      if (typeof n[I][0] != "number" || typeof n[I][1] != "number")
        throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
      let T = Tt.round(n[I][0], n[I][1]);
      T.x === y.x && T.y === y.y || (this.segments.push(lt.fromRing(y, T, this)), T.x < this.bbox.ll.x && (this.bbox.ll.x = T.x), T.y < this.bbox.ll.y && (this.bbox.ll.y = T.y), T.x > this.bbox.ur.x && (this.bbox.ur.x = T.x), T.y > this.bbox.ur.y && (this.bbox.ur.y = T.y), y = T);
    }
    (b.x !== y.x || b.y !== y.y) && this.segments.push(lt.fromRing(y, b, this));
  }
  getSweepEvents() {
    const n = [];
    for (let l = 0, u = this.segments.length; l < u; l++) {
      const b = this.segments[l];
      n.push(b.leftSE), n.push(b.rightSE);
    }
    return n;
  }
}
class en {
  constructor(n, l) {
    if (!Array.isArray(n))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    this.exteriorRing = new va(n[0], this, !0), this.bbox = {
      ll: {
        x: this.exteriorRing.bbox.ll.x,
        y: this.exteriorRing.bbox.ll.y
      },
      ur: {
        x: this.exteriorRing.bbox.ur.x,
        y: this.exteriorRing.bbox.ur.y
      }
    }, this.interiorRings = [];
    for (let u = 1, b = n.length; u < b; u++) {
      const y = new va(n[u], this, !1);
      y.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = y.bbox.ll.x), y.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = y.bbox.ll.y), y.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = y.bbox.ur.x), y.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = y.bbox.ur.y), this.interiorRings.push(y);
    }
    this.multiPoly = l;
  }
  getSweepEvents() {
    const n = this.exteriorRing.getSweepEvents();
    for (let l = 0, u = this.interiorRings.length; l < u; l++) {
      const b = this.interiorRings[l].getSweepEvents();
      for (let y = 0, I = b.length; y < I; y++)
        n.push(b[y]);
    }
    return n;
  }
}
class ba {
  constructor(n, l) {
    if (!Array.isArray(n))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    try {
      typeof n[0][0][0] == "number" && (n = [n]);
    } catch {
    }
    this.polys = [], this.bbox = {
      ll: {
        x: Number.POSITIVE_INFINITY,
        y: Number.POSITIVE_INFINITY
      },
      ur: {
        x: Number.NEGATIVE_INFINITY,
        y: Number.NEGATIVE_INFINITY
      }
    };
    for (let u = 0, b = n.length; u < b; u++) {
      const y = new en(n[u], this);
      y.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = y.bbox.ll.x), y.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = y.bbox.ll.y), y.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = y.bbox.ur.x), y.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = y.bbox.ur.y), this.polys.push(y);
    }
    this.isSubject = l;
  }
  getSweepEvents() {
    const n = [];
    for (let l = 0, u = this.polys.length; l < u; l++) {
      const b = this.polys[l].getSweepEvents();
      for (let y = 0, I = b.length; y < I; y++)
        n.push(b[y]);
    }
    return n;
  }
}
class qt {
  /* Given the segments from the sweep line pass, compute & return a series
   * of closed rings from all the segments marked to be part of the result */
  static factory(n) {
    const l = [];
    for (let u = 0, b = n.length; u < b; u++) {
      const y = n[u];
      if (!y.isInResult() || y.ringOut)
        continue;
      let I = null, A = y.leftSE, T = y.rightSE;
      const z = [A], H = A.point, F = [];
      for (; I = A, A = T, z.push(A), A.point !== H; )
        for (; ; ) {
          const D = A.getAvailableLinkedEvents();
          if (D.length === 0) {
            const j = z[0].point, ee = z[z.length - 1].point;
            throw new Error(`Unable to complete output ring starting at [${j.x}, ${j.y}]. Last matching segment found ends at [${ee.x}, ${ee.y}].`);
          }
          if (D.length === 1) {
            T = D[0].otherSE;
            break;
          }
          let W = null;
          for (let j = 0, ee = F.length; j < ee; j++)
            if (F[j].point === A.point) {
              W = j;
              break;
            }
          if (W !== null) {
            const j = F.splice(W)[0], ee = z.splice(j.index);
            ee.unshift(ee[0].otherSE), l.push(new qt(ee.reverse()));
            continue;
          }
          F.push({
            index: z.length,
            point: A.point
          });
          const B = A.getLeftmostComparator(I);
          T = D.sort(B)[0].otherSE;
          break;
        }
      l.push(new qt(z));
    }
    return l;
  }
  constructor(n) {
    this.events = n;
    for (let l = 0, u = n.length; l < u; l++)
      n[l].segment.ringOut = this;
    this.poly = null;
  }
  getGeom() {
    let n = this.events[0].point;
    const l = [n];
    for (let z = 1, H = this.events.length - 1; z < H; z++) {
      const F = this.events[z].point, D = this.events[z + 1].point;
      pa(F, n, D) !== 0 && (l.push(F), n = F);
    }
    if (l.length === 1)
      return null;
    const u = l[0], b = l[1];
    pa(u, n, b) === 0 && l.shift(), l.push(l[0]);
    const y = this.isExteriorRing() ? 1 : -1, I = this.isExteriorRing() ? 0 : l.length - 1, A = this.isExteriorRing() ? l.length : -1, T = [];
    for (let z = I; z != A; z += y)
      T.push([l[z].x, l[z].y]);
    return T;
  }
  isExteriorRing() {
    if (this._isExteriorRing === void 0) {
      const n = this.enclosingRing();
      this._isExteriorRing = n ? !n.isExteriorRing() : !0;
    }
    return this._isExteriorRing;
  }
  enclosingRing() {
    return this._enclosingRing === void 0 && (this._enclosingRing = this._calcEnclosingRing()), this._enclosingRing;
  }
  /* Returns the ring that encloses this one, if any */
  _calcEnclosingRing() {
    let n = this.events[0];
    for (let b = 1, y = this.events.length; b < y; b++) {
      const I = this.events[b];
      Qe.compare(n, I) > 0 && (n = I);
    }
    let l = n.segment.prevInResult(), u = l ? l.prevInResult() : null;
    for (; ; ) {
      if (!l)
        return null;
      if (!u)
        return l.ringOut;
      if (u.ringOut !== l.ringOut)
        return u.ringOut.enclosingRing() !== l.ringOut ? l.ringOut : l.ringOut.enclosingRing();
      l = u.prevInResult(), u = l ? l.prevInResult() : null;
    }
  }
}
class ya {
  constructor(n) {
    this.exteriorRing = n, n.poly = this, this.interiorRings = [];
  }
  addInterior(n) {
    this.interiorRings.push(n), n.poly = this;
  }
  getGeom() {
    const n = [this.exteriorRing.getGeom()];
    if (n[0] === null)
      return null;
    for (let l = 0, u = this.interiorRings.length; l < u; l++) {
      const b = this.interiorRings[l].getGeom();
      b !== null && n.push(b);
    }
    return n;
  }
}
class tn {
  constructor(n) {
    this.rings = n, this.polys = this._composePolys(n);
  }
  getGeom() {
    const n = [];
    for (let l = 0, u = this.polys.length; l < u; l++) {
      const b = this.polys[l].getGeom();
      b !== null && n.push(b);
    }
    return n;
  }
  _composePolys(n) {
    const l = [];
    for (let u = 0, b = n.length; u < b; u++) {
      const y = n[u];
      if (!y.poly)
        if (y.isExteriorRing())
          l.push(new ya(y));
        else {
          const I = y.enclosingRing();
          I.poly || l.push(new ya(I)), I.poly.addInterior(y);
        }
    }
    return l;
  }
}
class an {
  constructor(n) {
    let l = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : lt.compare;
    this.queue = n, this.tree = new Ri(l), this.segments = [];
  }
  process(n) {
    const l = n.segment, u = [];
    if (n.consumedBy)
      return n.isLeft ? this.queue.remove(n.otherSE) : this.tree.remove(l), u;
    const b = n.isLeft ? this.tree.add(l) : this.tree.find(l);
    if (!b)
      throw new Error(`Unable to find segment #${l.id} [${l.leftSE.point.x}, ${l.leftSE.point.y}] -> [${l.rightSE.point.x}, ${l.rightSE.point.y}] in SweepLine tree.`);
    let y = b, I = b, A, T;
    for (; A === void 0; )
      y = this.tree.prev(y), y === null ? A = null : y.key.consumedBy === void 0 && (A = y.key);
    for (; T === void 0; )
      I = this.tree.next(I), I === null ? T = null : I.key.consumedBy === void 0 && (T = I.key);
    if (n.isLeft) {
      let z = null;
      if (A) {
        const F = A.getIntersection(l);
        if (F !== null && (l.isAnEndpoint(F) || (z = F), !A.isAnEndpoint(F))) {
          const D = this._splitSafely(A, F);
          for (let W = 0, B = D.length; W < B; W++)
            u.push(D[W]);
        }
      }
      let H = null;
      if (T) {
        const F = T.getIntersection(l);
        if (F !== null && (l.isAnEndpoint(F) || (H = F), !T.isAnEndpoint(F))) {
          const D = this._splitSafely(T, F);
          for (let W = 0, B = D.length; W < B; W++)
            u.push(D[W]);
        }
      }
      if (z !== null || H !== null) {
        let F = null;
        z === null ? F = H : H === null ? F = z : F = Qe.comparePoints(z, H) <= 0 ? z : H, this.queue.remove(l.rightSE), u.push(l.rightSE);
        const D = l.split(F);
        for (let W = 0, B = D.length; W < B; W++)
          u.push(D[W]);
      }
      u.length > 0 ? (this.tree.remove(l), u.push(n)) : (this.segments.push(l), l.prev = A);
    } else {
      if (A && T) {
        const z = A.getIntersection(T);
        if (z !== null) {
          if (!A.isAnEndpoint(z)) {
            const H = this._splitSafely(A, z);
            for (let F = 0, D = H.length; F < D; F++)
              u.push(H[F]);
          }
          if (!T.isAnEndpoint(z)) {
            const H = this._splitSafely(T, z);
            for (let F = 0, D = H.length; F < D; F++)
              u.push(H[F]);
          }
        }
      }
      this.tree.remove(l);
    }
    return u;
  }
  /* Safely split a segment that is currently in the datastructures
   * IE - a segment other than the one that is currently being processed. */
  _splitSafely(n, l) {
    this.tree.remove(n);
    const u = n.rightSE;
    this.queue.remove(u);
    const b = n.split(l);
    return b.push(u), n.consumedBy === void 0 && this.tree.add(n), b;
  }
}
const wa = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE || 1e6, sn = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS || 1e6;
class rn {
  run(n, l, u) {
    et.type = n, Tt.reset();
    const b = [new ba(l, !0)];
    for (let F = 0, D = u.length; F < D; F++)
      b.push(new ba(u[F], !1));
    if (et.numMultiPolys = b.length, et.type === "difference") {
      const F = b[0];
      let D = 1;
      for (; D < b.length; )
        Si(b[D].bbox, F.bbox) !== null ? D++ : b.splice(D, 1);
    }
    if (et.type === "intersection")
      for (let F = 0, D = b.length; F < D; F++) {
        const W = b[F];
        for (let B = F + 1, j = b.length; B < j; B++)
          if (Si(W.bbox, b[B].bbox) === null)
            return [];
      }
    const y = new Ri(Qe.compare);
    for (let F = 0, D = b.length; F < D; F++) {
      const W = b[F].getSweepEvents();
      for (let B = 0, j = W.length; B < j; B++)
        if (y.insert(W[B]), y.size > wa)
          throw new Error("Infinite loop when putting segment endpoints in a priority queue (queue size too big).");
    }
    const I = new an(y);
    let A = y.size, T = y.pop();
    for (; T; ) {
      const F = T.key;
      if (y.size === A) {
        const W = F.segment;
        throw new Error(`Unable to pop() ${F.isLeft ? "left" : "right"} SweepEvent [${F.point.x}, ${F.point.y}] from segment #${W.id} [${W.leftSE.point.x}, ${W.leftSE.point.y}] -> [${W.rightSE.point.x}, ${W.rightSE.point.y}] from queue.`);
      }
      if (y.size > wa)
        throw new Error("Infinite loop when passing sweep line over endpoints (queue size too big).");
      if (I.segments.length > sn)
        throw new Error("Infinite loop when passing sweep line over endpoints (too many sweep line segments).");
      const D = I.process(F);
      for (let W = 0, B = D.length; W < B; W++) {
        const j = D[W];
        j.consumedBy === void 0 && y.insert(j);
      }
      A = y.size, T = y.pop();
    }
    Tt.reset();
    const z = qt.factory(I.segments);
    return new tn(z).getGeom();
  }
}
const et = new rn(), nn = function(v) {
  for (var n = arguments.length, l = new Array(n > 1 ? n - 1 : 0), u = 1; u < n; u++)
    l[u - 1] = arguments[u];
  return et.run("union", v, l);
}, on = function(v) {
  for (var n = arguments.length, l = new Array(n > 1 ? n - 1 : 0), u = 1; u < n; u++)
    l[u - 1] = arguments[u];
  return et.run("intersection", v, l);
}, ln = function(v) {
  for (var n = arguments.length, l = new Array(n > 1 ? n - 1 : 0), u = 1; u < n; u++)
    l[u - 1] = arguments[u];
  return et.run("xor", v, l);
}, cn = function(v) {
  for (var n = arguments.length, l = new Array(n > 1 ? n - 1 : 0), u = 1; u < n; u++)
    l[u - 1] = arguments[u];
  return et.run("difference", v, l);
};
var hn = {
  union: nn,
  intersection: on,
  xor: ln,
  difference: cn
};
function Sa(v, n, l) {
  l === void 0 && (l = {});
  var u = xi(v), b = xi(n), y = hn.intersection(u.coordinates, b.coordinates);
  return y.length === 0 ? null : y.length === 1 ? Lt(y[0], l.properties) : sr(y, l.properties);
}
function dn(v, n, l) {
  l === void 0 && (l = {});
  var u = JSON.stringify(l.properties || {}), b = v[0], y = v[1], I = v[2], A = v[3], T = (y + A) / 2, z = (b + I) / 2, H = n * 2 / sa([b, T], [I, T], l), F = H * (I - b), D = n * 2 / sa([z, y], [z, A], l), W = D * (A - y), B = F / 2, j = B * 2, ee = Math.sqrt(3) / 2 * W, te = I - b, M = A - y, V = 3 / 4 * j, G = ee, X = (te - j) / (j - B / 2), $ = Math.floor(X), K = ($ * V - B / 2 - te) / 2 - B / 2 + V / 2, J = Math.floor((M - ee) / ee), ie = (M - J * ee) / 2, re = J * ee - M > ee / 2;
  re && (ie -= ee / 4);
  for (var ne = [], ce = [], ge = 0; ge < 6; ge++) {
    var ue = 2 * Math.PI / 6 * ge;
    ne.push(Math.cos(ue)), ce.push(Math.sin(ue));
  }
  for (var Le = [], ke = 0; ke <= $; ke++)
    for (var Ae = 0; Ae <= J; Ae++) {
      var Me = ke % 2 === 1;
      if (!(Ae === 0 && Me) && !(Ae === 0 && re)) {
        var Te = ke * V + b - K, oe = Ae * G + y + ie;
        if (Me && (oe -= ee / 2), l.triangles === !0)
          gn([Te, oe], F / 2, W / 2, JSON.parse(u), ne, ce).forEach(function(ae) {
            l.mask ? Sa(l.mask, ae) && Le.push(ae) : Le.push(ae);
          });
        else {
          var Q = un([Te, oe], F / 2, W / 2, JSON.parse(u), ne, ce);
          l.mask ? Sa(l.mask, Q) && Le.push(Q) : Le.push(Q);
        }
      }
    }
  return ar(Le);
}
function un(v, n, l, u, b, y) {
  for (var I = [], A = 0; A < 6; A++) {
    var T = v[0] + n * b[A], z = v[1] + l * y[A];
    I.push([T, z]);
  }
  return I.push(I[0].slice()), Lt([I], u);
}
function gn(v, n, l, u, b, y) {
  for (var I = [], A = 0; A < 6; A++) {
    var T = [];
    T.push(v), T.push([v[0] + n * b[A], v[1] + l * y[A]]), T.push([
      v[0] + n * b[(A + 1) % 6],
      v[1] + l * y[(A + 1) % 6]
    ]), T.push(v), I.push(Lt([T], u));
  }
  return I;
}
function qa(v, n) {
  const l = {}, u = Object.keys(v);
  for (const b of u)
    if (Object.getOwnPropertyDescriptor(n, b)) {
      const y = v[b], I = n[b];
      if (typeof y == "object" && typeof I == "object" && !Array.isArray(y) && y !== null && !Array.isArray(I) && I !== null) {
        const A = qa(y, I);
        A && (l[b] = A);
      } else
        Array.isArray(y) && Array.isArray(I) ? (y.length !== I.length || JSON.stringify(y) !== JSON.stringify(I)) && (l[b] = I) : typeof y != "function" && typeof I != "function" && y !== I && (l[b] = I);
    }
  return l;
}
function fn(v, n) {
  return Object.keys(v).forEach((l) => {
    const u = l;
    n[u] = Object.assign(v[u], n[u]);
  }), n;
}
function Ua(v, n) {
  const l = { ...v }, u = Object.keys(v);
  for (const b of u)
    if (Object.getOwnPropertyDescriptor(n, b)) {
      const y = v[b], I = n[b];
      if (typeof y == "object" && typeof I == "object" && !Array.isArray(y) && y !== null && !Array.isArray(I) && I !== null) {
        const A = Ua(y, I);
        A && (l[b] = A);
      } else
        l[b] = I;
    }
  return l;
}
function pn(v, n) {
  return Object.fromEntries(
    Object.entries(v).filter(n)
  );
}
function gi(v) {
  const n = Number((Math.abs(v) * 100).toPrecision(15));
  return Number(Math.round(n) / 100 * Math.sign(v));
}
const Ci = `<svg
    xmlns="http://www.w3.org/2000/svg"
    width="16"
    height="16"
    viewBox="0 0 16 16"
  >
    <g id="Group_860" transform="translate(10 0) rotate(90)">
      <circle
        id="Ellipse_40"
        cx="2"
        cy="2"
        r="2"
        transform="translate(0 0)"
        fill="currentColor"
      />
      <circle
        id="Ellipse_41"
        cx="2"
        cy="2"
        r="2"
        transform="translate(6 0)"
        fill="currentColor"
      />
      <circle
        id="Ellipse_42"
        cx="2"
        cy="2"
        r="2"
        transform="translate(12 0)"
        fill="currentColor"
      />
    </g>
    <rect id="size" width="16" height="16" fill="none" />
  </svg>`;
function Za(v) {
  return v.length > 0 ? v.reduce((n, l) => n + l) : 0;
}
function Ja(v) {
  return new Promise((n) => {
    setTimeout(n, v);
  });
}
function Ka(v) {
  var u;
  const n = (u = v.getGeometry()) == null ? void 0 : u.getCoordinates(), l = [];
  return n == null || n.forEach((b) => {
    const y = [];
    b.forEach((I) => {
      const A = [I[0], I[1]];
      y.push(kt.mercatorToWgs84(A));
    }), y.push(y[0]), l.push(y);
  }), new Ct({
    geometry: new Li(l)
  });
}
function xn(v) {
  const n = [v[0], v[1]], l = [v[2], v[3]];
  return [...kt.mercatorToWgs84(n), ...kt.mercatorToWgs84(l)];
}
function mn(v) {
  var l;
  const n = Lt(
    (l = Ka(v).getGeometry()) == null ? void 0 : l.getCoordinates()
  );
  return _r(n);
}
var Qa = { exports: {} };
(function(v, n) {
  (function() {
    var l = Math.PI, u = Math.sin, b = Math.cos, y = Math.tan, I = Math.asin, A = Math.atan2, T = Math.acos, z = l / 180, H = 1e3 * 60 * 60 * 24, F = 2440588, D = 2451545;
    function W(Q) {
      return Q.valueOf() / H - 0.5 + F;
    }
    function B(Q) {
      return new Date((Q + 0.5 - F) * H);
    }
    function j(Q) {
      return W(Q) - D;
    }
    var ee = z * 23.4397;
    function te(Q, ae) {
      return A(u(Q) * b(ee) - y(ae) * u(ee), b(Q));
    }
    function M(Q, ae) {
      return I(u(ae) * b(ee) + b(ae) * u(ee) * u(Q));
    }
    function V(Q, ae, le) {
      return A(u(Q), b(Q) * u(ae) - y(le) * b(ae));
    }
    function G(Q, ae, le) {
      return I(u(ae) * u(le) + b(ae) * b(le) * b(Q));
    }
    function X(Q, ae) {
      return z * (280.16 + 360.9856235 * Q) - ae;
    }
    function $(Q) {
      return Q < 0 && (Q = 0), 2967e-7 / Math.tan(Q + 312536e-8 / (Q + 0.08901179));
    }
    function K(Q) {
      return z * (357.5291 + 0.98560028 * Q);
    }
    function J(Q) {
      var ae = z * (1.9148 * u(Q) + 0.02 * u(2 * Q) + 3e-4 * u(3 * Q)), le = z * 102.9372;
      return Q + ae + le + l;
    }
    function ie(Q) {
      var ae = K(Q), le = J(ae);
      return {
        dec: M(le, 0),
        ra: te(le, 0)
      };
    }
    var re = {};
    re.getPosition = function(Q, ae, le) {
      var pe = z * -le, xe = z * ae, de = j(Q), ve = ie(de), ye = X(de, pe) - ve.ra;
      return {
        azimuth: V(ye, xe, ve.dec),
        altitude: G(ye, xe, ve.dec)
      };
    };
    var ne = re.times = [
      [-0.833, "sunrise", "sunset"],
      [-0.3, "sunriseEnd", "sunsetStart"],
      [-6, "dawn", "dusk"],
      [-12, "nauticalDawn", "nauticalDusk"],
      [-18, "nightEnd", "night"],
      [6, "goldenHourEnd", "goldenHour"]
    ];
    re.addTime = function(Q, ae, le) {
      ne.push([Q, ae, le]);
    };
    var ce = 9e-4;
    function ge(Q, ae) {
      return Math.round(Q - ce - ae / (2 * l));
    }
    function ue(Q, ae, le) {
      return ce + (Q + ae) / (2 * l) + le;
    }
    function Le(Q, ae, le) {
      return D + Q + 53e-4 * u(ae) - 69e-4 * u(2 * le);
    }
    function ke(Q, ae, le) {
      return T((u(Q) - u(ae) * u(le)) / (b(ae) * b(le)));
    }
    function Ae(Q) {
      return -2.076 * Math.sqrt(Q) / 60;
    }
    function Me(Q, ae, le, pe, xe, de, ve) {
      var ye = ke(Q, le, pe), Se = ue(ye, ae, xe);
      return Le(Se, de, ve);
    }
    re.getTimes = function(Q, ae, le, pe) {
      pe = pe || 0;
      var xe = z * -le, de = z * ae, ve = Ae(pe), ye = j(Q), Se = ge(ye, xe), Ee = ue(0, xe, Se), Re = K(Ee), ze = J(Re), De = M(ze, 0), _e = Le(Ee, Re, ze), He, Be, Xe, Ye, We, tt, Ge = {
        solarNoon: B(_e),
        nadir: B(_e - 0.5)
      };
      for (He = 0, Be = ne.length; He < Be; He += 1)
        Xe = ne[He], Ye = (Xe[0] + ve) * z, We = Me(Ye, xe, de, De, Se, Re, ze), tt = _e - (We - _e), Ge[Xe[1]] = B(tt), Ge[Xe[2]] = B(We);
      return Ge;
    };
    function Te(Q) {
      var ae = z * (218.316 + 13.176396 * Q), le = z * (134.963 + 13.064993 * Q), pe = z * (93.272 + 13.22935 * Q), xe = ae + z * 6.289 * u(le), de = z * 5.128 * u(pe), ve = 385001 - 20905 * b(le);
      return {
        ra: te(xe, de),
        dec: M(xe, de),
        dist: ve
      };
    }
    re.getMoonPosition = function(Q, ae, le) {
      var pe = z * -le, xe = z * ae, de = j(Q), ve = Te(de), ye = X(de, pe) - ve.ra, Se = G(ye, xe, ve.dec), Ee = A(u(ye), y(xe) * b(ve.dec) - u(ve.dec) * b(ye));
      return Se = Se + $(Se), {
        azimuth: V(ye, xe, ve.dec),
        altitude: Se,
        distance: ve.dist,
        parallacticAngle: Ee
      };
    }, re.getMoonIllumination = function(Q) {
      var ae = j(Q || /* @__PURE__ */ new Date()), le = ie(ae), pe = Te(ae), xe = 149598e3, de = T(u(le.dec) * u(pe.dec) + b(le.dec) * b(pe.dec) * b(le.ra - pe.ra)), ve = A(xe * u(de), pe.dist - xe * b(de)), ye = A(b(le.dec) * u(le.ra - pe.ra), u(le.dec) * b(pe.dec) - b(le.dec) * u(pe.dec) * b(le.ra - pe.ra));
      return {
        fraction: (1 + b(ve)) / 2,
        phase: 0.5 + 0.5 * ve * (ye < 0 ? -1 : 1) / Math.PI,
        angle: ye
      };
    };
    function oe(Q, ae) {
      return new Date(Q.valueOf() + ae * H / 24);
    }
    re.getMoonTimes = function(Q, ae, le, pe) {
      var xe = new Date(Q);
      pe ? xe.setUTCHours(0, 0, 0, 0) : xe.setHours(0, 0, 0, 0);
      for (var de = 0.133 * z, ve = re.getMoonPosition(xe, ae, le).altitude - de, ye, Se, Ee, Re, ze, De, _e, He, Be, Xe, Ye, We, tt, Ge = 1; Ge <= 24 && (ye = re.getMoonPosition(oe(xe, Ge), ae, le).altitude - de, Se = re.getMoonPosition(oe(xe, Ge + 1), ae, le).altitude - de, ze = (ve + Se) / 2 - ye, De = (Se - ve) / 2, _e = -De / (2 * ze), He = (ze * _e + De) * _e + ye, Be = De * De - 4 * ze * ye, Xe = 0, Be >= 0 && (tt = Math.sqrt(Be) / (Math.abs(ze) * 2), Ye = _e - tt, We = _e + tt, Math.abs(Ye) <= 1 && Xe++, Math.abs(We) <= 1 && Xe++, Ye < -1 && (Ye = We)), Xe === 1 ? ve < 0 ? Ee = Ge + Ye : Re = Ge + Ye : Xe === 2 && (Ee = Ge + (He < 0 ? We : Ye), Re = Ge + (He < 0 ? Ye : We)), !(Ee && Re)); Ge += 2)
        ve = Se;
      var at = {};
      return Ee && (at.rise = oe(xe, Ee)), Re && (at.set = oe(xe, Re)), !Ee && !Re && (at[He > 0 ? "alwaysUp" : "alwaysDown"] = !0), at;
    }, v.exports = re;
  })();
})(Qa);
var vn = Qa.exports;
const Ca = /* @__PURE__ */ Ii(vn);
function bn(v, n) {
  return new Date(n, v, 0).getDate();
}
function yn(v) {
  const n = [v.x, v.y, v.z], l = kt.mercatorToWgs84(n), u = [], b = /* @__PURE__ */ new Date();
  b.setDate(15), b.setMinutes(0);
  for (let y = 0; y < 12; y++) {
    b.setMonth(y);
    const I = Ca.getTimes(
      b,
      l[1],
      l[0]
    ), A = I.sunrise.getHours(), T = I.sunset.getHours() + 1;
    for (let z = A; z <= T; z++) {
      b.setHours(z);
      const H = Ca.getPosition(
        b,
        l[1],
        l[0]
      ), F = 1e6, D = v.x + F * Math.cos(H.azimuth * -1 - Math.PI / 2), W = v.y + F * Math.sin(H.azimuth * -1 - Math.PI / 2), B = v.z + F * Math.sin(H.altitude), j = new we(D, W, B);
      u.push({
        sunPoint: j,
        azimuth: H.azimuth,
        altitude: H.altitude,
        zenith: Math.PI / 2 - H.altitude,
        date: new Date(b)
      });
    }
  }
  return u;
}
function ka(v, n, l, u) {
  v.forEach((b) => {
    const { zenith: y } = b, A = ut(u)[2];
    let T, z = 0, H = 0, F = 0, D = 0;
    const W = n[b.date.getMonth()][0], B = n[b.date.getMonth()][4];
    y < Math.PI / 2 ? (T = Math.exp(-118e-6 * A - 1638e-12 * A * A) / Math.cos(y), T < 25 ? z = W ** T : z = 0, H = 1.367 * z * bn(b.date.getMonth() - 1, b.date.getFullYear()), D = Math.cos(y) * H, F = D / (1 - B) * B) : T = 0, F = F * 1 / l;
    const j = F * l;
    b.optPathLength = T, b.directRad = H, b.directRadHorizon = j, b.diffuseRad = F, b.diffuseRadHorizon = j;
  });
}
function wn(v, n) {
  let l = 0;
  return v.optPathLength && v.optPathLength < 25 && (l = Math.cos(v.zenith) * n ** v.optPathLength * 1.367), l;
}
function Sn(v) {
  let n = 1;
  return v[0] < 0 && (n = -1), 1e-3 * v[1] * n;
}
function Cn(v, n) {
  const l = [];
  for (let u = 0; u < 12; u++) {
    l[u] = [];
    let b = !1;
    do {
      const y = n[u][0], I = v.filter((A) => A.date.getMonth() === u).map((A) => wn(A, y)).reduce((A, T) => A + T);
      l[u][0] = n[u][3] - I, l[u][1] = Math.abs(l[u][0]) / n[u][3] * 100, l[u][1] <= 0.25 ? b = !0 : n[u][0] += Sn(l[u]);
    } while (!b);
  }
}
function kn(v, n) {
  v.forEach((l) => {
    l.calibrationValue = Math.cos(1.5707963267949 - l.zenith), l.countPoints = n, l.portionDiff = 1 / n / l.weightDiff, l.calibrationDiffrad = l.weightDiff * Math.cos(1.5707963267949 - l.zenith);
  });
}
function An(v) {
  const n = v.map((l) => l.calibrationDiffrad ? l.calibrationDiffrad : 0).reduce((l, u) => l + u);
  v.forEach((l) => {
    l.calibrationDiffrad = n;
  });
}
function Pn(v, n, l, u, b) {
  const y = [], I = Math.round(Math.PI / 2 / n);
  let A = Math.round(Math.PI * 2 / v);
  const T = Math.PI / 2 / I;
  let z = Math.PI * 2 / A;
  const H = T / 2;
  let F = H, D = 0, W = Math.cos(F) * u, B = 4 * W * Math.PI;
  const j = B / A, ee = 2 * u ** 2 * Math.PI;
  for (let M = 1; M <= I; M++) {
    for (let V = 1; V <= A; V++) {
      let G = 0, X = Math.PI / 2;
      F - H >= 0 && (G = F - H), F + H <= Math.PI / 2 && (X = F + H);
      const $ = u - Math.sin(G) * u, K = u - Math.sin(X) * u, J = $ - K, re = 2 * u * J * Math.PI / (ee * A), ne = (2 * Math.cos(G) + Math.cos(2 * G) - 2 * Math.cos(X) - Math.cos(2 * X)) / (4 * A), ce = b.x + W * Math.sin(D), ge = b.y + W * Math.cos(D), ue = b.z + u * Math.sin(F), Le = new we(ce, ge, ue);
      y.push({
        hemispherePoint: Le,
        azimuth: D,
        zenith: F,
        skySectorArea: re,
        weightDiff: ne
      }), D += z;
    }
    D = Math.PI * 2 - D + l * M, F += T, W = Math.cos(F) * u, B = 2 * W * Math.PI, A = Math.round(B / j), z = Math.PI * 2 / A;
  }
  const te = y.length;
  return kn(y, te), An(y), y;
}
class Ln extends Error {
  constructor(l, u) {
    super(l);
    Ve(this, "response");
    this.response = u;
  }
}
const Aa = [
  "jan",
  "feb",
  "mar",
  "apr",
  "may",
  "jun",
  "jul",
  "aug",
  "sep",
  "oct",
  "nov",
  "dec"
];
async function Mn(v, n) {
  const l = [], u = `https://power.larc.nasa.gov/api/temporal/climatology/point?parameters=ALLSKY_SFC_SW_DWN,ALLSKY_SFC_SW_DIFF&community=RE&longitude=${v}&latitude=${n}&format=JSON`, b = await fetch(u);
  if (!b.ok)
    throw new Ln("solarRevenue.nasa", b);
  const y = await b.json(), I = y.properties.parameter.ALLSKY_SFC_SW_DIFF, A = y.properties.parameter.ALLSKY_SFC_SW_DWN;
  return Object.entries(A).forEach(([T, z]) => {
    if (Aa.indexOf(T.toLowerCase()) >= 0) {
      const H = Aa.indexOf(T.toLowerCase());
      l[H] = [];
      const F = 0.3, D = z, W = I[T], B = D - W, j = W / D;
      l[H][0] = F, l[H][1] = D, l[H][2] = W, l[H][3] = B, l[H][4] = j;
    }
  }), l;
}
function En(v, n) {
  return we.subtract(n, v, new we());
}
class es {
  constructor(n, l, u) {
    Ve(this, "_fromPoint");
    Ve(this, "_toPoint");
    Ve(this, "_direction");
    Ve(this, "_app");
    Ve(this, "_isNotIntersected", !1);
    Ve(this, "_ray");
    this._fromPoint = n, this._toPoint = l, this._app = u, this._direction = En(
      ot([
        this._fromPoint.x,
        this._fromPoint.y,
        this._fromPoint.z
      ]),
      ot([this._toPoint.x, this._toPoint.y, this._toPoint.z])
    ), this._ray = new $s(
      ot([
        this._fromPoint.x,
        this._fromPoint.y,
        this._fromPoint.z
      ]),
      this._direction
    );
  }
  intersect() {
    var n;
    this._app.maps.activeMap instanceof Xa && ((n = this._app.maps.activeMap.getScene()) != null && n.pickFromRay(this._ray, [])) && (this._isNotIntersected = !0);
  }
  createRayFeature() {
    const n = new Ct({
      geometry: new Ds([
        [this._fromPoint.x, this._fromPoint.y, this._fromPoint.z],
        [this._toPoint.x, this._toPoint.y, this._toPoint.z]
      ])
    });
    let l = new Vt({
      stroke: new Gt({ color: "#00FF00", width: 1 })
    });
    return this._isNotIntersected && (l = new Vt({
      stroke: new Gt({ color: "#FF0000", width: 1 })
    })), n.setStyle(l), n;
  }
  get direction() {
    return this._direction;
  }
  get isNotIntersected() {
    return !this._isNotIntersected;
  }
}
class In extends es {
}
class Tn extends es {
}
function Pa(v, n) {
  return new Ha(
    n.x ** 2 * (1 - Math.cos(v)) + Math.cos(v),
    n.x * n.y * (1 - Math.cos(v)) - n.z * Math.sin(v),
    n.x * n.z * (1 - Math.cos(v)) + n.y * Math.sin(v),
    n.y * n.x * (1 - Math.cos(v)) + n.z * Math.sin(v),
    n.y ** 2 * (1 - Math.cos(v)) + Math.cos(v),
    n.y * n.z * (1 - Math.cos(v)) - n.x * Math.sin(v),
    n.z * n.x * (1 - Math.cos(v)) - n.y * Math.sin(v),
    n.z * n.y * (1 - Math.cos(v)) + n.x * Math.sin(v),
    n.z ** 2 * (1 - Math.cos(v)) + Math.cos(v)
  );
}
function Rn(v, n) {
  const l = we.cross(
    we.normalize(n, new we()),
    we.normalize(v, new we()),
    new we()
  );
  return we.normalize(l, new we());
}
function La(v) {
  var l;
  const n = (l = v.getGeometry()) == null ? void 0 : l.getCoordinates();
  if (n) {
    const u = ot(n[0][1]), b = ot(n[0][2]), y = ot(n[0][0]), I = we.subtract(b, u, new we()), A = we.subtract(y, u, new we()), T = we.cross(I, A, new we());
    return we.normalize(T, new we());
  } else
    return new we();
}
function fi(v) {
  var T;
  const n = (T = v.getGeometry()) == null ? void 0 : T.getCoordinates(), l = [], u = [], b = [];
  n == null || n.forEach((z) => {
    z.forEach((H) => {
      l.push(H[0]), u.push(H[1]), b.push(H[2]);
    });
  });
  const y = (Math.max(...l) + Math.min(...l)) / 2, I = (Math.max(...u) + Math.min(...u)) / 2, A = (Math.max(...b) + Math.min(...b)) / 2;
  return ot([y, I, A]);
}
function _n(v, n) {
  return Ha.multiplyByVector(v, n, new we());
}
function On(v, n) {
  return we.add(v, n, new we());
}
function zn(v, n) {
  return we.subtract(v, n, new we());
}
function Ma(v, n, l, u) {
  var H;
  const b = we.angleBetween(l, n), y = Rn(n, l), I = Pa(u ? -1 * b : b, y), A = [];
  (H = v.getGeometry()) == null || H.getCoordinates()[0].forEach((F) => {
    const D = zn(ot(F), n), W = _n(I, D), B = On(W, n), j = ut(B);
    A.push(j);
  });
  const T = new Ct({
    geometry: new Li([A])
  }), z = new Vt({
    stroke: new Gt({ color: "#FF61F4", width: 3 })
  });
  return T.setStyle(z), T;
}
function Fn(v, n, l) {
  var y, I;
  const u = [], b = (y = v == null ? void 0 : v.getGeometry()) == null ? void 0 : y.getExtent();
  if (b) {
    const A = Lt(
      (I = Ka(v).getGeometry()) == null ? void 0 : I.getCoordinates()
    ), T = {
      units: "meters",
      mask: A
    };
    dn(xn(b), l, T).features.forEach((H) => {
      if (Tr(ja(H), A)) {
        const F = [];
        H.geometry.coordinates.forEach((B) => {
          const j = [];
          B.forEach((ee) => {
            const te = kt.wgs84ToMercator(ee);
            te.push(ut(n)[2] + 0.3), j.push(te);
          }), F.push(j);
        });
        const D = new Ct({
          geometry: new Li(F)
        }), W = new Vt({
          stroke: new Gt({ color: "#00FF00", width: 1 })
        });
        D.setStyle(W), u.push(D);
      }
    });
  }
  return v ? u : [];
}
function Dn(v, n) {
  let l = 0, u = 0;
  v.surfacePoints && v.surfacePoints.forEach((b) => {
    b.directRad.forEach((y) => {
      l += y;
    }), b.diffuseRad.forEach((y) => {
      u += y;
    });
  }), v.diffuseRad = u, v.directRad = l, v.globalRad = u + l, n.solarIrradiation = u + l;
}
async function Xn(v) {
  const n = ut(v.centerPoint), l = new we(
    n[0],
    n[1],
    n[2]
  ), u = kt.mercatorToWgs84(
    ut(v.centerPoint)
  ), b = yn(l), y = Pn(
    0.21,
    0.157,
    0.05,
    1e6,
    l
  ), I = await Mn(u[0], u[1]);
  ka(
    b,
    I,
    y[0].calibrationDiffrad || 0,
    v.centerPoint
  ), Cn(b, I), ka(
    b,
    I,
    y[0].calibrationDiffrad || 0,
    v.centerPoint
  ), v.sunPoints = b, v.hemispherePoints = y;
}
function Yn(v, n) {
  var B, j;
  const l = fi(v);
  let u = La(v);
  const b = n.maps.activeMap.getScene();
  let y = new we();
  b && (y = new qs(b).direction);
  const I = Ji.fromPointNormal(l, u);
  if (Ji.getPointDistance(I, y) > 0) {
    const ee = (B = v.getGeometry()) == null ? void 0 : B.getCoordinates()[0].toReversed();
    ee && ((j = v.getGeometry()) == null || j.setCoordinates([ee]), u = La(v));
  }
  const T = Ma(
    v,
    l,
    u,
    !1
  ), z = mn(T), H = z < 50 ? 1 : z / 50, F = Fn(
    T,
    l,
    H
  ), D = [];
  if (F.length > 1) {
    const ee = z / F.length;
    F.forEach((te) => {
      const M = Ma(
        te,
        l,
        u,
        !0
      ), V = fi(M), G = new Ct({
        geometry: new qi(ut(V))
      }), X = {
        area: ee,
        directRad: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        diffuseRad: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        globalRad: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        surfacePointFeature: G,
        gridFeature3D: M,
        gridFeature2D: te
      };
      D.push(X);
    });
  } else {
    const ee = fi(v), te = we.multiplyByScalar(
      u,
      0.3,
      new we()
    ), M = we.add(
      ee,
      te,
      new we()
    ), V = new Ct({
      geometry: new qi(ut(M))
    }), G = {
      area: z,
      directRad: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      diffuseRad: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      globalRad: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      surfacePointFeature: V
    };
    D.push(G);
  }
  return {
    centerPoint: l,
    directRad: 0,
    diffuseRad: 0,
    globalRad: 0,
    solarArea: z,
    normal: u,
    surfacePoints: D,
    surfaceFeature: v
  };
}
function _i(v) {
  v.progress = v.numberCurrentRays / v.numberTotalRays * 100;
}
async function Nn(v, n, l, u) {
  var b, y;
  if (v.sunPoints && v.surfacePoints)
    for (const I of v.surfacePoints) {
      let A = 0;
      const T = [];
      I.directRad = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
      for (const z of v.sunPoints) {
        const H = (y = (b = I.surfacePointFeature) == null ? void 0 : b.getGeometry()) == null ? void 0 : y.getCoordinates();
        if (H) {
          const F = new we(
            H[0],
            H[1],
            H[2]
          ), D = new In(F, z.sunPoint, n);
          D.intersect(), A += 1, l.numberCurrentRays += 1, A % 20 === 0 && (await Ja(0), _i(l));
          const W = Math.cos(
            we.angleBetween(v.normal, D.direction)
          );
          if (u && T.push(D.createRayFeature()), D.isNotIntersected) {
            const B = (z.directRad || 0) * W * I.area;
            I.directRad[z.date.getMonth()] += B;
          }
        }
      }
      u && (I.sunRayFeatures = T);
    }
}
async function Hn(v, n, l, u) {
  var b, y;
  if (v.surfacePoints && v.hemispherePoints)
    for (const I of v.surfacePoints) {
      let A = 0;
      const T = [];
      I.diffuseRad = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
      let z = 0;
      for (const H of v.hemispherePoints) {
        const F = (y = (b = I.surfacePointFeature) == null ? void 0 : b.getGeometry()) == null ? void 0 : y.getCoordinates();
        if (F) {
          const D = new we(
            F[0],
            F[1],
            F[2]
          ), W = new Tn(
            D,
            H.hemispherePoint,
            n
          );
          W.intersect(), A += 1, l.numberCurrentRays += 1, A % 20 === 0 && (await Ja(0), _i(l));
          const B = Math.cos(
            we.angleBetween(
              v.normal,
              W.direction
            )
          );
          u && T.push(W.createRayFeature()), W.isNotIntersected && (z += B * H.weightDiff);
        }
      }
      u && (I.hemisphereRayFeatures = T), z *= I.area;
      for (let H = 0; H < 12; H++) {
        let F = 0;
        v.sunPoints && (F = v.sunPoints.map((D) => D.date.getMonth() - 1 === H && D.diffuseRad ? D.diffuseRad : 0).reduce((D, W) => D + W)), I.diffuseRad[H] = z * F;
      }
    }
}
async function ts(v, n, l) {
  var u;
  if (v.solarSurface) {
    v.calculatedProgress = {
      numberTotalRays: 0,
      numberCurrentRays: 0,
      progress: 0
    };
    const b = (u = v.actions) == null ? void 0 : u.find((z) => z.name === "calculateSolarModule");
    b && (b.icon = "$vcsProgress");
    try {
      await Xn(v.solarSurface);
    } catch (z) {
      throw b && (b.icon = "mdi-alert-circle-outline"), n.notifier.add({
        type: ki.WARNING,
        message: "solarRevenue.nasa"
      }), z;
    }
    const y = v.solarSurface.surfacePoints.length, I = v.solarSurface.sunPoints ? v.solarSurface.sunPoints.length : 0, A = v.solarSurface.hemispherePoints ? v.solarSurface.hemispherePoints.length : 0, T = (I + A) * y;
    v.calculatedProgress.numberTotalRays = T, await Hn(
      v.solarSurface,
      n,
      v.calculatedProgress,
      l
    ), await Nn(
      v.solarSurface,
      n,
      v.calculatedProgress,
      l
    ), Dn(v.solarSurface, v), b && (b.icon = "mdi-refresh-circle"), _i(v.calculatedProgress);
  }
}
async function is(v, n, l) {
  for (const u of v)
    await ts(u, n, l);
}
const Bn = ft({
  name: "SolarRevenue",
  methods: { calculateSolarAreaModules: is },
  components: {
    VcsSlider: Es,
    VcsCheckbox: Ta,
    VcsLabel: gt,
    VRow: pt,
    VCol: xt,
    VDialog: _t,
    VcsFormButton: Ra,
    VCard: Ot,
    VcsWizard: Is,
    VcsWizardStep: Ts,
    VContainer: mt,
    VcsTextField: _a,
    VcsFormattedNumber: Rt,
    VDivider: Mi,
    VSwitch: Gs,
    VIcon: Pt
  },
  props: {
    solarOptions: {
      type: Object,
      required: !0
    },
    investmentCosts: {
      type: Number,
      required: !0
    },
    creditAmount: {
      type: Number,
      required: !0
    },
    isFinance: {
      type: Boolean,
      required: !0
    },
    isStorageConsumption: {
      type: Boolean,
      required: !0
    },
    selectedModules: {
      type: Array,
      required: !0
    }
  },
  setup(v, n) {
    const l = Zt("vcsApp"), u = Pe(!1), b = Pe(!1), y = Pe(!1), I = Pe(!1), A = Pe(3), T = {
      DEMAND: 1,
      CONSUMPTION: 2,
      COSTS: 3,
      FINANCE: 4
    }, z = Pe(T.DEMAND), H = be({
      get() {
        return v.solarOptions;
      },
      set(B) {
        n.emit("update-solar-options", B);
      }
    }), F = be({
      get() {
        return v.isFinance;
      },
      set(B) {
        n.emit("update-isFinance", !!B);
      }
    }), D = be({
      get() {
        return v.isStorageConsumption;
      },
      set(B) {
        n.emit("update-isStorageConsumption", !!B);
      }
    }), W = () => {
      H.value.userOptions.electricityDemand = H.value.userOptions.numberOfPersons * H.value.adminOptions.electricityDemandPerPerson, u.value && (H.value.userOptions.electricityDemand += H.value.userOptions.livingSpace * H.value.adminOptions.electricityDemandHeatPump), b.value && (H.value.userOptions.electricityDemand += H.value.userOptions.annualDrivingDistance * H.value.adminOptions.electricityDemandCar / 100);
    };
    return W(), dt(
      () => H.value.userOptions.numberOfPersons,
      () => W()
    ), dt(
      () => H.value.userOptions.livingSpace,
      () => W()
    ), dt(
      () => H.value.userOptions.annualDrivingDistance,
      () => W()
    ), dt(u, () => W()), dt(b, () => W()), {
      app: l,
      dialog: I,
      stepOrder: T,
      currentStep: z,
      isHeatPump: u,
      isCar: b,
      sliderValues: A,
      isPriceIncrease: y,
      localSolarOptions: H,
      localIsFinance: F,
      localIsStorageConsumption: D,
      creditRule(B) {
        return B < v.investmentCosts && B > 0 || "Eigenkapital darf die Investitionskosten nicht übersteigen";
      }
    };
  }
});
function vt(v, n, l, u, b, y, I, A) {
  var T = typeof v == "function" ? v.options : v;
  n && (T.render = n, T.staticRenderFns = l, T._compiled = !0), u && (T.functional = !0), y && (T._scopeId = "data-v-" + y);
  var z;
  if (I ? (z = function(D) {
    D = D || // cached call
    this.$vnode && this.$vnode.ssrContext || // stateful
    this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext, !D && typeof __VUE_SSR_CONTEXT__ < "u" && (D = __VUE_SSR_CONTEXT__), b && b.call(this, D), D && D._registeredComponents && D._registeredComponents.add(I);
  }, T._ssrRegister = z) : b && (z = A ? function() {
    b.call(
      this,
      (T.functional ? this.parent : this).$root.$options.shadowRoot
    );
  } : b), z)
    if (T.functional) {
      T._injectStyles = z;
      var H = T.render;
      T.render = function(W, B) {
        return z.call(B), H(W, B);
      };
    } else {
      var F = T.beforeCreate;
      T.beforeCreate = F ? [].concat(F, z) : [z];
    }
  return {
    exports: v,
    options: T
  };
}
var Wn = function() {
  var n = this, l = n._self._c;
  return n._self._setupProxy, l("v-dialog", { attrs: { width: "500px" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: u }) {
    return [l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-center" }, [l("vcs-form-button", n._g({ attrs: { small: "" } }, u), [n._v(" " + n._s(n.$t("solarRevenue.revenue.button")))])], 1)], 1)];
  } }]), model: { value: n.dialog, callback: function(u) {
    n.dialog = u;
  }, expression: "dialog" } }, [l("v-card", [l("v-container", { staticClass: "px-5 py-1" }, [l("h3", { staticClass: "d-flex align-center px-0 py-3" }, [l("v-icon", { staticClass: "mr-1 text--primary", attrs: { size: "16" } }, [n._v("mdi-finance")]), l("span", { staticClass: "d-inline-block user-select-none font-weight-bold text--primary" }, [n._v(" " + n._s(n.$t("solarRevenue.revenue.title")) + " ")])], 1), l("VcsWizard", { staticClass: "elevation-0", model: { value: n.currentStep, callback: function(u) {
    n.currentStep = n._n(u);
  }, expression: "currentStep" } }, [l("VcsWizardStep", { attrs: { step: n.stepOrder.DEMAND, editable: "", "help-text": "solarRevenue.revenue.help.demand", heading: "solarRevenue.revenue.demand.title" }, scopedSlots: n._u([{ key: "content", fn: function() {
    return [l("v-container", [l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.demand.person")))])], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("v-container", { staticClass: "px-1 pt-9" }, [l("VcsSlider", { attrs: { max: 4, min: 1, type: "number", step: "1", ticks: "always", "thumb-label": "always", "thumb-size": 24 }, model: { value: n.localSolarOptions.userOptions.numberOfPersons, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "numberOfPersons", u);
    }, expression: "localSolarOptions.userOptions.numberOfPersons" } })], 1)], 1)], 1), l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsCheckbox", { attrs: { label: "solarRevenue.revenue.demand.isHeatPump" }, model: { value: n.isHeatPump, callback: function(u) {
      n.isHeatPump = u;
    }, expression: "isHeatPump" } })], 1)], 1), n.isHeatPump ? l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "pl-10" }, [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.demand.livingSpace")))])], 1), l("v-col", [l("VcsTextField", { attrs: { type: "number", unit: "m²", "show-spin-buttons": "", step: "5", decimals: 0 }, model: { value: n.localSolarOptions.userOptions.livingSpace, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "livingSpace", n._n(u));
    }, expression: "localSolarOptions.userOptions.livingSpace" } })], 1)], 1) : n._e(), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsCheckbox", { attrs: { label: "solarRevenue.revenue.demand.isCar" }, model: { value: n.isCar, callback: function(u) {
      n.isCar = u;
    }, expression: "isCar" } })], 1)], 1), n.isCar ? l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "pl-10" }, [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.demand.distance")))])], 1), l("v-col", [l("VcsTextField", { attrs: { disabled: !n.isCar, type: "number", unit: "km", "show-spin-buttons": "", step: "1000", decimals: 0 }, model: { value: n.localSolarOptions.userOptions.annualDrivingDistance, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "annualDrivingDistance", n._n(u));
    }, expression: `
                      localSolarOptions.userOptions.annualDrivingDistance
                    ` } })], 1)], 1) : n._e(), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { staticClass: "font-weight-bold" }, [n._v(n._s(n.$t("solarRevenue.revenue.demand.demand")))])], 1), l("v-col", [l("VcsTextField", { attrs: { type: "number", unit: n.$t("solarRevenue.revenue.demand.demandUnit").toString(), "show-spin-buttons": "" }, model: { value: n.localSolarOptions.userOptions.electricityDemand, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "electricityDemand", n._n(u));
    }, expression: `
                      localSolarOptions.userOptions.electricityDemand
                    ` } })], 1)], 1)], 1)];
  }, proxy: !0 }]), model: { value: n.currentStep, callback: function(u) {
    n.currentStep = n._n(u);
  }, expression: "currentStep" } }), l("VcsWizardStep", { attrs: { step: n.stepOrder.CONSUMPTION, editable: "", "help-text": "solarRevenue.revenue.help.consumption", heading: "solarRevenue.revenue.consumption.title" }, scopedSlots: n._u([{ key: "content", fn: function() {
    return [l("v-container", { staticClass: "px-1 py-0" }, [l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.consumption.directConsumption")))])], 1)], 1), l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", { attrs: { cols: "10" } }, [l("VcsSlider", { attrs: { max: 100, min: 0, type: "number", step: "1" }, model: { value: n.localSolarOptions.userOptions.directConsumptionPortion, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "directConsumptionPortion", u);
    }, expression: `
                      localSolarOptions.userOptions.directConsumptionPortion
                    ` } })], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.localSolarOptions.userOptions.directConsumptionPortion, unit: "%", "fraction-digits": 0 } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsCheckbox", { attrs: { label: "solarRevenue.revenue.consumption.isStorageConsumption" }, model: { value: n.localIsStorageConsumption, callback: function(u) {
      n.localIsStorageConsumption = u;
    }, expression: "localIsStorageConsumption" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.consumption.storageConsumption")))])], 1)], 1), l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", { attrs: { cols: "10" } }, [l("VcsSlider", { attrs: { disabled: !n.localIsStorageConsumption, max: 100, min: 0, type: "number", step: "1" }, model: { value: n.localSolarOptions.userOptions.storageConsumptionPortion, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "storageConsumptionPortion", u);
    }, expression: `
                      localSolarOptions.userOptions.storageConsumptionPortion
                    ` } })], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.localSolarOptions.userOptions.storageConsumptionPortion, unit: "%", "fraction-digits": 0 } })], 1)], 1)], 1)];
  }, proxy: !0 }]), model: { value: n.currentStep, callback: function(u) {
    n.currentStep = n._n(u);
  }, expression: "currentStep" } }), l("VcsWizardStep", { attrs: { step: n.stepOrder.COSTS, editable: "", "help-text": "solarRevenue.revenue.help.costs", heading: "solarRevenue.revenue.costs.title" }, scopedSlots: n._u([{ key: "content", fn: function() {
    return [l("v-container", { staticClass: "px-1 py-0" }, [l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.costs.consumption")))])], 1), l("v-col", [l("VcsTextField", { attrs: { type: "number", unit: "€", "show-spin-buttons": "", step: "0.01", decimals: 2 }, model: { value: n.localSolarOptions.userOptions.gridPurchaseCosts, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "gridPurchaseCosts", n._n(u));
    }, expression: `
                      localSolarOptions.userOptions.gridPurchaseCosts
                    ` } })], 1)], 1), l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.costs.supply")))])], 1), l("v-col", [l("VcsTextField", { attrs: { type: "number", unit: "€", "show-spin-buttons": "", step: "0.001", decimals: 3 }, model: { value: n.localSolarOptions.userOptions.feedInTariff, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "feedInTariff", n._n(u));
    }, expression: `
                      localSolarOptions.userOptions.feedInTariff
                    ` } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsCheckbox", { attrs: { label: "solarRevenue.revenue.costs.isIncrease" }, model: { value: n.isPriceIncrease, callback: function(u) {
      n.isPriceIncrease = u;
    }, expression: "isPriceIncrease" } })], 1)], 1), l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.costs.increase")))])], 1), l("v-col", [l("VcsTextField", { attrs: { disabled: !n.isPriceIncrease, type: "number", unit: "%", "show-spin-buttons": "", step: "0.1", decimals: 1 }, model: { value: n.localSolarOptions.userOptions.electricityPriceIncrease, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "electricityPriceIncrease", n._n(u));
    }, expression: `
                      localSolarOptions.userOptions.electricityPriceIncrease
                    ` } })], 1)], 1)], 1)];
  }, proxy: !0 }]), model: { value: n.currentStep, callback: function(u) {
    n.currentStep = n._n(u);
  }, expression: "currentStep" } }), l("VcsWizardStep", { attrs: { step: n.stepOrder.FINANCE, editable: "", "help-text": "solarRevenue.revenue.help.finance", heading: "solarRevenue.revenue.finance.title" }, scopedSlots: n._u([{ key: "content", fn: function() {
    return [l("v-container", { staticClass: "px-1 py-0" }, [l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.finance.isFinance")))])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("v-switch", { staticClass: "ma-0", attrs: { "hide-details": "" }, model: { value: n.localIsFinance, callback: function(u) {
      n.localIsFinance = u;
    }, expression: "localIsFinance" } })], 1)], 1), l("v-row", { staticClass: "align-center font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.finance.invest")))])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.investmentCosts, unit: "€", "fraction-digits": 2 } })], 1)], 1), n.localIsFinance ? l("v-container", { staticClass: "px-0 py-0" }, [l("v-row", { staticClass: "align-center font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.finance.credit")))])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.creditAmount, unit: "€", "fraction-digits": 2 } })], 1)], 1), l("v-divider"), l("v-row", { staticClass: "align-center pt-2", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.finance.equity")))])], 1), l("v-col", [l("VcsTextField", { attrs: { type: "number", unit: "€", "show-spin-buttons": "", rules: [n.creditRule], step: 500, decimals: 0 }, model: { value: n.localSolarOptions.userOptions.equityCapital, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "equityCapital", n._n(u));
    }, expression: `
                        localSolarOptions.userOptions.equityCapital
                      ` } })], 1)], 1), l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.finance.duration")))])], 1), l("v-col", [l("VcsTextField", { attrs: { type: "number", unit: n.$t(
      "solarRevenue.revenue.finance.durationUnit"
    ).toString(), "show-spin-buttons": "", max: 40, min: 1, step: 1, decimals: 0 }, model: { value: n.localSolarOptions.userOptions.creditPeriod, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "creditPeriod", n._n(u));
    }, expression: `
                        localSolarOptions.userOptions.creditPeriod
                      ` } })], 1)], 1), l("v-row", { staticClass: "align-center", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.revenue.finance.interest")))])], 1), l("v-col", [l("VcsTextField", { attrs: { type: "number", unit: "%", "show-spin-buttons": "", max: 30, min: 0, step: 0.1 }, model: { value: n.localSolarOptions.userOptions.creditInterest, callback: function(u) {
      n.$set(n.localSolarOptions.userOptions, "creditInterest", n._n(u));
    }, expression: `
                        localSolarOptions.userOptions.creditInterest
                      ` } })], 1)], 1)], 1) : n._e()], 1)];
  }, proxy: !0 }]), model: { value: n.currentStep, callback: function(u) {
    n.currentStep = n._n(u);
  }, expression: "currentStep" } })], 1)], 1)], 1)], 1);
}, Vn = [], Gn = /* @__PURE__ */ vt(
  Bn,
  Wn,
  Vn,
  !1,
  null,
  null,
  null,
  null
);
const jn = Gn.exports;
var as = { exports: {} }, Ht = { exports: {} };
/*!
 * ApexCharts v3.45.1
 * (c) 2018-2023 ApexCharts
 * Released under the MIT License.
 */
var Ea;
function $n() {
  return Ea || (Ea = 1, function(v, n) {
    (function(l, u) {
      v.exports = u();
    })(Kt, function() {
      function l(P, e) {
        var t = Object.keys(P);
        if (Object.getOwnPropertySymbols) {
          var i = Object.getOwnPropertySymbols(P);
          e && (i = i.filter(function(a) {
            return Object.getOwnPropertyDescriptor(P, a).enumerable;
          })), t.push.apply(t, i);
        }
        return t;
      }
      function u(P) {
        for (var e = 1; e < arguments.length; e++) {
          var t = arguments[e] != null ? arguments[e] : {};
          e % 2 ? l(Object(t), !0).forEach(function(i) {
            T(P, i, t[i]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(P, Object.getOwnPropertyDescriptors(t)) : l(Object(t)).forEach(function(i) {
            Object.defineProperty(P, i, Object.getOwnPropertyDescriptor(t, i));
          });
        }
        return P;
      }
      function b(P) {
        return b = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, b(P);
      }
      function y(P, e) {
        if (!(P instanceof e))
          throw new TypeError("Cannot call a class as a function");
      }
      function I(P, e) {
        for (var t = 0; t < e.length; t++) {
          var i = e[t];
          i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(P, i.key, i);
        }
      }
      function A(P, e, t) {
        return e && I(P.prototype, e), t && I(P, t), P;
      }
      function T(P, e, t) {
        return e in P ? Object.defineProperty(P, e, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : P[e] = t, P;
      }
      function z(P, e) {
        if (typeof e != "function" && e !== null)
          throw new TypeError("Super expression must either be null or a function");
        P.prototype = Object.create(e && e.prototype, { constructor: { value: P, writable: !0, configurable: !0 } }), e && F(P, e);
      }
      function H(P) {
        return H = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
          return e.__proto__ || Object.getPrototypeOf(e);
        }, H(P);
      }
      function F(P, e) {
        return F = Object.setPrototypeOf || function(t, i) {
          return t.__proto__ = i, t;
        }, F(P, e);
      }
      function D(P) {
        if (P === void 0)
          throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return P;
      }
      function W(P) {
        var e = function() {
          if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham)
            return !1;
          if (typeof Proxy == "function")
            return !0;
          try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
            })), !0;
          } catch {
            return !1;
          }
        }();
        return function() {
          var t, i = H(P);
          if (e) {
            var a = H(this).constructor;
            t = Reflect.construct(i, arguments, a);
          } else
            t = i.apply(this, arguments);
          return function(s, r) {
            if (r && (typeof r == "object" || typeof r == "function"))
              return r;
            if (r !== void 0)
              throw new TypeError("Derived constructors may only return object or undefined");
            return D(s);
          }(this, t);
        };
      }
      function B(P, e) {
        return function(t) {
          if (Array.isArray(t))
            return t;
        }(P) || function(t, i) {
          var a = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
          if (a != null) {
            var s, r, o = [], c = !0, d = !1;
            try {
              for (a = a.call(t); !(c = (s = a.next()).done) && (o.push(s.value), !i || o.length !== i); c = !0)
                ;
            } catch (g) {
              d = !0, r = g;
            } finally {
              try {
                c || a.return == null || a.return();
              } finally {
                if (d)
                  throw r;
              }
            }
            return o;
          }
        }(P, e) || ee(P, e) || function() {
          throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
        }();
      }
      function j(P) {
        return function(e) {
          if (Array.isArray(e))
            return te(e);
        }(P) || function(e) {
          if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null)
            return Array.from(e);
        }(P) || ee(P) || function() {
          throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
        }();
      }
      function ee(P, e) {
        if (P) {
          if (typeof P == "string")
            return te(P, e);
          var t = Object.prototype.toString.call(P).slice(8, -1);
          return t === "Object" && P.constructor && (t = P.constructor.name), t === "Map" || t === "Set" ? Array.from(P) : t === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? te(P, e) : void 0;
        }
      }
      function te(P, e) {
        (e == null || e > P.length) && (e = P.length);
        for (var t = 0, i = new Array(e); t < e; t++)
          i[t] = P[t];
        return i;
      }
      var M = function() {
        function P() {
          y(this, P);
        }
        return A(P, [{ key: "shadeRGBColor", value: function(e, t) {
          var i = t.split(","), a = e < 0 ? 0 : 255, s = e < 0 ? -1 * e : e, r = parseInt(i[0].slice(4), 10), o = parseInt(i[1], 10), c = parseInt(i[2], 10);
          return "rgb(" + (Math.round((a - r) * s) + r) + "," + (Math.round((a - o) * s) + o) + "," + (Math.round((a - c) * s) + c) + ")";
        } }, { key: "shadeHexColor", value: function(e, t) {
          var i = parseInt(t.slice(1), 16), a = e < 0 ? 0 : 255, s = e < 0 ? -1 * e : e, r = i >> 16, o = i >> 8 & 255, c = 255 & i;
          return "#" + (16777216 + 65536 * (Math.round((a - r) * s) + r) + 256 * (Math.round((a - o) * s) + o) + (Math.round((a - c) * s) + c)).toString(16).slice(1);
        } }, { key: "shadeColor", value: function(e, t) {
          return P.isColorHex(t) ? this.shadeHexColor(e, t) : this.shadeRGBColor(e, t);
        } }], [{ key: "bind", value: function(e, t) {
          return function() {
            return e.apply(t, arguments);
          };
        } }, { key: "isObject", value: function(e) {
          return e && b(e) === "object" && !Array.isArray(e) && e != null;
        } }, { key: "is", value: function(e, t) {
          return Object.prototype.toString.call(t) === "[object " + e + "]";
        } }, { key: "listToArray", value: function(e) {
          var t, i = [];
          for (t = 0; t < e.length; t++)
            i[t] = e[t];
          return i;
        } }, { key: "extend", value: function(e, t) {
          var i = this;
          typeof Object.assign != "function" && (Object.assign = function(s) {
            if (s == null)
              throw new TypeError("Cannot convert undefined or null to object");
            for (var r = Object(s), o = 1; o < arguments.length; o++) {
              var c = arguments[o];
              if (c != null)
                for (var d in c)
                  c.hasOwnProperty(d) && (r[d] = c[d]);
            }
            return r;
          });
          var a = Object.assign({}, e);
          return this.isObject(e) && this.isObject(t) && Object.keys(t).forEach(function(s) {
            i.isObject(t[s]) && s in e ? a[s] = i.extend(e[s], t[s]) : Object.assign(a, T({}, s, t[s]));
          }), a;
        } }, { key: "extendArray", value: function(e, t) {
          var i = [];
          return e.map(function(a) {
            i.push(P.extend(t, a));
          }), e = i;
        } }, { key: "monthMod", value: function(e) {
          return e % 12;
        } }, { key: "clone", value: function(e) {
          if (P.is("Array", e)) {
            for (var t = [], i = 0; i < e.length; i++)
              t[i] = this.clone(e[i]);
            return t;
          }
          if (P.is("Null", e))
            return null;
          if (P.is("Date", e))
            return e;
          if (b(e) === "object") {
            var a = {};
            for (var s in e)
              e.hasOwnProperty(s) && (a[s] = this.clone(e[s]));
            return a;
          }
          return e;
        } }, { key: "log10", value: function(e) {
          return Math.log(e) / Math.LN10;
        } }, { key: "roundToBase10", value: function(e) {
          return Math.pow(10, Math.floor(Math.log10(e)));
        } }, { key: "roundToBase", value: function(e, t) {
          return Math.pow(t, Math.floor(Math.log(e) / Math.log(t)));
        } }, { key: "parseNumber", value: function(e) {
          return e === null ? e : parseFloat(e);
        } }, { key: "stripNumber", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 2;
          return Number.isInteger(e) ? e : parseFloat(e.toPrecision(t));
        } }, { key: "randomId", value: function() {
          return (Math.random() + 1).toString(36).substring(4);
        } }, { key: "noExponents", value: function(e) {
          var t = String(e).split(/[eE]/);
          if (t.length === 1)
            return t[0];
          var i = "", a = e < 0 ? "-" : "", s = t[0].replace(".", ""), r = Number(t[1]) + 1;
          if (r < 0) {
            for (i = a + "0."; r++; )
              i += "0";
            return i + s.replace(/^-/, "");
          }
          for (r -= s.length; r--; )
            i += "0";
          return s + i;
        } }, { key: "getDimensions", value: function(e) {
          var t = getComputedStyle(e, null), i = e.clientHeight, a = e.clientWidth;
          return i -= parseFloat(t.paddingTop) + parseFloat(t.paddingBottom), [a -= parseFloat(t.paddingLeft) + parseFloat(t.paddingRight), i];
        } }, { key: "getBoundingClientRect", value: function(e) {
          var t = e.getBoundingClientRect();
          return { top: t.top, right: t.right, bottom: t.bottom, left: t.left, width: e.clientWidth, height: e.clientHeight, x: t.left, y: t.top };
        } }, { key: "getLargestStringFromArr", value: function(e) {
          return e.reduce(function(t, i) {
            return Array.isArray(i) && (i = i.reduce(function(a, s) {
              return a.length > s.length ? a : s;
            })), t.length > i.length ? t : i;
          }, 0);
        } }, { key: "hexToRgba", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "#999999", t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0.6;
          e.substring(0, 1) !== "#" && (e = "#999999");
          var i = e.replace("#", "");
          i = i.match(new RegExp("(.{" + i.length / 3 + "})", "g"));
          for (var a = 0; a < i.length; a++)
            i[a] = parseInt(i[a].length === 1 ? i[a] + i[a] : i[a], 16);
          return t !== void 0 && i.push(t), "rgba(" + i.join(",") + ")";
        } }, { key: "getOpacityFromRGBA", value: function(e) {
          return parseFloat(e.replace(/^.*,(.+)\)/, "$1"));
        } }, { key: "rgb2hex", value: function(e) {
          return (e = e.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i)) && e.length === 4 ? "#" + ("0" + parseInt(e[1], 10).toString(16)).slice(-2) + ("0" + parseInt(e[2], 10).toString(16)).slice(-2) + ("0" + parseInt(e[3], 10).toString(16)).slice(-2) : "";
        } }, { key: "isColorHex", value: function(e) {
          return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)|(^#[0-9A-F]{8}$)/i.test(e);
        } }, { key: "getPolygonPos", value: function(e, t) {
          for (var i = [], a = 2 * Math.PI / t, s = 0; s < t; s++) {
            var r = {};
            r.x = e * Math.sin(s * a), r.y = -e * Math.cos(s * a), i.push(r);
          }
          return i;
        } }, { key: "polarToCartesian", value: function(e, t, i, a) {
          var s = (a - 90) * Math.PI / 180;
          return { x: e + i * Math.cos(s), y: t + i * Math.sin(s) };
        } }, { key: "escapeString", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "x", i = e.toString().slice();
          return i = i.replace(/[` ~!@#$%^&*()|+\=?;:'",.<>{}[\]\\/]/gi, t);
        } }, { key: "negToZero", value: function(e) {
          return e < 0 ? 0 : e;
        } }, { key: "moveIndexInArray", value: function(e, t, i) {
          if (i >= e.length)
            for (var a = i - e.length + 1; a--; )
              e.push(void 0);
          return e.splice(i, 0, e.splice(t, 1)[0]), e;
        } }, { key: "extractNumber", value: function(e) {
          return parseFloat(e.replace(/[^\d.]*/g, ""));
        } }, { key: "findAncestor", value: function(e, t) {
          for (; (e = e.parentElement) && !e.classList.contains(t); )
            ;
          return e;
        } }, { key: "setELstyles", value: function(e, t) {
          for (var i in t)
            t.hasOwnProperty(i) && (e.style.key = t[i]);
        } }, { key: "isNumber", value: function(e) {
          return !isNaN(e) && parseFloat(Number(e)) === e && !isNaN(parseInt(e, 10));
        } }, { key: "isFloat", value: function(e) {
          return Number(e) === e && e % 1 != 0;
        } }, { key: "isSafari", value: function() {
          return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
        } }, { key: "isFirefox", value: function() {
          return navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
        } }, { key: "isIE11", value: function() {
          if (window.navigator.userAgent.indexOf("MSIE") !== -1 || window.navigator.appVersion.indexOf("Trident/") > -1)
            return !0;
        } }, { key: "isIE", value: function() {
          var e = window.navigator.userAgent, t = e.indexOf("MSIE ");
          if (t > 0)
            return parseInt(e.substring(t + 5, e.indexOf(".", t)), 10);
          if (e.indexOf("Trident/") > 0) {
            var i = e.indexOf("rv:");
            return parseInt(e.substring(i + 3, e.indexOf(".", i)), 10);
          }
          var a = e.indexOf("Edge/");
          return a > 0 && parseInt(e.substring(a + 5, e.indexOf(".", a)), 10);
        } }]), P;
      }(), V = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.setEasingFunctions();
        }
        return A(P, [{ key: "setEasingFunctions", value: function() {
          var e;
          if (!this.w.globals.easing) {
            switch (this.w.config.chart.animations.easing) {
              case "linear":
                e = "-";
                break;
              case "easein":
                e = "<";
                break;
              case "easeout":
                e = ">";
                break;
              case "easeinout":
              default:
                e = "<>";
                break;
              case "swing":
                e = function(t) {
                  var i = 1.70158;
                  return (t -= 1) * t * ((i + 1) * t + i) + 1;
                };
                break;
              case "bounce":
                e = function(t) {
                  return t < 1 / 2.75 ? 7.5625 * t * t : t < 2 / 2.75 ? 7.5625 * (t -= 1.5 / 2.75) * t + 0.75 : t < 2.5 / 2.75 ? 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375 : 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
                };
                break;
              case "elastic":
                e = function(t) {
                  return t === !!t ? t : Math.pow(2, -10 * t) * Math.sin((t - 0.075) * (2 * Math.PI) / 0.3) + 1;
                };
            }
            this.w.globals.easing = e;
          }
        } }, { key: "animateLine", value: function(e, t, i, a) {
          e.attr(t).animate(a).attr(i);
        } }, { key: "animateMarker", value: function(e, t, i, a, s, r) {
          t || (t = 0), e.attr({ r: t, width: t, height: t }).animate(a, s).attr({ r: i, width: i.width, height: i.height }).afterAll(function() {
            r();
          });
        } }, { key: "animateCircle", value: function(e, t, i, a, s) {
          e.attr({ r: t.r, cx: t.cx, cy: t.cy }).animate(a, s).attr({ r: i.r, cx: i.cx, cy: i.cy });
        } }, { key: "animateRect", value: function(e, t, i, a, s) {
          e.attr(t).animate(a).attr(i).afterAll(function() {
            return s();
          });
        } }, { key: "animatePathsGradually", value: function(e) {
          var t = e.el, i = e.realIndex, a = e.j, s = e.fill, r = e.pathFrom, o = e.pathTo, c = e.speed, d = e.delay, g = this.w, f = 0;
          g.config.chart.animations.animateGradually.enabled && (f = g.config.chart.animations.animateGradually.delay), g.config.chart.animations.dynamicAnimation.enabled && g.globals.dataChanged && g.config.chart.type !== "bar" && (f = 0), this.morphSVG(t, i, a, g.config.chart.type !== "line" || g.globals.comboCharts ? s : "stroke", r, o, c, d * f);
        } }, { key: "showDelayedElements", value: function() {
          this.w.globals.delayedElements.forEach(function(e) {
            var t = e.el;
            t.classList.remove("apexcharts-element-hidden"), t.classList.add("apexcharts-hidden-element-shown");
          });
        } }, { key: "animationCompleted", value: function(e) {
          var t = this.w;
          t.globals.animationEnded || (t.globals.animationEnded = !0, this.showDelayedElements(), typeof t.config.chart.events.animationEnd == "function" && t.config.chart.events.animationEnd(this.ctx, { el: e, w: t }));
        } }, { key: "morphSVG", value: function(e, t, i, a, s, r, o, c) {
          var d = this, g = this.w;
          s || (s = e.attr("pathFrom")), r || (r = e.attr("pathTo"));
          var f = function(p) {
            return g.config.chart.type === "radar" && (o = 1), "M 0 ".concat(g.globals.gridHeight);
          };
          (!s || s.indexOf("undefined") > -1 || s.indexOf("NaN") > -1) && (s = f()), (!r || r.indexOf("undefined") > -1 || r.indexOf("NaN") > -1) && (r = f()), g.globals.shouldAnimate || (o = 1), e.plot(s).animate(1, g.globals.easing, c).plot(s).animate(o, g.globals.easing, c).plot(r).afterAll(function() {
            M.isNumber(i) ? i === g.globals.series[g.globals.maxValsInArrayIndex].length - 2 && g.globals.shouldAnimate && d.animationCompleted(e) : a !== "none" && g.globals.shouldAnimate && (!g.globals.comboCharts && t === g.globals.series.length - 1 || g.globals.comboCharts) && d.animationCompleted(e), d.showDelayedElements();
          });
        } }]), P;
      }(), G = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "getDefaultFilter", value: function(e, t) {
          var i = this.w;
          e.unfilter(!0), new window.SVG.Filter().size("120%", "180%", "-5%", "-40%"), i.config.states.normal.filter !== "none" ? this.applyFilter(e, t, i.config.states.normal.filter.type, i.config.states.normal.filter.value) : i.config.chart.dropShadow.enabled && this.dropShadow(e, i.config.chart.dropShadow, t);
        } }, { key: "addNormalFilter", value: function(e, t) {
          var i = this.w;
          i.config.chart.dropShadow.enabled && !e.node.classList.contains("apexcharts-marker") && this.dropShadow(e, i.config.chart.dropShadow, t);
        } }, { key: "addLightenFilter", value: function(e, t, i) {
          var a = this, s = this.w, r = i.intensity;
          e.unfilter(!0), new window.SVG.Filter(), e.filter(function(o) {
            var c = s.config.chart.dropShadow;
            (c.enabled ? a.addShadow(o, t, c) : o).componentTransfer({ rgb: { type: "linear", slope: 1.5, intercept: r } });
          }), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node);
        } }, { key: "addDarkenFilter", value: function(e, t, i) {
          var a = this, s = this.w, r = i.intensity;
          e.unfilter(!0), new window.SVG.Filter(), e.filter(function(o) {
            var c = s.config.chart.dropShadow;
            (c.enabled ? a.addShadow(o, t, c) : o).componentTransfer({ rgb: { type: "linear", slope: r } });
          }), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node);
        } }, { key: "applyFilter", value: function(e, t, i) {
          var a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0.5;
          switch (i) {
            case "none":
              this.addNormalFilter(e, t);
              break;
            case "lighten":
              this.addLightenFilter(e, t, { intensity: a });
              break;
            case "darken":
              this.addDarkenFilter(e, t, { intensity: a });
          }
        } }, { key: "addShadow", value: function(e, t, i) {
          var a = i.blur, s = i.top, r = i.left, o = i.color, c = i.opacity, d = e.flood(Array.isArray(o) ? o[t] : o, c).composite(e.sourceAlpha, "in").offset(r, s).gaussianBlur(a).merge(e.source);
          return e.blend(e.source, d);
        } }, { key: "dropShadow", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, a = t.top, s = t.left, r = t.blur, o = t.color, c = t.opacity, d = t.noUserSpaceOnUse, g = this.w;
          return e.unfilter(!0), M.isIE() && g.config.chart.type === "radialBar" || (o = Array.isArray(o) ? o[i] : o, e.filter(function(f) {
            var p = null;
            p = M.isSafari() || M.isFirefox() || M.isIE() ? f.flood(o, c).composite(f.sourceAlpha, "in").offset(s, a).gaussianBlur(r) : f.flood(o, c).composite(f.sourceAlpha, "in").offset(s, a).gaussianBlur(r).merge(f.source), f.blend(f.source, p);
          }), d || e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node)), e;
        } }, { key: "setSelectionFilter", value: function(e, t, i) {
          var a = this.w;
          if (a.globals.selectedDataPoints[t] !== void 0 && a.globals.selectedDataPoints[t].indexOf(i) > -1) {
            e.node.setAttribute("selected", !0);
            var s = a.config.states.active.filter;
            s !== "none" && this.applyFilter(e, t, s.type, s.value);
          }
        } }, { key: "_scaleFilterSize", value: function(e) {
          (function(t) {
            for (var i in t)
              t.hasOwnProperty(i) && e.setAttribute(i, t[i]);
          })({ width: "200%", height: "200%", x: "-50%", y: "-50%" });
        } }]), P;
      }(), X = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "roundPathCorners", value: function(e, t) {
          function i(O, Y, N) {
            var q = Y.x - O.x, Z = Y.y - O.y, U = Math.sqrt(q * q + Z * Z);
            return a(O, Y, Math.min(1, N / U));
          }
          function a(O, Y, N) {
            return { x: O.x + (Y.x - O.x) * N, y: O.y + (Y.y - O.y) * N };
          }
          function s(O, Y) {
            O.length > 2 && (O[O.length - 2] = Y.x, O[O.length - 1] = Y.y);
          }
          function r(O) {
            return { x: parseFloat(O[O.length - 2]), y: parseFloat(O[O.length - 1]) };
          }
          e.indexOf("NaN") > -1 && (e = "");
          var o = e.split(/[,\s]/).reduce(function(O, Y) {
            var N = Y.match("([a-zA-Z])(.+)");
            return N ? (O.push(N[1]), O.push(N[2])) : O.push(Y), O;
          }, []).reduce(function(O, Y) {
            return parseFloat(Y) == Y && O.length ? O[O.length - 1].push(Y) : O.push([Y]), O;
          }, []), c = [];
          if (o.length > 1) {
            var d = r(o[0]), g = null;
            o[o.length - 1][0] == "Z" && o[0].length > 2 && (g = ["L", d.x, d.y], o[o.length - 1] = g), c.push(o[0]);
            for (var f = 1; f < o.length; f++) {
              var p = c[c.length - 1], m = o[f], w = m == g ? o[1] : o[f + 1];
              if (w && p && p.length > 2 && m[0] == "L" && w.length > 2 && w[0] == "L") {
                var C, k, E = r(p), _ = r(m), h = r(w);
                C = i(_, E, t), k = i(_, h, t), s(m, C), m.origPoint = _, c.push(m);
                var x = a(C, _, 0.5), S = a(_, k, 0.5), L = ["C", x.x, x.y, S.x, S.y, k.x, k.y];
                L.origPoint = _, c.push(L);
              } else
                c.push(m);
            }
            if (g) {
              var R = r(c[c.length - 1]);
              c.push(["Z"]), s(c[0], R);
            }
          } else
            c = o;
          return c.reduce(function(O, Y) {
            return O + Y.join(" ") + " ";
          }, "");
        } }, { key: "drawLine", value: function(e, t, i, a) {
          var s = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : "#a8a8a8", r = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : 0, o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : null, c = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : "butt";
          return this.w.globals.dom.Paper.line().attr({ x1: e, y1: t, x2: i, y2: a, stroke: s, "stroke-dasharray": r, "stroke-width": o, "stroke-linecap": c });
        } }, { key: "drawRect", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0, s = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0, r = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : "#fefefe", o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : 1, c = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : null, d = arguments.length > 8 && arguments[8] !== void 0 ? arguments[8] : null, g = arguments.length > 9 && arguments[9] !== void 0 ? arguments[9] : 0, f = this.w.globals.dom.Paper.rect();
          return f.attr({ x: e, y: t, width: i > 0 ? i : 0, height: a > 0 ? a : 0, rx: s, ry: s, opacity: o, "stroke-width": c !== null ? c : 0, stroke: d !== null ? d : "none", "stroke-dasharray": g }), f.node.setAttribute("fill", r), f;
        } }, { key: "drawPolygon", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "#e1e1e1", i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "none";
          return this.w.globals.dom.Paper.polygon(e).attr({ fill: a, stroke: t, "stroke-width": i });
        } }, { key: "drawCircle", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
          e < 0 && (e = 0);
          var i = this.w.globals.dom.Paper.circle(2 * e);
          return t !== null && i.attr(t), i;
        } }, { key: "drawPath", value: function(e) {
          var t = e.d, i = t === void 0 ? "" : t, a = e.stroke, s = a === void 0 ? "#a8a8a8" : a, r = e.strokeWidth, o = r === void 0 ? 1 : r, c = e.fill, d = e.fillOpacity, g = d === void 0 ? 1 : d, f = e.strokeOpacity, p = f === void 0 ? 1 : f, m = e.classes, w = e.strokeLinecap, C = w === void 0 ? null : w, k = e.strokeDashArray, E = k === void 0 ? 0 : k, _ = this.w;
          return C === null && (C = _.config.stroke.lineCap), (i.indexOf("undefined") > -1 || i.indexOf("NaN") > -1) && (i = "M 0 ".concat(_.globals.gridHeight)), _.globals.dom.Paper.path(i).attr({ fill: c, "fill-opacity": g, stroke: s, "stroke-opacity": p, "stroke-linecap": C, "stroke-width": o, "stroke-dasharray": E, class: m });
        } }, { key: "group", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null, t = this.w.globals.dom.Paper.group();
          return e !== null && t.attr(e), t;
        } }, { key: "move", value: function(e, t) {
          var i = ["M", e, t].join(" ");
          return i;
        } }, { key: "line", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = null;
          return i === null ? a = [" L", e, t].join(" ") : i === "H" ? a = [" H", e].join(" ") : i === "V" && (a = [" V", t].join(" ")), a;
        } }, { key: "curve", value: function(e, t, i, a, s, r) {
          var o = ["C", e, t, i, a, s, r].join(" ");
          return o;
        } }, { key: "quadraticCurve", value: function(e, t, i, a) {
          return ["Q", e, t, i, a].join(" ");
        } }, { key: "arc", value: function(e, t, i, a, s, r, o) {
          var c = "A";
          arguments.length > 7 && arguments[7] !== void 0 && arguments[7] && (c = "a");
          var d = [c, e, t, i, a, s, r, o].join(" ");
          return d;
        } }, { key: "renderPaths", value: function(e) {
          var t, i = e.j, a = e.realIndex, s = e.pathFrom, r = e.pathTo, o = e.stroke, c = e.strokeWidth, d = e.strokeLinecap, g = e.fill, f = e.animationDelay, p = e.initialSpeed, m = e.dataChangeSpeed, w = e.className, C = e.shouldClipToGrid, k = C === void 0 || C, E = e.bindEventsOnPaths, _ = E === void 0 || E, h = e.drawShadow, x = h === void 0 || h, S = this.w, L = new G(this.ctx), R = new V(this.ctx), O = this.w.config.chart.animations.enabled, Y = O && this.w.config.chart.animations.dynamicAnimation.enabled, N = !!(O && !S.globals.resized || Y && S.globals.dataChanged && S.globals.shouldAnimate);
          N ? t = s : (t = r, S.globals.animationEnded = !0);
          var q = S.config.stroke.dashArray, Z = 0;
          Z = Array.isArray(q) ? q[a] : S.config.stroke.dashArray;
          var U = this.drawPath({ d: t, stroke: o, strokeWidth: c, fill: g, fillOpacity: 1, classes: w, strokeLinecap: d, strokeDashArray: Z });
          if (U.attr("index", a), k && U.attr({ "clip-path": "url(#gridRectMask".concat(S.globals.cuid, ")") }), S.config.states.normal.filter.type !== "none")
            L.getDefaultFilter(U, a);
          else if (S.config.chart.dropShadow.enabled && x && (!S.config.chart.dropShadow.enabledOnSeries || S.config.chart.dropShadow.enabledOnSeries && S.config.chart.dropShadow.enabledOnSeries.indexOf(a) !== -1)) {
            var se = S.config.chart.dropShadow;
            L.dropShadow(U, se, a);
          }
          _ && (U.node.addEventListener("mouseenter", this.pathMouseEnter.bind(this, U)), U.node.addEventListener("mouseleave", this.pathMouseLeave.bind(this, U)), U.node.addEventListener("mousedown", this.pathMouseDown.bind(this, U))), U.attr({ pathTo: r, pathFrom: s });
          var he = { el: U, j: i, realIndex: a, pathFrom: s, pathTo: r, fill: g, strokeWidth: c, delay: f };
          return !O || S.globals.resized || S.globals.dataChanged ? !S.globals.resized && S.globals.dataChanged || R.showDelayedElements() : R.animatePathsGradually(u(u({}, he), {}, { speed: p })), S.globals.dataChanged && Y && N && R.animatePathsGradually(u(u({}, he), {}, { speed: m })), U;
        } }, { key: "drawPattern", value: function(e, t, i) {
          var a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "#a8a8a8", s = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0;
          return this.w.globals.dom.Paper.pattern(t, i, function(r) {
            e === "horizontalLines" ? r.line(0, 0, i, 0).stroke({ color: a, width: s + 1 }) : e === "verticalLines" ? r.line(0, 0, 0, t).stroke({ color: a, width: s + 1 }) : e === "slantedLines" ? r.line(0, 0, t, i).stroke({ color: a, width: s }) : e === "squares" ? r.rect(t, i).fill("none").stroke({ color: a, width: s }) : e === "circles" && r.circle(t).fill("none").stroke({ color: a, width: s });
          });
        } }, { key: "drawGradient", value: function(e, t, i, a, s) {
          var r, o = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : null, c = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : null, d = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : null, g = arguments.length > 8 && arguments[8] !== void 0 ? arguments[8] : 0, f = this.w;
          t.length < 9 && t.indexOf("#") === 0 && (t = M.hexToRgba(t, a)), i.length < 9 && i.indexOf("#") === 0 && (i = M.hexToRgba(i, s));
          var p = 0, m = 1, w = 1, C = null;
          c !== null && (p = c[0] !== void 0 ? c[0] / 100 : 0, m = c[1] !== void 0 ? c[1] / 100 : 1, w = c[2] !== void 0 ? c[2] / 100 : 1, C = c[3] !== void 0 ? c[3] / 100 : null);
          var k = !(f.config.chart.type !== "donut" && f.config.chart.type !== "pie" && f.config.chart.type !== "polarArea" && f.config.chart.type !== "bubble");
          if (r = d === null || d.length === 0 ? f.globals.dom.Paper.gradient(k ? "radial" : "linear", function(h) {
            h.at(p, t, a), h.at(m, i, s), h.at(w, i, s), C !== null && h.at(C, t, a);
          }) : f.globals.dom.Paper.gradient(k ? "radial" : "linear", function(h) {
            (Array.isArray(d[g]) ? d[g] : d).forEach(function(x) {
              h.at(x.offset / 100, x.color, x.opacity);
            });
          }), k) {
            var E = f.globals.gridWidth / 2, _ = f.globals.gridHeight / 2;
            f.config.chart.type !== "bubble" ? r.attr({ gradientUnits: "userSpaceOnUse", cx: E, cy: _, r: o }) : r.attr({ cx: 0.5, cy: 0.5, r: 0.8, fx: 0.2, fy: 0.2 });
          } else
            e === "vertical" ? r.from(0, 0).to(0, 1) : e === "diagonal" ? r.from(0, 0).to(1, 1) : e === "horizontal" ? r.from(0, 1).to(1, 1) : e === "diagonal2" && r.from(1, 0).to(0, 1);
          return r;
        } }, { key: "getTextBasedOnMaxWidth", value: function(e) {
          var t = e.text, i = e.maxWidth, a = e.fontSize, s = e.fontFamily, r = this.getTextRects(t, a, s), o = r.width / t.length, c = Math.floor(i / o);
          return i < r.width ? t.slice(0, c - 3) + "..." : t;
        } }, { key: "drawText", value: function(e) {
          var t = this, i = e.x, a = e.y, s = e.text, r = e.textAnchor, o = e.fontSize, c = e.fontFamily, d = e.fontWeight, g = e.foreColor, f = e.opacity, p = e.maxWidth, m = e.cssClass, w = m === void 0 ? "" : m, C = e.isPlainText, k = C === void 0 || C, E = e.dominantBaseline, _ = E === void 0 ? "auto" : E, h = this.w;
          s === void 0 && (s = "");
          var x = s;
          r || (r = "start"), g && g.length || (g = h.config.chart.foreColor), c = c || h.config.chart.fontFamily, d = d || "regular";
          var S, L = { maxWidth: p, fontSize: o = o || "11px", fontFamily: c };
          return Array.isArray(s) ? S = h.globals.dom.Paper.text(function(R) {
            for (var O = 0; O < s.length; O++)
              x = s[O], p && (x = t.getTextBasedOnMaxWidth(u({ text: s[O] }, L))), O === 0 ? R.tspan(x) : R.tspan(x).newLine();
          }) : (p && (x = this.getTextBasedOnMaxWidth(u({ text: s }, L))), S = k ? h.globals.dom.Paper.plain(s) : h.globals.dom.Paper.text(function(R) {
            return R.tspan(x);
          })), S.attr({ x: i, y: a, "text-anchor": r, "dominant-baseline": _, "font-size": o, "font-family": c, "font-weight": d, fill: g, class: "apexcharts-text " + w }), S.node.style.fontFamily = c, S.node.style.opacity = f, S;
        } }, { key: "drawMarker", value: function(e, t, i) {
          e = e || 0;
          var a = i.pSize || 0, s = null;
          if (i.shape === "square" || i.shape === "rect") {
            var r = i.pRadius === void 0 ? a / 2 : i.pRadius;
            t !== null && a || (a = 0, r = 0);
            var o = 1.2 * a + r, c = this.drawRect(o, o, o, o, r);
            c.attr({ x: e - o / 2, y: t - o / 2, cx: e, cy: t, class: i.class ? i.class : "", fill: i.pointFillColor, "fill-opacity": i.pointFillOpacity ? i.pointFillOpacity : 1, stroke: i.pointStrokeColor, "stroke-width": i.pointStrokeWidth ? i.pointStrokeWidth : 0, "stroke-opacity": i.pointStrokeOpacity ? i.pointStrokeOpacity : 1 }), s = c;
          } else
            i.shape !== "circle" && i.shape || (M.isNumber(t) || (a = 0, t = 0), s = this.drawCircle(a, { cx: e, cy: t, class: i.class ? i.class : "", stroke: i.pointStrokeColor, fill: i.pointFillColor, "fill-opacity": i.pointFillOpacity ? i.pointFillOpacity : 1, "stroke-width": i.pointStrokeWidth ? i.pointStrokeWidth : 0, "stroke-opacity": i.pointStrokeOpacity ? i.pointStrokeOpacity : 1 }));
          return s;
        } }, { key: "pathMouseEnter", value: function(e, t) {
          var i = this.w, a = new G(this.ctx), s = parseInt(e.node.getAttribute("index"), 10), r = parseInt(e.node.getAttribute("j"), 10);
          if (typeof i.config.chart.events.dataPointMouseEnter == "function" && i.config.chart.events.dataPointMouseEnter(t, this.ctx, { seriesIndex: s, dataPointIndex: r, w: i }), this.ctx.events.fireEvent("dataPointMouseEnter", [t, this.ctx, { seriesIndex: s, dataPointIndex: r, w: i }]), (i.config.states.active.filter.type === "none" || e.node.getAttribute("selected") !== "true") && i.config.states.hover.filter.type !== "none" && !i.globals.isTouchDevice) {
            var o = i.config.states.hover.filter;
            a.applyFilter(e, s, o.type, o.value);
          }
        } }, { key: "pathMouseLeave", value: function(e, t) {
          var i = this.w, a = new G(this.ctx), s = parseInt(e.node.getAttribute("index"), 10), r = parseInt(e.node.getAttribute("j"), 10);
          typeof i.config.chart.events.dataPointMouseLeave == "function" && i.config.chart.events.dataPointMouseLeave(t, this.ctx, { seriesIndex: s, dataPointIndex: r, w: i }), this.ctx.events.fireEvent("dataPointMouseLeave", [t, this.ctx, { seriesIndex: s, dataPointIndex: r, w: i }]), i.config.states.active.filter.type !== "none" && e.node.getAttribute("selected") === "true" || i.config.states.hover.filter.type !== "none" && a.getDefaultFilter(e, s);
        } }, { key: "pathMouseDown", value: function(e, t) {
          var i = this.w, a = new G(this.ctx), s = parseInt(e.node.getAttribute("index"), 10), r = parseInt(e.node.getAttribute("j"), 10), o = "false";
          if (e.node.getAttribute("selected") === "true") {
            if (e.node.setAttribute("selected", "false"), i.globals.selectedDataPoints[s].indexOf(r) > -1) {
              var c = i.globals.selectedDataPoints[s].indexOf(r);
              i.globals.selectedDataPoints[s].splice(c, 1);
            }
          } else {
            if (!i.config.states.active.allowMultipleDataPointsSelection && i.globals.selectedDataPoints.length > 0) {
              i.globals.selectedDataPoints = [];
              var d = i.globals.dom.Paper.select(".apexcharts-series path").members, g = i.globals.dom.Paper.select(".apexcharts-series circle, .apexcharts-series rect").members, f = function(w) {
                Array.prototype.forEach.call(w, function(C) {
                  C.node.setAttribute("selected", "false"), a.getDefaultFilter(C, s);
                });
              };
              f(d), f(g);
            }
            e.node.setAttribute("selected", "true"), o = "true", i.globals.selectedDataPoints[s] === void 0 && (i.globals.selectedDataPoints[s] = []), i.globals.selectedDataPoints[s].push(r);
          }
          if (o === "true") {
            var p = i.config.states.active.filter;
            if (p !== "none")
              a.applyFilter(e, s, p.type, p.value);
            else if (i.config.states.hover.filter !== "none" && !i.globals.isTouchDevice) {
              var m = i.config.states.hover.filter;
              a.applyFilter(e, s, m.type, m.value);
            }
          } else
            i.config.states.active.filter.type !== "none" && (i.config.states.hover.filter.type === "none" || i.globals.isTouchDevice ? a.getDefaultFilter(e, s) : (m = i.config.states.hover.filter, a.applyFilter(e, s, m.type, m.value)));
          typeof i.config.chart.events.dataPointSelection == "function" && i.config.chart.events.dataPointSelection(t, this.ctx, { selectedDataPoints: i.globals.selectedDataPoints, seriesIndex: s, dataPointIndex: r, w: i }), t && this.ctx.events.fireEvent("dataPointSelection", [t, this.ctx, { selectedDataPoints: i.globals.selectedDataPoints, seriesIndex: s, dataPointIndex: r, w: i }]);
        } }, { key: "rotateAroundCenter", value: function(e) {
          var t = {};
          return e && typeof e.getBBox == "function" && (t = e.getBBox()), { x: t.x + t.width / 2, y: t.y + t.height / 2 };
        } }, { key: "getTextRects", value: function(e, t, i, a) {
          var s = !(arguments.length > 4 && arguments[4] !== void 0) || arguments[4], r = this.w, o = this.drawText({ x: -200, y: -200, text: e, textAnchor: "start", fontSize: t, fontFamily: i, foreColor: "#fff", opacity: 0 });
          a && o.attr("transform", a), r.globals.dom.Paper.add(o);
          var c = o.bbox();
          return s || (c = o.node.getBoundingClientRect()), o.remove(), { width: c.width, height: c.height };
        } }, { key: "placeTextWithEllipsis", value: function(e, t, i) {
          if (typeof e.getComputedTextLength == "function" && (e.textContent = t, t.length > 0 && e.getComputedTextLength() >= i / 1.1)) {
            for (var a = t.length - 3; a > 0; a -= 3)
              if (e.getSubStringLength(0, a) <= i / 1.1)
                return void (e.textContent = t.substring(0, a) + "...");
            e.textContent = ".";
          }
        } }], [{ key: "setAttrs", value: function(e, t) {
          for (var i in t)
            t.hasOwnProperty(i) && e.setAttribute(i, t[i]);
        } }]), P;
      }(), $ = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "getStackedSeriesTotals", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], t = this.w, i = [];
          if (t.globals.series.length === 0)
            return i;
          for (var a = 0; a < t.globals.series[t.globals.maxValsInArrayIndex].length; a++) {
            for (var s = 0, r = 0; r < t.globals.series.length; r++)
              t.globals.series[r][a] !== void 0 && e.indexOf(r) === -1 && (s += t.globals.series[r][a]);
            i.push(s);
          }
          return i;
        } }, { key: "getSeriesTotalByIndex", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
          return e === null ? this.w.config.series.reduce(function(t, i) {
            return t + i;
          }, 0) : this.w.globals.series[e].reduce(function(t, i) {
            return t + i;
          }, 0);
        } }, { key: "getStackedSeriesTotalsByGroups", value: function() {
          var e = this, t = this.w, i = [];
          return t.globals.seriesGroups.forEach(function(a) {
            var s = [];
            t.config.series.forEach(function(o, c) {
              a.indexOf(o.name) > -1 && s.push(c);
            });
            var r = t.globals.series.map(function(o, c) {
              return s.indexOf(c) === -1 ? c : -1;
            }).filter(function(o) {
              return o !== -1;
            });
            i.push(e.getStackedSeriesTotals(r));
          }), i;
        } }, { key: "isSeriesNull", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
          return (e === null ? this.w.config.series.filter(function(t) {
            return t !== null;
          }) : this.w.config.series[e].data.filter(function(t) {
            return t !== null;
          })).length === 0;
        } }, { key: "seriesHaveSameValues", value: function(e) {
          return this.w.globals.series[e].every(function(t, i, a) {
            return t === a[0];
          });
        } }, { key: "getCategoryLabels", value: function(e) {
          var t = this.w, i = e.slice();
          return t.config.xaxis.convertedCatToNumeric && (i = e.map(function(a, s) {
            return t.config.xaxis.labels.formatter(a - t.globals.minX + 1);
          })), i;
        } }, { key: "getLargestSeries", value: function() {
          var e = this.w;
          e.globals.maxValsInArrayIndex = e.globals.series.map(function(t) {
            return t.length;
          }).indexOf(Math.max.apply(Math, e.globals.series.map(function(t) {
            return t.length;
          })));
        } }, { key: "getLargestMarkerSize", value: function() {
          var e = this.w, t = 0;
          return e.globals.markers.size.forEach(function(i) {
            t = Math.max(t, i);
          }), e.config.markers.discrete && e.config.markers.discrete.length && e.config.markers.discrete.forEach(function(i) {
            t = Math.max(t, i.size);
          }), t > 0 && (t += e.config.markers.hover.sizeOffset + 1), e.globals.markers.largestSize = t, t;
        } }, { key: "getSeriesTotals", value: function() {
          var e = this.w;
          e.globals.seriesTotals = e.globals.series.map(function(t, i) {
            var a = 0;
            if (Array.isArray(t))
              for (var s = 0; s < t.length; s++)
                a += t[s];
            else
              a += t;
            return a;
          });
        } }, { key: "getSeriesTotalsXRange", value: function(e, t) {
          var i = this.w;
          return i.globals.series.map(function(a, s) {
            for (var r = 0, o = 0; o < a.length; o++)
              i.globals.seriesX[s][o] > e && i.globals.seriesX[s][o] < t && (r += a[o]);
            return r;
          });
        } }, { key: "getPercentSeries", value: function() {
          var e = this.w;
          e.globals.seriesPercent = e.globals.series.map(function(t, i) {
            var a = [];
            if (Array.isArray(t))
              for (var s = 0; s < t.length; s++) {
                var r = e.globals.stackedSeriesTotals[s], o = 0;
                r && (o = 100 * t[s] / r), a.push(o);
              }
            else {
              var c = 100 * t / e.globals.seriesTotals.reduce(function(d, g) {
                return d + g;
              }, 0);
              a.push(c);
            }
            return a;
          });
        } }, { key: "getCalculatedRatios", value: function() {
          var e, t, i, a, s = this.w.globals, r = [], o = 0, c = [], d = 0.1, g = 0;
          if (s.yRange = [], s.isMultipleYAxis)
            for (var f = 0; f < s.minYArr.length; f++)
              s.yRange.push(Math.abs(s.minYArr[f] - s.maxYArr[f])), c.push(0);
          else
            s.yRange.push(Math.abs(s.minY - s.maxY));
          s.xRange = Math.abs(s.maxX - s.minX), s.zRange = Math.abs(s.maxZ - s.minZ);
          for (var p = 0; p < s.yRange.length; p++)
            r.push(s.yRange[p] / s.gridHeight);
          if (t = s.xRange / s.gridWidth, i = Math.abs(s.initialMaxX - s.initialMinX) / s.gridWidth, e = s.yRange / s.gridWidth, a = s.xRange / s.gridHeight, (o = s.zRange / s.gridHeight * 16) || (o = 1), s.minY !== Number.MIN_VALUE && Math.abs(s.minY) !== 0 && (s.hasNegs = !0), s.isMultipleYAxis) {
            c = [];
            for (var m = 0; m < r.length; m++)
              c.push(-s.minYArr[m] / r[m]);
          } else
            c.push(-s.minY / r[0]), s.minY !== Number.MIN_VALUE && Math.abs(s.minY) !== 0 && (d = -s.minY / e, g = s.minX / t);
          return { yRatio: r, invertedYRatio: e, zRatio: o, xRatio: t, initialXRatio: i, invertedXRatio: a, baseLineInvertedY: d, baseLineY: c, baseLineX: g };
        } }, { key: "getLogSeries", value: function(e) {
          var t = this, i = this.w;
          return i.globals.seriesLog = e.map(function(a, s) {
            return i.config.yaxis[s] && i.config.yaxis[s].logarithmic ? a.map(function(r) {
              return r === null ? null : t.getLogVal(i.config.yaxis[s].logBase, r, s);
            }) : a;
          }), i.globals.invalidLogScale ? e : i.globals.seriesLog;
        } }, { key: "getBaseLog", value: function(e, t) {
          return Math.log(t) / Math.log(e);
        } }, { key: "getLogVal", value: function(e, t, i) {
          if (t === 0)
            return 0;
          var a = this.w, s = a.globals.minYArr[i] === 0 ? -1 : this.getBaseLog(e, a.globals.minYArr[i]), r = (a.globals.maxYArr[i] === 0 ? 0 : this.getBaseLog(e, a.globals.maxYArr[i])) - s;
          return t < 1 ? t / r : (this.getBaseLog(e, t) - s) / r;
        } }, { key: "getLogYRatios", value: function(e) {
          var t = this, i = this.w, a = this.w.globals;
          return a.yLogRatio = e.slice(), a.logYRange = a.yRange.map(function(s, r) {
            if (i.config.yaxis[r] && t.w.config.yaxis[r].logarithmic) {
              var o, c = -Number.MAX_VALUE, d = Number.MIN_VALUE;
              return a.seriesLog.forEach(function(g, f) {
                g.forEach(function(p) {
                  i.config.yaxis[f] && i.config.yaxis[f].logarithmic && (c = Math.max(p, c), d = Math.min(p, d));
                });
              }), o = Math.pow(a.yRange[r], Math.abs(d - c) / a.yRange[r]), a.yLogRatio[r] = o / a.gridHeight, o;
            }
          }), a.invalidLogScale ? e.slice() : a.yLogRatio;
        } }], [{ key: "checkComboSeries", value: function(e) {
          var t = !1, i = 0, a = 0;
          return e.length && e[0].type !== void 0 && e.forEach(function(s) {
            s.type !== "bar" && s.type !== "column" && s.type !== "candlestick" && s.type !== "boxPlot" || i++, s.type !== void 0 && a++;
          }), a > 0 && (t = !0), { comboBarCount: i, comboCharts: t };
        } }, { key: "extendArrayProps", value: function(e, t, i) {
          return t.yaxis && (t = e.extendYAxis(t, i)), t.annotations && (t.annotations.yaxis && (t = e.extendYAxisAnnotations(t)), t.annotations.xaxis && (t = e.extendXAxisAnnotations(t)), t.annotations.points && (t = e.extendPointAnnotations(t))), t;
        } }]), P;
      }(), K = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.annoCtx = e;
        }
        return A(P, [{ key: "setOrientations", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null, i = this.w;
          if (e.label.orientation === "vertical") {
            var a = t !== null ? t : 0, s = i.globals.dom.baseEl.querySelector(".apexcharts-xaxis-annotations .apexcharts-xaxis-annotation-label[rel='".concat(a, "']"));
            if (s !== null) {
              var r = s.getBoundingClientRect();
              s.setAttribute("x", parseFloat(s.getAttribute("x")) - r.height + 4), e.label.position === "top" ? s.setAttribute("y", parseFloat(s.getAttribute("y")) + r.width) : s.setAttribute("y", parseFloat(s.getAttribute("y")) - r.width);
              var o = this.annoCtx.graphics.rotateAroundCenter(s), c = o.x, d = o.y;
              s.setAttribute("transform", "rotate(-90 ".concat(c, " ").concat(d, ")"));
            }
          }
        } }, { key: "addBackgroundToAnno", value: function(e, t) {
          var i = this.w;
          if (!e || t.label.text === void 0 || t.label.text !== void 0 && !String(t.label.text).trim())
            return null;
          var a = i.globals.dom.baseEl.querySelector(".apexcharts-grid").getBoundingClientRect(), s = e.getBoundingClientRect(), r = t.label.style.padding.left, o = t.label.style.padding.right, c = t.label.style.padding.top, d = t.label.style.padding.bottom;
          t.label.orientation === "vertical" && (c = t.label.style.padding.left, d = t.label.style.padding.right, r = t.label.style.padding.top, o = t.label.style.padding.bottom);
          var g = s.left - a.left - r, f = s.top - a.top - c, p = this.annoCtx.graphics.drawRect(g - i.globals.barPadForNumericAxis, f, s.width + r + o, s.height + c + d, t.label.borderRadius, t.label.style.background, 1, t.label.borderWidth, t.label.borderColor, 0);
          return t.id && p.node.classList.add(t.id), p;
        } }, { key: "annotationsBackground", value: function() {
          var e = this, t = this.w, i = function(a, s, r) {
            var o = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(r, "-annotations .apexcharts-").concat(r, "-annotation-label[rel='").concat(s, "']"));
            if (o) {
              var c = o.parentNode, d = e.addBackgroundToAnno(o, a);
              d && (c.insertBefore(d.node, o), a.label.mouseEnter && d.node.addEventListener("mouseenter", a.label.mouseEnter.bind(e, a)), a.label.mouseLeave && d.node.addEventListener("mouseleave", a.label.mouseLeave.bind(e, a)), a.label.click && d.node.addEventListener("click", a.label.click.bind(e, a)));
            }
          };
          t.config.annotations.xaxis.map(function(a, s) {
            i(a, s, "xaxis");
          }), t.config.annotations.yaxis.map(function(a, s) {
            i(a, s, "yaxis");
          }), t.config.annotations.points.map(function(a, s) {
            i(a, s, "point");
          });
        } }, { key: "getY1Y2", value: function(e, t) {
          var i, a = e === "y1" ? t.y : t.y2, s = this.w;
          if (this.annoCtx.invertAxis) {
            var r = s.globals.labels.indexOf(a);
            s.config.xaxis.convertedCatToNumeric && (r = s.globals.categoryLabels.indexOf(a));
            var o = s.globals.dom.baseEl.querySelector(".apexcharts-yaxis-texts-g text:nth-child(" + (r + 1) + ")");
            o && (i = parseFloat(o.getAttribute("y"))), t.seriesIndex !== void 0 && s.globals.barHeight && (i = i - s.globals.barHeight / 2 * (s.globals.series.length - 1) + s.globals.barHeight * t.seriesIndex);
          } else {
            var c;
            s.config.yaxis[t.yAxisIndex].logarithmic ? c = (a = new $(this.annoCtx.ctx).getLogVal(a, t.yAxisIndex)) / s.globals.yLogRatio[t.yAxisIndex] : c = (a - s.globals.minYArr[t.yAxisIndex]) / (s.globals.yRange[t.yAxisIndex] / s.globals.gridHeight), i = s.globals.gridHeight - c, !t.marker || t.y !== void 0 && t.y !== null || (i = 0), s.config.yaxis[t.yAxisIndex] && s.config.yaxis[t.yAxisIndex].reversed && (i = c);
          }
          return typeof a == "string" && a.indexOf("px") > -1 && (i = parseFloat(a)), i;
        } }, { key: "getX1X2", value: function(e, t) {
          var i = this.w, a = this.annoCtx.invertAxis ? i.globals.minY : i.globals.minX, s = this.annoCtx.invertAxis ? i.globals.maxY : i.globals.maxX, r = this.annoCtx.invertAxis ? i.globals.yRange[0] : i.globals.xRange, o = (t.x - a) / (r / i.globals.gridWidth);
          this.annoCtx.inversedReversedAxis && (o = (s - t.x) / (r / i.globals.gridWidth)), i.config.xaxis.type !== "category" && !i.config.xaxis.convertedCatToNumeric || this.annoCtx.invertAxis || i.globals.dataFormatXNumeric || (o = this.getStringX(t.x));
          var c = (t.x2 - a) / (r / i.globals.gridWidth);
          return this.annoCtx.inversedReversedAxis && (c = (s - t.x2) / (r / i.globals.gridWidth)), i.config.xaxis.type !== "category" && !i.config.xaxis.convertedCatToNumeric || this.annoCtx.invertAxis || i.globals.dataFormatXNumeric || (c = this.getStringX(t.x2)), t.x !== void 0 && t.x !== null || !t.marker || (o = i.globals.gridWidth), e === "x1" && typeof t.x == "string" && t.x.indexOf("px") > -1 && (o = parseFloat(t.x)), e === "x2" && typeof t.x2 == "string" && t.x2.indexOf("px") > -1 && (c = parseFloat(t.x2)), t.seriesIndex !== void 0 && i.globals.barWidth && !this.annoCtx.invertAxis && (o = o - i.globals.barWidth / 2 * (i.globals.series.length - 1) + i.globals.barWidth * t.seriesIndex), e === "x1" ? o : c;
        } }, { key: "getStringX", value: function(e) {
          var t = this.w, i = e;
          t.config.xaxis.convertedCatToNumeric && t.globals.categoryLabels.length && (e = t.globals.categoryLabels.indexOf(e) + 1);
          var a = t.globals.labels.indexOf(e), s = t.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g text:nth-child(" + (a + 1) + ")");
          return s && (i = parseFloat(s.getAttribute("x"))), i;
        } }]), P;
      }(), J = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.annoCtx = e, this.invertAxis = this.annoCtx.invertAxis, this.helpers = new K(this.annoCtx);
        }
        return A(P, [{ key: "addXaxisAnnotation", value: function(e, t, i) {
          var a, s = this.w, r = this.helpers.getX1X2("x1", e), o = e.label.text, c = e.strokeDashArray;
          if (M.isNumber(r)) {
            if (e.x2 === null || e.x2 === void 0) {
              var d = this.annoCtx.graphics.drawLine(r + e.offsetX, 0 + e.offsetY, r + e.offsetX, s.globals.gridHeight + e.offsetY, e.borderColor, c, e.borderWidth);
              t.appendChild(d.node), e.id && d.node.classList.add(e.id);
            } else {
              if ((a = this.helpers.getX1X2("x2", e)) < r) {
                var g = r;
                r = a, a = g;
              }
              var f = this.annoCtx.graphics.drawRect(r + e.offsetX, 0 + e.offsetY, a - r, s.globals.gridHeight + e.offsetY, 0, e.fillColor, e.opacity, 1, e.borderColor, c);
              f.node.classList.add("apexcharts-annotation-rect"), f.attr("clip-path", "url(#gridRectMask".concat(s.globals.cuid, ")")), t.appendChild(f.node), e.id && f.node.classList.add(e.id);
            }
            var p = this.annoCtx.graphics.getTextRects(o, parseFloat(e.label.style.fontSize)), m = e.label.position === "top" ? 4 : e.label.position === "center" ? s.globals.gridHeight / 2 + (e.label.orientation === "vertical" ? p.width / 2 : 0) : s.globals.gridHeight, w = this.annoCtx.graphics.drawText({ x: r + e.label.offsetX, y: m + e.label.offsetY - (e.label.orientation === "vertical" ? e.label.position === "top" ? p.width / 2 - 12 : -p.width / 2 : 0), text: o, textAnchor: e.label.textAnchor, fontSize: e.label.style.fontSize, fontFamily: e.label.style.fontFamily, fontWeight: e.label.style.fontWeight, foreColor: e.label.style.color, cssClass: "apexcharts-xaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "") });
            w.attr({ rel: i }), t.appendChild(w.node), this.annoCtx.helpers.setOrientations(e, i);
          }
        } }, { key: "drawXAxisAnnotations", value: function() {
          var e = this, t = this.w, i = this.annoCtx.graphics.group({ class: "apexcharts-xaxis-annotations" });
          return t.config.annotations.xaxis.map(function(a, s) {
            e.addXaxisAnnotation(a, i.node, s);
          }), i;
        } }]), P;
      }(), ie = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.annoCtx = e, this.helpers = new K(this.annoCtx);
        }
        return A(P, [{ key: "addYaxisAnnotation", value: function(e, t, i) {
          var a, s = this.w, r = e.strokeDashArray, o = this.helpers.getY1Y2("y1", e), c = e.label.text;
          if (e.y2 === null || e.y2 === void 0) {
            var d = this.annoCtx.graphics.drawLine(0 + e.offsetX, o + e.offsetY, this._getYAxisAnnotationWidth(e), o + e.offsetY, e.borderColor, r, e.borderWidth);
            t.appendChild(d.node), e.id && d.node.classList.add(e.id);
          } else {
            if ((a = this.helpers.getY1Y2("y2", e)) > o) {
              var g = o;
              o = a, a = g;
            }
            var f = this.annoCtx.graphics.drawRect(0 + e.offsetX, a + e.offsetY, this._getYAxisAnnotationWidth(e), o - a, 0, e.fillColor, e.opacity, 1, e.borderColor, r);
            f.node.classList.add("apexcharts-annotation-rect"), f.attr("clip-path", "url(#gridRectMask".concat(s.globals.cuid, ")")), t.appendChild(f.node), e.id && f.node.classList.add(e.id);
          }
          var p = e.label.position === "right" ? s.globals.gridWidth : e.label.position === "center" ? s.globals.gridWidth / 2 : 0, m = this.annoCtx.graphics.drawText({ x: p + e.label.offsetX, y: (a ?? o) + e.label.offsetY - 3, text: c, textAnchor: e.label.textAnchor, fontSize: e.label.style.fontSize, fontFamily: e.label.style.fontFamily, fontWeight: e.label.style.fontWeight, foreColor: e.label.style.color, cssClass: "apexcharts-yaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "") });
          m.attr({ rel: i }), t.appendChild(m.node);
        } }, { key: "_getYAxisAnnotationWidth", value: function(e) {
          var t = this.w;
          return t.globals.gridWidth, (e.width.indexOf("%") > -1 ? t.globals.gridWidth * parseInt(e.width, 10) / 100 : parseInt(e.width, 10)) + e.offsetX;
        } }, { key: "drawYAxisAnnotations", value: function() {
          var e = this, t = this.w, i = this.annoCtx.graphics.group({ class: "apexcharts-yaxis-annotations" });
          return t.config.annotations.yaxis.map(function(a, s) {
            e.addYaxisAnnotation(a, i.node, s);
          }), i;
        } }]), P;
      }(), re = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.annoCtx = e, this.helpers = new K(this.annoCtx);
        }
        return A(P, [{ key: "addPointAnnotation", value: function(e, t, i) {
          this.w;
          var a = this.helpers.getX1X2("x1", e), s = this.helpers.getY1Y2("y1", e);
          if (M.isNumber(a)) {
            var r = { pSize: e.marker.size, pointStrokeWidth: e.marker.strokeWidth, pointFillColor: e.marker.fillColor, pointStrokeColor: e.marker.strokeColor, shape: e.marker.shape, pRadius: e.marker.radius, class: "apexcharts-point-annotation-marker ".concat(e.marker.cssClass, " ").concat(e.id ? e.id : "") }, o = this.annoCtx.graphics.drawMarker(a + e.marker.offsetX, s + e.marker.offsetY, r);
            t.appendChild(o.node);
            var c = e.label.text ? e.label.text : "", d = this.annoCtx.graphics.drawText({ x: a + e.label.offsetX, y: s + e.label.offsetY - e.marker.size - parseFloat(e.label.style.fontSize) / 1.6, text: c, textAnchor: e.label.textAnchor, fontSize: e.label.style.fontSize, fontFamily: e.label.style.fontFamily, fontWeight: e.label.style.fontWeight, foreColor: e.label.style.color, cssClass: "apexcharts-point-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "") });
            if (d.attr({ rel: i }), t.appendChild(d.node), e.customSVG.SVG) {
              var g = this.annoCtx.graphics.group({ class: "apexcharts-point-annotations-custom-svg " + e.customSVG.cssClass });
              g.attr({ transform: "translate(".concat(a + e.customSVG.offsetX, ", ").concat(s + e.customSVG.offsetY, ")") }), g.node.innerHTML = e.customSVG.SVG, t.appendChild(g.node);
            }
            if (e.image.path) {
              var f = e.image.width ? e.image.width : 20, p = e.image.height ? e.image.height : 20;
              o = this.annoCtx.addImage({ x: a + e.image.offsetX - f / 2, y: s + e.image.offsetY - p / 2, width: f, height: p, path: e.image.path, appendTo: ".apexcharts-point-annotations" });
            }
            e.mouseEnter && o.node.addEventListener("mouseenter", e.mouseEnter.bind(this, e)), e.mouseLeave && o.node.addEventListener("mouseleave", e.mouseLeave.bind(this, e)), e.click && o.node.addEventListener("click", e.click.bind(this, e));
          }
        } }, { key: "drawPointAnnotations", value: function() {
          var e = this, t = this.w, i = this.annoCtx.graphics.group({ class: "apexcharts-point-annotations" });
          return t.config.annotations.points.map(function(a, s) {
            e.addPointAnnotation(a, i.node, s);
          }), i;
        } }]), P;
      }(), ne = { name: "en", options: { months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], toolbar: { exportToSVG: "Download SVG", exportToPNG: "Download PNG", exportToCSV: "Download CSV", menu: "Menu", selection: "Selection", selectionZoom: "Selection Zoom", zoomIn: "Zoom In", zoomOut: "Zoom Out", pan: "Panning", reset: "Reset Zoom" } } }, ce = function() {
        function P() {
          y(this, P), this.yAxis = { show: !0, showAlways: !1, showForNullSeries: !0, seriesName: void 0, opposite: !1, reversed: !1, logarithmic: !1, logBase: 10, tickAmount: void 0, stepSize: void 0, forceNiceScale: !1, max: void 0, min: void 0, floating: !1, decimalsInFloat: void 0, labels: { show: !0, minWidth: 0, maxWidth: 160, offsetX: 0, offsetY: 0, align: void 0, rotate: 0, padding: 20, style: { colors: [], fontSize: "11px", fontWeight: 400, fontFamily: void 0, cssClass: "" }, formatter: void 0 }, axisBorder: { show: !1, color: "#e0e0e0", width: 1, offsetX: 0, offsetY: 0 }, axisTicks: { show: !1, color: "#e0e0e0", width: 6, offsetX: 0, offsetY: 0 }, title: { text: void 0, rotate: -90, offsetY: 0, offsetX: 0, style: { color: void 0, fontSize: "11px", fontWeight: 900, fontFamily: void 0, cssClass: "" } }, tooltip: { enabled: !1, offsetX: 0 }, crosshairs: { show: !0, position: "front", stroke: { color: "#b6b6b6", width: 1, dashArray: 0 } } }, this.pointAnnotation = { id: void 0, x: 0, y: null, yAxisIndex: 0, seriesIndex: void 0, mouseEnter: void 0, mouseLeave: void 0, click: void 0, marker: { size: 4, fillColor: "#fff", strokeWidth: 2, strokeColor: "#333", shape: "circle", offsetX: 0, offsetY: 0, radius: 2, cssClass: "" }, label: { borderColor: "#c2c2c2", borderWidth: 1, borderRadius: 2, text: void 0, textAnchor: "middle", offsetX: 0, offsetY: 0, mouseEnter: void 0, mouseLeave: void 0, click: void 0, style: { background: "#fff", color: void 0, fontSize: "11px", fontFamily: void 0, fontWeight: 400, cssClass: "", padding: { left: 5, right: 5, top: 2, bottom: 2 } } }, customSVG: { SVG: void 0, cssClass: void 0, offsetX: 0, offsetY: 0 }, image: { path: void 0, width: 20, height: 20, offsetX: 0, offsetY: 0 } }, this.yAxisAnnotation = { id: void 0, y: 0, y2: null, strokeDashArray: 1, fillColor: "#c2c2c2", borderColor: "#c2c2c2", borderWidth: 1, opacity: 0.3, offsetX: 0, offsetY: 0, width: "100%", yAxisIndex: 0, label: { borderColor: "#c2c2c2", borderWidth: 1, borderRadius: 2, text: void 0, textAnchor: "end", position: "right", offsetX: 0, offsetY: -3, mouseEnter: void 0, mouseLeave: void 0, click: void 0, style: { background: "#fff", color: void 0, fontSize: "11px", fontFamily: void 0, fontWeight: 400, cssClass: "", padding: { left: 5, right: 5, top: 2, bottom: 2 } } } }, this.xAxisAnnotation = { id: void 0, x: 0, x2: null, strokeDashArray: 1, fillColor: "#c2c2c2", borderColor: "#c2c2c2", borderWidth: 1, opacity: 0.3, offsetX: 0, offsetY: 0, label: { borderColor: "#c2c2c2", borderWidth: 1, borderRadius: 2, text: void 0, textAnchor: "middle", orientation: "vertical", position: "top", offsetX: 0, offsetY: 0, mouseEnter: void 0, mouseLeave: void 0, click: void 0, style: { background: "#fff", color: void 0, fontSize: "11px", fontFamily: void 0, fontWeight: 400, cssClass: "", padding: { left: 5, right: 5, top: 2, bottom: 2 } } } }, this.text = { x: 0, y: 0, text: "", textAnchor: "start", foreColor: void 0, fontSize: "13px", fontFamily: void 0, fontWeight: 400, appendTo: ".apexcharts-annotations", backgroundColor: "transparent", borderColor: "#c2c2c2", borderRadius: 0, borderWidth: 0, paddingLeft: 4, paddingRight: 4, paddingTop: 2, paddingBottom: 2 };
        }
        return A(P, [{ key: "init", value: function() {
          return { annotations: { yaxis: [this.yAxisAnnotation], xaxis: [this.xAxisAnnotation], points: [this.pointAnnotation], texts: [], images: [], shapes: [] }, chart: { animations: { enabled: !0, easing: "easeinout", speed: 800, animateGradually: { delay: 150, enabled: !0 }, dynamicAnimation: { enabled: !0, speed: 350 } }, background: "transparent", locales: [ne], defaultLocale: "en", dropShadow: { enabled: !1, enabledOnSeries: void 0, top: 2, left: 2, blur: 4, color: "#000", opacity: 0.35 }, events: { animationEnd: void 0, beforeMount: void 0, mounted: void 0, updated: void 0, click: void 0, mouseMove: void 0, mouseLeave: void 0, xAxisLabelClick: void 0, legendClick: void 0, markerClick: void 0, selection: void 0, dataPointSelection: void 0, dataPointMouseEnter: void 0, dataPointMouseLeave: void 0, beforeZoom: void 0, beforeResetZoom: void 0, zoomed: void 0, scrolled: void 0, brushScrolled: void 0 }, foreColor: "#373d3f", fontFamily: "Helvetica, Arial, sans-serif", height: "auto", parentHeightOffset: 15, redrawOnParentResize: !0, redrawOnWindowResize: !0, id: void 0, group: void 0, nonce: void 0, offsetX: 0, offsetY: 0, selection: { enabled: !1, type: "x", fill: { color: "#24292e", opacity: 0.1 }, stroke: { width: 1, color: "#24292e", opacity: 0.4, dashArray: 3 }, xaxis: { min: void 0, max: void 0 }, yaxis: { min: void 0, max: void 0 } }, sparkline: { enabled: !1 }, brush: { enabled: !1, autoScaleYaxis: !0, target: void 0, targets: void 0 }, stacked: !1, stackOnlyBar: !0, stackType: "normal", toolbar: { show: !0, offsetX: 0, offsetY: 0, tools: { download: !0, selection: !0, zoom: !0, zoomin: !0, zoomout: !0, pan: !0, reset: !0, customIcons: [] }, export: { csv: { filename: void 0, columnDelimiter: ",", headerCategory: "category", headerValue: "value", dateFormatter: function(e) {
            return new Date(e).toDateString();
          } }, png: { filename: void 0 }, svg: { filename: void 0 } }, autoSelected: "zoom" }, type: "line", width: "100%", zoom: { enabled: !0, type: "x", autoScaleYaxis: !1, zoomedArea: { fill: { color: "#90CAF9", opacity: 0.4 }, stroke: { color: "#0D47A1", opacity: 0.4, width: 1 } } } }, plotOptions: { area: { fillTo: "origin" }, bar: { horizontal: !1, columnWidth: "70%", barHeight: "70%", distributed: !1, borderRadius: 0, borderRadiusApplication: "around", borderRadiusWhenStacked: "last", rangeBarOverlap: !0, rangeBarGroupRows: !1, hideZeroBarsWhenGrouped: !1, isDumbbell: !1, dumbbellColors: void 0, isFunnel: !1, isFunnel3d: !0, colors: { ranges: [], backgroundBarColors: [], backgroundBarOpacity: 1, backgroundBarRadius: 0 }, dataLabels: { position: "top", maxItems: 100, hideOverflowingLabels: !0, orientation: "horizontal", total: { enabled: !1, formatter: void 0, offsetX: 0, offsetY: 0, style: { color: "#373d3f", fontSize: "12px", fontFamily: void 0, fontWeight: 600 } } } }, bubble: { zScaling: !0, minBubbleRadius: void 0, maxBubbleRadius: void 0 }, candlestick: { colors: { upward: "#00B746", downward: "#EF403C" }, wick: { useFillColor: !0 } }, boxPlot: { colors: { upper: "#00E396", lower: "#008FFB" } }, heatmap: { radius: 2, enableShades: !0, shadeIntensity: 0.5, reverseNegativeShade: !1, distributed: !1, useFillColorAsStroke: !1, colorScale: { inverse: !1, ranges: [], min: void 0, max: void 0 } }, treemap: { enableShades: !0, shadeIntensity: 0.5, distributed: !1, reverseNegativeShade: !1, useFillColorAsStroke: !1, dataLabels: { format: "scale" }, colorScale: { inverse: !1, ranges: [], min: void 0, max: void 0 } }, radialBar: { inverseOrder: !1, startAngle: 0, endAngle: 360, offsetX: 0, offsetY: 0, hollow: { margin: 5, size: "50%", background: "transparent", image: void 0, imageWidth: 150, imageHeight: 150, imageOffsetX: 0, imageOffsetY: 0, imageClipped: !0, position: "front", dropShadow: { enabled: !1, top: 0, left: 0, blur: 3, color: "#000", opacity: 0.5 } }, track: { show: !0, startAngle: void 0, endAngle: void 0, background: "#f2f2f2", strokeWidth: "97%", opacity: 1, margin: 5, dropShadow: { enabled: !1, top: 0, left: 0, blur: 3, color: "#000", opacity: 0.5 } }, dataLabels: { show: !0, name: { show: !0, fontSize: "16px", fontFamily: void 0, fontWeight: 600, color: void 0, offsetY: 0, formatter: function(e) {
            return e;
          } }, value: { show: !0, fontSize: "14px", fontFamily: void 0, fontWeight: 400, color: void 0, offsetY: 16, formatter: function(e) {
            return e + "%";
          } }, total: { show: !1, label: "Total", fontSize: "16px", fontWeight: 600, fontFamily: void 0, color: void 0, formatter: function(e) {
            return e.globals.seriesTotals.reduce(function(t, i) {
              return t + i;
            }, 0) / e.globals.series.length + "%";
          } } }, barLabels: { enabled: !1, margin: 5, useSeriesColors: !0, fontFamily: void 0, fontWeight: 600, fontSize: "16px", formatter: function(e) {
            return e;
          }, onClick: void 0 } }, pie: { customScale: 1, offsetX: 0, offsetY: 0, startAngle: 0, endAngle: 360, expandOnClick: !0, dataLabels: { offset: 0, minAngleToShowLabel: 10 }, donut: { size: "65%", background: "transparent", labels: { show: !1, name: { show: !0, fontSize: "16px", fontFamily: void 0, fontWeight: 600, color: void 0, offsetY: -10, formatter: function(e) {
            return e;
          } }, value: { show: !0, fontSize: "20px", fontFamily: void 0, fontWeight: 400, color: void 0, offsetY: 10, formatter: function(e) {
            return e;
          } }, total: { show: !1, showAlways: !1, label: "Total", fontSize: "16px", fontWeight: 400, fontFamily: void 0, color: void 0, formatter: function(e) {
            return e.globals.seriesTotals.reduce(function(t, i) {
              return t + i;
            }, 0);
          } } } } }, polarArea: { rings: { strokeWidth: 1, strokeColor: "#e8e8e8" }, spokes: { strokeWidth: 1, connectorColors: "#e8e8e8" } }, radar: { size: void 0, offsetX: 0, offsetY: 0, polygons: { strokeWidth: 1, strokeColors: "#e8e8e8", connectorColors: "#e8e8e8", fill: { colors: void 0 } } } }, colors: void 0, dataLabels: { enabled: !0, enabledOnSeries: void 0, formatter: function(e) {
            return e !== null ? e : "";
          }, textAnchor: "middle", distributed: !1, offsetX: 0, offsetY: 0, style: { fontSize: "12px", fontFamily: void 0, fontWeight: 600, colors: void 0 }, background: { enabled: !0, foreColor: "#fff", borderRadius: 2, padding: 4, opacity: 0.9, borderWidth: 1, borderColor: "#fff", dropShadow: { enabled: !1, top: 1, left: 1, blur: 1, color: "#000", opacity: 0.45 } }, dropShadow: { enabled: !1, top: 1, left: 1, blur: 1, color: "#000", opacity: 0.45 } }, fill: { type: "solid", colors: void 0, opacity: 0.85, gradient: { shade: "dark", type: "horizontal", shadeIntensity: 0.5, gradientToColors: void 0, inverseColors: !0, opacityFrom: 1, opacityTo: 1, stops: [0, 50, 100], colorStops: [] }, image: { src: [], width: void 0, height: void 0 }, pattern: { style: "squares", width: 6, height: 6, strokeWidth: 2 } }, forecastDataPoints: { count: 0, fillOpacity: 0.5, strokeWidth: void 0, dashArray: 4 }, grid: { show: !0, borderColor: "#e0e0e0", strokeDashArray: 0, position: "back", xaxis: { lines: { show: !1 } }, yaxis: { lines: { show: !0 } }, row: { colors: void 0, opacity: 0.5 }, column: { colors: void 0, opacity: 0.5 }, padding: { top: 0, right: 10, bottom: 0, left: 12 } }, labels: [], legend: { show: !0, showForSingleSeries: !1, showForNullSeries: !0, showForZeroSeries: !0, floating: !1, position: "bottom", horizontalAlign: "center", inverseOrder: !1, fontSize: "12px", fontFamily: void 0, fontWeight: 400, width: void 0, height: void 0, formatter: void 0, tooltipHoverFormatter: void 0, offsetX: -20, offsetY: 4, customLegendItems: [], labels: { colors: void 0, useSeriesColors: !1 }, markers: { width: 12, height: 12, strokeWidth: 0, fillColors: void 0, strokeColor: "#fff", radius: 12, customHTML: void 0, offsetX: 0, offsetY: 0, onClick: void 0 }, itemMargin: { horizontal: 5, vertical: 2 }, onItemClick: { toggleDataSeries: !0 }, onItemHover: { highlightDataSeries: !0 } }, markers: { discrete: [], size: 0, colors: void 0, strokeColors: "#fff", strokeWidth: 2, strokeOpacity: 0.9, strokeDashArray: 0, fillOpacity: 1, shape: "circle", width: 8, height: 8, radius: 2, offsetX: 0, offsetY: 0, onClick: void 0, onDblClick: void 0, showNullDataPoints: !0, hover: { size: void 0, sizeOffset: 3 } }, noData: { text: void 0, align: "center", verticalAlign: "middle", offsetX: 0, offsetY: 0, style: { color: void 0, fontSize: "14px", fontFamily: void 0 } }, responsive: [], series: void 0, states: { normal: { filter: { type: "none", value: 0 } }, hover: { filter: { type: "lighten", value: 0.1 } }, active: { allowMultipleDataPointsSelection: !1, filter: { type: "darken", value: 0.5 } } }, title: { text: void 0, align: "left", margin: 5, offsetX: 0, offsetY: 0, floating: !1, style: { fontSize: "14px", fontWeight: 900, fontFamily: void 0, color: void 0 } }, subtitle: { text: void 0, align: "left", margin: 5, offsetX: 0, offsetY: 30, floating: !1, style: { fontSize: "12px", fontWeight: 400, fontFamily: void 0, color: void 0 } }, stroke: { show: !0, curve: "smooth", lineCap: "butt", width: 2, colors: void 0, dashArray: 0, fill: { type: "solid", colors: void 0, opacity: 0.85, gradient: { shade: "dark", type: "horizontal", shadeIntensity: 0.5, gradientToColors: void 0, inverseColors: !0, opacityFrom: 1, opacityTo: 1, stops: [0, 50, 100], colorStops: [] } } }, tooltip: { enabled: !0, enabledOnSeries: void 0, shared: !0, hideEmptySeries: !0, followCursor: !1, intersect: !1, inverseOrder: !1, custom: void 0, fillSeriesColor: !1, theme: "light", cssClass: "", style: { fontSize: "12px", fontFamily: void 0 }, onDatasetHover: { highlightDataSeries: !1 }, x: { show: !0, format: "dd MMM", formatter: void 0 }, y: { formatter: void 0, title: { formatter: function(e) {
            return e ? e + ": " : "";
          } } }, z: { formatter: void 0, title: "Size: " }, marker: { show: !0, fillColors: void 0 }, items: { display: "flex" }, fixed: { enabled: !1, position: "topRight", offsetX: 0, offsetY: 0 } }, xaxis: { type: "category", categories: [], convertedCatToNumeric: !1, offsetX: 0, offsetY: 0, overwriteCategories: void 0, labels: { show: !0, rotate: -45, rotateAlways: !1, hideOverlappingLabels: !0, trim: !1, minHeight: void 0, maxHeight: 120, showDuplicates: !0, style: { colors: [], fontSize: "12px", fontWeight: 400, fontFamily: void 0, cssClass: "" }, offsetX: 0, offsetY: 0, format: void 0, formatter: void 0, datetimeUTC: !0, datetimeFormatter: { year: "yyyy", month: "MMM 'yy", day: "dd MMM", hour: "HH:mm", minute: "HH:mm:ss", second: "HH:mm:ss" } }, group: { groups: [], style: { colors: [], fontSize: "12px", fontWeight: 400, fontFamily: void 0, cssClass: "" } }, axisBorder: { show: !0, color: "#e0e0e0", width: "100%", height: 1, offsetX: 0, offsetY: 0 }, axisTicks: { show: !0, color: "#e0e0e0", height: 6, offsetX: 0, offsetY: 0 }, stepSize: void 0, tickAmount: void 0, tickPlacement: "on", min: void 0, max: void 0, range: void 0, floating: !1, decimalsInFloat: void 0, position: "bottom", title: { text: void 0, offsetX: 0, offsetY: 0, style: { color: void 0, fontSize: "12px", fontWeight: 900, fontFamily: void 0, cssClass: "" } }, crosshairs: { show: !0, width: 1, position: "back", opacity: 0.9, stroke: { color: "#b6b6b6", width: 1, dashArray: 3 }, fill: { type: "solid", color: "#B1B9C4", gradient: { colorFrom: "#D8E3F0", colorTo: "#BED1E6", stops: [0, 100], opacityFrom: 0.4, opacityTo: 0.5 } }, dropShadow: { enabled: !1, left: 0, top: 0, blur: 1, opacity: 0.4 } }, tooltip: { enabled: !0, offsetY: 0, formatter: void 0, style: { fontSize: "12px", fontFamily: void 0 } } }, yaxis: this.yAxis, theme: { mode: "light", palette: "palette1", monochrome: { enabled: !1, color: "#008FFB", shadeTo: "light", shadeIntensity: 0.65 } } };
        } }]), P;
      }(), ge = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.graphics = new X(this.ctx), this.w.globals.isBarHorizontal && (this.invertAxis = !0), this.helpers = new K(this), this.xAxisAnnotations = new J(this), this.yAxisAnnotations = new ie(this), this.pointsAnnotations = new re(this), this.w.globals.isBarHorizontal && this.w.config.yaxis[0].reversed && (this.inversedReversedAxis = !0), this.xDivision = this.w.globals.gridWidth / this.w.globals.dataPoints;
        }
        return A(P, [{ key: "drawAxesAnnotations", value: function() {
          var e = this.w;
          if (e.globals.axisCharts) {
            for (var t = this.yAxisAnnotations.drawYAxisAnnotations(), i = this.xAxisAnnotations.drawXAxisAnnotations(), a = this.pointsAnnotations.drawPointAnnotations(), s = e.config.chart.animations.enabled, r = [t, i, a], o = [i.node, t.node, a.node], c = 0; c < 3; c++)
              e.globals.dom.elGraphical.add(r[c]), !s || e.globals.resized || e.globals.dataChanged || e.config.chart.type !== "scatter" && e.config.chart.type !== "bubble" && e.globals.dataPoints > 1 && o[c].classList.add("apexcharts-element-hidden"), e.globals.delayedElements.push({ el: o[c], index: 0 });
            this.helpers.annotationsBackground();
          }
        } }, { key: "drawImageAnnos", value: function() {
          var e = this;
          this.w.config.annotations.images.map(function(t, i) {
            e.addImage(t, i);
          });
        } }, { key: "drawTextAnnos", value: function() {
          var e = this;
          this.w.config.annotations.texts.map(function(t, i) {
            e.addText(t, i);
          });
        } }, { key: "addXaxisAnnotation", value: function(e, t, i) {
          this.xAxisAnnotations.addXaxisAnnotation(e, t, i);
        } }, { key: "addYaxisAnnotation", value: function(e, t, i) {
          this.yAxisAnnotations.addYaxisAnnotation(e, t, i);
        } }, { key: "addPointAnnotation", value: function(e, t, i) {
          this.pointsAnnotations.addPointAnnotation(e, t, i);
        } }, { key: "addText", value: function(e, t) {
          var i = e.x, a = e.y, s = e.text, r = e.textAnchor, o = e.foreColor, c = e.fontSize, d = e.fontFamily, g = e.fontWeight, f = e.cssClass, p = e.backgroundColor, m = e.borderWidth, w = e.strokeDashArray, C = e.borderRadius, k = e.borderColor, E = e.appendTo, _ = E === void 0 ? ".apexcharts-svg" : E, h = e.paddingLeft, x = h === void 0 ? 4 : h, S = e.paddingRight, L = S === void 0 ? 4 : S, R = e.paddingBottom, O = R === void 0 ? 2 : R, Y = e.paddingTop, N = Y === void 0 ? 2 : Y, q = this.w, Z = this.graphics.drawText({ x: i, y: a, text: s, textAnchor: r || "start", fontSize: c || "12px", fontWeight: g || "regular", fontFamily: d || q.config.chart.fontFamily, foreColor: o || q.config.chart.foreColor, cssClass: f }), U = q.globals.dom.baseEl.querySelector(_);
          U && U.appendChild(Z.node);
          var se = Z.bbox();
          if (s) {
            var he = this.graphics.drawRect(se.x - x, se.y - N, se.width + x + L, se.height + O + N, C, p || "transparent", 1, m, k, w);
            U.insertBefore(he.node, Z.node);
          }
        } }, { key: "addImage", value: function(e, t) {
          var i = this.w, a = e.path, s = e.x, r = s === void 0 ? 0 : s, o = e.y, c = o === void 0 ? 0 : o, d = e.width, g = d === void 0 ? 20 : d, f = e.height, p = f === void 0 ? 20 : f, m = e.appendTo, w = m === void 0 ? ".apexcharts-svg" : m, C = i.globals.dom.Paper.image(a);
          C.size(g, p).move(r, c);
          var k = i.globals.dom.baseEl.querySelector(w);
          return k && k.appendChild(C.node), C;
        } }, { key: "addXaxisAnnotationExternal", value: function(e, t, i) {
          return this.addAnnotationExternal({ params: e, pushToMemory: t, context: i, type: "xaxis", contextMethod: i.addXaxisAnnotation }), i;
        } }, { key: "addYaxisAnnotationExternal", value: function(e, t, i) {
          return this.addAnnotationExternal({ params: e, pushToMemory: t, context: i, type: "yaxis", contextMethod: i.addYaxisAnnotation }), i;
        } }, { key: "addPointAnnotationExternal", value: function(e, t, i) {
          return this.invertAxis === void 0 && (this.invertAxis = i.w.globals.isBarHorizontal), this.addAnnotationExternal({ params: e, pushToMemory: t, context: i, type: "point", contextMethod: i.addPointAnnotation }), i;
        } }, { key: "addAnnotationExternal", value: function(e) {
          var t = e.params, i = e.pushToMemory, a = e.context, s = e.type, r = e.contextMethod, o = a, c = o.w, d = c.globals.dom.baseEl.querySelector(".apexcharts-".concat(s, "-annotations")), g = d.childNodes.length + 1, f = new ce(), p = Object.assign({}, s === "xaxis" ? f.xAxisAnnotation : s === "yaxis" ? f.yAxisAnnotation : f.pointAnnotation), m = M.extend(p, t);
          switch (s) {
            case "xaxis":
              this.addXaxisAnnotation(m, d, g);
              break;
            case "yaxis":
              this.addYaxisAnnotation(m, d, g);
              break;
            case "point":
              this.addPointAnnotation(m, d, g);
          }
          var w = c.globals.dom.baseEl.querySelector(".apexcharts-".concat(s, "-annotations .apexcharts-").concat(s, "-annotation-label[rel='").concat(g, "']")), C = this.helpers.addBackgroundToAnno(w, m);
          return C && d.insertBefore(C.node, w), i && c.globals.memory.methodsToExec.push({ context: o, id: m.id ? m.id : M.randomId(), method: r, label: "addAnnotation", params: t }), a;
        } }, { key: "clearAnnotations", value: function(e) {
          var t = e.w, i = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis-annotations, .apexcharts-xaxis-annotations, .apexcharts-point-annotations");
          t.globals.memory.methodsToExec.map(function(a, s) {
            a.label !== "addText" && a.label !== "addAnnotation" || t.globals.memory.methodsToExec.splice(s, 1);
          }), i = M.listToArray(i), Array.prototype.forEach.call(i, function(a) {
            for (; a.firstChild; )
              a.removeChild(a.firstChild);
          });
        } }, { key: "removeAnnotation", value: function(e, t) {
          var i = e.w, a = i.globals.dom.baseEl.querySelectorAll(".".concat(t));
          a && (i.globals.memory.methodsToExec.map(function(s, r) {
            s.id === t && i.globals.memory.methodsToExec.splice(r, 1);
          }), Array.prototype.forEach.call(a, function(s) {
            s.parentElement.removeChild(s);
          }));
        } }]), P;
      }(), ue = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.months31 = [1, 3, 5, 7, 8, 10, 12], this.months30 = [2, 4, 6, 9, 11], this.daysCntOfYear = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        }
        return A(P, [{ key: "isValidDate", value: function(e) {
          return typeof e != "number" && !isNaN(this.parseDate(e));
        } }, { key: "getTimeStamp", value: function(e) {
          return Date.parse(e) ? this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toISOString().substr(0, 25)).getTime() : new Date(e).getTime() : e;
        } }, { key: "getDate", value: function(e) {
          return this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toUTCString()) : new Date(e);
        } }, { key: "parseDate", value: function(e) {
          var t = Date.parse(e);
          if (!isNaN(t))
            return this.getTimeStamp(e);
          var i = Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "));
          return i = this.getTimeStamp(i);
        } }, { key: "parseDateWithTimezone", value: function(e) {
          return Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "));
        } }, { key: "formatDate", value: function(e, t) {
          var i = this.w.globals.locale, a = this.w.config.xaxis.labels.datetimeUTC, s = ["\0"].concat(j(i.months)), r = [""].concat(j(i.shortMonths)), o = [""].concat(j(i.days)), c = [""].concat(j(i.shortDays));
          function d(O, Y) {
            var N = O + "";
            for (Y = Y || 2; N.length < Y; )
              N = "0" + N;
            return N;
          }
          var g = a ? e.getUTCFullYear() : e.getFullYear();
          t = (t = (t = t.replace(/(^|[^\\])yyyy+/g, "$1" + g)).replace(/(^|[^\\])yy/g, "$1" + g.toString().substr(2, 2))).replace(/(^|[^\\])y/g, "$1" + g);
          var f = (a ? e.getUTCMonth() : e.getMonth()) + 1;
          t = (t = (t = (t = t.replace(/(^|[^\\])MMMM+/g, "$1" + s[0])).replace(/(^|[^\\])MMM/g, "$1" + r[0])).replace(/(^|[^\\])MM/g, "$1" + d(f))).replace(/(^|[^\\])M/g, "$1" + f);
          var p = a ? e.getUTCDate() : e.getDate();
          t = (t = (t = (t = t.replace(/(^|[^\\])dddd+/g, "$1" + o[0])).replace(/(^|[^\\])ddd/g, "$1" + c[0])).replace(/(^|[^\\])dd/g, "$1" + d(p))).replace(/(^|[^\\])d/g, "$1" + p);
          var m = a ? e.getUTCHours() : e.getHours(), w = m > 12 ? m - 12 : m === 0 ? 12 : m;
          t = (t = (t = (t = t.replace(/(^|[^\\])HH+/g, "$1" + d(m))).replace(/(^|[^\\])H/g, "$1" + m)).replace(/(^|[^\\])hh+/g, "$1" + d(w))).replace(/(^|[^\\])h/g, "$1" + w);
          var C = a ? e.getUTCMinutes() : e.getMinutes();
          t = (t = t.replace(/(^|[^\\])mm+/g, "$1" + d(C))).replace(/(^|[^\\])m/g, "$1" + C);
          var k = a ? e.getUTCSeconds() : e.getSeconds();
          t = (t = t.replace(/(^|[^\\])ss+/g, "$1" + d(k))).replace(/(^|[^\\])s/g, "$1" + k);
          var E = a ? e.getUTCMilliseconds() : e.getMilliseconds();
          t = t.replace(/(^|[^\\])fff+/g, "$1" + d(E, 3)), E = Math.round(E / 10), t = t.replace(/(^|[^\\])ff/g, "$1" + d(E)), E = Math.round(E / 10);
          var _ = m < 12 ? "AM" : "PM";
          t = (t = (t = t.replace(/(^|[^\\])f/g, "$1" + E)).replace(/(^|[^\\])TT+/g, "$1" + _)).replace(/(^|[^\\])T/g, "$1" + _.charAt(0));
          var h = _.toLowerCase();
          t = (t = t.replace(/(^|[^\\])tt+/g, "$1" + h)).replace(/(^|[^\\])t/g, "$1" + h.charAt(0));
          var x = -e.getTimezoneOffset(), S = a || !x ? "Z" : x > 0 ? "+" : "-";
          if (!a) {
            var L = (x = Math.abs(x)) % 60;
            S += d(Math.floor(x / 60)) + ":" + d(L);
          }
          t = t.replace(/(^|[^\\])K/g, "$1" + S);
          var R = (a ? e.getUTCDay() : e.getDay()) + 1;
          return t = (t = (t = (t = (t = t.replace(new RegExp(o[0], "g"), o[R])).replace(new RegExp(c[0], "g"), c[R])).replace(new RegExp(s[0], "g"), s[f])).replace(new RegExp(r[0], "g"), r[f])).replace(/\\(.)/g, "$1");
        } }, { key: "getTimeUnitsfromTimestamp", value: function(e, t, i) {
          var a = this.w;
          a.config.xaxis.min !== void 0 && (e = a.config.xaxis.min), a.config.xaxis.max !== void 0 && (t = a.config.xaxis.max);
          var s = this.getDate(e), r = this.getDate(t), o = this.formatDate(s, "yyyy MM dd HH mm ss fff").split(" "), c = this.formatDate(r, "yyyy MM dd HH mm ss fff").split(" ");
          return { minMillisecond: parseInt(o[6], 10), maxMillisecond: parseInt(c[6], 10), minSecond: parseInt(o[5], 10), maxSecond: parseInt(c[5], 10), minMinute: parseInt(o[4], 10), maxMinute: parseInt(c[4], 10), minHour: parseInt(o[3], 10), maxHour: parseInt(c[3], 10), minDate: parseInt(o[2], 10), maxDate: parseInt(c[2], 10), minMonth: parseInt(o[1], 10) - 1, maxMonth: parseInt(c[1], 10) - 1, minYear: parseInt(o[0], 10), maxYear: parseInt(c[0], 10) };
        } }, { key: "isLeapYear", value: function(e) {
          return e % 4 == 0 && e % 100 != 0 || e % 400 == 0;
        } }, { key: "calculcateLastDaysOfMonth", value: function(e, t, i) {
          return this.determineDaysOfMonths(e, t) - i;
        } }, { key: "determineDaysOfYear", value: function(e) {
          var t = 365;
          return this.isLeapYear(e) && (t = 366), t;
        } }, { key: "determineRemainingDaysOfYear", value: function(e, t, i) {
          var a = this.daysCntOfYear[t] + i;
          return t > 1 && this.isLeapYear() && a++, a;
        } }, { key: "determineDaysOfMonths", value: function(e, t) {
          var i = 30;
          switch (e = M.monthMod(e), !0) {
            case this.months30.indexOf(e) > -1:
              e === 2 && (i = this.isLeapYear(t) ? 29 : 28);
              break;
            case this.months31.indexOf(e) > -1:
            default:
              i = 31;
          }
          return i;
        } }]), P;
      }(), Le = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.tooltipKeyFormat = "dd MMM";
        }
        return A(P, [{ key: "xLabelFormat", value: function(e, t, i, a) {
          var s = this.w;
          if (s.config.xaxis.type === "datetime" && s.config.xaxis.labels.formatter === void 0 && s.config.tooltip.x.formatter === void 0) {
            var r = new ue(this.ctx);
            return r.formatDate(r.getDate(t), s.config.tooltip.x.format);
          }
          return e(t, i, a);
        } }, { key: "defaultGeneralFormatter", value: function(e) {
          return Array.isArray(e) ? e.map(function(t) {
            return t;
          }) : e;
        } }, { key: "defaultYFormatter", value: function(e, t, i) {
          var a = this.w;
          return M.isNumber(e) && (e = a.globals.yValueDecimal !== 0 ? e.toFixed(t.decimalsInFloat !== void 0 ? t.decimalsInFloat : a.globals.yValueDecimal) : a.globals.maxYArr[i] - a.globals.minYArr[i] < 5 ? e.toFixed(1) : e.toFixed(0)), e;
        } }, { key: "setLabelFormatters", value: function() {
          var e = this, t = this.w;
          return t.globals.xaxisTooltipFormatter = function(i) {
            return e.defaultGeneralFormatter(i);
          }, t.globals.ttKeyFormatter = function(i) {
            return e.defaultGeneralFormatter(i);
          }, t.globals.ttZFormatter = function(i) {
            return i;
          }, t.globals.legendFormatter = function(i) {
            return e.defaultGeneralFormatter(i);
          }, t.config.xaxis.labels.formatter !== void 0 ? t.globals.xLabelFormatter = t.config.xaxis.labels.formatter : t.globals.xLabelFormatter = function(i) {
            if (M.isNumber(i)) {
              if (!t.config.xaxis.convertedCatToNumeric && t.config.xaxis.type === "numeric") {
                if (M.isNumber(t.config.xaxis.decimalsInFloat))
                  return i.toFixed(t.config.xaxis.decimalsInFloat);
                var a = t.globals.maxX - t.globals.minX;
                return a > 0 && a < 100 ? i.toFixed(1) : i.toFixed(0);
              }
              return t.globals.isBarHorizontal && t.globals.maxY - t.globals.minYArr < 4 ? i.toFixed(1) : i.toFixed(0);
            }
            return i;
          }, typeof t.config.tooltip.x.formatter == "function" ? t.globals.ttKeyFormatter = t.config.tooltip.x.formatter : t.globals.ttKeyFormatter = t.globals.xLabelFormatter, typeof t.config.xaxis.tooltip.formatter == "function" && (t.globals.xaxisTooltipFormatter = t.config.xaxis.tooltip.formatter), (Array.isArray(t.config.tooltip.y) || t.config.tooltip.y.formatter !== void 0) && (t.globals.ttVal = t.config.tooltip.y), t.config.tooltip.z.formatter !== void 0 && (t.globals.ttZFormatter = t.config.tooltip.z.formatter), t.config.legend.formatter !== void 0 && (t.globals.legendFormatter = t.config.legend.formatter), t.config.yaxis.forEach(function(i, a) {
            i.labels.formatter !== void 0 ? t.globals.yLabelFormatters[a] = i.labels.formatter : t.globals.yLabelFormatters[a] = function(s) {
              return t.globals.xyCharts ? Array.isArray(s) ? s.map(function(r) {
                return e.defaultYFormatter(r, i, a);
              }) : e.defaultYFormatter(s, i, a) : s;
            };
          }), t.globals;
        } }, { key: "heatmapLabelFormatters", value: function() {
          var e = this.w;
          if (e.config.chart.type === "heatmap") {
            e.globals.yAxisScale[0].result = e.globals.seriesNames.slice();
            var t = e.globals.seriesNames.reduce(function(i, a) {
              return i.length > a.length ? i : a;
            }, 0);
            e.globals.yAxisScale[0].niceMax = t, e.globals.yAxisScale[0].niceMin = t;
          }
        } }]), P;
      }(), ke = function(P) {
        var e, t = P.isTimeline, i = P.ctx, a = P.seriesIndex, s = P.dataPointIndex, r = P.y1, o = P.y2, c = P.w, d = c.globals.seriesRangeStart[a][s], g = c.globals.seriesRangeEnd[a][s], f = c.globals.labels[s], p = c.config.series[a].name ? c.config.series[a].name : "", m = c.globals.ttKeyFormatter, w = c.config.tooltip.y.title.formatter, C = { w: c, seriesIndex: a, dataPointIndex: s, start: d, end: g };
        typeof w == "function" && (p = w(p, C)), (e = c.config.series[a].data[s]) !== null && e !== void 0 && e.x && (f = c.config.series[a].data[s].x), t || c.config.xaxis.type === "datetime" && (f = new Le(i).xLabelFormat(c.globals.ttKeyFormatter, f, f, { i: void 0, dateFormatter: new ue(i).formatDate, w: c })), typeof m == "function" && (f = m(f, C)), Number.isFinite(r) && Number.isFinite(o) && (d = r, g = o);
        var k = "", E = "", _ = c.globals.colors[a];
        if (c.config.tooltip.x.formatter === void 0)
          if (c.config.xaxis.type === "datetime") {
            var h = new ue(i);
            k = h.formatDate(h.getDate(d), c.config.tooltip.x.format), E = h.formatDate(h.getDate(g), c.config.tooltip.x.format);
          } else
            k = d, E = g;
        else
          k = c.config.tooltip.x.formatter(d), E = c.config.tooltip.x.formatter(g);
        return { start: d, end: g, startVal: k, endVal: E, ylabel: f, color: _, seriesName: p };
      }, Ae = function(P) {
        var e = P.color, t = P.seriesName, i = P.ylabel, a = P.start, s = P.end, r = P.seriesIndex, o = P.dataPointIndex, c = P.ctx.tooltip.tooltipLabels.getFormatters(r);
        a = c.yLbFormatter(a), s = c.yLbFormatter(s);
        var d = c.yLbFormatter(P.w.globals.series[r][o]), g = `<span class="value start-value">
  `.concat(a, `
  </span> <span class="separator">-</span> <span class="value end-value">
  `).concat(s, `
  </span>`);
        return '<div class="apexcharts-tooltip-rangebar"><div> <span class="series-name" style="color: ' + e + '">' + (t || "") + '</span></div><div> <span class="category">' + i + ": </span> " + (P.w.globals.comboCharts ? P.w.config.series[r].type === "rangeArea" || P.w.config.series[r].type === "rangeBar" ? g : "<span>".concat(d, "</span>") : g) + " </div></div>";
      }, Me = function() {
        function P(e) {
          y(this, P), this.opts = e;
        }
        return A(P, [{ key: "hideYAxis", value: function() {
          this.opts.yaxis[0].show = !1, this.opts.yaxis[0].title.text = "", this.opts.yaxis[0].axisBorder.show = !1, this.opts.yaxis[0].axisTicks.show = !1, this.opts.yaxis[0].floating = !0;
        } }, { key: "line", value: function() {
          return { chart: { animations: { easing: "swing" } }, dataLabels: { enabled: !1 }, stroke: { width: 5, curve: "straight" }, markers: { size: 0, hover: { sizeOffset: 6 } }, xaxis: { crosshairs: { width: 1 } } };
        } }, { key: "sparkline", value: function(e) {
          return this.hideYAxis(), M.extend(e, { grid: { show: !1, padding: { left: 0, right: 0, top: 0, bottom: 0 } }, legend: { show: !1 }, xaxis: { labels: { show: !1 }, tooltip: { enabled: !1 }, axisBorder: { show: !1 }, axisTicks: { show: !1 } }, chart: { toolbar: { show: !1 }, zoom: { enabled: !1 } }, dataLabels: { enabled: !1 } });
        } }, { key: "bar", value: function() {
          return { chart: { stacked: !1, animations: { easing: "swing" } }, plotOptions: { bar: { dataLabels: { position: "center" } } }, dataLabels: { style: { colors: ["#fff"] }, background: { enabled: !1 } }, stroke: { width: 0, lineCap: "round" }, fill: { opacity: 0.85 }, legend: { markers: { shape: "square", radius: 2, size: 8 } }, tooltip: { shared: !1, intersect: !0 }, xaxis: { tooltip: { enabled: !1 }, tickPlacement: "between", crosshairs: { width: "barWidth", position: "back", fill: { type: "gradient" }, dropShadow: { enabled: !1 }, stroke: { width: 0 } } } };
        } }, { key: "funnel", value: function() {
          return this.hideYAxis(), u(u({}, this.bar()), {}, { chart: { animations: { easing: "linear", speed: 800, animateGradually: { enabled: !1 } } }, plotOptions: { bar: { horizontal: !0, borderRadiusApplication: "around", borderRadius: 0, dataLabels: { position: "center" } } }, grid: { show: !1, padding: { left: 0, right: 0 } }, xaxis: { labels: { show: !1 }, tooltip: { enabled: !1 }, axisBorder: { show: !1 }, axisTicks: { show: !1 } } });
        } }, { key: "candlestick", value: function() {
          var e = this;
          return { stroke: { width: 1, colors: ["#333"] }, fill: { opacity: 1 }, dataLabels: { enabled: !1 }, tooltip: { shared: !0, custom: function(t) {
            var i = t.seriesIndex, a = t.dataPointIndex, s = t.w;
            return e._getBoxTooltip(s, i, a, ["Open", "High", "", "Low", "Close"], "candlestick");
          } }, states: { active: { filter: { type: "none" } } }, xaxis: { crosshairs: { width: 1 } } };
        } }, { key: "boxPlot", value: function() {
          var e = this;
          return { chart: { animations: { dynamicAnimation: { enabled: !1 } } }, stroke: { width: 1, colors: ["#24292e"] }, dataLabels: { enabled: !1 }, tooltip: { shared: !0, custom: function(t) {
            var i = t.seriesIndex, a = t.dataPointIndex, s = t.w;
            return e._getBoxTooltip(s, i, a, ["Minimum", "Q1", "Median", "Q3", "Maximum"], "boxPlot");
          } }, markers: { size: 5, strokeWidth: 1, strokeColors: "#111" }, xaxis: { crosshairs: { width: 1 } } };
        } }, { key: "rangeBar", value: function() {
          return { chart: { animations: { animateGradually: !1 } }, stroke: { width: 0, lineCap: "square" }, plotOptions: { bar: { borderRadius: 0, dataLabels: { position: "center" } } }, dataLabels: { enabled: !1, formatter: function(e, t) {
            t.ctx;
            var i = t.seriesIndex, a = t.dataPointIndex, s = t.w, r = function() {
              var o = s.globals.seriesRangeStart[i][a];
              return s.globals.seriesRangeEnd[i][a] - o;
            };
            return s.globals.comboCharts ? s.config.series[i].type === "rangeBar" || s.config.series[i].type === "rangeArea" ? r() : e : r();
          }, background: { enabled: !1 }, style: { colors: ["#fff"] } }, markers: { size: 10 }, tooltip: { shared: !1, followCursor: !0, custom: function(e) {
            return e.w.config.plotOptions && e.w.config.plotOptions.bar && e.w.config.plotOptions.bar.horizontal ? function(t) {
              var i = ke(u(u({}, t), {}, { isTimeline: !0 })), a = i.color, s = i.seriesName, r = i.ylabel, o = i.startVal, c = i.endVal;
              return Ae(u(u({}, t), {}, { color: a, seriesName: s, ylabel: r, start: o, end: c }));
            }(e) : function(t) {
              var i = ke(t), a = i.color, s = i.seriesName, r = i.ylabel, o = i.start, c = i.end;
              return Ae(u(u({}, t), {}, { color: a, seriesName: s, ylabel: r, start: o, end: c }));
            }(e);
          } }, xaxis: { tickPlacement: "between", tooltip: { enabled: !1 }, crosshairs: { stroke: { width: 0 } } } };
        } }, { key: "dumbbell", value: function(e) {
          var t, i;
          return (t = e.plotOptions.bar) !== null && t !== void 0 && t.barHeight || (e.plotOptions.bar.barHeight = 2), (i = e.plotOptions.bar) !== null && i !== void 0 && i.columnWidth || (e.plotOptions.bar.columnWidth = 2), e;
        } }, { key: "area", value: function() {
          return { stroke: { width: 4, fill: { type: "solid", gradient: { inverseColors: !1, shade: "light", type: "vertical", opacityFrom: 0.65, opacityTo: 0.5, stops: [0, 100, 100] } } }, fill: { type: "gradient", gradient: { inverseColors: !1, shade: "light", type: "vertical", opacityFrom: 0.65, opacityTo: 0.5, stops: [0, 100, 100] } }, markers: { size: 0, hover: { sizeOffset: 6 } }, tooltip: { followCursor: !1 } };
        } }, { key: "rangeArea", value: function() {
          return { stroke: { curve: "straight", width: 0 }, fill: { type: "solid", opacity: 0.6 }, markers: { size: 0 }, states: { hover: { filter: { type: "none" } }, active: { filter: { type: "none" } } }, tooltip: { intersect: !1, shared: !0, followCursor: !0, custom: function(e) {
            return function(t) {
              var i = ke(t), a = i.color, s = i.seriesName, r = i.ylabel, o = i.start, c = i.end;
              return Ae(u(u({}, t), {}, { color: a, seriesName: s, ylabel: r, start: o, end: c }));
            }(e);
          } } };
        } }, { key: "brush", value: function(e) {
          return M.extend(e, { chart: { toolbar: { autoSelected: "selection", show: !1 }, zoom: { enabled: !1 } }, dataLabels: { enabled: !1 }, stroke: { width: 1 }, tooltip: { enabled: !1 }, xaxis: { tooltip: { enabled: !1 } } });
        } }, { key: "stacked100", value: function(e) {
          e.dataLabels = e.dataLabels || {}, e.dataLabels.formatter = e.dataLabels.formatter || void 0;
          var t = e.dataLabels.formatter;
          return e.yaxis.forEach(function(i, a) {
            e.yaxis[a].min = 0, e.yaxis[a].max = 100;
          }), e.chart.type === "bar" && (e.dataLabels.formatter = t || function(i) {
            return typeof i == "number" && i ? i.toFixed(0) + "%" : i;
          }), e;
        } }, { key: "stackedBars", value: function() {
          var e = this.bar();
          return u(u({}, e), {}, { plotOptions: u(u({}, e.plotOptions), {}, { bar: u(u({}, e.plotOptions.bar), {}, { borderRadiusApplication: "end", borderRadiusWhenStacked: "last" }) }) });
        } }, { key: "convertCatToNumeric", value: function(e) {
          return e.xaxis.convertedCatToNumeric = !0, e;
        } }, { key: "convertCatToNumericXaxis", value: function(e, t, i) {
          e.xaxis.type = "numeric", e.xaxis.labels = e.xaxis.labels || {}, e.xaxis.labels.formatter = e.xaxis.labels.formatter || function(r) {
            return M.isNumber(r) ? Math.floor(r) : r;
          };
          var a = e.xaxis.labels.formatter, s = e.xaxis.categories && e.xaxis.categories.length ? e.xaxis.categories : e.labels;
          return i && i.length && (s = i.map(function(r) {
            return Array.isArray(r) ? r : String(r);
          })), s && s.length && (e.xaxis.labels.formatter = function(r) {
            return M.isNumber(r) ? a(s[Math.floor(r) - 1]) : a(r);
          }), e.xaxis.categories = [], e.labels = [], e.xaxis.tickAmount = e.xaxis.tickAmount || "dataPoints", e;
        } }, { key: "bubble", value: function() {
          return { dataLabels: { style: { colors: ["#fff"] } }, tooltip: { shared: !1, intersect: !0 }, xaxis: { crosshairs: { width: 0 } }, fill: { type: "solid", gradient: { shade: "light", inverse: !0, shadeIntensity: 0.55, opacityFrom: 0.4, opacityTo: 0.8 } } };
        } }, { key: "scatter", value: function() {
          return { dataLabels: { enabled: !1 }, tooltip: { shared: !1, intersect: !0 }, markers: { size: 6, strokeWidth: 1, hover: { sizeOffset: 2 } } };
        } }, { key: "heatmap", value: function() {
          return { chart: { stacked: !1 }, fill: { opacity: 1 }, dataLabels: { style: { colors: ["#fff"] } }, stroke: { colors: ["#fff"] }, tooltip: { followCursor: !0, marker: { show: !1 }, x: { show: !1 } }, legend: { position: "top", markers: { shape: "square", size: 10, offsetY: 2 } }, grid: { padding: { right: 20 } } };
        } }, { key: "treemap", value: function() {
          return { chart: { zoom: { enabled: !1 } }, dataLabels: { style: { fontSize: 14, fontWeight: 600, colors: ["#fff"] } }, stroke: { show: !0, width: 2, colors: ["#fff"] }, legend: { show: !1 }, fill: { gradient: { stops: [0, 100] } }, tooltip: { followCursor: !0, x: { show: !1 } }, grid: { padding: { left: 0, right: 0 } }, xaxis: { crosshairs: { show: !1 }, tooltip: { enabled: !1 } } };
        } }, { key: "pie", value: function() {
          return { chart: { toolbar: { show: !1 } }, plotOptions: { pie: { donut: { labels: { show: !1 } } } }, dataLabels: { formatter: function(e) {
            return e.toFixed(1) + "%";
          }, style: { colors: ["#fff"] }, background: { enabled: !1 }, dropShadow: { enabled: !0 } }, stroke: { colors: ["#fff"] }, fill: { opacity: 1, gradient: { shade: "light", stops: [0, 100] } }, tooltip: { theme: "dark", fillSeriesColor: !0 }, legend: { position: "right" } };
        } }, { key: "donut", value: function() {
          return { chart: { toolbar: { show: !1 } }, dataLabels: { formatter: function(e) {
            return e.toFixed(1) + "%";
          }, style: { colors: ["#fff"] }, background: { enabled: !1 }, dropShadow: { enabled: !0 } }, stroke: { colors: ["#fff"] }, fill: { opacity: 1, gradient: { shade: "light", shadeIntensity: 0.35, stops: [80, 100], opacityFrom: 1, opacityTo: 1 } }, tooltip: { theme: "dark", fillSeriesColor: !0 }, legend: { position: "right" } };
        } }, { key: "polarArea", value: function() {
          return this.opts.yaxis[0].tickAmount = this.opts.yaxis[0].tickAmount ? this.opts.yaxis[0].tickAmount : 6, { chart: { toolbar: { show: !1 } }, dataLabels: { formatter: function(e) {
            return e.toFixed(1) + "%";
          }, enabled: !1 }, stroke: { show: !0, width: 2 }, fill: { opacity: 0.7 }, tooltip: { theme: "dark", fillSeriesColor: !0 }, legend: { position: "right" } };
        } }, { key: "radar", value: function() {
          return this.opts.yaxis[0].labels.offsetY = this.opts.yaxis[0].labels.offsetY ? this.opts.yaxis[0].labels.offsetY : 6, { dataLabels: { enabled: !1, style: { fontSize: "11px" } }, stroke: { width: 2 }, markers: { size: 3, strokeWidth: 1, strokeOpacity: 1 }, fill: { opacity: 0.2 }, tooltip: { shared: !1, intersect: !0, followCursor: !0 }, grid: { show: !1 }, xaxis: { labels: { formatter: function(e) {
            return e;
          }, style: { colors: ["#a8a8a8"], fontSize: "11px" } }, tooltip: { enabled: !1 }, crosshairs: { show: !1 } } };
        } }, { key: "radialBar", value: function() {
          return { chart: { animations: { dynamicAnimation: { enabled: !0, speed: 800 } }, toolbar: { show: !1 } }, fill: { gradient: { shade: "dark", shadeIntensity: 0.4, inverseColors: !1, type: "diagonal2", opacityFrom: 1, opacityTo: 1, stops: [70, 98, 100] } }, legend: { show: !1, position: "right" }, tooltip: { enabled: !1, fillSeriesColor: !0 } };
        } }, { key: "_getBoxTooltip", value: function(e, t, i, a, s) {
          var r = e.globals.seriesCandleO[t][i], o = e.globals.seriesCandleH[t][i], c = e.globals.seriesCandleM[t][i], d = e.globals.seriesCandleL[t][i], g = e.globals.seriesCandleC[t][i];
          return e.config.series[t].type && e.config.series[t].type !== s ? `<div class="apexcharts-custom-tooltip">
          `.concat(e.config.series[t].name ? e.config.series[t].name : "series-" + (t + 1), ": <strong>").concat(e.globals.series[t][i], `</strong>
        </div>`) : '<div class="apexcharts-tooltip-box apexcharts-tooltip-'.concat(e.config.chart.type, '">') + "<div>".concat(a[0], ': <span class="value">') + r + "</span></div>" + "<div>".concat(a[1], ': <span class="value">') + o + "</span></div>" + (c ? "<div>".concat(a[2], ': <span class="value">') + c + "</span></div>" : "") + "<div>".concat(a[3], ': <span class="value">') + d + "</span></div>" + "<div>".concat(a[4], ': <span class="value">') + g + "</span></div></div>";
        } }]), P;
      }(), Te = function() {
        function P(e) {
          y(this, P), this.opts = e;
        }
        return A(P, [{ key: "init", value: function(e) {
          var t = e.responsiveOverride, i = this.opts, a = new ce(), s = new Me(i);
          this.chartType = i.chart.type, i = this.extendYAxis(i), i = this.extendAnnotations(i);
          var r = a.init(), o = {};
          if (i && b(i) === "object") {
            var c, d, g, f, p, m, w, C, k, E, _ = {};
            _ = ["line", "area", "bar", "candlestick", "boxPlot", "rangeBar", "rangeArea", "bubble", "scatter", "heatmap", "treemap", "pie", "polarArea", "donut", "radar", "radialBar"].indexOf(i.chart.type) !== -1 ? s[i.chart.type]() : s.line(), (c = i.plotOptions) !== null && c !== void 0 && (d = c.bar) !== null && d !== void 0 && d.isFunnel && (_ = s.funnel()), i.chart.stacked && i.chart.type === "bar" && (_ = s.stackedBars()), (g = i.chart.brush) !== null && g !== void 0 && g.enabled && (_ = s.brush(_)), i.chart.stacked && i.chart.stackType === "100%" && (i = s.stacked100(i)), (f = i.plotOptions) !== null && f !== void 0 && (p = f.bar) !== null && p !== void 0 && p.isDumbbell && (i = s.dumbbell(i)), ((m = i) === null || m === void 0 || (w = m.stroke) === null || w === void 0 ? void 0 : w.curve) === "monotoneCubic" && (i.stroke.curve = "smooth"), this.checkForDarkTheme(window.Apex), this.checkForDarkTheme(i), i.xaxis = i.xaxis || window.Apex.xaxis || {}, t || (i.xaxis.convertedCatToNumeric = !1), ((C = (i = this.checkForCatToNumericXAxis(this.chartType, _, i)).chart.sparkline) !== null && C !== void 0 && C.enabled || (k = window.Apex.chart) !== null && k !== void 0 && (E = k.sparkline) !== null && E !== void 0 && E.enabled) && (_ = s.sparkline(_)), o = M.extend(r, _);
          }
          var h = M.extend(o, window.Apex);
          return r = M.extend(h, i), r = this.handleUserInputErrors(r);
        } }, { key: "checkForCatToNumericXAxis", value: function(e, t, i) {
          var a, s, r = new Me(i), o = (e === "bar" || e === "boxPlot") && ((a = i.plotOptions) === null || a === void 0 || (s = a.bar) === null || s === void 0 ? void 0 : s.horizontal), c = e === "pie" || e === "polarArea" || e === "donut" || e === "radar" || e === "radialBar" || e === "heatmap", d = i.xaxis.type !== "datetime" && i.xaxis.type !== "numeric", g = i.xaxis.tickPlacement ? i.xaxis.tickPlacement : t.xaxis && t.xaxis.tickPlacement;
          return o || c || !d || g === "between" || (i = r.convertCatToNumeric(i)), i;
        } }, { key: "extendYAxis", value: function(e, t) {
          var i = new ce();
          (e.yaxis === void 0 || !e.yaxis || Array.isArray(e.yaxis) && e.yaxis.length === 0) && (e.yaxis = {}), e.yaxis.constructor !== Array && window.Apex.yaxis && window.Apex.yaxis.constructor !== Array && (e.yaxis = M.extend(e.yaxis, window.Apex.yaxis)), e.yaxis.constructor !== Array ? e.yaxis = [M.extend(i.yAxis, e.yaxis)] : e.yaxis = M.extendArray(e.yaxis, i.yAxis);
          var a = !1;
          e.yaxis.forEach(function(r) {
            r.logarithmic && (a = !0);
          });
          var s = e.series;
          return t && !s && (s = t.config.series), a && s.length !== e.yaxis.length && s.length && (e.yaxis = s.map(function(r, o) {
            if (r.name || (s[o].name = "series-".concat(o + 1)), e.yaxis[o])
              return e.yaxis[o].seriesName = s[o].name, e.yaxis[o];
            var c = M.extend(i.yAxis, e.yaxis[0]);
            return c.show = !1, c;
          })), a && s.length > 1 && s.length !== e.yaxis.length && console.warn("A multi-series logarithmic chart should have equal number of series and y-axes"), e;
        } }, { key: "extendAnnotations", value: function(e) {
          return e.annotations === void 0 && (e.annotations = {}, e.annotations.yaxis = [], e.annotations.xaxis = [], e.annotations.points = []), e = this.extendYAxisAnnotations(e), e = this.extendXAxisAnnotations(e), e = this.extendPointAnnotations(e);
        } }, { key: "extendYAxisAnnotations", value: function(e) {
          var t = new ce();
          return e.annotations.yaxis = M.extendArray(e.annotations.yaxis !== void 0 ? e.annotations.yaxis : [], t.yAxisAnnotation), e;
        } }, { key: "extendXAxisAnnotations", value: function(e) {
          var t = new ce();
          return e.annotations.xaxis = M.extendArray(e.annotations.xaxis !== void 0 ? e.annotations.xaxis : [], t.xAxisAnnotation), e;
        } }, { key: "extendPointAnnotations", value: function(e) {
          var t = new ce();
          return e.annotations.points = M.extendArray(e.annotations.points !== void 0 ? e.annotations.points : [], t.pointAnnotation), e;
        } }, { key: "checkForDarkTheme", value: function(e) {
          e.theme && e.theme.mode === "dark" && (e.tooltip || (e.tooltip = {}), e.tooltip.theme !== "light" && (e.tooltip.theme = "dark"), e.chart.foreColor || (e.chart.foreColor = "#f6f7f8"), e.chart.background || (e.chart.background = "#424242"), e.theme.palette || (e.theme.palette = "palette4"));
        } }, { key: "handleUserInputErrors", value: function(e) {
          var t = e;
          if (t.tooltip.shared && t.tooltip.intersect)
            throw new Error("tooltip.shared cannot be enabled when tooltip.intersect is true. Turn off any other option by setting it to false.");
          if (t.chart.type === "bar" && t.plotOptions.bar.horizontal) {
            if (t.yaxis.length > 1)
              throw new Error("Multiple Y Axis for bars are not supported. Switch to column chart by setting plotOptions.bar.horizontal=false");
            t.yaxis[0].reversed && (t.yaxis[0].opposite = !0), t.xaxis.tooltip.enabled = !1, t.yaxis[0].tooltip.enabled = !1, t.chart.zoom.enabled = !1;
          }
          return t.chart.type !== "bar" && t.chart.type !== "rangeBar" || t.tooltip.shared && t.xaxis.crosshairs.width === "barWidth" && t.series.length > 1 && (t.xaxis.crosshairs.width = "tickWidth"), t.chart.type !== "candlestick" && t.chart.type !== "boxPlot" || t.yaxis[0].reversed && (console.warn("Reversed y-axis in ".concat(t.chart.type, " chart is not supported.")), t.yaxis[0].reversed = !1), t;
        } }]), P;
      }(), oe = function() {
        function P() {
          y(this, P);
        }
        return A(P, [{ key: "initGlobalVars", value: function(e) {
          e.series = [], e.seriesCandleO = [], e.seriesCandleH = [], e.seriesCandleM = [], e.seriesCandleL = [], e.seriesCandleC = [], e.seriesRangeStart = [], e.seriesRangeEnd = [], e.seriesRange = [], e.seriesPercent = [], e.seriesGoals = [], e.seriesX = [], e.seriesZ = [], e.seriesNames = [], e.seriesTotals = [], e.seriesLog = [], e.seriesColors = [], e.stackedSeriesTotals = [], e.seriesXvalues = [], e.seriesYvalues = [], e.labels = [], e.hasXaxisGroups = !1, e.groups = [], e.hasSeriesGroups = !1, e.seriesGroups = [], e.categoryLabels = [], e.timescaleLabels = [], e.noLabelsProvided = !1, e.resizeTimer = null, e.selectionResizeTimer = null, e.delayedElements = [], e.pointsArray = [], e.dataLabelsRects = [], e.isXNumeric = !1, e.skipLastTimelinelabel = !1, e.skipFirstTimelinelabel = !1, e.isDataXYZ = !1, e.isMultiLineX = !1, e.isMultipleYAxis = !1, e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE, e.minYArr = [], e.maxYArr = [], e.maxX = -Number.MAX_VALUE, e.minX = Number.MAX_VALUE, e.initialMaxX = -Number.MAX_VALUE, e.initialMinX = Number.MAX_VALUE, e.maxDate = 0, e.minDate = Number.MAX_VALUE, e.minZ = Number.MAX_VALUE, e.maxZ = -Number.MAX_VALUE, e.minXDiff = Number.MAX_VALUE, e.yAxisScale = [], e.xAxisScale = null, e.xAxisTicksPositions = [], e.yLabelsCoords = [], e.yTitleCoords = [], e.barPadForNumericAxis = 0, e.padHorizontal = 0, e.xRange = 0, e.yRange = [], e.zRange = 0, e.dataPoints = 0, e.xTickAmount = 0;
        } }, { key: "globalVars", value: function(e) {
          return { chartID: null, cuid: null, events: { beforeMount: [], mounted: [], updated: [], clicked: [], selection: [], dataPointSelection: [], zoomed: [], scrolled: [] }, colors: [], clientX: null, clientY: null, fill: { colors: [] }, stroke: { colors: [] }, dataLabels: { style: { colors: [] } }, radarPolygons: { fill: { colors: [] } }, markers: { colors: [], size: e.markers.size, largestSize: 0 }, animationEnded: !1, isTouchDevice: "ontouchstart" in window || navigator.msMaxTouchPoints, isDirty: !1, isExecCalled: !1, initialConfig: null, initialSeries: [], lastXAxis: [], lastYAxis: [], columnSeries: null, labels: [], timescaleLabels: [], noLabelsProvided: !1, allSeriesCollapsed: !1, collapsedSeries: [], collapsedSeriesIndices: [], ancillaryCollapsedSeries: [], ancillaryCollapsedSeriesIndices: [], risingSeries: [], dataFormatXNumeric: !1, capturedSeriesIndex: -1, capturedDataPointIndex: -1, selectedDataPoints: [], goldenPadding: 35, invalidLogScale: !1, ignoreYAxisIndexes: [], yAxisSameScaleIndices: [], maxValsInArrayIndex: 0, radialSize: 0, selection: void 0, zoomEnabled: e.chart.toolbar.autoSelected === "zoom" && e.chart.toolbar.tools.zoom && e.chart.zoom.enabled, panEnabled: e.chart.toolbar.autoSelected === "pan" && e.chart.toolbar.tools.pan, selectionEnabled: e.chart.toolbar.autoSelected === "selection" && e.chart.toolbar.tools.selection, yaxis: null, mousedown: !1, lastClientPosition: {}, visibleXRange: void 0, yValueDecimal: 0, total: 0, SVGNS: "http://www.w3.org/2000/svg", svgWidth: 0, svgHeight: 0, noData: !1, locale: {}, dom: {}, memory: { methodsToExec: [] }, shouldAnimate: !0, skipLastTimelinelabel: !1, skipFirstTimelinelabel: !1, delayedElements: [], axisCharts: !0, isDataXYZ: !1, resized: !1, resizeTimer: null, comboCharts: !1, dataChanged: !1, previousPaths: [], allSeriesHasEqualX: !0, pointsArray: [], dataLabelsRects: [], lastDrawnDataLabelsIndexes: [], hasNullValues: !1, easing: null, zoomed: !1, gridWidth: 0, gridHeight: 0, rotateXLabels: !1, defaultLabels: !1, xLabelFormatter: void 0, yLabelFormatters: [], xaxisTooltipFormatter: void 0, ttKeyFormatter: void 0, ttVal: void 0, ttZFormatter: void 0, LINE_HEIGHT_RATIO: 1.618, xAxisLabelsHeight: 0, xAxisGroupLabelsHeight: 0, xAxisLabelsWidth: 0, yAxisLabelsWidth: 0, scaleX: 1, scaleY: 1, translateX: 0, translateY: 0, translateYAxisX: [], yAxisWidths: [], translateXAxisY: 0, translateXAxisX: 0, tooltip: null };
        } }, { key: "init", value: function(e) {
          var t = this.globalVars(e);
          return this.initGlobalVars(t), t.initialConfig = M.extend({}, e), t.initialSeries = M.clone(e.series), t.lastXAxis = M.clone(t.initialConfig.xaxis), t.lastYAxis = M.clone(t.initialConfig.yaxis), t;
        } }]), P;
      }(), Q = function() {
        function P(e) {
          y(this, P), this.opts = e;
        }
        return A(P, [{ key: "init", value: function() {
          var e = new Te(this.opts).init({ responsiveOverride: !1 });
          return { config: e, globals: new oe().init(e) };
        } }]), P;
      }(), ae = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.opts = null, this.seriesIndex = 0;
        }
        return A(P, [{ key: "clippedImgArea", value: function(e) {
          var t = this.w, i = t.config, a = parseInt(t.globals.gridWidth, 10), s = parseInt(t.globals.gridHeight, 10), r = a > s ? a : s, o = e.image, c = 0, d = 0;
          e.width === void 0 && e.height === void 0 ? i.fill.image.width !== void 0 && i.fill.image.height !== void 0 ? (c = i.fill.image.width + 1, d = i.fill.image.height) : (c = r + 1, d = r) : (c = e.width, d = e.height);
          var g = document.createElementNS(t.globals.SVGNS, "pattern");
          X.setAttrs(g, { id: e.patternID, patternUnits: e.patternUnits ? e.patternUnits : "userSpaceOnUse", width: c + "px", height: d + "px" });
          var f = document.createElementNS(t.globals.SVGNS, "image");
          g.appendChild(f), f.setAttributeNS(window.SVG.xlink, "href", o), X.setAttrs(f, { x: 0, y: 0, preserveAspectRatio: "none", width: c + "px", height: d + "px" }), f.style.opacity = e.opacity, t.globals.dom.elDefs.node.appendChild(g);
        } }, { key: "getSeriesIndex", value: function(e) {
          var t = this.w, i = t.config.chart.type;
          return (i === "bar" || i === "rangeBar") && t.config.plotOptions.bar.distributed || i === "heatmap" || i === "treemap" ? this.seriesIndex = e.seriesNumber : this.seriesIndex = e.seriesNumber % t.globals.series.length, this.seriesIndex;
        } }, { key: "fillPath", value: function(e) {
          var t = this.w;
          this.opts = e;
          var i, a, s, r = this.w.config;
          this.seriesIndex = this.getSeriesIndex(e);
          var o = this.getFillColors()[this.seriesIndex];
          t.globals.seriesColors[this.seriesIndex] !== void 0 && (o = t.globals.seriesColors[this.seriesIndex]), typeof o == "function" && (o = o({ seriesIndex: this.seriesIndex, dataPointIndex: e.dataPointIndex, value: e.value, w: t }));
          var c = e.fillType ? e.fillType : this.getFillType(this.seriesIndex), d = Array.isArray(r.fill.opacity) ? r.fill.opacity[this.seriesIndex] : r.fill.opacity;
          e.color && (o = e.color), o || (o = "#fff", console.warn("undefined color - ApexCharts"));
          var g = o;
          if (o.indexOf("rgb") === -1 ? o.length < 9 && (g = M.hexToRgba(o, d)) : o.indexOf("rgba") > -1 && (d = M.getOpacityFromRGBA(o)), e.opacity && (d = e.opacity), c === "pattern" && (a = this.handlePatternFill({ fillConfig: e.fillConfig, patternFill: a, fillColor: o, fillOpacity: d, defaultColor: g })), c === "gradient" && (s = this.handleGradientFill({ fillConfig: e.fillConfig, fillColor: o, fillOpacity: d, i: this.seriesIndex })), c === "image") {
            var f = r.fill.image.src, p = e.patternID ? e.patternID : "";
            this.clippedImgArea({ opacity: d, image: Array.isArray(f) ? e.seriesNumber < f.length ? f[e.seriesNumber] : f[0] : f, width: e.width ? e.width : void 0, height: e.height ? e.height : void 0, patternUnits: e.patternUnits, patternID: "pattern".concat(t.globals.cuid).concat(e.seriesNumber + 1).concat(p) }), i = "url(#pattern".concat(t.globals.cuid).concat(e.seriesNumber + 1).concat(p, ")");
          } else
            i = c === "gradient" ? s : c === "pattern" ? a : g;
          return e.solid && (i = g), i;
        } }, { key: "getFillType", value: function(e) {
          var t = this.w;
          return Array.isArray(t.config.fill.type) ? t.config.fill.type[e] : t.config.fill.type;
        } }, { key: "getFillColors", value: function() {
          var e = this.w, t = e.config, i = this.opts, a = [];
          return e.globals.comboCharts ? e.config.series[this.seriesIndex].type === "line" ? Array.isArray(e.globals.stroke.colors) ? a = e.globals.stroke.colors : a.push(e.globals.stroke.colors) : Array.isArray(e.globals.fill.colors) ? a = e.globals.fill.colors : a.push(e.globals.fill.colors) : t.chart.type === "line" ? Array.isArray(e.globals.stroke.colors) ? a = e.globals.stroke.colors : a.push(e.globals.stroke.colors) : Array.isArray(e.globals.fill.colors) ? a = e.globals.fill.colors : a.push(e.globals.fill.colors), i.fillColors !== void 0 && (a = [], Array.isArray(i.fillColors) ? a = i.fillColors.slice() : a.push(i.fillColors)), a;
        } }, { key: "handlePatternFill", value: function(e) {
          var t = e.fillConfig, i = e.patternFill, a = e.fillColor, s = e.fillOpacity, r = e.defaultColor, o = this.w.config.fill;
          t && (o = t);
          var c = this.opts, d = new X(this.ctx), g = Array.isArray(o.pattern.strokeWidth) ? o.pattern.strokeWidth[this.seriesIndex] : o.pattern.strokeWidth, f = a;
          return Array.isArray(o.pattern.style) ? i = o.pattern.style[c.seriesNumber] !== void 0 ? d.drawPattern(o.pattern.style[c.seriesNumber], o.pattern.width, o.pattern.height, f, g, s) : r : i = d.drawPattern(o.pattern.style, o.pattern.width, o.pattern.height, f, g, s), i;
        } }, { key: "handleGradientFill", value: function(e) {
          var t = e.fillColor, i = e.fillOpacity, a = e.fillConfig, s = e.i, r = this.w.config.fill;
          a && (r = u(u({}, r), a));
          var o, c = this.opts, d = new X(this.ctx), g = new M(), f = r.gradient.type, p = t, m = r.gradient.opacityFrom === void 0 ? i : Array.isArray(r.gradient.opacityFrom) ? r.gradient.opacityFrom[s] : r.gradient.opacityFrom;
          p.indexOf("rgba") > -1 && (m = M.getOpacityFromRGBA(p));
          var w = r.gradient.opacityTo === void 0 ? i : Array.isArray(r.gradient.opacityTo) ? r.gradient.opacityTo[s] : r.gradient.opacityTo;
          if (r.gradient.gradientToColors === void 0 || r.gradient.gradientToColors.length === 0)
            o = r.gradient.shade === "dark" ? g.shadeColor(-1 * parseFloat(r.gradient.shadeIntensity), t.indexOf("rgb") > -1 ? M.rgb2hex(t) : t) : g.shadeColor(parseFloat(r.gradient.shadeIntensity), t.indexOf("rgb") > -1 ? M.rgb2hex(t) : t);
          else if (r.gradient.gradientToColors[c.seriesNumber]) {
            var C = r.gradient.gradientToColors[c.seriesNumber];
            o = C, C.indexOf("rgba") > -1 && (w = M.getOpacityFromRGBA(C));
          } else
            o = t;
          if (r.gradient.gradientFrom && (p = r.gradient.gradientFrom), r.gradient.gradientTo && (o = r.gradient.gradientTo), r.gradient.inverseColors) {
            var k = p;
            p = o, o = k;
          }
          return p.indexOf("rgb") > -1 && (p = M.rgb2hex(p)), o.indexOf("rgb") > -1 && (o = M.rgb2hex(o)), d.drawGradient(f, p, o, m, w, c.size, r.gradient.stops, r.gradient.colorStops, s);
        } }]), P;
      }(), le = function() {
        function P(e, t) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "setGlobalMarkerSize", value: function() {
          var e = this.w;
          if (e.globals.markers.size = Array.isArray(e.config.markers.size) ? e.config.markers.size : [e.config.markers.size], e.globals.markers.size.length > 0) {
            if (e.globals.markers.size.length < e.globals.series.length + 1)
              for (var t = 0; t <= e.globals.series.length; t++)
                e.globals.markers.size[t] === void 0 && e.globals.markers.size.push(e.globals.markers.size[0]);
          } else
            e.globals.markers.size = e.config.series.map(function(i) {
              return e.config.markers.size;
            });
        } }, { key: "plotChartMarkers", value: function(e, t, i, a) {
          var s, r = arguments.length > 4 && arguments[4] !== void 0 && arguments[4], o = this.w, c = t, d = e, g = null, f = new X(this.ctx), p = o.config.markers.discrete && o.config.markers.discrete.length;
          if ((o.globals.markers.size[t] > 0 || r || p) && (g = f.group({ class: r || p ? "" : "apexcharts-series-markers" })).attr("clip-path", "url(#gridRectMarkerMask".concat(o.globals.cuid, ")")), Array.isArray(d.x))
            for (var m = 0; m < d.x.length; m++) {
              var w = i;
              i === 1 && m === 0 && (w = 0), i === 1 && m === 1 && (w = 1);
              var C = "apexcharts-marker";
              if (o.config.chart.type !== "line" && o.config.chart.type !== "area" || o.globals.comboCharts || o.config.tooltip.intersect || (C += " no-pointer-events"), (Array.isArray(o.config.markers.size) ? o.globals.markers.size[t] > 0 : o.config.markers.size > 0) || r || p) {
                M.isNumber(d.y[m]) ? C += " w".concat(M.randomId()) : C = "apexcharts-nullpoint";
                var k = this.getMarkerConfig({ cssClass: C, seriesIndex: t, dataPointIndex: w });
                o.config.series[c].data[w] && (o.config.series[c].data[w].fillColor && (k.pointFillColor = o.config.series[c].data[w].fillColor), o.config.series[c].data[w].strokeColor && (k.pointStrokeColor = o.config.series[c].data[w].strokeColor)), a && (k.pSize = a), (d.x[m] < 0 || d.x[m] > o.globals.gridWidth || d.y[m] < -o.globals.markers.largestSize || d.y[m] > o.globals.gridHeight + o.globals.markers.largestSize) && (k.pSize = 0), (s = f.drawMarker(d.x[m], d.y[m], k)).attr("rel", w), s.attr("j", w), s.attr("index", t), s.node.setAttribute("default-marker-size", k.pSize), new G(this.ctx).setSelectionFilter(s, t, w), this.addEvents(s), g && g.add(s);
              } else
                o.globals.pointsArray[t] === void 0 && (o.globals.pointsArray[t] = []), o.globals.pointsArray[t].push([d.x[m], d.y[m]]);
            }
          return g;
        } }, { key: "getMarkerConfig", value: function(e) {
          var t = e.cssClass, i = e.seriesIndex, a = e.dataPointIndex, s = a === void 0 ? null : a, r = e.finishRadius, o = r === void 0 ? null : r, c = this.w, d = this.getMarkerStyle(i), g = c.globals.markers.size[i], f = c.config.markers;
          return s !== null && f.discrete.length && f.discrete.map(function(p) {
            p.seriesIndex === i && p.dataPointIndex === s && (d.pointStrokeColor = p.strokeColor, d.pointFillColor = p.fillColor, g = p.size, d.pointShape = p.shape);
          }), { pSize: o === null ? g : o, pRadius: f.radius, width: Array.isArray(f.width) ? f.width[i] : f.width, height: Array.isArray(f.height) ? f.height[i] : f.height, pointStrokeWidth: Array.isArray(f.strokeWidth) ? f.strokeWidth[i] : f.strokeWidth, pointStrokeColor: d.pointStrokeColor, pointFillColor: d.pointFillColor, shape: d.pointShape || (Array.isArray(f.shape) ? f.shape[i] : f.shape), class: t, pointStrokeOpacity: Array.isArray(f.strokeOpacity) ? f.strokeOpacity[i] : f.strokeOpacity, pointStrokeDashArray: Array.isArray(f.strokeDashArray) ? f.strokeDashArray[i] : f.strokeDashArray, pointFillOpacity: Array.isArray(f.fillOpacity) ? f.fillOpacity[i] : f.fillOpacity, seriesIndex: i };
        } }, { key: "addEvents", value: function(e) {
          var t = this.w, i = new X(this.ctx);
          e.node.addEventListener("mouseenter", i.pathMouseEnter.bind(this.ctx, e)), e.node.addEventListener("mouseleave", i.pathMouseLeave.bind(this.ctx, e)), e.node.addEventListener("mousedown", i.pathMouseDown.bind(this.ctx, e)), e.node.addEventListener("click", t.config.markers.onClick), e.node.addEventListener("dblclick", t.config.markers.onDblClick), e.node.addEventListener("touchstart", i.pathMouseDown.bind(this.ctx, e), { passive: !0 });
        } }, { key: "getMarkerStyle", value: function(e) {
          var t = this.w, i = t.globals.markers.colors, a = t.config.markers.strokeColor || t.config.markers.strokeColors;
          return { pointStrokeColor: Array.isArray(a) ? a[e] : a, pointFillColor: Array.isArray(i) ? i[e] : i };
        } }]), P;
      }(), pe = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled;
        }
        return A(P, [{ key: "draw", value: function(e, t, i) {
          var a = this.w, s = new X(this.ctx), r = i.realIndex, o = i.pointsPos, c = i.zRatio, d = i.elParent, g = s.group({ class: "apexcharts-series-markers apexcharts-series-".concat(a.config.chart.type) });
          if (g.attr("clip-path", "url(#gridRectMarkerMask".concat(a.globals.cuid, ")")), Array.isArray(o.x))
            for (var f = 0; f < o.x.length; f++) {
              var p = t + 1, m = !0;
              t === 0 && f === 0 && (p = 0), t === 0 && f === 1 && (p = 1);
              var w = 0, C = a.globals.markers.size[r];
              if (c !== 1 / 0) {
                var k = a.config.plotOptions.bubble;
                C = a.globals.seriesZ[r][p], k.zScaling && (C /= c), k.minBubbleRadius && C < k.minBubbleRadius && (C = k.minBubbleRadius), k.maxBubbleRadius && C > k.maxBubbleRadius && (C = k.maxBubbleRadius);
              }
              a.config.chart.animations.enabled || (w = C);
              var E = o.x[f], _ = o.y[f];
              if (w = w || 0, _ !== null && a.globals.series[r][p] !== void 0 || (m = !1), m) {
                var h = this.drawPoint(E, _, w, C, r, p, t);
                g.add(h);
              }
              d.add(g);
            }
        } }, { key: "drawPoint", value: function(e, t, i, a, s, r, o) {
          var c = this.w, d = s, g = new V(this.ctx), f = new G(this.ctx), p = new ae(this.ctx), m = new le(this.ctx), w = new X(this.ctx), C = m.getMarkerConfig({ cssClass: "apexcharts-marker", seriesIndex: d, dataPointIndex: r, finishRadius: c.config.chart.type === "bubble" || c.globals.comboCharts && c.config.series[s] && c.config.series[s].type === "bubble" ? a : null });
          a = C.pSize;
          var k, E = p.fillPath({ seriesNumber: s, dataPointIndex: r, color: C.pointFillColor, patternUnits: "objectBoundingBox", value: c.globals.series[s][o] });
          if (C.shape === "circle" ? k = w.drawCircle(i) : C.shape !== "square" && C.shape !== "rect" || (k = w.drawRect(0, 0, C.width - C.pointStrokeWidth / 2, C.height - C.pointStrokeWidth / 2, C.pRadius)), c.config.series[d].data[r] && c.config.series[d].data[r].fillColor && (E = c.config.series[d].data[r].fillColor), k.attr({ x: e - C.width / 2 - C.pointStrokeWidth / 2, y: t - C.height / 2 - C.pointStrokeWidth / 2, cx: e, cy: t, fill: E, "fill-opacity": C.pointFillOpacity, stroke: C.pointStrokeColor, r: a, "stroke-width": C.pointStrokeWidth, "stroke-dasharray": C.pointStrokeDashArray, "stroke-opacity": C.pointStrokeOpacity }), c.config.chart.dropShadow.enabled) {
            var _ = c.config.chart.dropShadow;
            f.dropShadow(k, _, s);
          }
          if (!this.initialAnim || c.globals.dataChanged || c.globals.resized)
            c.globals.animationEnded = !0;
          else {
            var h = c.config.chart.animations.speed;
            g.animateMarker(k, 0, C.shape === "circle" ? a : { width: C.width, height: C.height }, h, c.globals.easing, function() {
              window.setTimeout(function() {
                g.animationCompleted(k);
              }, 100);
            });
          }
          if (c.globals.dataChanged && C.shape === "circle")
            if (this.dynamicAnim) {
              var x, S, L, R, O = c.config.chart.animations.dynamicAnimation.speed;
              (R = c.globals.previousPaths[s] && c.globals.previousPaths[s][o]) != null && (x = R.x, S = R.y, L = R.r !== void 0 ? R.r : a);
              for (var Y = 0; Y < c.globals.collapsedSeries.length; Y++)
                c.globals.collapsedSeries[Y].index === s && (O = 1, a = 0);
              e === 0 && t === 0 && (a = 0), g.animateCircle(k, { cx: x, cy: S, r: L }, { cx: e, cy: t, r: a }, O, c.globals.easing);
            } else
              k.attr({ r: a });
          return k.attr({ rel: r, j: r, index: s, "default-marker-size": a }), f.setSelectionFilter(k, s, r), m.addEvents(k), k.node.classList.add("apexcharts-marker"), k;
        } }, { key: "centerTextInBubble", value: function(e) {
          var t = this.w;
          return { y: e += parseInt(t.config.dataLabels.style.fontSize, 10) / 4 };
        } }]), P;
      }(), xe = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "dataLabelsCorrection", value: function(e, t, i, a, s, r, o) {
          var c = this.w, d = !1, g = new X(this.ctx).getTextRects(i, o), f = g.width, p = g.height;
          t < 0 && (t = 0), t > c.globals.gridHeight + p && (t = c.globals.gridHeight + p / 2), c.globals.dataLabelsRects[a] === void 0 && (c.globals.dataLabelsRects[a] = []), c.globals.dataLabelsRects[a].push({ x: e, y: t, width: f, height: p });
          var m = c.globals.dataLabelsRects[a].length - 2, w = c.globals.lastDrawnDataLabelsIndexes[a] !== void 0 ? c.globals.lastDrawnDataLabelsIndexes[a][c.globals.lastDrawnDataLabelsIndexes[a].length - 1] : 0;
          if (c.globals.dataLabelsRects[a][m] !== void 0) {
            var C = c.globals.dataLabelsRects[a][w];
            (e > C.x + C.width || t > C.y + C.height || t + p < C.y || e + f < C.x) && (d = !0);
          }
          return (s === 0 || r) && (d = !0), { x: e, y: t, textRects: g, drawnextLabel: d };
        } }, { key: "drawDataLabel", value: function(e) {
          var t = this, i = e.type, a = e.pos, s = e.i, r = e.j, o = e.isRangeStart, c = e.strokeWidth, d = c === void 0 ? 2 : c, g = this.w, f = new X(this.ctx), p = g.config.dataLabels, m = 0, w = 0, C = r, k = null;
          if (!p.enabled || !Array.isArray(a.x))
            return k;
          k = f.group({ class: "apexcharts-data-labels" });
          for (var E = 0; E < a.x.length; E++)
            if (m = a.x[E] + p.offsetX, w = a.y[E] + p.offsetY + d, !isNaN(m)) {
              r === 1 && E === 0 && (C = 0), r === 1 && E === 1 && (C = 1);
              var _ = g.globals.series[s][C];
              i === "rangeArea" && (_ = o ? g.globals.seriesRangeStart[s][C] : g.globals.seriesRangeEnd[s][C]);
              var h = "", x = function(S) {
                return g.config.dataLabels.formatter(S, { ctx: t.ctx, seriesIndex: s, dataPointIndex: C, w: g });
              };
              g.config.chart.type === "bubble" ? (h = x(_ = g.globals.seriesZ[s][C]), w = a.y[E], w = new pe(this.ctx).centerTextInBubble(w, s, C).y) : _ !== void 0 && (h = x(_)), this.plotDataLabelsText({ x: m, y: w, text: h, i: s, j: C, parent: k, offsetCorrection: !0, dataLabelsConfig: g.config.dataLabels });
            }
          return k;
        } }, { key: "plotDataLabelsText", value: function(e) {
          var t = this.w, i = new X(this.ctx), a = e.x, s = e.y, r = e.i, o = e.j, c = e.text, d = e.textAnchor, g = e.fontSize, f = e.parent, p = e.dataLabelsConfig, m = e.color, w = e.alwaysDrawDataLabel, C = e.offsetCorrection;
          if (!(Array.isArray(t.config.dataLabels.enabledOnSeries) && t.config.dataLabels.enabledOnSeries.indexOf(r) < 0)) {
            var k = { x: a, y: s, drawnextLabel: !0, textRects: null };
            C && (k = this.dataLabelsCorrection(a, s, c, r, o, w, parseInt(p.style.fontSize, 10))), t.globals.zoomed || (a = k.x, s = k.y), k.textRects && (a < -20 - k.textRects.width || a > t.globals.gridWidth + k.textRects.width + 30) && (c = "");
            var E = t.globals.dataLabels.style.colors[r];
            ((t.config.chart.type === "bar" || t.config.chart.type === "rangeBar") && t.config.plotOptions.bar.distributed || t.config.dataLabels.distributed) && (E = t.globals.dataLabels.style.colors[o]), typeof E == "function" && (E = E({ series: t.globals.series, seriesIndex: r, dataPointIndex: o, w: t })), m && (E = m);
            var _ = p.offsetX, h = p.offsetY;
            if (t.config.chart.type !== "bar" && t.config.chart.type !== "rangeBar" || (_ = 0, h = 0), k.drawnextLabel) {
              var x = i.drawText({ width: 100, height: parseInt(p.style.fontSize, 10), x: a + _, y: s + h, foreColor: E, textAnchor: d || p.textAnchor, text: c, fontSize: g || p.style.fontSize, fontFamily: p.style.fontFamily, fontWeight: p.style.fontWeight || "normal" });
              if (x.attr({ class: "apexcharts-datalabel", cx: a, cy: s }), p.dropShadow.enabled) {
                var S = p.dropShadow;
                new G(this.ctx).dropShadow(x, S);
              }
              f.add(x), t.globals.lastDrawnDataLabelsIndexes[r] === void 0 && (t.globals.lastDrawnDataLabelsIndexes[r] = []), t.globals.lastDrawnDataLabelsIndexes[r].push(o);
            }
          }
        } }, { key: "addBackgroundToDataLabel", value: function(e, t) {
          var i = this.w, a = i.config.dataLabels.background, s = a.padding, r = a.padding / 2, o = t.width, c = t.height, d = new X(this.ctx).drawRect(t.x - s, t.y - r / 2, o + 2 * s, c + r, a.borderRadius, i.config.chart.background === "transparent" ? "#fff" : i.config.chart.background, a.opacity, a.borderWidth, a.borderColor);
          return a.dropShadow.enabled && new G(this.ctx).dropShadow(d, a.dropShadow), d;
        } }, { key: "dataLabelsBackground", value: function() {
          var e = this.w;
          if (e.config.chart.type !== "bubble")
            for (var t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels text"), i = 0; i < t.length; i++) {
              var a = t[i], s = a.getBBox(), r = null;
              if (s.width && s.height && (r = this.addBackgroundToDataLabel(a, s)), r) {
                a.parentNode.insertBefore(r.node, a);
                var o = a.getAttribute("fill");
                e.config.chart.animations.enabled && !e.globals.resized && !e.globals.dataChanged ? r.animate().attr({ fill: o }) : r.attr({ fill: o }), a.setAttribute("fill", e.config.dataLabels.background.foreColor);
              }
            }
        } }, { key: "bringForward", value: function() {
          for (var e = this.w, t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels"), i = e.globals.dom.baseEl.querySelector(".apexcharts-plot-series:last-child"), a = 0; a < t.length; a++)
            i && i.insertBefore(t[a], i.nextSibling);
        } }]), P;
      }(), de = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.legendInactiveClass = "legend-mouseover-inactive";
        }
        return A(P, [{ key: "getAllSeriesEls", value: function() {
          return this.w.globals.dom.baseEl.getElementsByClassName("apexcharts-series");
        } }, { key: "getSeriesByName", value: function(e) {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner .apexcharts-series[seriesName='".concat(M.escapeString(e), "']"));
        } }, { key: "isSeriesHidden", value: function(e) {
          var t = this.getSeriesByName(e), i = parseInt(t.getAttribute("data:realIndex"), 10);
          return { isHidden: t.classList.contains("apexcharts-series-collapsed"), realIndex: i };
        } }, { key: "addCollapsedClassToSeries", value: function(e, t) {
          var i = this.w;
          function a(s) {
            for (var r = 0; r < s.length; r++)
              s[r].index === t && e.node.classList.add("apexcharts-series-collapsed");
          }
          a(i.globals.collapsedSeries), a(i.globals.ancillaryCollapsedSeries);
        } }, { key: "toggleSeries", value: function(e) {
          var t = this.isSeriesHidden(e);
          return this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, t.isHidden), t.isHidden;
        } }, { key: "showSeries", value: function(e) {
          var t = this.isSeriesHidden(e);
          t.isHidden && this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !0);
        } }, { key: "hideSeries", value: function(e) {
          var t = this.isSeriesHidden(e);
          t.isHidden || this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !1);
        } }, { key: "resetSeries", value: function() {
          var e = !(arguments.length > 0 && arguments[0] !== void 0) || arguments[0], t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], a = this.w, s = M.clone(a.globals.initialSeries);
          a.globals.previousPaths = [], i ? (a.globals.collapsedSeries = [], a.globals.ancillaryCollapsedSeries = [], a.globals.collapsedSeriesIndices = [], a.globals.ancillaryCollapsedSeriesIndices = []) : s = this.emptyCollapsedSeries(s), a.config.series = s, e && (t && (a.globals.zoomed = !1, this.ctx.updateHelpers.revertDefaultAxisMinMax()), this.ctx.updateHelpers._updateSeries(s, a.config.chart.animations.dynamicAnimation.enabled));
        } }, { key: "emptyCollapsedSeries", value: function(e) {
          for (var t = this.w, i = 0; i < e.length; i++)
            t.globals.collapsedSeriesIndices.indexOf(i) > -1 && (e[i].data = []);
          return e;
        } }, { key: "toggleSeriesOnHover", value: function(e, t) {
          var i = this.w;
          t || (t = e.target);
          var a = i.globals.dom.baseEl.querySelectorAll(".apexcharts-series, .apexcharts-datalabels");
          if (e.type === "mousemove") {
            var s = parseInt(t.getAttribute("rel"), 10) - 1, r = null, o = null;
            i.globals.axisCharts || i.config.chart.type === "radialBar" ? i.globals.axisCharts ? (r = i.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(s, "']")), o = i.globals.dom.baseEl.querySelector(".apexcharts-datalabels[data\\:realIndex='".concat(s, "']"))) : r = i.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(s + 1, "']")) : r = i.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(s + 1, "'] path"));
            for (var c = 0; c < a.length; c++)
              a[c].classList.add(this.legendInactiveClass);
            r !== null && (i.globals.axisCharts || r.parentNode.classList.remove(this.legendInactiveClass), r.classList.remove(this.legendInactiveClass), o !== null && o.classList.remove(this.legendInactiveClass));
          } else if (e.type === "mouseout")
            for (var d = 0; d < a.length; d++)
              a[d].classList.remove(this.legendInactiveClass);
        } }, { key: "highlightRangeInSeries", value: function(e, t) {
          var i = this, a = this.w, s = a.globals.dom.baseEl.getElementsByClassName("apexcharts-heatmap-rect"), r = function(c) {
            for (var d = 0; d < s.length; d++)
              s[d].classList[c](i.legendInactiveClass);
          };
          if (e.type === "mousemove") {
            var o = parseInt(t.getAttribute("rel"), 10) - 1;
            r("add"), function(c) {
              for (var d = 0; d < s.length; d++) {
                var g = parseInt(s[d].getAttribute("val"), 10);
                g >= c.from && g <= c.to && s[d].classList.remove(i.legendInactiveClass);
              }
            }(a.config.plotOptions.heatmap.colorScale.ranges[o]);
          } else
            e.type === "mouseout" && r("remove");
        } }, { key: "getActiveConfigSeriesIndex", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "asc", t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], i = this.w, a = 0;
          if (i.config.series.length > 1) {
            for (var s = i.config.series.map(function(o, c) {
              return o.data && o.data.length > 0 && i.globals.collapsedSeriesIndices.indexOf(c) === -1 && (!i.globals.comboCharts || t.length === 0 || t.length && t.indexOf(i.config.series[c].type) > -1) ? c : -1;
            }), r = e === "asc" ? 0 : s.length - 1; e === "asc" ? r < s.length : r >= 0; e === "asc" ? r++ : r--)
              if (s[r] !== -1) {
                a = s[r];
                break;
              }
          }
          return a;
        } }, { key: "getBarSeriesIndices", value: function() {
          return this.w.globals.comboCharts ? this.w.config.series.map(function(e, t) {
            return e.type === "bar" || e.type === "column" ? t : -1;
          }).filter(function(e) {
            return e !== -1;
          }) : this.w.config.series.map(function(e, t) {
            return t;
          });
        } }, { key: "getPreviousPaths", value: function() {
          var e = this.w;
          function t(r, o, c) {
            for (var d = r[o].childNodes, g = { type: c, paths: [], realIndex: r[o].getAttribute("data:realIndex") }, f = 0; f < d.length; f++)
              if (d[f].hasAttribute("pathTo")) {
                var p = d[f].getAttribute("pathTo");
                g.paths.push({ d: p });
              }
            e.globals.previousPaths.push(g);
          }
          e.globals.previousPaths = [], ["line", "area", "bar", "rangebar", "rangeArea", "candlestick", "radar"].forEach(function(r) {
            for (var o, c = (o = r, e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(o, "-series .apexcharts-series"))), d = 0; d < c.length; d++)
              t(c, d, r);
          }), this.handlePrevBubbleScatterPaths("bubble"), this.handlePrevBubbleScatterPaths("scatter");
          var i = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart.type, " .apexcharts-series"));
          if (i.length > 0)
            for (var a = function(r) {
              for (var o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart.type, " .apexcharts-series[data\\:realIndex='").concat(r, "'] rect")), c = [], d = function(f) {
                var p = function(w) {
                  return o[f].getAttribute(w);
                }, m = { x: parseFloat(p("x")), y: parseFloat(p("y")), width: parseFloat(p("width")), height: parseFloat(p("height")) };
                c.push({ rect: m, color: o[f].getAttribute("color") });
              }, g = 0; g < o.length; g++)
                d(g);
              e.globals.previousPaths.push(c);
            }, s = 0; s < i.length; s++)
              a(s);
          e.globals.axisCharts || (e.globals.previousPaths = e.globals.series);
        } }, { key: "handlePrevBubbleScatterPaths", value: function(e) {
          var t = this.w, i = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e, "-series .apexcharts-series"));
          if (i.length > 0)
            for (var a = 0; a < i.length; a++) {
              for (var s = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e, "-series .apexcharts-series[data\\:realIndex='").concat(a, "'] circle")), r = [], o = 0; o < s.length; o++)
                r.push({ x: s[o].getAttribute("cx"), y: s[o].getAttribute("cy"), r: s[o].getAttribute("r") });
              t.globals.previousPaths.push(r);
            }
        } }, { key: "clearPreviousPaths", value: function() {
          var e = this.w;
          e.globals.previousPaths = [], e.globals.allSeriesCollapsed = !1;
        } }, { key: "handleNoData", value: function() {
          var e = this.w, t = e.config.noData, i = new X(this.ctx), a = e.globals.svgWidth / 2, s = e.globals.svgHeight / 2, r = "middle";
          if (e.globals.noData = !0, e.globals.animationEnded = !0, t.align === "left" ? (a = 10, r = "start") : t.align === "right" && (a = e.globals.svgWidth - 10, r = "end"), t.verticalAlign === "top" ? s = 50 : t.verticalAlign === "bottom" && (s = e.globals.svgHeight - 50), a += t.offsetX, s = s + parseInt(t.style.fontSize, 10) + 2 + t.offsetY, t.text !== void 0 && t.text !== "") {
            var o = i.drawText({ x: a, y: s, text: t.text, textAnchor: r, fontSize: t.style.fontSize, fontFamily: t.style.fontFamily, foreColor: t.style.color, opacity: 1, class: "apexcharts-text-nodata" });
            e.globals.dom.Paper.add(o);
          }
        } }, { key: "setNullSeriesToZeroValues", value: function(e) {
          for (var t = this.w, i = 0; i < e.length; i++)
            if (e[i].length === 0)
              for (var a = 0; a < e[t.globals.maxValsInArrayIndex].length; a++)
                e[i].push(0);
          return e;
        } }, { key: "hasAllSeriesEqualX", value: function() {
          for (var e = !0, t = this.w, i = this.filteredSeriesX(), a = 0; a < i.length - 1; a++)
            if (i[a][0] !== i[a + 1][0]) {
              e = !1;
              break;
            }
          return t.globals.allSeriesHasEqualX = e, e;
        } }, { key: "filteredSeriesX", value: function() {
          var e = this.w.globals.seriesX.map(function(t) {
            return t.length > 0 ? t : [];
          });
          return e;
        } }]), P;
      }(), ve = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.twoDSeries = [], this.threeDSeries = [], this.twoDSeriesX = [], this.seriesGoals = [], this.coreUtils = new $(this.ctx);
        }
        return A(P, [{ key: "isMultiFormat", value: function() {
          return this.isFormatXY() || this.isFormat2DArray();
        } }, { key: "isFormatXY", value: function() {
          var e = this.w.config.series.slice(), t = new de(this.ctx);
          if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), e[this.activeSeriesIndex].data !== void 0 && e[this.activeSeriesIndex].data.length > 0 && e[this.activeSeriesIndex].data[0] !== null && e[this.activeSeriesIndex].data[0].x !== void 0 && e[this.activeSeriesIndex].data[0] !== null)
            return !0;
        } }, { key: "isFormat2DArray", value: function() {
          var e = this.w.config.series.slice(), t = new de(this.ctx);
          if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), e[this.activeSeriesIndex].data !== void 0 && e[this.activeSeriesIndex].data.length > 0 && e[this.activeSeriesIndex].data[0] !== void 0 && e[this.activeSeriesIndex].data[0] !== null && e[this.activeSeriesIndex].data[0].constructor === Array)
            return !0;
        } }, { key: "handleFormat2DArray", value: function(e, t) {
          for (var i = this.w.config, a = this.w.globals, s = i.chart.type === "boxPlot" || i.series[t].type === "boxPlot", r = 0; r < e[t].data.length; r++)
            if (e[t].data[r][1] !== void 0 && (Array.isArray(e[t].data[r][1]) && e[t].data[r][1].length === 4 && !s ? this.twoDSeries.push(M.parseNumber(e[t].data[r][1][3])) : e[t].data[r].length >= 5 ? this.twoDSeries.push(M.parseNumber(e[t].data[r][4])) : this.twoDSeries.push(M.parseNumber(e[t].data[r][1])), a.dataFormatXNumeric = !0), i.xaxis.type === "datetime") {
              var o = new Date(e[t].data[r][0]);
              o = new Date(o).getTime(), this.twoDSeriesX.push(o);
            } else
              this.twoDSeriesX.push(e[t].data[r][0]);
          for (var c = 0; c < e[t].data.length; c++)
            e[t].data[c][2] !== void 0 && (this.threeDSeries.push(e[t].data[c][2]), a.isDataXYZ = !0);
        } }, { key: "handleFormatXY", value: function(e, t) {
          var i = this.w.config, a = this.w.globals, s = new ue(this.ctx), r = t;
          a.collapsedSeriesIndices.indexOf(t) > -1 && (r = this.activeSeriesIndex);
          for (var o = 0; o < e[t].data.length; o++)
            e[t].data[o].y !== void 0 && (Array.isArray(e[t].data[o].y) ? this.twoDSeries.push(M.parseNumber(e[t].data[o].y[e[t].data[o].y.length - 1])) : this.twoDSeries.push(M.parseNumber(e[t].data[o].y))), e[t].data[o].goals !== void 0 && Array.isArray(e[t].data[o].goals) ? (this.seriesGoals[t] === void 0 && (this.seriesGoals[t] = []), this.seriesGoals[t].push(e[t].data[o].goals)) : (this.seriesGoals[t] === void 0 && (this.seriesGoals[t] = []), this.seriesGoals[t].push(null));
          for (var c = 0; c < e[r].data.length; c++) {
            var d = typeof e[r].data[c].x == "string", g = Array.isArray(e[r].data[c].x), f = !g && !!s.isValidDate(e[r].data[c].x);
            if (d || f)
              if (d || i.xaxis.convertedCatToNumeric) {
                var p = a.isBarHorizontal && a.isRangeData;
                i.xaxis.type !== "datetime" || p ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[r].data[c].x), isNaN(e[r].data[c].x) || this.w.config.xaxis.type === "category" || typeof e[r].data[c].x == "string" || (a.isXNumeric = !0)) : this.twoDSeriesX.push(s.parseDate(e[r].data[c].x));
              } else
                i.xaxis.type === "datetime" ? this.twoDSeriesX.push(s.parseDate(e[r].data[c].x.toString())) : (a.dataFormatXNumeric = !0, a.isXNumeric = !0, this.twoDSeriesX.push(parseFloat(e[r].data[c].x)));
            else
              g ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[r].data[c].x)) : (a.isXNumeric = !0, a.dataFormatXNumeric = !0, this.twoDSeriesX.push(e[r].data[c].x));
          }
          if (e[t].data[0] && e[t].data[0].z !== void 0) {
            for (var m = 0; m < e[t].data.length; m++)
              this.threeDSeries.push(e[t].data[m].z);
            a.isDataXYZ = !0;
          }
        } }, { key: "handleRangeData", value: function(e, t) {
          var i = this.w.globals, a = {};
          return this.isFormat2DArray() ? a = this.handleRangeDataFormat("array", e, t) : this.isFormatXY() && (a = this.handleRangeDataFormat("xy", e, t)), i.seriesRangeStart.push(a.start), i.seriesRangeEnd.push(a.end), i.seriesRange.push(a.rangeUniques), i.seriesRange.forEach(function(s, r) {
            s && s.forEach(function(o, c) {
              o.y.forEach(function(d, g) {
                for (var f = 0; f < o.y.length; f++)
                  if (g !== f) {
                    var p = d.y1, m = d.y2, w = o.y[f].y1;
                    p <= o.y[f].y2 && w <= m && (o.overlaps.indexOf(d.rangeName) < 0 && o.overlaps.push(d.rangeName), o.overlaps.indexOf(o.y[f].rangeName) < 0 && o.overlaps.push(o.y[f].rangeName));
                  }
              });
            });
          }), a;
        } }, { key: "handleCandleStickBoxData", value: function(e, t) {
          var i = this.w.globals, a = {};
          return this.isFormat2DArray() ? a = this.handleCandleStickBoxDataFormat("array", e, t) : this.isFormatXY() && (a = this.handleCandleStickBoxDataFormat("xy", e, t)), i.seriesCandleO[t] = a.o, i.seriesCandleH[t] = a.h, i.seriesCandleM[t] = a.m, i.seriesCandleL[t] = a.l, i.seriesCandleC[t] = a.c, a;
        } }, { key: "handleRangeDataFormat", value: function(e, t, i) {
          var a = [], s = [], r = t[i].data.filter(function(g, f, p) {
            return f === p.findIndex(function(m) {
              return m.x === g.x;
            });
          }).map(function(g, f) {
            return { x: g.x, overlaps: [], y: [] };
          });
          if (e === "array")
            for (var o = 0; o < t[i].data.length; o++)
              Array.isArray(t[i].data[o]) ? (a.push(t[i].data[o][1][0]), s.push(t[i].data[o][1][1])) : (a.push(t[i].data[o]), s.push(t[i].data[o]));
          else if (e === "xy")
            for (var c = function(g) {
              var f = Array.isArray(t[i].data[g].y), p = M.randomId(), m = t[i].data[g].x, w = { y1: f ? t[i].data[g].y[0] : t[i].data[g].y, y2: f ? t[i].data[g].y[1] : t[i].data[g].y, rangeName: p };
              t[i].data[g].rangeName = p;
              var C = r.findIndex(function(k) {
                return k.x === m;
              });
              r[C].y.push(w), a.push(w.y1), s.push(w.y2);
            }, d = 0; d < t[i].data.length; d++)
              c(d);
          return { start: a, end: s, rangeUniques: r };
        } }, { key: "handleCandleStickBoxDataFormat", value: function(e, t, i) {
          var a = this.w, s = a.config.chart.type === "boxPlot" || a.config.series[i].type === "boxPlot", r = [], o = [], c = [], d = [], g = [];
          if (e === "array")
            if (s && t[i].data[0].length === 6 || !s && t[i].data[0].length === 5)
              for (var f = 0; f < t[i].data.length; f++)
                r.push(t[i].data[f][1]), o.push(t[i].data[f][2]), s ? (c.push(t[i].data[f][3]), d.push(t[i].data[f][4]), g.push(t[i].data[f][5])) : (d.push(t[i].data[f][3]), g.push(t[i].data[f][4]));
            else
              for (var p = 0; p < t[i].data.length; p++)
                Array.isArray(t[i].data[p][1]) && (r.push(t[i].data[p][1][0]), o.push(t[i].data[p][1][1]), s ? (c.push(t[i].data[p][1][2]), d.push(t[i].data[p][1][3]), g.push(t[i].data[p][1][4])) : (d.push(t[i].data[p][1][2]), g.push(t[i].data[p][1][3])));
          else if (e === "xy")
            for (var m = 0; m < t[i].data.length; m++)
              Array.isArray(t[i].data[m].y) && (r.push(t[i].data[m].y[0]), o.push(t[i].data[m].y[1]), s ? (c.push(t[i].data[m].y[2]), d.push(t[i].data[m].y[3]), g.push(t[i].data[m].y[4])) : (d.push(t[i].data[m].y[2]), g.push(t[i].data[m].y[3])));
          return { o: r, h: o, m: c, l: d, c: g };
        } }, { key: "parseDataAxisCharts", value: function(e) {
          var t, i = this, a = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.ctx, s = this.w.config, r = this.w.globals, o = new ue(a), c = s.labels.length > 0 ? s.labels.slice() : s.xaxis.categories.slice();
          if (r.isRangeBar = s.chart.type === "rangeBar" && r.isBarHorizontal, r.hasXaxisGroups = s.xaxis.type === "category" && s.xaxis.group.groups.length > 0, r.hasXaxisGroups && (r.groups = s.xaxis.group.groups), r.hasSeriesGroups = (t = e[0]) === null || t === void 0 ? void 0 : t.group, r.hasSeriesGroups) {
            var d = [], g = j(new Set(e.map(function(w) {
              return w.group;
            })));
            e.forEach(function(w, C) {
              var k = g.indexOf(w.group);
              d[k] || (d[k] = []), d[k].push(w.name);
            }), r.seriesGroups = d;
          }
          for (var f = function() {
            for (var w = 0; w < c.length; w++)
              if (typeof c[w] == "string") {
                if (!o.isValidDate(c[w]))
                  throw new Error("You have provided invalid Date format. Please provide a valid JavaScript Date");
                i.twoDSeriesX.push(o.parseDate(c[w]));
              } else
                i.twoDSeriesX.push(c[w]);
          }, p = 0; p < e.length; p++) {
            if (this.twoDSeries = [], this.twoDSeriesX = [], this.threeDSeries = [], e[p].data === void 0)
              return void console.error("It is a possibility that you may have not included 'data' property in series.");
            if (s.chart.type !== "rangeBar" && s.chart.type !== "rangeArea" && e[p].type !== "rangeBar" && e[p].type !== "rangeArea" || (r.isRangeData = !0, s.chart.type !== "rangeBar" && s.chart.type !== "rangeArea" || this.handleRangeData(e, p)), this.isMultiFormat())
              this.isFormat2DArray() ? this.handleFormat2DArray(e, p) : this.isFormatXY() && this.handleFormatXY(e, p), s.chart.type !== "candlestick" && e[p].type !== "candlestick" && s.chart.type !== "boxPlot" && e[p].type !== "boxPlot" || this.handleCandleStickBoxData(e, p), r.series.push(this.twoDSeries), r.labels.push(this.twoDSeriesX), r.seriesX.push(this.twoDSeriesX), r.seriesGoals = this.seriesGoals, p !== this.activeSeriesIndex || this.fallbackToCategory || (r.isXNumeric = !0);
            else {
              s.xaxis.type === "datetime" ? (r.isXNumeric = !0, f(), r.seriesX.push(this.twoDSeriesX)) : s.xaxis.type === "numeric" && (r.isXNumeric = !0, c.length > 0 && (this.twoDSeriesX = c, r.seriesX.push(this.twoDSeriesX))), r.labels.push(this.twoDSeriesX);
              var m = e[p].data.map(function(w) {
                return M.parseNumber(w);
              });
              r.series.push(m);
            }
            r.seriesZ.push(this.threeDSeries), e[p].name !== void 0 ? r.seriesNames.push(e[p].name) : r.seriesNames.push("series-" + parseInt(p + 1, 10)), e[p].color !== void 0 ? r.seriesColors.push(e[p].color) : r.seriesColors.push(void 0);
          }
          return this.w;
        } }, { key: "parseDataNonAxisCharts", value: function(e) {
          var t = this.w.globals, i = this.w.config;
          t.series = e.slice(), t.seriesNames = i.labels.slice();
          for (var a = 0; a < t.series.length; a++)
            t.seriesNames[a] === void 0 && t.seriesNames.push("series-" + (a + 1));
          return this.w;
        } }, { key: "handleExternalLabelsData", value: function(e) {
          var t = this.w.config, i = this.w.globals;
          t.xaxis.categories.length > 0 ? i.labels = t.xaxis.categories : t.labels.length > 0 ? i.labels = t.labels.slice() : this.fallbackToCategory ? (i.labels = i.labels[0], i.seriesRange.length && (i.seriesRange.map(function(a) {
            a.forEach(function(s) {
              i.labels.indexOf(s.x) < 0 && s.x && i.labels.push(s.x);
            });
          }), i.labels = Array.from(new Set(i.labels.map(JSON.stringify)), JSON.parse)), t.xaxis.convertedCatToNumeric && (new Me(t).convertCatToNumericXaxis(t, this.ctx, i.seriesX[0]), this._generateExternalLabels(e))) : this._generateExternalLabels(e);
        } }, { key: "_generateExternalLabels", value: function(e) {
          var t = this.w.globals, i = this.w.config, a = [];
          if (t.axisCharts) {
            if (t.series.length > 0)
              if (this.isFormatXY())
                for (var s = i.series.map(function(f, p) {
                  return f.data.filter(function(m, w, C) {
                    return C.findIndex(function(k) {
                      return k.x === m.x;
                    }) === w;
                  });
                }), r = s.reduce(function(f, p, m, w) {
                  return w[f].length > p.length ? f : m;
                }, 0), o = 0; o < s[r].length; o++)
                  a.push(o + 1);
              else
                for (var c = 0; c < t.series[t.maxValsInArrayIndex].length; c++)
                  a.push(c + 1);
            t.seriesX = [];
            for (var d = 0; d < e.length; d++)
              t.seriesX.push(a);
            this.w.globals.isBarHorizontal || (t.isXNumeric = !0);
          }
          if (a.length === 0) {
            a = t.axisCharts ? [] : t.series.map(function(f, p) {
              return p + 1;
            });
            for (var g = 0; g < e.length; g++)
              t.seriesX.push(a);
          }
          t.labels = a, i.xaxis.convertedCatToNumeric && (t.categoryLabels = a.map(function(f) {
            return i.xaxis.labels.formatter(f);
          })), t.noLabelsProvided = !0;
        } }, { key: "parseData", value: function(e) {
          var t = this.w, i = t.config, a = t.globals;
          if (this.excludeCollapsedSeriesInYAxis(), this.fallbackToCategory = !1, this.ctx.core.resetGlobals(), this.ctx.core.isMultipleY(), a.axisCharts ? (this.parseDataAxisCharts(e), this.coreUtils.getLargestSeries()) : this.parseDataNonAxisCharts(e), i.chart.stacked) {
            var s = new de(this.ctx);
            a.series = s.setNullSeriesToZeroValues(a.series);
          }
          this.coreUtils.getSeriesTotals(), a.axisCharts && (a.stackedSeriesTotals = this.coreUtils.getStackedSeriesTotals(), a.stackedSeriesTotalsByGroups = this.coreUtils.getStackedSeriesTotalsByGroups()), this.coreUtils.getPercentSeries(), a.dataFormatXNumeric || a.isXNumeric && (i.xaxis.type !== "numeric" || i.labels.length !== 0 || i.xaxis.categories.length !== 0) || this.handleExternalLabelsData(e);
          for (var r = this.coreUtils.getCategoryLabels(a.labels), o = 0; o < r.length; o++)
            if (Array.isArray(r[o])) {
              a.isMultiLineX = !0;
              break;
            }
        } }, { key: "excludeCollapsedSeriesInYAxis", value: function() {
          var e = this, t = this.w;
          t.globals.ignoreYAxisIndexes = t.globals.collapsedSeries.map(function(i, a) {
            if (e.w.globals.isMultipleYAxis && !t.config.chart.stacked)
              return i.index;
          });
        } }]), P;
      }(), ye = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "getLabel", value: function(e, t, i, a) {
          var s = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : [], r = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : "12px", o = !(arguments.length > 6 && arguments[6] !== void 0) || arguments[6], c = this.w, d = e[a] === void 0 ? "" : e[a], g = d, f = c.globals.xLabelFormatter, p = c.config.xaxis.labels.formatter, m = !1, w = new Le(this.ctx), C = d;
          o && (g = w.xLabelFormat(f, d, C, { i: a, dateFormatter: new ue(this.ctx).formatDate, w: c }), p !== void 0 && (g = p(d, e[a], { i: a, dateFormatter: new ue(this.ctx).formatDate, w: c })));
          var k, E;
          t.length > 0 ? (k = t[a].unit, E = null, t.forEach(function(S) {
            S.unit === "month" ? E = "year" : S.unit === "day" ? E = "month" : S.unit === "hour" ? E = "day" : S.unit === "minute" && (E = "hour");
          }), m = E === k, i = t[a].position, g = t[a].value) : c.config.xaxis.type === "datetime" && p === void 0 && (g = ""), g === void 0 && (g = ""), g = Array.isArray(g) ? g : g.toString();
          var _ = new X(this.ctx), h = {};
          h = c.globals.rotateXLabels && o ? _.getTextRects(g, parseInt(r, 10), null, "rotate(".concat(c.config.xaxis.labels.rotate, " 0 0)"), !1) : _.getTextRects(g, parseInt(r, 10));
          var x = !c.config.xaxis.labels.showDuplicates && this.ctx.timeScale;
          return !Array.isArray(g) && (g.indexOf("NaN") === 0 || g.toLowerCase().indexOf("invalid") === 0 || g.toLowerCase().indexOf("infinity") >= 0 || s.indexOf(g) >= 0 && x) && (g = ""), { x: i, text: g, textRect: h, isBold: m };
        } }, { key: "checkLabelBasedOnTickamount", value: function(e, t, i) {
          var a = this.w, s = a.config.xaxis.tickAmount;
          return s === "dataPoints" && (s = Math.round(a.globals.gridWidth / 120)), s > i || e % Math.round(i / (s + 1)) == 0 || (t.text = ""), t;
        } }, { key: "checkForOverflowingLabels", value: function(e, t, i, a, s) {
          var r = this.w;
          if (e === 0 && r.globals.skipFirstTimelinelabel && (t.text = ""), e === i - 1 && r.globals.skipLastTimelinelabel && (t.text = ""), r.config.xaxis.labels.hideOverlappingLabels && a.length > 0) {
            var o = s[s.length - 1];
            t.x < o.textRect.width / (r.globals.rotateXLabels ? Math.abs(r.config.xaxis.labels.rotate) / 12 : 1.01) + o.x && (t.text = "");
          }
          return t;
        } }, { key: "checkForReversedLabels", value: function(e, t) {
          var i = this.w;
          return i.config.yaxis[e] && i.config.yaxis[e].reversed && t.reverse(), t;
        } }, { key: "isYAxisHidden", value: function(e) {
          var t = this.w, i = new $(this.ctx);
          return !t.config.yaxis[e].show || !t.config.yaxis[e].showForNullSeries && i.isSeriesNull(e) && t.globals.collapsedSeriesIndices.indexOf(e) === -1;
        } }, { key: "getYAxisForeColor", value: function(e, t) {
          var i = this.w;
          return Array.isArray(e) && i.globals.yAxisScale[t] && this.ctx.theme.pushExtraColors(e, i.globals.yAxisScale[t].result.length, !1), e;
        } }, { key: "drawYAxisTicks", value: function(e, t, i, a, s, r, o) {
          var c = this.w, d = new X(this.ctx), g = c.globals.translateY;
          if (a.show && t > 0) {
            c.config.yaxis[s].opposite === !0 && (e += a.width);
            for (var f = t; f >= 0; f--) {
              var p = g + t / 10 + c.config.yaxis[s].labels.offsetY - 1;
              c.globals.isBarHorizontal && (p = r * f), c.config.chart.type === "heatmap" && (p += r / 2);
              var m = d.drawLine(e + i.offsetX - a.width + a.offsetX, p + a.offsetY, e + i.offsetX + a.offsetX, p + a.offsetY, a.color);
              o.add(m), g += r;
            }
          }
        } }]), P;
      }(), Se = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "scaleSvgNode", value: function(e, t) {
          var i = parseFloat(e.getAttributeNS(null, "width")), a = parseFloat(e.getAttributeNS(null, "height"));
          e.setAttributeNS(null, "width", i * t), e.setAttributeNS(null, "height", a * t), e.setAttributeNS(null, "viewBox", "0 0 " + i + " " + a);
        } }, { key: "fixSvgStringForIe11", value: function(e) {
          if (!M.isIE11())
            return e.replace(/&nbsp;/g, "&#160;");
          var t = 0, i = e.replace(/xmlns="http:\/\/www.w3.org\/2000\/svg"/g, function(a) {
            return ++t === 2 ? 'xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev"' : a;
          });
          return i = (i = i.replace(/xmlns:NS\d+=""/g, "")).replace(/NS\d+:(\w+:\w+=")/g, "$1");
        } }, { key: "getSvgString", value: function(e) {
          e == null && (e = 1);
          var t = this.w.globals.dom.Paper.svg();
          if (e !== 1) {
            var i = this.w.globals.dom.Paper.node.cloneNode(!0);
            this.scaleSvgNode(i, e), t = new XMLSerializer().serializeToString(i);
          }
          return this.fixSvgStringForIe11(t);
        } }, { key: "cleanup", value: function() {
          var e = this.w, t = e.globals.dom.baseEl.getElementsByClassName("apexcharts-xcrosshairs"), i = e.globals.dom.baseEl.getElementsByClassName("apexcharts-ycrosshairs"), a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-zoom-rect, .apexcharts-selection-rect");
          Array.prototype.forEach.call(a, function(s) {
            s.setAttribute("width", 0);
          }), t && t[0] && (t[0].setAttribute("x", -500), t[0].setAttribute("x1", -500), t[0].setAttribute("x2", -500)), i && i[0] && (i[0].setAttribute("y", -100), i[0].setAttribute("y1", -100), i[0].setAttribute("y2", -100));
        } }, { key: "svgUrl", value: function() {
          this.cleanup();
          var e = this.getSvgString(), t = new Blob([e], { type: "image/svg+xml;charset=utf-8" });
          return URL.createObjectURL(t);
        } }, { key: "dataURI", value: function(e) {
          var t = this;
          return new Promise(function(i) {
            var a = t.w, s = e ? e.scale || e.width / a.globals.svgWidth : 1;
            t.cleanup();
            var r = document.createElement("canvas");
            r.width = a.globals.svgWidth * s, r.height = parseInt(a.globals.dom.elWrap.style.height, 10) * s;
            var o = a.config.chart.background === "transparent" ? "#fff" : a.config.chart.background, c = r.getContext("2d");
            c.fillStyle = o, c.fillRect(0, 0, r.width * s, r.height * s);
            var d = t.getSvgString(s);
            if (window.canvg && M.isIE11()) {
              var g = window.canvg.Canvg.fromString(c, d, { ignoreClear: !0, ignoreDimensions: !0 });
              g.start();
              var f = r.msToBlob();
              g.stop(), i({ blob: f });
            } else {
              var p = "data:image/svg+xml," + encodeURIComponent(d), m = new Image();
              m.crossOrigin = "anonymous", m.onload = function() {
                if (c.drawImage(m, 0, 0), r.msToBlob) {
                  var w = r.msToBlob();
                  i({ blob: w });
                } else {
                  var C = r.toDataURL("image/png");
                  i({ imgURI: C });
                }
              }, m.src = p;
            }
          });
        } }, { key: "exportToSVG", value: function() {
          this.triggerDownload(this.svgUrl(), this.w.config.chart.toolbar.export.svg.filename, ".svg");
        } }, { key: "exportToPng", value: function() {
          var e = this;
          this.dataURI().then(function(t) {
            var i = t.imgURI, a = t.blob;
            a ? navigator.msSaveOrOpenBlob(a, e.w.globals.chartID + ".png") : e.triggerDownload(i, e.w.config.chart.toolbar.export.png.filename, ".png");
          });
        } }, { key: "exportToCSV", value: function(e) {
          var t = this, i = e.series, a = e.fileName, s = e.columnDelimiter, r = s === void 0 ? "," : s, o = e.lineDelimiter, c = o === void 0 ? `
` : o, d = this.w;
          i || (i = d.config.series);
          var g, f, p = [], m = [], w = "", C = d.globals.series.map(function(L, R) {
            return d.globals.collapsedSeriesIndices.indexOf(R) === -1 ? L : [];
          }), k = function(L) {
            return d.config.xaxis.type === "datetime" && String(L).length >= 10;
          }, E = Math.max.apply(Math, j(i.map(function(L) {
            return L.data ? L.data.length : 0;
          }))), _ = new ve(this.ctx), h = new ye(this.ctx), x = function(L) {
            var R = "";
            if (d.globals.axisCharts) {
              if (d.config.xaxis.type === "category" || d.config.xaxis.convertedCatToNumeric)
                if (d.globals.isBarHorizontal) {
                  var O = d.globals.yLabelFormatters[0], Y = new de(t.ctx).getActiveConfigSeriesIndex();
                  R = O(d.globals.labels[L], { seriesIndex: Y, dataPointIndex: L, w: d });
                } else
                  R = h.getLabel(d.globals.labels, d.globals.timescaleLabels, 0, L).text;
              d.config.xaxis.type === "datetime" && (d.config.xaxis.categories.length ? R = d.config.xaxis.categories[L] : d.config.labels.length && (R = d.config.labels[L]));
            } else
              R = d.config.labels[L];
            return Array.isArray(R) && (R = R.join(" ")), M.isNumber(R) ? R : R.split(r).join("");
          }, S = function(L, R) {
            if (p.length && R === 0 && m.push(p.join(r)), L.data) {
              L.data = L.data.length && L.data || j(Array(E)).map(function() {
                return "";
              });
              for (var O = 0; O < L.data.length; O++) {
                p = [];
                var Y = x(O);
                if (Y || (_.isFormatXY() ? Y = i[R].data[O].x : _.isFormat2DArray() && (Y = i[R].data[O] ? i[R].data[O][0] : "")), R === 0) {
                  p.push(k(Y) ? d.config.chart.toolbar.export.csv.dateFormatter(Y) : M.isNumber(Y) ? Y : Y.split(r).join(""));
                  for (var N = 0; N < d.globals.series.length; N++) {
                    var q;
                    _.isFormatXY() ? p.push((q = i[N].data[O]) === null || q === void 0 ? void 0 : q.y) : p.push(C[N][O]);
                  }
                }
                (d.config.chart.type === "candlestick" || L.type && L.type === "candlestick") && (p.pop(), p.push(d.globals.seriesCandleO[R][O]), p.push(d.globals.seriesCandleH[R][O]), p.push(d.globals.seriesCandleL[R][O]), p.push(d.globals.seriesCandleC[R][O])), (d.config.chart.type === "boxPlot" || L.type && L.type === "boxPlot") && (p.pop(), p.push(d.globals.seriesCandleO[R][O]), p.push(d.globals.seriesCandleH[R][O]), p.push(d.globals.seriesCandleM[R][O]), p.push(d.globals.seriesCandleL[R][O]), p.push(d.globals.seriesCandleC[R][O])), d.config.chart.type === "rangeBar" && (p.pop(), p.push(d.globals.seriesRangeStart[R][O]), p.push(d.globals.seriesRangeEnd[R][O])), p.length && m.push(p.join(r));
              }
            }
          };
          p.push(d.config.chart.toolbar.export.csv.headerCategory), d.config.chart.type === "boxPlot" ? (p.push("minimum"), p.push("q1"), p.push("median"), p.push("q3"), p.push("maximum")) : d.config.chart.type === "candlestick" ? (p.push("open"), p.push("high"), p.push("low"), p.push("close")) : d.config.chart.type === "rangeBar" ? (p.push("minimum"), p.push("maximum")) : i.map(function(L, R) {
            var O = (L.name ? L.name : "series-".concat(R)) + "";
            d.globals.axisCharts && p.push(O.split(r).join("") ? O.split(r).join("") : "series-".concat(R));
          }), d.globals.axisCharts || (p.push(d.config.chart.toolbar.export.csv.headerValue), m.push(p.join(r))), d.globals.allSeriesHasEqualX || !d.globals.axisCharts || d.config.xaxis.categories.length || d.config.labels.length ? i.map(function(L, R) {
            d.globals.axisCharts ? S(L, R) : ((p = []).push(d.globals.labels[R].split(r).join("")), p.push(C[R]), m.push(p.join(r)));
          }) : (g = /* @__PURE__ */ new Set(), f = {}, i.forEach(function(L, R) {
            L == null || L.data.forEach(function(O) {
              var Y, N;
              if (_.isFormatXY())
                Y = O.x, N = O.y;
              else {
                if (!_.isFormat2DArray())
                  return;
                Y = O[0], N = O[1];
              }
              f[Y] || (f[Y] = Array(i.length).fill("")), f[Y][R] = N, g.add(Y);
            });
          }), p.length && m.push(p.join(r)), Array.from(g).sort().forEach(function(L) {
            m.push([k(L) && d.config.xaxis.type === "datetime" ? d.config.chart.toolbar.export.csv.dateFormatter(L) : M.isNumber(L) ? L : L.split(r).join(""), f[L].join(r)]);
          })), w += m.join(c), this.triggerDownload("data:text/csv; charset=utf-8," + encodeURIComponent("\uFEFF" + w), a || d.config.chart.toolbar.export.csv.filename, ".csv");
        } }, { key: "triggerDownload", value: function(e, t, i) {
          var a = document.createElement("a");
          a.href = e, a.download = (t || this.w.globals.chartID) + i, document.body.appendChild(a), a.click(), document.body.removeChild(a);
        } }]), P;
      }(), Ee = function() {
        function P(e, t) {
          y(this, P), this.ctx = e, this.elgrid = t, this.w = e.w;
          var i = this.w;
          this.axesUtils = new ye(e), this.xaxisLabels = i.globals.labels.slice(), i.globals.timescaleLabels.length > 0 && !i.globals.isBarHorizontal && (this.xaxisLabels = i.globals.timescaleLabels.slice()), i.config.xaxis.overwriteCategories && (this.xaxisLabels = i.config.xaxis.overwriteCategories), this.drawnLabels = [], this.drawnLabelsRects = [], i.config.xaxis.position === "top" ? this.offY = 0 : this.offY = i.globals.gridHeight + 1, this.offY = this.offY + i.config.xaxis.axisBorder.offsetY, this.isCategoryBarHorizontal = i.config.chart.type === "bar" && i.config.plotOptions.bar.horizontal, this.xaxisFontSize = i.config.xaxis.labels.style.fontSize, this.xaxisFontFamily = i.config.xaxis.labels.style.fontFamily, this.xaxisForeColors = i.config.xaxis.labels.style.colors, this.xaxisBorderWidth = i.config.xaxis.axisBorder.width, this.isCategoryBarHorizontal && (this.xaxisBorderWidth = i.config.yaxis[0].axisBorder.width.toString()), this.xaxisBorderWidth.indexOf("%") > -1 ? this.xaxisBorderWidth = i.globals.gridWidth * parseInt(this.xaxisBorderWidth, 10) / 100 : this.xaxisBorderWidth = parseInt(this.xaxisBorderWidth, 10), this.xaxisBorderHeight = i.config.xaxis.axisBorder.height, this.yaxis = i.config.yaxis[0];
        }
        return A(P, [{ key: "drawXaxis", value: function() {
          var e = this.w, t = new X(this.ctx), i = t.group({ class: "apexcharts-xaxis", transform: "translate(".concat(e.config.xaxis.offsetX, ", ").concat(e.config.xaxis.offsetY, ")") }), a = t.group({ class: "apexcharts-xaxis-texts-g", transform: "translate(".concat(e.globals.translateXAxisX, ", ").concat(e.globals.translateXAxisY, ")") });
          i.add(a);
          for (var s = [], r = 0; r < this.xaxisLabels.length; r++)
            s.push(this.xaxisLabels[r]);
          if (this.drawXAxisLabelAndGroup(!0, t, a, s, e.globals.isXNumeric, function(w, C) {
            return C;
          }), e.globals.hasXaxisGroups) {
            var o = e.globals.groups;
            s = [];
            for (var c = 0; c < o.length; c++)
              s.push(o[c].title);
            var d = {};
            e.config.xaxis.group.style && (d.xaxisFontSize = e.config.xaxis.group.style.fontSize, d.xaxisFontFamily = e.config.xaxis.group.style.fontFamily, d.xaxisForeColors = e.config.xaxis.group.style.colors, d.fontWeight = e.config.xaxis.group.style.fontWeight, d.cssClass = e.config.xaxis.group.style.cssClass), this.drawXAxisLabelAndGroup(!1, t, a, s, !1, function(w, C) {
              return o[w].cols * C;
            }, d);
          }
          if (e.config.xaxis.title.text !== void 0) {
            var g = t.group({ class: "apexcharts-xaxis-title" }), f = t.drawText({ x: e.globals.gridWidth / 2 + e.config.xaxis.title.offsetX, y: this.offY + parseFloat(this.xaxisFontSize) + (e.config.xaxis.position === "bottom" ? e.globals.xAxisLabelsHeight : -e.globals.xAxisLabelsHeight - 10) + e.config.xaxis.title.offsetY, text: e.config.xaxis.title.text, textAnchor: "middle", fontSize: e.config.xaxis.title.style.fontSize, fontFamily: e.config.xaxis.title.style.fontFamily, fontWeight: e.config.xaxis.title.style.fontWeight, foreColor: e.config.xaxis.title.style.color, cssClass: "apexcharts-xaxis-title-text " + e.config.xaxis.title.style.cssClass });
            g.add(f), i.add(g);
          }
          if (e.config.xaxis.axisBorder.show) {
            var p = e.globals.barPadForNumericAxis, m = t.drawLine(e.globals.padHorizontal + e.config.xaxis.axisBorder.offsetX - p, this.offY, this.xaxisBorderWidth + p, this.offY, e.config.xaxis.axisBorder.color, 0, this.xaxisBorderHeight);
            this.elgrid && this.elgrid.elGridBorders && e.config.grid.show ? this.elgrid.elGridBorders.add(m) : i.add(m);
          }
          return i;
        } }, { key: "drawXAxisLabelAndGroup", value: function(e, t, i, a, s, r) {
          var o, c = this, d = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : {}, g = [], f = [], p = this.w, m = d.xaxisFontSize || this.xaxisFontSize, w = d.xaxisFontFamily || this.xaxisFontFamily, C = d.xaxisForeColors || this.xaxisForeColors, k = d.fontWeight || p.config.xaxis.labels.style.fontWeight, E = d.cssClass || p.config.xaxis.labels.style.cssClass, _ = p.globals.padHorizontal, h = a.length, x = p.config.xaxis.type === "category" ? p.globals.dataPoints : h;
          if (x === 0 && h > x && (x = h), s) {
            var S = x > 1 ? x - 1 : x;
            o = p.globals.gridWidth / Math.min(S, h - 1), _ = _ + r(0, o) / 2 + p.config.xaxis.labels.offsetX;
          } else
            o = p.globals.gridWidth / x, _ = _ + r(0, o) + p.config.xaxis.labels.offsetX;
          for (var L = function(O) {
            var Y = _ - r(O, o) / 2 + p.config.xaxis.labels.offsetX;
            O === 0 && h === 1 && o / 2 === _ && x === 1 && (Y = p.globals.gridWidth / 2);
            var N = c.axesUtils.getLabel(a, p.globals.timescaleLabels, Y, O, g, m, e), q = 28;
            if (p.globals.rotateXLabels && e && (q = 22), p.config.xaxis.title.text && p.config.xaxis.position === "top" && (q += parseFloat(p.config.xaxis.title.style.fontSize) + 2), e || (q = q + parseFloat(m) + (p.globals.xAxisLabelsHeight - p.globals.xAxisGroupLabelsHeight) + (p.globals.rotateXLabels ? 10 : 0)), N = p.config.xaxis.tickAmount !== void 0 && p.config.xaxis.tickAmount !== "dataPoints" && p.config.xaxis.type !== "datetime" ? c.axesUtils.checkLabelBasedOnTickamount(O, N, h) : c.axesUtils.checkForOverflowingLabels(O, N, h, g, f), p.config.xaxis.labels.show) {
              var Z = t.drawText({ x: N.x, y: c.offY + p.config.xaxis.labels.offsetY + q - (p.config.xaxis.position === "top" ? p.globals.xAxisHeight + p.config.xaxis.axisTicks.height - 2 : 0), text: N.text, textAnchor: "middle", fontWeight: N.isBold ? 600 : k, fontSize: m, fontFamily: w, foreColor: Array.isArray(C) ? e && p.config.xaxis.convertedCatToNumeric ? C[p.globals.minX + O - 1] : C[O] : C, isPlainText: !1, cssClass: (e ? "apexcharts-xaxis-label " : "apexcharts-xaxis-group-label ") + E });
              if (i.add(Z), Z.on("click", function(se) {
                if (typeof p.config.chart.events.xAxisLabelClick == "function") {
                  var he = Object.assign({}, p, { labelIndex: O });
                  p.config.chart.events.xAxisLabelClick(se, c.ctx, he);
                }
              }), e) {
                var U = document.createElementNS(p.globals.SVGNS, "title");
                U.textContent = Array.isArray(N.text) ? N.text.join(" ") : N.text, Z.node.appendChild(U), N.text !== "" && (g.push(N.text), f.push(N));
              }
            }
            O < h - 1 && (_ += r(O + 1, o));
          }, R = 0; R <= h - 1; R++)
            L(R);
        } }, { key: "drawXaxisInversed", value: function(e) {
          var t, i, a = this, s = this.w, r = new X(this.ctx), o = s.config.yaxis[0].opposite ? s.globals.translateYAxisX[e] : 0, c = r.group({ class: "apexcharts-yaxis apexcharts-xaxis-inversed", rel: e }), d = r.group({ class: "apexcharts-yaxis-texts-g apexcharts-xaxis-inversed-texts-g", transform: "translate(" + o + ", 0)" });
          c.add(d);
          var g = [];
          if (s.config.yaxis[e].show)
            for (var f = 0; f < this.xaxisLabels.length; f++)
              g.push(this.xaxisLabels[f]);
          t = s.globals.gridHeight / g.length, i = -t / 2.2;
          var p = s.globals.yLabelFormatters[0], m = s.config.yaxis[0].labels;
          if (m.show)
            for (var w = function(S) {
              var L = g[S] === void 0 ? "" : g[S];
              L = p(L, { seriesIndex: e, dataPointIndex: S, w: s });
              var R = a.axesUtils.getYAxisForeColor(m.style.colors, e), O = 0;
              Array.isArray(L) && (O = L.length / 2 * parseInt(m.style.fontSize, 10));
              var Y = m.offsetX - 15, N = "end";
              a.yaxis.opposite && (N = "start"), s.config.yaxis[0].labels.align === "left" ? (Y = m.offsetX, N = "start") : s.config.yaxis[0].labels.align === "center" ? (Y = m.offsetX, N = "middle") : s.config.yaxis[0].labels.align === "right" && (N = "end");
              var q = r.drawText({ x: Y, y: i + t + m.offsetY - O, text: L, textAnchor: N, foreColor: Array.isArray(R) ? R[S] : R, fontSize: m.style.fontSize, fontFamily: m.style.fontFamily, fontWeight: m.style.fontWeight, isPlainText: !1, cssClass: "apexcharts-yaxis-label " + m.style.cssClass, maxWidth: m.maxWidth });
              d.add(q), q.on("click", function(se) {
                if (typeof s.config.chart.events.xAxisLabelClick == "function") {
                  var he = Object.assign({}, s, { labelIndex: S });
                  s.config.chart.events.xAxisLabelClick(se, a.ctx, he);
                }
              });
              var Z = document.createElementNS(s.globals.SVGNS, "title");
              if (Z.textContent = Array.isArray(L) ? L.join(" ") : L, q.node.appendChild(Z), s.config.yaxis[e].labels.rotate !== 0) {
                var U = r.rotateAroundCenter(q.node);
                q.node.setAttribute("transform", "rotate(".concat(s.config.yaxis[e].labels.rotate, " 0 ").concat(U.y, ")"));
              }
              i += t;
            }, C = 0; C <= g.length - 1; C++)
              w(C);
          if (s.config.yaxis[0].title.text !== void 0) {
            var k = r.group({ class: "apexcharts-yaxis-title apexcharts-xaxis-title-inversed", transform: "translate(" + o + ", 0)" }), E = r.drawText({ x: s.config.yaxis[0].title.offsetX, y: s.globals.gridHeight / 2 + s.config.yaxis[0].title.offsetY, text: s.config.yaxis[0].title.text, textAnchor: "middle", foreColor: s.config.yaxis[0].title.style.color, fontSize: s.config.yaxis[0].title.style.fontSize, fontWeight: s.config.yaxis[0].title.style.fontWeight, fontFamily: s.config.yaxis[0].title.style.fontFamily, cssClass: "apexcharts-yaxis-title-text " + s.config.yaxis[0].title.style.cssClass });
            k.add(E), c.add(k);
          }
          var _ = 0;
          this.isCategoryBarHorizontal && s.config.yaxis[0].opposite && (_ = s.globals.gridWidth);
          var h = s.config.xaxis.axisBorder;
          if (h.show) {
            var x = r.drawLine(s.globals.padHorizontal + h.offsetX + _, 1 + h.offsetY, s.globals.padHorizontal + h.offsetX + _, s.globals.gridHeight + h.offsetY, h.color, 0);
            this.elgrid && this.elgrid.elGridBorders && s.config.grid.show ? this.elgrid.elGridBorders.add(x) : c.add(x);
          }
          return s.config.yaxis[0].axisTicks.show && this.axesUtils.drawYAxisTicks(_, g.length, s.config.yaxis[0].axisBorder, s.config.yaxis[0].axisTicks, 0, t, c), c;
        } }, { key: "drawXaxisTicks", value: function(e, t, i) {
          var a = this.w, s = e;
          if (!(e < 0 || e - 2 > a.globals.gridWidth)) {
            var r = this.offY + a.config.xaxis.axisTicks.offsetY;
            if (t = t + r + a.config.xaxis.axisTicks.height, a.config.xaxis.position === "top" && (t = r - a.config.xaxis.axisTicks.height), a.config.xaxis.axisTicks.show) {
              var o = new X(this.ctx).drawLine(e + a.config.xaxis.axisTicks.offsetX, r + a.config.xaxis.offsetY, s + a.config.xaxis.axisTicks.offsetX, t + a.config.xaxis.offsetY, a.config.xaxis.axisTicks.color);
              i.add(o), o.node.classList.add("apexcharts-xaxis-tick");
            }
          }
        } }, { key: "getXAxisTicksPositions", value: function() {
          var e = this.w, t = [], i = this.xaxisLabels.length, a = e.globals.padHorizontal;
          if (e.globals.timescaleLabels.length > 0)
            for (var s = 0; s < i; s++)
              a = this.xaxisLabels[s].position, t.push(a);
          else
            for (var r = i, o = 0; o < r; o++) {
              var c = r;
              e.globals.isXNumeric && e.config.chart.type !== "bar" && (c -= 1), a += e.globals.gridWidth / c, t.push(a);
            }
          return t;
        } }, { key: "xAxisLabelCorrections", value: function() {
          var e = this.w, t = new X(this.ctx), i = e.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g"), a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-xaxis-texts-g text:not(.apexcharts-xaxis-group-label)"), s = e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis-inversed text"), r = e.globals.dom.baseEl.querySelectorAll(".apexcharts-xaxis-inversed-texts-g text tspan");
          if (e.globals.rotateXLabels || e.config.xaxis.labels.rotateAlways)
            for (var o = 0; o < a.length; o++) {
              var c = t.rotateAroundCenter(a[o]);
              c.y = c.y - 1, c.x = c.x + 1, a[o].setAttribute("transform", "rotate(".concat(e.config.xaxis.labels.rotate, " ").concat(c.x, " ").concat(c.y, ")")), a[o].setAttribute("text-anchor", "end"), i.setAttribute("transform", "translate(0, ".concat(-10, ")"));
              var d = a[o].childNodes;
              e.config.xaxis.labels.trim && Array.prototype.forEach.call(d, function(m) {
                t.placeTextWithEllipsis(m, m.textContent, e.globals.xAxisLabelsHeight - (e.config.legend.position === "bottom" ? 20 : 10));
              });
            }
          else
            (function() {
              for (var m = e.globals.gridWidth / (e.globals.labels.length + 1), w = 0; w < a.length; w++) {
                var C = a[w].childNodes;
                e.config.xaxis.labels.trim && e.config.xaxis.type !== "datetime" && Array.prototype.forEach.call(C, function(k) {
                  t.placeTextWithEllipsis(k, k.textContent, m);
                });
              }
            })();
          if (s.length > 0) {
            var g = s[s.length - 1].getBBox(), f = s[0].getBBox();
            g.x < -20 && s[s.length - 1].parentNode.removeChild(s[s.length - 1]), f.x + f.width > e.globals.gridWidth && !e.globals.isBarHorizontal && s[0].parentNode.removeChild(s[0]);
            for (var p = 0; p < r.length; p++)
              t.placeTextWithEllipsis(r[p], r[p].textContent, e.config.yaxis[0].labels.maxWidth - (e.config.yaxis[0].title.text ? 2 * parseFloat(e.config.yaxis[0].title.style.fontSize) : 0) - 15);
          }
        } }]), P;
      }(), Re = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
          var t = this.w;
          this.xaxisLabels = t.globals.labels.slice(), this.axesUtils = new ye(e), this.isRangeBar = t.globals.seriesRange.length && t.globals.isBarHorizontal, t.globals.timescaleLabels.length > 0 && (this.xaxisLabels = t.globals.timescaleLabels.slice());
        }
        return A(P, [{ key: "drawGridArea", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null, t = this.w, i = new X(this.ctx);
          e === null && (e = i.group({ class: "apexcharts-grid" }));
          var a = i.drawLine(t.globals.padHorizontal, 1, t.globals.padHorizontal, t.globals.gridHeight, "transparent"), s = i.drawLine(t.globals.padHorizontal, t.globals.gridHeight, t.globals.gridWidth, t.globals.gridHeight, "transparent");
          return e.add(s), e.add(a), e;
        } }, { key: "drawGrid", value: function() {
          var e = null;
          return this.w.globals.axisCharts && (e = this.renderGrid(), this.drawGridArea(e.el)), e;
        } }, { key: "createGridMask", value: function() {
          var e = this.w, t = e.globals, i = new X(this.ctx), a = Array.isArray(e.config.stroke.width) ? 0 : e.config.stroke.width;
          if (Array.isArray(e.config.stroke.width)) {
            var s = 0;
            e.config.stroke.width.forEach(function(f) {
              s = Math.max(s, f);
            }), a = s;
          }
          t.dom.elGridRectMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elGridRectMask.setAttribute("id", "gridRectMask".concat(t.cuid)), t.dom.elGridRectMarkerMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elGridRectMarkerMask.setAttribute("id", "gridRectMarkerMask".concat(t.cuid)), t.dom.elForecastMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elForecastMask.setAttribute("id", "forecastMask".concat(t.cuid)), t.dom.elNonForecastMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elNonForecastMask.setAttribute("id", "nonForecastMask".concat(t.cuid));
          var r = e.config.chart.type, o = 0, c = 0;
          (r === "bar" || r === "rangeBar" || r === "candlestick" || r === "boxPlot" || e.globals.comboBarCount > 0) && e.globals.isXNumeric && !e.globals.isBarHorizontal && (o = e.config.grid.padding.left, c = e.config.grid.padding.right, t.barPadForNumericAxis > o && (o = t.barPadForNumericAxis, c = t.barPadForNumericAxis)), t.dom.elGridRect = i.drawRect(-a - o - 2, 2 * -a - 2, t.gridWidth + a + c + o + 4, t.gridHeight + 4 * a + 4, 0, "#fff");
          var d = e.globals.markers.largestSize + 1;
          t.dom.elGridRectMarker = i.drawRect(2 * -d, 2 * -d, t.gridWidth + 4 * d, t.gridHeight + 4 * d, 0, "#fff"), t.dom.elGridRectMask.appendChild(t.dom.elGridRect.node), t.dom.elGridRectMarkerMask.appendChild(t.dom.elGridRectMarker.node);
          var g = t.dom.baseEl.querySelector("defs");
          g.appendChild(t.dom.elGridRectMask), g.appendChild(t.dom.elForecastMask), g.appendChild(t.dom.elNonForecastMask), g.appendChild(t.dom.elGridRectMarkerMask);
        } }, { key: "_drawGridLines", value: function(e) {
          var t = e.i, i = e.x1, a = e.y1, s = e.x2, r = e.y2, o = e.xCount, c = e.parent, d = this.w;
          if (!(t === 0 && d.globals.skipFirstTimelinelabel || t === o - 1 && d.globals.skipLastTimelinelabel && !d.config.xaxis.labels.formatter || d.config.chart.type === "radar")) {
            d.config.grid.xaxis.lines.show && this._drawGridLine({ i: t, x1: i, y1: a, x2: s, y2: r, xCount: o, parent: c });
            var g = 0;
            if (d.globals.hasXaxisGroups && d.config.xaxis.tickPlacement === "between") {
              var f = d.globals.groups;
              if (f) {
                for (var p = 0, m = 0; p < t && m < f.length; m++)
                  p += f[m].cols;
                p === t && (g = 0.6 * d.globals.xAxisLabelsHeight);
              }
            }
            new Ee(this.ctx).drawXaxisTicks(i, g, d.globals.dom.elGraphical);
          }
        } }, { key: "_drawGridLine", value: function(e) {
          var t = e.i, i = e.x1, a = e.y1, s = e.x2, r = e.y2, o = e.xCount, c = e.parent, d = this.w, g = !1, f = c.node.classList.contains("apexcharts-gridlines-horizontal"), p = d.config.grid.strokeDashArray, m = d.globals.barPadForNumericAxis;
          (a === 0 && r === 0 || i === 0 && s === 0) && (g = !0), a === d.globals.gridHeight && r === d.globals.gridHeight && (g = !0), !d.globals.isBarHorizontal || t !== 0 && t !== o - 1 || (g = !0);
          var w = new X(this).drawLine(i - (f ? m : 0), a, s + (f ? m : 0), r, d.config.grid.borderColor, p);
          w.node.classList.add("apexcharts-gridline"), g && d.config.grid.show ? this.elGridBorders.add(w) : c.add(w);
        } }, { key: "_drawGridBandRect", value: function(e) {
          var t = e.c, i = e.x1, a = e.y1, s = e.x2, r = e.y2, o = e.type, c = this.w, d = new X(this.ctx), g = c.globals.barPadForNumericAxis;
          if (o !== "column" || c.config.xaxis.type !== "datetime") {
            var f = c.config.grid[o].colors[t], p = d.drawRect(i - (o === "row" ? g : 0), a, s + (o === "row" ? 2 * g : 0), r, 0, f, c.config.grid[o].opacity);
            this.elg.add(p), p.attr("clip-path", "url(#gridRectMask".concat(c.globals.cuid, ")")), p.node.classList.add("apexcharts-grid-".concat(o));
          }
        } }, { key: "_drawXYLines", value: function(e) {
          var t = this, i = e.xCount, a = e.tickAmount, s = this.w;
          if (s.config.grid.xaxis.lines.show || s.config.xaxis.axisTicks.show) {
            var r, o = s.globals.padHorizontal, c = s.globals.gridHeight;
            s.globals.timescaleLabels.length ? function(w) {
              for (var C = w.xC, k = w.x1, E = w.y1, _ = w.x2, h = w.y2, x = 0; x < C; x++)
                k = t.xaxisLabels[x].position, _ = t.xaxisLabels[x].position, t._drawGridLines({ i: x, x1: k, y1: E, x2: _, y2: h, xCount: i, parent: t.elgridLinesV });
            }({ xC: i, x1: o, y1: 0, x2: r, y2: c }) : (s.globals.isXNumeric && (i = s.globals.xAxisScale.result.length), function(w) {
              for (var C = w.xC, k = w.x1, E = w.y1, _ = w.x2, h = w.y2, x = 0; x < C + (s.globals.isXNumeric ? 0 : 1); x++)
                x === 0 && C === 1 && s.globals.dataPoints === 1 && (_ = k = s.globals.gridWidth / 2), t._drawGridLines({ i: x, x1: k, y1: E, x2: _, y2: h, xCount: i, parent: t.elgridLinesV }), _ = k += s.globals.gridWidth / (s.globals.isXNumeric ? C - 1 : C);
            }({ xC: i, x1: o, y1: 0, x2: r, y2: c }));
          }
          if (s.config.grid.yaxis.lines.show) {
            var d = 0, g = 0, f = s.globals.gridWidth, p = a + 1;
            this.isRangeBar && (p = s.globals.labels.length);
            for (var m = 0; m < p + (this.isRangeBar ? 1 : 0); m++)
              this._drawGridLine({ i: m, xCount: p + (this.isRangeBar ? 1 : 0), x1: 0, y1: d, x2: f, y2: g, parent: this.elgridLinesH }), g = d += s.globals.gridHeight / (this.isRangeBar ? p : a);
          }
        } }, { key: "_drawInvertedXYLines", value: function(e) {
          var t = e.xCount, i = this.w;
          if (i.config.grid.xaxis.lines.show || i.config.xaxis.axisTicks.show)
            for (var a, s = i.globals.padHorizontal, r = i.globals.gridHeight, o = 0; o < t + 1; o++)
              i.config.grid.xaxis.lines.show && this._drawGridLine({ i: o, xCount: t + 1, x1: s, y1: 0, x2: a, y2: r, parent: this.elgridLinesV }), new Ee(this.ctx).drawXaxisTicks(s, 0, i.globals.dom.elGraphical), a = s = s + i.globals.gridWidth / t + 0.3;
          if (i.config.grid.yaxis.lines.show)
            for (var c = 0, d = 0, g = i.globals.gridWidth, f = 0; f < i.globals.dataPoints + 1; f++)
              this._drawGridLine({ i: f, xCount: i.globals.dataPoints + 1, x1: 0, y1: c, x2: g, y2: d, parent: this.elgridLinesH }), d = c += i.globals.gridHeight / i.globals.dataPoints;
        } }, { key: "renderGrid", value: function() {
          var e = this.w, t = new X(this.ctx);
          this.elg = t.group({ class: "apexcharts-grid" }), this.elgridLinesH = t.group({ class: "apexcharts-gridlines-horizontal" }), this.elgridLinesV = t.group({ class: "apexcharts-gridlines-vertical" }), this.elGridBorders = t.group({ class: "apexcharts-grid-borders" }), this.elg.add(this.elgridLinesH), this.elg.add(this.elgridLinesV), e.config.grid.show || (this.elgridLinesV.hide(), this.elgridLinesH.hide(), this.elGridBorders.hide());
          for (var i, a = e.globals.yAxisScale.length ? e.globals.yAxisScale[0].result.length - 1 : 5, s = 0; s < e.globals.series.length && (e.globals.yAxisScale[s] !== void 0 && (a = e.globals.yAxisScale[s].result.length - 1), !(a > 2)); s++)
            ;
          if (!e.globals.isBarHorizontal || this.isRangeBar) {
            var r, o, c;
            i = this.xaxisLabels.length, this.isRangeBar && (i--, a = e.globals.labels.length, e.config.xaxis.tickAmount && e.config.xaxis.labels.formatter && (i = e.config.xaxis.tickAmount), ((r = e.globals.yAxisScale) === null || r === void 0 || (o = r[0]) === null || o === void 0 || (c = o.result) === null || c === void 0 ? void 0 : c.length) > 0 && e.config.xaxis.type !== "datetime" && (i = e.globals.yAxisScale[0].result.length - 1)), this._drawXYLines({ xCount: i, tickAmount: a });
          } else
            i = a, a = e.globals.xTickAmount, this._drawInvertedXYLines({ xCount: i, tickAmount: a });
          return this.drawGridBands(i, a), { el: this.elg, elGridBorders: this.elGridBorders, xAxisTickWidth: e.globals.gridWidth / i };
        } }, { key: "drawGridBands", value: function(e, t) {
          var i = this.w;
          if (i.config.grid.row.colors !== void 0 && i.config.grid.row.colors.length > 0)
            for (var a = 0, s = i.globals.gridHeight / t, r = i.globals.gridWidth, o = 0, c = 0; o < t; o++, c++)
              c >= i.config.grid.row.colors.length && (c = 0), this._drawGridBandRect({ c, x1: 0, y1: a, x2: r, y2: s, type: "row" }), a += i.globals.gridHeight / t;
          if (i.config.grid.column.colors !== void 0 && i.config.grid.column.colors.length > 0)
            for (var d = i.globals.isBarHorizontal || i.config.xaxis.tickPlacement !== "on" || i.config.xaxis.type !== "category" && !i.config.xaxis.convertedCatToNumeric ? e : e - 1, g = i.globals.padHorizontal, f = i.globals.padHorizontal + i.globals.gridWidth / d, p = i.globals.gridHeight, m = 0, w = 0; m < e; m++, w++)
              w >= i.config.grid.column.colors.length && (w = 0), this._drawGridBandRect({ c: w, x1: g, y1: 0, x2: f, y2: p, type: "column" }), g += i.globals.gridWidth / d;
        } }]), P;
      }(), ze = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "niceScale", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 5, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0, s = arguments.length > 4 ? arguments[4] : void 0, r = this.w, o = Math.abs(t - e);
          if ((i = this._adjustTicksForSmallRange(i, a, o)) === "dataPoints" && (i = r.globals.dataPoints - 1), e === Number.MIN_VALUE && t === 0 || !M.isNumber(e) && !M.isNumber(t) || e === Number.MIN_VALUE && t === -Number.MAX_VALUE)
            return e = 0, t = i, this.linearScale(e, t, i, a, r.config.yaxis[a].stepSize);
          e > t ? (console.warn("axis.min cannot be greater than axis.max"), t = e + 0.1) : e === t && (e = e === 0 ? 0 : e - 0.5, t = t === 0 ? 2 : t + 0.5);
          var c = [];
          o < 1 && s && (r.config.chart.type === "candlestick" || r.config.series[a].type === "candlestick" || r.config.chart.type === "boxPlot" || r.config.series[a].type === "boxPlot" || r.globals.isRangeData) && (t *= 1.01);
          var d = i + 1;
          d < 2 ? d = 2 : d > 2 && (d -= 2);
          var g = o / d, f = Math.floor(M.log10(g)), p = Math.pow(10, f), m = Math.round(g / p);
          m < 1 && (m = 1);
          var w = m * p;
          r.config.yaxis[a].stepSize && (w = r.config.yaxis[a].stepSize), r.globals.isBarHorizontal && r.config.xaxis.stepSize && r.config.xaxis.type !== "datetime" && (w = r.config.xaxis.stepSize);
          var C = w * Math.floor(e / w), k = w * Math.ceil(t / w), E = C;
          if (s && o > 2) {
            for (; c.push(M.stripNumber(E, 7)), !((E += w) > k); )
              ;
            return { result: c, niceMin: c[0], niceMax: c[c.length - 1] };
          }
          var _ = e;
          (c = []).push(M.stripNumber(_, 7));
          for (var h = Math.abs(t - e) / i, x = 0; x <= i; x++)
            _ += h, c.push(_);
          return c[c.length - 2] >= t && c.pop(), { result: c, niceMin: c[0], niceMax: c[c.length - 1] };
        } }, { key: "linearScale", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 5, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0, s = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : void 0, r = Math.abs(t - e);
          (i = this._adjustTicksForSmallRange(i, a, r)) === "dataPoints" && (i = this.w.globals.dataPoints - 1), s || (s = r / i), i === Number.MAX_VALUE && (i = 5, s = 1);
          for (var o = [], c = e; i >= 0; )
            o.push(c), c += s, i -= 1;
          return { result: o, niceMin: o[0], niceMax: o[o.length - 1] };
        } }, { key: "logarithmicScaleNice", value: function(e, t, i) {
          t <= 0 && (t = Math.max(e, i)), e <= 0 && (e = Math.min(t, i));
          for (var a = [], s = Math.ceil(Math.log(t) / Math.log(i) + 1), r = Math.floor(Math.log(e) / Math.log(i)); r < s; r++)
            a.push(Math.pow(i, r));
          return { result: a, niceMin: a[0], niceMax: a[a.length - 1] };
        } }, { key: "logarithmicScale", value: function(e, t, i) {
          t <= 0 && (t = Math.max(e, i)), e <= 0 && (e = Math.min(t, i));
          for (var a = [], s = Math.log(t) / Math.log(i), r = Math.log(e) / Math.log(i), o = s - r, c = Math.round(o), d = o / c, g = 0, f = r; g < c; g++, f += d)
            a.push(Math.pow(i, f));
          return a.push(Math.pow(i, s)), { result: a, niceMin: e, niceMax: t };
        } }, { key: "_adjustTicksForSmallRange", value: function(e, t, i) {
          var a = e;
          if (t !== void 0 && this.w.config.yaxis[t].labels.formatter && this.w.config.yaxis[t].tickAmount === void 0) {
            var s = Number(this.w.config.yaxis[t].labels.formatter(1));
            M.isNumber(s) && this.w.globals.yValueDecimal === 0 && (a = Math.ceil(i));
          }
          return a < e ? a : e;
        } }, { key: "setYScaleForIndex", value: function(e, t, i) {
          var a = this.w.globals, s = this.w.config, r = a.isBarHorizontal ? s.xaxis : s.yaxis[e];
          a.yAxisScale[e] === void 0 && (a.yAxisScale[e] = []);
          var o = Math.abs(i - t);
          if (r.logarithmic && o <= 5 && (a.invalidLogScale = !0), r.logarithmic && o > 5)
            a.allSeriesCollapsed = !1, a.yAxisScale[e] = this.logarithmicScale(t, i, r.logBase), a.yAxisScale[e] = r.forceNiceScale ? this.logarithmicScaleNice(t, i, r.logBase) : this.logarithmicScale(t, i, r.logBase);
          else if (i !== -Number.MAX_VALUE && M.isNumber(i))
            if (a.allSeriesCollapsed = !1, r.min === void 0 && r.max === void 0 || r.forceNiceScale) {
              var c = s.yaxis[e].max === void 0 && s.yaxis[e].min === void 0 || s.yaxis[e].forceNiceScale;
              a.yAxisScale[e] = this.niceScale(t, i, r.tickAmount ? r.tickAmount : o < 5 && o > 1 ? o + 1 : 5, e, c);
            } else
              a.yAxisScale[e] = this.linearScale(t, i, r.tickAmount, e, s.yaxis[e].stepSize);
          else
            a.yAxisScale[e] = this.linearScale(0, 5, 5, e, s.yaxis[e].stepSize);
        } }, { key: "setXScale", value: function(e, t) {
          var i = this.w, a = i.globals, s = Math.abs(t - e);
          return t !== -Number.MAX_VALUE && M.isNumber(t) ? a.xAxisScale = this.linearScale(e, t, i.config.xaxis.tickAmount ? i.config.xaxis.tickAmount : s < 5 && s > 1 ? s + 1 : 5, 0, i.config.xaxis.stepSize) : a.xAxisScale = this.linearScale(0, 5, 5), a.xAxisScale;
        } }, { key: "setMultipleYScales", value: function() {
          var e = this, t = this.w.globals, i = this.w.config, a = t.minYArr.concat([]), s = t.maxYArr.concat([]), r = [];
          i.yaxis.forEach(function(o, c) {
            var d = c;
            i.series.forEach(function(p, m) {
              p.name === o.seriesName && (d = m, c !== m ? r.push({ index: m, similarIndex: c, alreadyExists: !0 }) : r.push({ index: m }));
            });
            var g = a[d], f = s[d];
            e.setYScaleForIndex(c, g, f);
          }), this.sameScaleInMultipleAxes(a, s, r);
        } }, { key: "sameScaleInMultipleAxes", value: function(e, t, i) {
          var a = this, s = this.w.config, r = this.w.globals, o = [];
          i.forEach(function(C) {
            C.alreadyExists && (o[C.index] === void 0 && (o[C.index] = []), o[C.index].push(C.index), o[C.index].push(C.similarIndex));
          }), r.yAxisSameScaleIndices = o, o.forEach(function(C, k) {
            o.forEach(function(E, _) {
              var h, x;
              k !== _ && (h = C, x = E, h.filter(function(S) {
                return x.indexOf(S) !== -1;
              })).length > 0 && (o[k] = o[k].concat(o[_]));
            });
          });
          var c = o.map(function(C) {
            return C.filter(function(k, E) {
              return C.indexOf(k) === E;
            });
          }).map(function(C) {
            return C.sort();
          });
          o = o.filter(function(C) {
            return !!C;
          });
          var d = c.slice(), g = d.map(function(C) {
            return JSON.stringify(C);
          });
          d = d.filter(function(C, k) {
            return g.indexOf(JSON.stringify(C)) === k;
          });
          var f = [], p = [];
          e.forEach(function(C, k) {
            d.forEach(function(E, _) {
              E.indexOf(k) > -1 && (f[_] === void 0 && (f[_] = [], p[_] = []), f[_].push({ key: k, value: C }), p[_].push({ key: k, value: t[k] }));
            });
          });
          var m = Array.apply(null, Array(d.length)).map(Number.prototype.valueOf, Number.MIN_VALUE), w = Array.apply(null, Array(d.length)).map(Number.prototype.valueOf, -Number.MAX_VALUE);
          f.forEach(function(C, k) {
            C.forEach(function(E, _) {
              m[k] = Math.min(E.value, m[k]);
            });
          }), p.forEach(function(C, k) {
            C.forEach(function(E, _) {
              w[k] = Math.max(E.value, w[k]);
            });
          }), e.forEach(function(C, k) {
            p.forEach(function(E, _) {
              var h = m[_], x = w[_];
              s.chart.stacked && (x = 0, E.forEach(function(S, L) {
                S.value !== -Number.MAX_VALUE && (x += S.value), h !== Number.MIN_VALUE && (h += f[_][L].value);
              })), E.forEach(function(S, L) {
                E[L].key === k && (s.yaxis[k].min !== void 0 && (h = typeof s.yaxis[k].min == "function" ? s.yaxis[k].min(r.minY) : s.yaxis[k].min), s.yaxis[k].max !== void 0 && (x = typeof s.yaxis[k].max == "function" ? s.yaxis[k].max(r.maxY) : s.yaxis[k].max), a.setYScaleForIndex(k, h, x));
              });
            });
          });
        } }, { key: "autoScaleY", value: function(e, t, i) {
          e || (e = this);
          var a = e.w;
          if (a.globals.isMultipleYAxis || a.globals.collapsedSeries.length)
            return console.warn("autoScaleYaxis not supported in a multi-yaxis chart."), t;
          var s = a.globals.seriesX[0], r = a.config.chart.stacked;
          return t.forEach(function(o, c) {
            for (var d = 0, g = 0; g < s.length; g++)
              if (s[g] >= i.xaxis.min) {
                d = g;
                break;
              }
            var f, p, m = a.globals.minYArr[c], w = a.globals.maxYArr[c], C = a.globals.stackedSeriesTotals;
            a.globals.series.forEach(function(k, E) {
              var _ = k[d];
              r ? (_ = C[d], f = p = _, C.forEach(function(h, x) {
                s[x] <= i.xaxis.max && s[x] >= i.xaxis.min && (h > p && h !== null && (p = h), k[x] < f && k[x] !== null && (f = k[x]));
              })) : (f = p = _, k.forEach(function(h, x) {
                if (s[x] <= i.xaxis.max && s[x] >= i.xaxis.min) {
                  var S = h, L = h;
                  a.globals.series.forEach(function(R, O) {
                    h !== null && (S = Math.min(R[x], S), L = Math.max(R[x], L));
                  }), L > p && L !== null && (p = L), S < f && S !== null && (f = S);
                }
              })), f === void 0 && p === void 0 && (f = m, p = w), p *= p < 0 ? 0.9 : 1.1, (f *= f < 0 ? 1.1 : 0.9) === 0 && p === 0 && (f = -1, p = 1), p < 0 && p < w && (p = w), f < 0 && f > m && (f = m), t.length > 1 ? (t[E].min = o.min === void 0 ? f : o.min, t[E].max = o.max === void 0 ? p : o.max) : (t[0].min = o.min === void 0 ? f : o.min, t[0].max = o.max === void 0 ? p : o.max);
            });
          }), t;
        } }]), P;
      }(), De = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.scales = new ze(e);
        }
        return A(P, [{ key: "init", value: function() {
          this.setYRange(), this.setXRange(), this.setZRange();
        } }, { key: "getMinYMaxY", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : Number.MAX_VALUE, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : -Number.MAX_VALUE, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null, s = this.w.config, r = this.w.globals, o = -Number.MAX_VALUE, c = Number.MIN_VALUE;
          a === null && (a = e + 1);
          var d = r.series, g = d, f = d;
          s.chart.type === "candlestick" ? (g = r.seriesCandleL, f = r.seriesCandleH) : s.chart.type === "boxPlot" ? (g = r.seriesCandleO, f = r.seriesCandleC) : r.isRangeData && (g = r.seriesRangeStart, f = r.seriesRangeEnd);
          for (var p = e; p < a; p++) {
            r.dataPoints = Math.max(r.dataPoints, d[p].length), r.categoryLabels.length && (r.dataPoints = r.categoryLabels.filter(function(C) {
              return C !== void 0;
            }).length), r.labels.length && s.xaxis.type !== "datetime" && r.series.reduce(function(C, k) {
              return C + k.length;
            }, 0) !== 0 && (r.dataPoints = Math.max(r.dataPoints, r.labels.length));
            for (var m = 0; m < r.series[p].length; m++) {
              var w = d[p][m];
              w !== null && M.isNumber(w) ? (f[p][m] !== void 0 && (o = Math.max(o, f[p][m]), t = Math.min(t, f[p][m])), g[p][m] !== void 0 && (t = Math.min(t, g[p][m]), i = Math.max(i, g[p][m])), this.w.config.chart.type !== "candlestick" && this.w.config.chart.type !== "boxPlot" && this.w.config.chart.type === "rangeArea" && this.w.config.chart.type === "rangeBar" || (this.w.config.chart.type !== "candlestick" && this.w.config.chart.type !== "boxPlot" || r.seriesCandleC[p][m] !== void 0 && (o = Math.max(o, r.seriesCandleO[p][m]), o = Math.max(o, r.seriesCandleH[p][m]), o = Math.max(o, r.seriesCandleL[p][m]), o = Math.max(o, r.seriesCandleC[p][m]), this.w.config.chart.type === "boxPlot" && (o = Math.max(o, r.seriesCandleM[p][m]))), !s.series[p].type || s.series[p].type === "candlestick" && s.series[p].type === "boxPlot" && s.series[p].type === "rangeArea" && s.series[p].type === "rangeBar" || (o = Math.max(o, r.series[p][m]), t = Math.min(t, r.series[p][m])), i = o), r.seriesGoals[p] && r.seriesGoals[p][m] && Array.isArray(r.seriesGoals[p][m]) && r.seriesGoals[p][m].forEach(function(C) {
                c !== Number.MIN_VALUE && (c = Math.min(c, C.value), t = c), o = Math.max(o, C.value), i = o;
              }), M.isFloat(w) && (w = M.noExponents(w), r.yValueDecimal = Math.max(r.yValueDecimal, w.toString().split(".")[1].length)), c > g[p][m] && g[p][m] < 0 && (c = g[p][m])) : r.hasNullValues = !0;
            }
          }
          return s.chart.type === "rangeBar" && r.seriesRangeStart.length && r.isBarHorizontal && (c = t), s.chart.type === "bar" && (c < 0 && o < 0 && (o = 0), c === Number.MIN_VALUE && (c = 0)), { minY: c, maxY: o, lowestY: t, highestY: i };
        } }, { key: "setYRange", value: function() {
          var e = this.w.globals, t = this.w.config;
          e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE;
          var i = Number.MAX_VALUE;
          if (e.isMultipleYAxis)
            for (var a = 0; a < e.series.length; a++) {
              var s = this.getMinYMaxY(a, i, null, a + 1);
              e.minYArr.push(s.minY), e.maxYArr.push(s.maxY), i = s.lowestY;
            }
          var r = this.getMinYMaxY(0, i, null, e.series.length);
          if (e.minY = r.minY, e.maxY = r.maxY, i = r.lowestY, t.chart.stacked && this._setStackedMinMax(), (t.chart.type === "line" || t.chart.type === "area" || t.chart.type === "candlestick" || t.chart.type === "boxPlot" || t.chart.type === "rangeBar" && !e.isBarHorizontal) && e.minY === Number.MIN_VALUE && i !== -Number.MAX_VALUE && i !== e.maxY) {
            var o = e.maxY - i;
            (i >= 0 && i <= 10 || t.yaxis[0].min !== void 0 || t.yaxis[0].max !== void 0) && (o = 0), e.minY = i - 5 * o / 100, i > 0 && e.minY < 0 && (e.minY = 0), e.maxY = e.maxY + 5 * o / 100;
          }
          return t.yaxis.forEach(function(c, d) {
            c.max !== void 0 && (typeof c.max == "number" ? e.maxYArr[d] = c.max : typeof c.max == "function" && (e.maxYArr[d] = c.max(e.isMultipleYAxis ? e.maxYArr[d] : e.maxY)), e.maxY = e.maxYArr[d]), c.min !== void 0 && (typeof c.min == "number" ? e.minYArr[d] = c.min : typeof c.min == "function" && (e.minYArr[d] = c.min(e.isMultipleYAxis ? e.minYArr[d] === Number.MIN_VALUE ? 0 : e.minYArr[d] : e.minY)), e.minY = e.minYArr[d]);
          }), e.isBarHorizontal && ["min", "max"].forEach(function(c) {
            t.xaxis[c] !== void 0 && typeof t.xaxis[c] == "number" && (c === "min" ? e.minY = t.xaxis[c] : e.maxY = t.xaxis[c]);
          }), e.isMultipleYAxis ? (this.scales.setMultipleYScales(), e.minY = i, e.yAxisScale.forEach(function(c, d) {
            e.minYArr[d] = c.niceMin, e.maxYArr[d] = c.niceMax;
          })) : (this.scales.setYScaleForIndex(0, e.minY, e.maxY), e.minY = e.yAxisScale[0].niceMin, e.maxY = e.yAxisScale[0].niceMax, e.minYArr[0] = e.yAxisScale[0].niceMin, e.maxYArr[0] = e.yAxisScale[0].niceMax), { minY: e.minY, maxY: e.maxY, minYArr: e.minYArr, maxYArr: e.maxYArr, yAxisScale: e.yAxisScale };
        } }, { key: "setXRange", value: function() {
          var e = this.w.globals, t = this.w.config, i = t.xaxis.type === "numeric" || t.xaxis.type === "datetime" || t.xaxis.type === "category" && !e.noLabelsProvided || e.noLabelsProvided || e.isXNumeric;
          if (e.isXNumeric && function() {
            for (var o = 0; o < e.series.length; o++)
              if (e.labels[o])
                for (var c = 0; c < e.labels[o].length; c++)
                  e.labels[o][c] !== null && M.isNumber(e.labels[o][c]) && (e.maxX = Math.max(e.maxX, e.labels[o][c]), e.initialMaxX = Math.max(e.maxX, e.labels[o][c]), e.minX = Math.min(e.minX, e.labels[o][c]), e.initialMinX = Math.min(e.minX, e.labels[o][c]));
          }(), e.noLabelsProvided && t.xaxis.categories.length === 0 && (e.maxX = e.labels[e.labels.length - 1], e.initialMaxX = e.labels[e.labels.length - 1], e.minX = 1, e.initialMinX = 1), e.isXNumeric || e.noLabelsProvided || e.dataFormatXNumeric) {
            var a;
            if (t.xaxis.tickAmount === void 0 ? (a = Math.round(e.svgWidth / 150), t.xaxis.type === "numeric" && e.dataPoints < 30 && (a = e.dataPoints - 1), a > e.dataPoints && e.dataPoints !== 0 && (a = e.dataPoints - 1)) : t.xaxis.tickAmount === "dataPoints" ? (e.series.length > 1 && (a = e.series[e.maxValsInArrayIndex].length - 1), e.isXNumeric && (a = e.maxX - e.minX - 1)) : a = t.xaxis.tickAmount, e.xTickAmount = a, t.xaxis.max !== void 0 && typeof t.xaxis.max == "number" && (e.maxX = t.xaxis.max), t.xaxis.min !== void 0 && typeof t.xaxis.min == "number" && (e.minX = t.xaxis.min), t.xaxis.range !== void 0 && (e.minX = e.maxX - t.xaxis.range), e.minX !== Number.MAX_VALUE && e.maxX !== -Number.MAX_VALUE)
              if (t.xaxis.convertedCatToNumeric && !e.dataFormatXNumeric) {
                for (var s = [], r = e.minX - 1; r < e.maxX; r++)
                  s.push(r + 1);
                e.xAxisScale = { result: s, niceMin: s[0], niceMax: s[s.length - 1] };
              } else
                e.xAxisScale = this.scales.setXScale(e.minX, e.maxX);
            else
              e.xAxisScale = this.scales.linearScale(0, a, a, 0, t.xaxis.stepSize), e.noLabelsProvided && e.labels.length > 0 && (e.xAxisScale = this.scales.linearScale(1, e.labels.length, a - 1, 0, t.xaxis.stepSize), e.seriesX = e.labels.slice());
            i && (e.labels = e.xAxisScale.result.slice());
          }
          return e.isBarHorizontal && e.labels.length && (e.xTickAmount = e.labels.length), this._handleSingleDataPoint(), this._getMinXDiff(), { minX: e.minX, maxX: e.maxX };
        } }, { key: "setZRange", value: function() {
          var e = this.w.globals;
          if (e.isDataXYZ) {
            for (var t = 0; t < e.series.length; t++)
              if (e.seriesZ[t] !== void 0)
                for (var i = 0; i < e.seriesZ[t].length; i++)
                  e.seriesZ[t][i] !== null && M.isNumber(e.seriesZ[t][i]) && (e.maxZ = Math.max(e.maxZ, e.seriesZ[t][i]), e.minZ = Math.min(e.minZ, e.seriesZ[t][i]));
          }
        } }, { key: "_handleSingleDataPoint", value: function() {
          var e = this.w.globals, t = this.w.config;
          if (e.minX === e.maxX) {
            var i = new ue(this.ctx);
            if (t.xaxis.type === "datetime") {
              var a = i.getDate(e.minX);
              t.xaxis.labels.datetimeUTC ? a.setUTCDate(a.getUTCDate() - 2) : a.setDate(a.getDate() - 2), e.minX = new Date(a).getTime();
              var s = i.getDate(e.maxX);
              t.xaxis.labels.datetimeUTC ? s.setUTCDate(s.getUTCDate() + 2) : s.setDate(s.getDate() + 2), e.maxX = new Date(s).getTime();
            } else
              (t.xaxis.type === "numeric" || t.xaxis.type === "category" && !e.noLabelsProvided) && (e.minX = e.minX - 2, e.initialMinX = e.minX, e.maxX = e.maxX + 2, e.initialMaxX = e.maxX);
          }
        } }, { key: "_getMinXDiff", value: function() {
          var e = this.w.globals;
          e.isXNumeric && e.seriesX.forEach(function(t, i) {
            t.length === 1 && t.push(e.seriesX[e.maxValsInArrayIndex][e.seriesX[e.maxValsInArrayIndex].length - 1]);
            var a = t.slice();
            a.sort(function(s, r) {
              return s - r;
            }), a.forEach(function(s, r) {
              if (r > 0) {
                var o = s - a[r - 1];
                o > 0 && (e.minXDiff = Math.min(o, e.minXDiff));
              }
            }), e.dataPoints !== 1 && e.minXDiff !== Number.MAX_VALUE || (e.minXDiff = 0.5);
          });
        } }, { key: "_setStackedMinMax", value: function() {
          var e = this, t = this.w.globals;
          if (t.series.length) {
            var i = t.seriesGroups;
            i.length || (i = [this.w.config.series.map(function(r) {
              return r.name;
            })]);
            var a = {}, s = {};
            i.forEach(function(r) {
              a[r] = [], s[r] = [], e.w.config.series.map(function(o, c) {
                return r.indexOf(o.name) > -1 ? c : null;
              }).filter(function(o) {
                return o !== null;
              }).forEach(function(o) {
                for (var c = 0; c < t.series[t.maxValsInArrayIndex].length; c++) {
                  var d, g;
                  a[r][c] === void 0 && (a[r][c] = 0, s[r][c] = 0), (e.w.config.chart.stacked && !t.comboCharts || e.w.config.chart.stacked && t.comboCharts && (!e.w.config.chart.stackOnlyBar || ((d = e.w.config.series) === null || d === void 0 || (g = d[o]) === null || g === void 0 ? void 0 : g.type) === "bar")) && t.series[o][c] !== null && M.isNumber(t.series[o][c]) && (t.series[o][c] > 0 ? a[r][c] += parseFloat(t.series[o][c]) + 1e-4 : s[r][c] += parseFloat(t.series[o][c]));
                }
              });
            }), Object.entries(a).forEach(function(r) {
              var o = B(r, 1)[0];
              a[o].forEach(function(c, d) {
                t.maxY = Math.max(t.maxY, a[o][d]), t.minY = Math.min(t.minY, s[o][d]);
              });
            });
          }
        } }]), P;
      }(), _e = function() {
        function P(e, t) {
          y(this, P), this.ctx = e, this.elgrid = t, this.w = e.w;
          var i = this.w;
          this.xaxisFontSize = i.config.xaxis.labels.style.fontSize, this.axisFontFamily = i.config.xaxis.labels.style.fontFamily, this.xaxisForeColors = i.config.xaxis.labels.style.colors, this.isCategoryBarHorizontal = i.config.chart.type === "bar" && i.config.plotOptions.bar.horizontal, this.xAxisoffX = 0, i.config.xaxis.position === "bottom" && (this.xAxisoffX = i.globals.gridHeight), this.drawnLabels = [], this.axesUtils = new ye(e);
        }
        return A(P, [{ key: "drawYaxis", value: function(e) {
          var t = this, i = this.w, a = new X(this.ctx), s = i.config.yaxis[e].labels.style, r = s.fontSize, o = s.fontFamily, c = s.fontWeight, d = a.group({ class: "apexcharts-yaxis", rel: e, transform: "translate(" + i.globals.translateYAxisX[e] + ", 0)" });
          if (this.axesUtils.isYAxisHidden(e))
            return d;
          var g = a.group({ class: "apexcharts-yaxis-texts-g" });
          d.add(g);
          var f = i.globals.yAxisScale[e].result.length - 1, p = i.globals.gridHeight / f, m = i.globals.translateY, w = i.globals.yLabelFormatters[e], C = i.globals.yAxisScale[e].result.slice();
          C = this.axesUtils.checkForReversedLabels(e, C);
          var k = "";
          if (i.config.yaxis[e].labels.show)
            for (var E = function(Y) {
              var N = C[Y];
              N = w(N, Y, i);
              var q = i.config.yaxis[e].labels.padding;
              i.config.yaxis[e].opposite && i.config.yaxis.length !== 0 && (q *= -1);
              var Z = "end";
              i.config.yaxis[e].opposite && (Z = "start"), i.config.yaxis[e].labels.align === "left" ? Z = "start" : i.config.yaxis[e].labels.align === "center" ? Z = "middle" : i.config.yaxis[e].labels.align === "right" && (Z = "end");
              var U = t.axesUtils.getYAxisForeColor(s.colors, e), se = i.config.yaxis[e].labels.offsetY;
              i.config.chart.type === "heatmap" && (se -= (i.globals.gridHeight / i.globals.series.length - 1) / 2);
              var he = a.drawText({ x: q, y: m + f / 10 + se + 1, text: N, textAnchor: Z, fontSize: r, fontFamily: o, fontWeight: c, maxWidth: i.config.yaxis[e].labels.maxWidth, foreColor: Array.isArray(U) ? U[Y] : U, isPlainText: !1, cssClass: "apexcharts-yaxis-label " + s.cssClass });
              Y === f && (k = he), g.add(he);
              var me = document.createElementNS(i.globals.SVGNS, "title");
              if (me.textContent = Array.isArray(N) ? N.join(" ") : N, he.node.appendChild(me), i.config.yaxis[e].labels.rotate !== 0) {
                var fe = a.rotateAroundCenter(k.node), Ce = a.rotateAroundCenter(he.node);
                he.node.setAttribute("transform", "rotate(".concat(i.config.yaxis[e].labels.rotate, " ").concat(fe.x, " ").concat(Ce.y, ")"));
              }
              m += p;
            }, _ = f; _ >= 0; _--)
              E(_);
          if (i.config.yaxis[e].title.text !== void 0) {
            var h = a.group({ class: "apexcharts-yaxis-title" }), x = 0;
            i.config.yaxis[e].opposite && (x = i.globals.translateYAxisX[e]);
            var S = a.drawText({ x, y: i.globals.gridHeight / 2 + i.globals.translateY + i.config.yaxis[e].title.offsetY, text: i.config.yaxis[e].title.text, textAnchor: "end", foreColor: i.config.yaxis[e].title.style.color, fontSize: i.config.yaxis[e].title.style.fontSize, fontWeight: i.config.yaxis[e].title.style.fontWeight, fontFamily: i.config.yaxis[e].title.style.fontFamily, cssClass: "apexcharts-yaxis-title-text " + i.config.yaxis[e].title.style.cssClass });
            h.add(S), d.add(h);
          }
          var L = i.config.yaxis[e].axisBorder, R = 31 + L.offsetX;
          if (i.config.yaxis[e].opposite && (R = -31 - L.offsetX), L.show) {
            var O = a.drawLine(R, i.globals.translateY + L.offsetY - 2, R, i.globals.gridHeight + i.globals.translateY + L.offsetY + 2, L.color, 0, L.width);
            d.add(O);
          }
          return i.config.yaxis[e].axisTicks.show && this.axesUtils.drawYAxisTicks(R, f, L, i.config.yaxis[e].axisTicks, e, p, d), d;
        } }, { key: "drawYaxisInversed", value: function(e) {
          var t = this.w, i = new X(this.ctx), a = i.group({ class: "apexcharts-xaxis apexcharts-yaxis-inversed" }), s = i.group({ class: "apexcharts-xaxis-texts-g", transform: "translate(".concat(t.globals.translateXAxisX, ", ").concat(t.globals.translateXAxisY, ")") });
          a.add(s);
          var r = t.globals.yAxisScale[e].result.length - 1, o = t.globals.gridWidth / r + 0.1, c = o + t.config.xaxis.labels.offsetX, d = t.globals.xLabelFormatter, g = t.globals.yAxisScale[e].result.slice(), f = t.globals.timescaleLabels;
          f.length > 0 && (this.xaxisLabels = f.slice(), r = (g = f.slice()).length), g = this.axesUtils.checkForReversedLabels(e, g);
          var p = f.length;
          if (t.config.xaxis.labels.show)
            for (var m = p ? 0 : r; p ? m < p : m >= 0; p ? m++ : m--) {
              var w = g[m];
              w = d(w, m, t);
              var C = t.globals.gridWidth + t.globals.padHorizontal - (c - o + t.config.xaxis.labels.offsetX);
              if (f.length) {
                var k = this.axesUtils.getLabel(g, f, C, m, this.drawnLabels, this.xaxisFontSize);
                C = k.x, w = k.text, this.drawnLabels.push(k.text), m === 0 && t.globals.skipFirstTimelinelabel && (w = ""), m === g.length - 1 && t.globals.skipLastTimelinelabel && (w = "");
              }
              var E = i.drawText({ x: C, y: this.xAxisoffX + t.config.xaxis.labels.offsetY + 30 - (t.config.xaxis.position === "top" ? t.globals.xAxisHeight + t.config.xaxis.axisTicks.height - 2 : 0), text: w, textAnchor: "middle", foreColor: Array.isArray(this.xaxisForeColors) ? this.xaxisForeColors[e] : this.xaxisForeColors, fontSize: this.xaxisFontSize, fontFamily: this.xaxisFontFamily, fontWeight: t.config.xaxis.labels.style.fontWeight, isPlainText: !1, cssClass: "apexcharts-xaxis-label " + t.config.xaxis.labels.style.cssClass });
              s.add(E), E.tspan(w);
              var _ = document.createElementNS(t.globals.SVGNS, "title");
              _.textContent = w, E.node.appendChild(_), c += o;
            }
          return this.inversedYAxisTitleText(a), this.inversedYAxisBorder(a), a;
        } }, { key: "inversedYAxisBorder", value: function(e) {
          var t = this.w, i = new X(this.ctx), a = t.config.xaxis.axisBorder;
          if (a.show) {
            var s = 0;
            t.config.chart.type === "bar" && t.globals.isXNumeric && (s -= 15);
            var r = i.drawLine(t.globals.padHorizontal + s + a.offsetX, this.xAxisoffX, t.globals.gridWidth, this.xAxisoffX, a.color, 0, a.height);
            this.elgrid && this.elgrid.elGridBorders && t.config.grid.show ? this.elgrid.elGridBorders.add(r) : e.add(r);
          }
        } }, { key: "inversedYAxisTitleText", value: function(e) {
          var t = this.w, i = new X(this.ctx);
          if (t.config.xaxis.title.text !== void 0) {
            var a = i.group({ class: "apexcharts-xaxis-title apexcharts-yaxis-title-inversed" }), s = i.drawText({ x: t.globals.gridWidth / 2 + t.config.xaxis.title.offsetX, y: this.xAxisoffX + parseFloat(this.xaxisFontSize) + parseFloat(t.config.xaxis.title.style.fontSize) + t.config.xaxis.title.offsetY + 20, text: t.config.xaxis.title.text, textAnchor: "middle", fontSize: t.config.xaxis.title.style.fontSize, fontFamily: t.config.xaxis.title.style.fontFamily, fontWeight: t.config.xaxis.title.style.fontWeight, foreColor: t.config.xaxis.title.style.color, cssClass: "apexcharts-xaxis-title-text " + t.config.xaxis.title.style.cssClass });
            a.add(s), e.add(a);
          }
        } }, { key: "yAxisTitleRotate", value: function(e, t) {
          var i = this.w, a = new X(this.ctx), s = { width: 0, height: 0 }, r = { width: 0, height: 0 }, o = i.globals.dom.baseEl.querySelector(" .apexcharts-yaxis[rel='".concat(e, "'] .apexcharts-yaxis-texts-g"));
          o !== null && (s = o.getBoundingClientRect());
          var c = i.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(e, "'] .apexcharts-yaxis-title text"));
          if (c !== null && (r = c.getBoundingClientRect()), c !== null) {
            var d = this.xPaddingForYAxisTitle(e, s, r, t);
            c.setAttribute("x", d.xPos - (t ? 10 : 0));
          }
          if (c !== null) {
            var g = a.rotateAroundCenter(c);
            c.setAttribute("transform", "rotate(".concat(t ? -1 * i.config.yaxis[e].title.rotate : i.config.yaxis[e].title.rotate, " ").concat(g.x, " ").concat(g.y, ")"));
          }
        } }, { key: "xPaddingForYAxisTitle", value: function(e, t, i, a) {
          var s = this.w, r = 0, o = 0, c = 10;
          return s.config.yaxis[e].title.text === void 0 || e < 0 ? { xPos: o, padd: 0 } : (a ? (o = t.width + s.config.yaxis[e].title.offsetX + i.width / 2 + c / 2, (r += 1) === 0 && (o -= c / 2)) : (o = -1 * t.width + s.config.yaxis[e].title.offsetX + c / 2 + i.width / 2, s.globals.isBarHorizontal && (c = 25, o = -1 * t.width - s.config.yaxis[e].title.offsetX - c)), { xPos: o, padd: c });
        } }, { key: "setYAxisXPosition", value: function(e, t) {
          var i = this.w, a = 0, s = 0, r = 18, o = 1;
          i.config.yaxis.length > 1 && (this.multipleYs = !0), i.config.yaxis.map(function(c, d) {
            var g = i.globals.ignoreYAxisIndexes.indexOf(d) > -1 || !c.show || c.floating || e[d].width === 0, f = e[d].width + t[d].width;
            c.opposite ? i.globals.isBarHorizontal ? (s = i.globals.gridWidth + i.globals.translateX - 1, i.globals.translateYAxisX[d] = s - c.labels.offsetX) : (s = i.globals.gridWidth + i.globals.translateX + o, g || (o = o + f + 20), i.globals.translateYAxisX[d] = s - c.labels.offsetX + 20) : (a = i.globals.translateX - r, g || (r = r + f + 20), i.globals.translateYAxisX[d] = a + c.labels.offsetX);
          });
        } }, { key: "setYAxisTextAlignments", value: function() {
          var e = this.w, t = e.globals.dom.baseEl.getElementsByClassName("apexcharts-yaxis");
          (t = M.listToArray(t)).forEach(function(i, a) {
            var s = e.config.yaxis[a];
            if (s && !s.floating && s.labels.align !== void 0) {
              var r = e.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(a, "'] .apexcharts-yaxis-texts-g")), o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis[rel='".concat(a, "'] .apexcharts-yaxis-label"));
              o = M.listToArray(o);
              var c = r.getBoundingClientRect();
              s.labels.align === "left" ? (o.forEach(function(d, g) {
                d.setAttribute("text-anchor", "start");
              }), s.opposite || r.setAttribute("transform", "translate(-".concat(c.width, ", 0)"))) : s.labels.align === "center" ? (o.forEach(function(d, g) {
                d.setAttribute("text-anchor", "middle");
              }), r.setAttribute("transform", "translate(".concat(c.width / 2 * (s.opposite ? 1 : -1), ", 0)"))) : s.labels.align === "right" && (o.forEach(function(d, g) {
                d.setAttribute("text-anchor", "end");
              }), s.opposite && r.setAttribute("transform", "translate(".concat(c.width, ", 0)")));
            }
          });
        } }]), P;
      }(), He = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.documentEvent = M.bind(this.documentEvent, this);
        }
        return A(P, [{ key: "addEventListener", value: function(e, t) {
          var i = this.w;
          i.globals.events.hasOwnProperty(e) ? i.globals.events[e].push(t) : i.globals.events[e] = [t];
        } }, { key: "removeEventListener", value: function(e, t) {
          var i = this.w;
          if (i.globals.events.hasOwnProperty(e)) {
            var a = i.globals.events[e].indexOf(t);
            a !== -1 && i.globals.events[e].splice(a, 1);
          }
        } }, { key: "fireEvent", value: function(e, t) {
          var i = this.w;
          if (i.globals.events.hasOwnProperty(e)) {
            t && t.length || (t = []);
            for (var a = i.globals.events[e], s = a.length, r = 0; r < s; r++)
              a[r].apply(null, t);
          }
        } }, { key: "setupEventHandlers", value: function() {
          var e = this, t = this.w, i = this.ctx, a = t.globals.dom.baseEl.querySelector(t.globals.chartClass);
          this.ctx.eventList.forEach(function(s) {
            a.addEventListener(s, function(r) {
              var o = Object.assign({}, t, { seriesIndex: t.globals.capturedSeriesIndex, dataPointIndex: t.globals.capturedDataPointIndex });
              r.type === "mousemove" || r.type === "touchmove" ? typeof t.config.chart.events.mouseMove == "function" && t.config.chart.events.mouseMove(r, i, o) : r.type === "mouseleave" || r.type === "touchleave" ? typeof t.config.chart.events.mouseLeave == "function" && t.config.chart.events.mouseLeave(r, i, o) : (r.type === "mouseup" && r.which === 1 || r.type === "touchend") && (typeof t.config.chart.events.click == "function" && t.config.chart.events.click(r, i, o), i.ctx.events.fireEvent("click", [r, i, o]));
            }, { capture: !1, passive: !0 });
          }), this.ctx.eventList.forEach(function(s) {
            t.globals.dom.baseEl.addEventListener(s, e.documentEvent, { passive: !0 });
          }), this.ctx.core.setupBrushHandler();
        } }, { key: "documentEvent", value: function(e) {
          var t = this.w, i = e.target.className;
          if (e.type === "click") {
            var a = t.globals.dom.baseEl.querySelector(".apexcharts-menu");
            a && a.classList.contains("apexcharts-menu-open") && i !== "apexcharts-menu-icon" && a.classList.remove("apexcharts-menu-open");
          }
          t.globals.clientX = e.type === "touchmove" ? e.touches[0].clientX : e.clientX, t.globals.clientY = e.type === "touchmove" ? e.touches[0].clientY : e.clientY;
        } }]), P;
      }(), Be = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "setCurrentLocaleValues", value: function(e) {
          var t = this.w.config.chart.locales;
          window.Apex.chart && window.Apex.chart.locales && window.Apex.chart.locales.length > 0 && (t = this.w.config.chart.locales.concat(window.Apex.chart.locales));
          var i = t.filter(function(s) {
            return s.name === e;
          })[0];
          if (!i)
            throw new Error("Wrong locale name provided. Please make sure you set the correct locale name in options");
          var a = M.extend(ne, i);
          this.w.globals.locale = a.options;
        } }]), P;
      }(), Xe = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "drawAxis", value: function(e, t) {
          var i, a, s = this, r = this.w.globals, o = this.w.config, c = new Ee(this.ctx, t), d = new _e(this.ctx, t);
          r.axisCharts && e !== "radar" && (r.isBarHorizontal ? (a = d.drawYaxisInversed(0), i = c.drawXaxisInversed(0), r.dom.elGraphical.add(i), r.dom.elGraphical.add(a)) : (i = c.drawXaxis(), r.dom.elGraphical.add(i), o.yaxis.map(function(g, f) {
            if (r.ignoreYAxisIndexes.indexOf(f) === -1 && (a = d.drawYaxis(f), r.dom.Paper.add(a), s.w.config.grid.position === "back")) {
              var p = r.dom.Paper.children()[1];
              p.remove(), r.dom.Paper.add(p);
            }
          })));
        } }]), P;
      }(), Ye = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "drawXCrosshairs", value: function() {
          var e = this.w, t = new X(this.ctx), i = new G(this.ctx), a = e.config.xaxis.crosshairs.fill.gradient, s = e.config.xaxis.crosshairs.dropShadow, r = e.config.xaxis.crosshairs.fill.type, o = a.colorFrom, c = a.colorTo, d = a.opacityFrom, g = a.opacityTo, f = a.stops, p = s.enabled, m = s.left, w = s.top, C = s.blur, k = s.color, E = s.opacity, _ = e.config.xaxis.crosshairs.fill.color;
          if (e.config.xaxis.crosshairs.show) {
            r === "gradient" && (_ = t.drawGradient("vertical", o, c, d, g, null, f, null));
            var h = t.drawRect();
            e.config.xaxis.crosshairs.width === 1 && (h = t.drawLine());
            var x = e.globals.gridHeight;
            (!M.isNumber(x) || x < 0) && (x = 0);
            var S = e.config.xaxis.crosshairs.width;
            (!M.isNumber(S) || S < 0) && (S = 0), h.attr({ class: "apexcharts-xcrosshairs", x: 0, y: 0, y2: x, width: S, height: x, fill: _, filter: "none", "fill-opacity": e.config.xaxis.crosshairs.opacity, stroke: e.config.xaxis.crosshairs.stroke.color, "stroke-width": e.config.xaxis.crosshairs.stroke.width, "stroke-dasharray": e.config.xaxis.crosshairs.stroke.dashArray }), p && (h = i.dropShadow(h, { left: m, top: w, blur: C, color: k, opacity: E })), e.globals.dom.elGraphical.add(h);
          }
        } }, { key: "drawYCrosshairs", value: function() {
          var e = this.w, t = new X(this.ctx), i = e.config.yaxis[0].crosshairs, a = e.globals.barPadForNumericAxis;
          if (e.config.yaxis[0].crosshairs.show) {
            var s = t.drawLine(-a, 0, e.globals.gridWidth + a, 0, i.stroke.color, i.stroke.dashArray, i.stroke.width);
            s.attr({ class: "apexcharts-ycrosshairs" }), e.globals.dom.elGraphical.add(s);
          }
          var r = t.drawLine(-a, 0, e.globals.gridWidth + a, 0, i.stroke.color, 0, 0);
          r.attr({ class: "apexcharts-ycrosshairs-hidden" }), e.globals.dom.elGraphical.add(r);
        } }]), P;
      }(), We = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "checkResponsiveConfig", value: function(e) {
          var t = this, i = this.w, a = i.config;
          if (a.responsive.length !== 0) {
            var s = a.responsive.slice();
            s.sort(function(d, g) {
              return d.breakpoint > g.breakpoint ? 1 : g.breakpoint > d.breakpoint ? -1 : 0;
            }).reverse();
            var r = new Te({}), o = function() {
              var d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, g = s[0].breakpoint, f = window.innerWidth > 0 ? window.innerWidth : screen.width;
              if (f > g) {
                var p = $.extendArrayProps(r, i.globals.initialConfig, i);
                d = M.extend(p, d), d = M.extend(i.config, d), t.overrideResponsiveOptions(d);
              } else
                for (var m = 0; m < s.length; m++)
                  f < s[m].breakpoint && (d = $.extendArrayProps(r, s[m].options, i), d = M.extend(i.config, d), t.overrideResponsiveOptions(d));
            };
            if (e) {
              var c = $.extendArrayProps(r, e, i);
              c = M.extend(i.config, c), o(c = M.extend(c, e));
            } else
              o({});
          }
        } }, { key: "overrideResponsiveOptions", value: function(e) {
          var t = new Te(e).init({ responsiveOverride: !0 });
          this.w.config = t;
        } }]), P;
      }(), tt = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.colors = [], this.w = e.w;
          var t = this.w;
          this.isColorFn = !1, this.isHeatmapDistributed = t.config.chart.type === "treemap" && t.config.plotOptions.treemap.distributed || t.config.chart.type === "heatmap" && t.config.plotOptions.heatmap.distributed, this.isBarDistributed = t.config.plotOptions.bar.distributed && (t.config.chart.type === "bar" || t.config.chart.type === "rangeBar");
        }
        return A(P, [{ key: "init", value: function() {
          this.setDefaultColors();
        } }, { key: "setDefaultColors", value: function() {
          var e, t = this, i = this.w, a = new M();
          if (i.globals.dom.elWrap.classList.add("apexcharts-theme-".concat(i.config.theme.mode)), i.config.colors === void 0 || ((e = i.config.colors) === null || e === void 0 ? void 0 : e.length) === 0 ? i.globals.colors = this.predefined() : (i.globals.colors = i.config.colors, Array.isArray(i.config.colors) && i.config.colors.length > 0 && typeof i.config.colors[0] == "function" && (i.globals.colors = i.config.series.map(function(w, C) {
            var k = i.config.colors[C];
            return k || (k = i.config.colors[0]), typeof k == "function" ? (t.isColorFn = !0, k({ value: i.globals.axisCharts ? i.globals.series[C][0] ? i.globals.series[C][0] : 0 : i.globals.series[C], seriesIndex: C, dataPointIndex: C, w: i })) : k;
          }))), i.globals.seriesColors.map(function(w, C) {
            w && (i.globals.colors[C] = w);
          }), i.config.theme.monochrome.enabled) {
            var s = [], r = i.globals.series.length;
            (this.isBarDistributed || this.isHeatmapDistributed) && (r = i.globals.series[0].length * i.globals.series.length);
            for (var o = i.config.theme.monochrome.color, c = 1 / (r / i.config.theme.monochrome.shadeIntensity), d = i.config.theme.monochrome.shadeTo, g = 0, f = 0; f < r; f++) {
              var p = void 0;
              d === "dark" ? (p = a.shadeColor(-1 * g, o), g += c) : (p = a.shadeColor(g, o), g += c), s.push(p);
            }
            i.globals.colors = s.slice();
          }
          var m = i.globals.colors.slice();
          this.pushExtraColors(i.globals.colors), ["fill", "stroke"].forEach(function(w) {
            i.config[w].colors === void 0 ? i.globals[w].colors = t.isColorFn ? i.config.colors : m : i.globals[w].colors = i.config[w].colors.slice(), t.pushExtraColors(i.globals[w].colors);
          }), i.config.dataLabels.style.colors === void 0 ? i.globals.dataLabels.style.colors = m : i.globals.dataLabels.style.colors = i.config.dataLabels.style.colors.slice(), this.pushExtraColors(i.globals.dataLabels.style.colors, 50), i.config.plotOptions.radar.polygons.fill.colors === void 0 ? i.globals.radarPolygons.fill.colors = [i.config.theme.mode === "dark" ? "#424242" : "none"] : i.globals.radarPolygons.fill.colors = i.config.plotOptions.radar.polygons.fill.colors.slice(), this.pushExtraColors(i.globals.radarPolygons.fill.colors, 20), i.config.markers.colors === void 0 ? i.globals.markers.colors = m : i.globals.markers.colors = i.config.markers.colors.slice(), this.pushExtraColors(i.globals.markers.colors);
        } }, { key: "pushExtraColors", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = this.w, s = t || a.globals.series.length;
          if (i === null && (i = this.isBarDistributed || this.isHeatmapDistributed || a.config.chart.type === "heatmap" && a.config.plotOptions.heatmap.colorScale.inverse), i && a.globals.series.length && (s = a.globals.series[a.globals.maxValsInArrayIndex].length * a.globals.series.length), e.length < s)
            for (var r = s - e.length, o = 0; o < r; o++)
              e.push(e[o]);
        } }, { key: "updateThemeOptions", value: function(e) {
          e.chart = e.chart || {}, e.tooltip = e.tooltip || {};
          var t = e.theme.mode || "light", i = e.theme.palette ? e.theme.palette : t === "dark" ? "palette4" : "palette1", a = e.chart.foreColor ? e.chart.foreColor : t === "dark" ? "#f6f7f8" : "#373d3f";
          return e.tooltip.theme = t, e.chart.foreColor = a, e.theme.palette = i, e;
        } }, { key: "predefined", value: function() {
          switch (this.w.config.theme.palette) {
            case "palette1":
            default:
              this.colors = ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"];
              break;
            case "palette2":
              this.colors = ["#3f51b5", "#03a9f4", "#4caf50", "#f9ce1d", "#FF9800"];
              break;
            case "palette3":
              this.colors = ["#33b2df", "#546E7A", "#d4526e", "#13d8aa", "#A5978B"];
              break;
            case "palette4":
              this.colors = ["#4ecdc4", "#c7f464", "#81D4FA", "#fd6a6a", "#546E7A"];
              break;
            case "palette5":
              this.colors = ["#2b908f", "#f9a3a4", "#90ee7e", "#fa4443", "#69d2e7"];
              break;
            case "palette6":
              this.colors = ["#449DD1", "#F86624", "#EA3546", "#662E9B", "#C5D86D"];
              break;
            case "palette7":
              this.colors = ["#D7263D", "#1B998B", "#2E294E", "#F46036", "#E2C044"];
              break;
            case "palette8":
              this.colors = ["#662E9B", "#F86624", "#F9C80E", "#EA3546", "#43BCCD"];
              break;
            case "palette9":
              this.colors = ["#5C4742", "#A5978B", "#8D5B4C", "#5A2A27", "#C4BBAF"];
              break;
            case "palette10":
              this.colors = ["#A300D6", "#7D02EB", "#5653FE", "#2983FF", "#00B1F2"];
          }
          return this.colors;
        } }]), P;
      }(), Ge = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "draw", value: function() {
          this.drawTitleSubtitle("title"), this.drawTitleSubtitle("subtitle");
        } }, { key: "drawTitleSubtitle", value: function(e) {
          var t = this.w, i = e === "title" ? t.config.title : t.config.subtitle, a = t.globals.svgWidth / 2, s = i.offsetY, r = "middle";
          if (i.align === "left" ? (a = 10, r = "start") : i.align === "right" && (a = t.globals.svgWidth - 10, r = "end"), a += i.offsetX, s = s + parseInt(i.style.fontSize, 10) + i.margin / 2, i.text !== void 0) {
            var o = new X(this.ctx).drawText({ x: a, y: s, text: i.text, textAnchor: r, fontSize: i.style.fontSize, fontFamily: i.style.fontFamily, fontWeight: i.style.fontWeight, foreColor: i.style.color, opacity: 1 });
            o.node.setAttribute("class", "apexcharts-".concat(e, "-text")), t.globals.dom.Paper.add(o);
          }
        } }]), P;
      }(), at = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.dCtx = e;
        }
        return A(P, [{ key: "getTitleSubtitleCoords", value: function(e) {
          var t = this.w, i = 0, a = 0, s = e === "title" ? t.config.title.floating : t.config.subtitle.floating, r = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(e, "-text"));
          if (r !== null && !s) {
            var o = r.getBoundingClientRect();
            i = o.width, a = t.globals.axisCharts ? o.height + 5 : o.height;
          }
          return { width: i, height: a };
        } }, { key: "getLegendsRect", value: function() {
          var e = this.w, t = e.globals.dom.elLegendWrap;
          e.config.legend.height || e.config.legend.position !== "top" && e.config.legend.position !== "bottom" || (t.style.maxHeight = e.globals.svgHeight / 2 + "px");
          var i = Object.assign({}, M.getBoundingClientRect(t));
          return t !== null && !e.config.legend.floating && e.config.legend.show ? this.dCtx.lgRect = { x: i.x, y: i.y, height: i.height, width: i.height === 0 ? 0 : i.width } : this.dCtx.lgRect = { x: 0, y: 0, height: 0, width: 0 }, e.config.legend.position !== "left" && e.config.legend.position !== "right" || 1.5 * this.dCtx.lgRect.width > e.globals.svgWidth && (this.dCtx.lgRect.width = e.globals.svgWidth / 1.5), this.dCtx.lgRect;
        } }, { key: "getLargestStringFromMultiArr", value: function(e, t) {
          var i = e;
          if (this.w.globals.isMultiLineX) {
            var a = t.map(function(r, o) {
              return Array.isArray(r) ? r.length : 1;
            }), s = Math.max.apply(Math, j(a));
            i = t[a.indexOf(s)];
          }
          return i;
        } }]), P;
      }(), ei = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.dCtx = e;
        }
        return A(P, [{ key: "getxAxisLabelsCoords", value: function() {
          var e, t = this.w, i = t.globals.labels.slice();
          if (t.config.xaxis.convertedCatToNumeric && i.length === 0 && (i = t.globals.categoryLabels), t.globals.timescaleLabels.length > 0) {
            var a = this.getxAxisTimeScaleLabelsCoords();
            e = { width: a.width, height: a.height }, t.globals.rotateXLabels = !1;
          } else {
            this.dCtx.lgWidthForSideLegends = t.config.legend.position !== "left" && t.config.legend.position !== "right" || t.config.legend.floating ? 0 : this.dCtx.lgRect.width;
            var s = t.globals.xLabelFormatter, r = M.getLargestStringFromArr(i), o = this.dCtx.dimHelpers.getLargestStringFromMultiArr(r, i);
            t.globals.isBarHorizontal && (o = r = t.globals.yAxisScale[0].result.reduce(function(w, C) {
              return w.length > C.length ? w : C;
            }, 0));
            var c = new Le(this.dCtx.ctx), d = r;
            r = c.xLabelFormat(s, r, d, { i: void 0, dateFormatter: new ue(this.dCtx.ctx).formatDate, w: t }), o = c.xLabelFormat(s, o, d, { i: void 0, dateFormatter: new ue(this.dCtx.ctx).formatDate, w: t }), (t.config.xaxis.convertedCatToNumeric && r === void 0 || String(r).trim() === "") && (o = r = "1");
            var g = new X(this.dCtx.ctx), f = g.getTextRects(r, t.config.xaxis.labels.style.fontSize), p = f;
            if (r !== o && (p = g.getTextRects(o, t.config.xaxis.labels.style.fontSize)), (e = { width: f.width >= p.width ? f.width : p.width, height: f.height >= p.height ? f.height : p.height }).width * i.length > t.globals.svgWidth - this.dCtx.lgWidthForSideLegends - this.dCtx.yAxisWidth - this.dCtx.gridPad.left - this.dCtx.gridPad.right && t.config.xaxis.labels.rotate !== 0 || t.config.xaxis.labels.rotateAlways) {
              if (!t.globals.isBarHorizontal) {
                t.globals.rotateXLabels = !0;
                var m = function(w) {
                  return g.getTextRects(w, t.config.xaxis.labels.style.fontSize, t.config.xaxis.labels.style.fontFamily, "rotate(".concat(t.config.xaxis.labels.rotate, " 0 0)"), !1);
                };
                f = m(r), r !== o && (p = m(o)), e.height = (f.height > p.height ? f.height : p.height) / 1.5, e.width = f.width > p.width ? f.width : p.width;
              }
            } else
              t.globals.rotateXLabels = !1;
          }
          return t.config.xaxis.labels.show || (e = { width: 0, height: 0 }), { width: e.width, height: e.height };
        } }, { key: "getxAxisGroupLabelsCoords", value: function() {
          var e, t = this.w;
          if (!t.globals.hasXaxisGroups)
            return { width: 0, height: 0 };
          var i, a = ((e = t.config.xaxis.group.style) === null || e === void 0 ? void 0 : e.fontSize) || t.config.xaxis.labels.style.fontSize, s = t.globals.groups.map(function(f) {
            return f.title;
          }), r = M.getLargestStringFromArr(s), o = this.dCtx.dimHelpers.getLargestStringFromMultiArr(r, s), c = new X(this.dCtx.ctx), d = c.getTextRects(r, a), g = d;
          return r !== o && (g = c.getTextRects(o, a)), i = { width: d.width >= g.width ? d.width : g.width, height: d.height >= g.height ? d.height : g.height }, t.config.xaxis.labels.show || (i = { width: 0, height: 0 }), { width: i.width, height: i.height };
        } }, { key: "getxAxisTitleCoords", value: function() {
          var e = this.w, t = 0, i = 0;
          if (e.config.xaxis.title.text !== void 0) {
            var a = new X(this.dCtx.ctx).getTextRects(e.config.xaxis.title.text, e.config.xaxis.title.style.fontSize);
            t = a.width, i = a.height;
          }
          return { width: t, height: i };
        } }, { key: "getxAxisTimeScaleLabelsCoords", value: function() {
          var e, t = this.w;
          this.dCtx.timescaleLabels = t.globals.timescaleLabels.slice();
          var i = this.dCtx.timescaleLabels.map(function(s) {
            return s.value;
          }), a = i.reduce(function(s, r) {
            return s === void 0 ? (console.error("You have possibly supplied invalid Date format. Please supply a valid JavaScript Date"), 0) : s.length > r.length ? s : r;
          }, 0);
          return 1.05 * (e = new X(this.dCtx.ctx).getTextRects(a, t.config.xaxis.labels.style.fontSize)).width * i.length > t.globals.gridWidth && t.config.xaxis.labels.rotate !== 0 && (t.globals.overlappingXLabels = !0), e;
        } }, { key: "additionalPaddingXLabels", value: function(e) {
          var t = this, i = this.w, a = i.globals, s = i.config, r = s.xaxis.type, o = e.width;
          a.skipLastTimelinelabel = !1, a.skipFirstTimelinelabel = !1;
          var c = i.config.yaxis[0].opposite && i.globals.isBarHorizontal, d = function(g, f) {
            s.yaxis.length > 1 && function(p) {
              return a.collapsedSeriesIndices.indexOf(p) !== -1;
            }(f) || function(p) {
              if (t.dCtx.timescaleLabels && t.dCtx.timescaleLabels.length) {
                var m = t.dCtx.timescaleLabels[0], w = t.dCtx.timescaleLabels[t.dCtx.timescaleLabels.length - 1].position + o / 1.75 - t.dCtx.yAxisWidthRight, C = m.position - o / 1.75 + t.dCtx.yAxisWidthLeft, k = i.config.legend.position === "right" && t.dCtx.lgRect.width > 0 ? t.dCtx.lgRect.width : 0;
                w > a.svgWidth - a.translateX - k && (a.skipLastTimelinelabel = !0), C < -(p.show && !p.floating || s.chart.type !== "bar" && s.chart.type !== "candlestick" && s.chart.type !== "rangeBar" && s.chart.type !== "boxPlot" ? 10 : o / 1.75) && (a.skipFirstTimelinelabel = !0);
              } else
                r === "datetime" ? t.dCtx.gridPad.right < o && !a.rotateXLabels && (a.skipLastTimelinelabel = !0) : r !== "datetime" && t.dCtx.gridPad.right < o / 2 - t.dCtx.yAxisWidthRight && !a.rotateXLabels && !i.config.xaxis.labels.trim && (i.config.xaxis.tickPlacement !== "between" || i.globals.isBarHorizontal) && (t.dCtx.xPadRight = o / 2 + 1);
            }(g);
          };
          s.yaxis.forEach(function(g, f) {
            c ? (t.dCtx.gridPad.left < o && (t.dCtx.xPadLeft = o / 2 + 1), t.dCtx.xPadRight = o / 2 + 1) : d(g, f);
          });
        } }]), P;
      }(), Ft = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.dCtx = e;
        }
        return A(P, [{ key: "getyAxisLabelsCoords", value: function() {
          var e = this, t = this.w, i = [], a = 10, s = new ye(this.dCtx.ctx);
          return t.config.yaxis.map(function(r, o) {
            var c = { seriesIndex: o, dataPointIndex: -1, w: t }, d = t.globals.yAxisScale[o], g = 0;
            if (!s.isYAxisHidden(o) && r.labels.show && r.labels.minWidth !== void 0 && (g = r.labels.minWidth), !s.isYAxisHidden(o) && r.labels.show && d.result.length) {
              var f = t.globals.yLabelFormatters[o], p = d.niceMin === Number.MIN_VALUE ? 0 : d.niceMin, m = d.result.reduce(function(x, S) {
                var L, R;
                return ((L = String(f(x, c))) === null || L === void 0 ? void 0 : L.length) > ((R = String(f(S, c))) === null || R === void 0 ? void 0 : R.length) ? x : S;
              }, p), w = m = f(m, c);
              if (m !== void 0 && m.length !== 0 || (m = d.niceMax), t.globals.isBarHorizontal) {
                a = 0;
                var C = t.globals.labels.slice();
                m = M.getLargestStringFromArr(C), m = f(m, { seriesIndex: o, dataPointIndex: -1, w: t }), w = e.dCtx.dimHelpers.getLargestStringFromMultiArr(m, C);
              }
              var k = new X(e.dCtx.ctx), E = "rotate(".concat(r.labels.rotate, " 0 0)"), _ = k.getTextRects(m, r.labels.style.fontSize, r.labels.style.fontFamily, E, !1), h = _;
              m !== w && (h = k.getTextRects(w, r.labels.style.fontSize, r.labels.style.fontFamily, E, !1)), i.push({ width: (g > h.width || g > _.width ? g : h.width > _.width ? h.width : _.width) + a, height: h.height > _.height ? h.height : _.height });
            } else
              i.push({ width: 0, height: 0 });
          }), i;
        } }, { key: "getyAxisTitleCoords", value: function() {
          var e = this, t = this.w, i = [];
          return t.config.yaxis.map(function(a, s) {
            if (a.show && a.title.text !== void 0) {
              var r = new X(e.dCtx.ctx), o = "rotate(".concat(a.title.rotate, " 0 0)"), c = r.getTextRects(a.title.text, a.title.style.fontSize, a.title.style.fontFamily, o, !1);
              i.push({ width: c.width, height: c.height });
            } else
              i.push({ width: 0, height: 0 });
          }), i;
        } }, { key: "getTotalYAxisWidth", value: function() {
          var e = this.w, t = 0, i = 0, a = 0, s = e.globals.yAxisScale.length > 1 ? 10 : 0, r = new ye(this.dCtx.ctx), o = function(c, d) {
            var g = e.config.yaxis[d].floating, f = 0;
            c.width > 0 && !g ? (f = c.width + s, function(p) {
              return e.globals.ignoreYAxisIndexes.indexOf(p) > -1;
            }(d) && (f = f - c.width - s)) : f = g || r.isYAxisHidden(d) ? 0 : 5, e.config.yaxis[d].opposite ? a += f : i += f, t += f;
          };
          return e.globals.yLabelsCoords.map(function(c, d) {
            o(c, d);
          }), e.globals.yTitleCoords.map(function(c, d) {
            o(c, d);
          }), e.globals.isBarHorizontal && !e.config.yaxis[0].floating && (t = e.globals.yLabelsCoords[0].width + e.globals.yTitleCoords[0].width + 15), this.dCtx.yAxisWidthLeft = i, this.dCtx.yAxisWidthRight = a, t;
        } }]), P;
      }(), Dt = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.dCtx = e;
        }
        return A(P, [{ key: "gridPadForColumnsInNumericAxis", value: function(e) {
          var t = this.w;
          if (t.globals.noData || t.globals.allSeriesCollapsed)
            return 0;
          var i = function(g) {
            return g === "bar" || g === "rangeBar" || g === "candlestick" || g === "boxPlot";
          }, a = t.config.chart.type, s = 0, r = i(a) ? t.config.series.length : 1;
          if (t.globals.comboBarCount > 0 && (r = t.globals.comboBarCount), t.globals.collapsedSeries.forEach(function(g) {
            i(g.type) && (r -= 1);
          }), t.config.chart.stacked && (r = 1), (i(a) || t.globals.comboBarCount > 0) && t.globals.isXNumeric && !t.globals.isBarHorizontal && r > 0) {
            var o, c, d = Math.abs(t.globals.initialMaxX - t.globals.initialMinX);
            d <= 3 && (d = t.globals.dataPoints), o = d / e, t.globals.minXDiff && t.globals.minXDiff / o > 0 && (c = t.globals.minXDiff / o), c > e / 2 && (c /= 2), (s = c / r * parseInt(t.config.plotOptions.bar.columnWidth, 10) / 100) < 1 && (s = 1), s = s / (r > 1 ? 1 : 1.5) + 5, t.globals.barPadForNumericAxis = s;
          }
          return s;
        } }, { key: "gridPadFortitleSubtitle", value: function() {
          var e = this, t = this.w, i = t.globals, a = this.dCtx.isSparkline || !t.globals.axisCharts ? 0 : 10;
          ["title", "subtitle"].forEach(function(o) {
            t.config[o].text !== void 0 ? a += t.config[o].margin : a += e.dCtx.isSparkline || !t.globals.axisCharts ? 0 : 5;
          }), !t.config.legend.show || t.config.legend.position !== "bottom" || t.config.legend.floating || t.globals.axisCharts || (a += 10);
          var s = this.dCtx.dimHelpers.getTitleSubtitleCoords("title"), r = this.dCtx.dimHelpers.getTitleSubtitleCoords("subtitle");
          i.gridHeight = i.gridHeight - s.height - r.height - a, i.translateY = i.translateY + s.height + r.height + a;
        } }, { key: "setGridXPosForDualYAxis", value: function(e, t) {
          var i = this.w, a = new ye(this.dCtx.ctx);
          i.config.yaxis.map(function(s, r) {
            i.globals.ignoreYAxisIndexes.indexOf(r) !== -1 || s.floating || a.isYAxisHidden(r) || (s.opposite && (i.globals.translateX = i.globals.translateX - (t[r].width + e[r].width) - parseInt(i.config.yaxis[r].labels.style.fontSize, 10) / 1.2 - 12), i.globals.translateX < 2 && (i.globals.translateX = 2));
          });
        } }]), P;
      }(), st = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.lgRect = {}, this.yAxisWidth = 0, this.yAxisWidthLeft = 0, this.yAxisWidthRight = 0, this.xAxisHeight = 0, this.isSparkline = this.w.config.chart.sparkline.enabled, this.dimHelpers = new at(this), this.dimYAxis = new Ft(this), this.dimXAxis = new ei(this), this.dimGrid = new Dt(this), this.lgWidthForSideLegends = 0, this.gridPad = this.w.config.grid.padding, this.xPadRight = 0, this.xPadLeft = 0;
        }
        return A(P, [{ key: "plotCoords", value: function() {
          var e = this, t = this.w, i = t.globals;
          this.lgRect = this.dimHelpers.getLegendsRect(), this.isSparkline && ((t.config.markers.discrete.length > 0 || t.config.markers.size > 0) && Object.entries(this.gridPad).forEach(function(s) {
            var r = B(s, 2), o = r[0], c = r[1];
            e.gridPad[o] = Math.max(c, e.w.globals.markers.largestSize / 1.5);
          }), this.gridPad.top = Math.max(t.config.stroke.width / 2, this.gridPad.top), this.gridPad.bottom = Math.max(t.config.stroke.width / 2, this.gridPad.bottom)), i.axisCharts ? this.setDimensionsForAxisCharts() : this.setDimensionsForNonAxisCharts(), this.dimGrid.gridPadFortitleSubtitle(), i.gridHeight = i.gridHeight - this.gridPad.top - this.gridPad.bottom, i.gridWidth = i.gridWidth - this.gridPad.left - this.gridPad.right - this.xPadRight - this.xPadLeft;
          var a = this.dimGrid.gridPadForColumnsInNumericAxis(i.gridWidth);
          i.gridWidth = i.gridWidth - 2 * a, i.translateX = i.translateX + this.gridPad.left + this.xPadLeft + (a > 0 ? a + 4 : 0), i.translateY = i.translateY + this.gridPad.top;
        } }, { key: "setDimensionsForAxisCharts", value: function() {
          var e = this, t = this.w, i = t.globals, a = this.dimYAxis.getyAxisLabelsCoords(), s = this.dimYAxis.getyAxisTitleCoords();
          t.globals.yLabelsCoords = [], t.globals.yTitleCoords = [], t.config.yaxis.map(function(m, w) {
            t.globals.yLabelsCoords.push({ width: a[w].width, index: w }), t.globals.yTitleCoords.push({ width: s[w].width, index: w });
          }), this.yAxisWidth = this.dimYAxis.getTotalYAxisWidth();
          var r = this.dimXAxis.getxAxisLabelsCoords(), o = this.dimXAxis.getxAxisGroupLabelsCoords(), c = this.dimXAxis.getxAxisTitleCoords();
          this.conditionalChecksForAxisCoords(r, c, o), i.translateXAxisY = t.globals.rotateXLabels ? this.xAxisHeight / 8 : -4, i.translateXAxisX = t.globals.rotateXLabels && t.globals.isXNumeric && t.config.xaxis.labels.rotate <= -45 ? -this.xAxisWidth / 4 : 0, t.globals.isBarHorizontal && (i.rotateXLabels = !1, i.translateXAxisY = parseInt(t.config.xaxis.labels.style.fontSize, 10) / 1.5 * -1), i.translateXAxisY = i.translateXAxisY + t.config.xaxis.labels.offsetY, i.translateXAxisX = i.translateXAxisX + t.config.xaxis.labels.offsetX;
          var d = this.yAxisWidth, g = this.xAxisHeight;
          i.xAxisLabelsHeight = this.xAxisHeight - c.height, i.xAxisGroupLabelsHeight = i.xAxisLabelsHeight - r.height, i.xAxisLabelsWidth = this.xAxisWidth, i.xAxisHeight = this.xAxisHeight;
          var f = 10;
          (t.config.chart.type === "radar" || this.isSparkline) && (d = 0, g = i.goldenPadding), this.isSparkline && (this.lgRect = { height: 0, width: 0 }), (this.isSparkline || t.config.chart.type === "treemap") && (d = 0, g = 0, f = 0), this.isSparkline || this.dimXAxis.additionalPaddingXLabels(r);
          var p = function() {
            i.translateX = d, i.gridHeight = i.svgHeight - e.lgRect.height - g - (e.isSparkline || t.config.chart.type === "treemap" ? 0 : t.globals.rotateXLabels ? 10 : 15), i.gridWidth = i.svgWidth - d;
          };
          switch (t.config.xaxis.position === "top" && (f = i.xAxisHeight - t.config.xaxis.axisTicks.height - 5), t.config.legend.position) {
            case "bottom":
              i.translateY = f, p();
              break;
            case "top":
              i.translateY = this.lgRect.height + f, p();
              break;
            case "left":
              i.translateY = f, i.translateX = this.lgRect.width + d, i.gridHeight = i.svgHeight - g - 12, i.gridWidth = i.svgWidth - this.lgRect.width - d;
              break;
            case "right":
              i.translateY = f, i.translateX = d, i.gridHeight = i.svgHeight - g - 12, i.gridWidth = i.svgWidth - this.lgRect.width - d - 5;
              break;
            default:
              throw new Error("Legend position not supported");
          }
          this.dimGrid.setGridXPosForDualYAxis(s, a), new _e(this.ctx).setYAxisXPosition(a, s);
        } }, { key: "setDimensionsForNonAxisCharts", value: function() {
          var e = this.w, t = e.globals, i = e.config, a = 0;
          e.config.legend.show && !e.config.legend.floating && (a = 20);
          var s = i.chart.type === "pie" || i.chart.type === "polarArea" || i.chart.type === "donut" ? "pie" : "radialBar", r = i.plotOptions[s].offsetY, o = i.plotOptions[s].offsetX;
          if (!i.legend.show || i.legend.floating)
            return t.gridHeight = t.svgHeight - i.grid.padding.left + i.grid.padding.right, t.gridWidth = t.gridHeight, t.translateY = r, void (t.translateX = o + (t.svgWidth - t.gridWidth) / 2);
          switch (i.legend.position) {
            case "bottom":
              t.gridHeight = t.svgHeight - this.lgRect.height - t.goldenPadding, t.gridWidth = t.svgWidth, t.translateY = r - 10, t.translateX = o + (t.svgWidth - t.gridWidth) / 2;
              break;
            case "top":
              t.gridHeight = t.svgHeight - this.lgRect.height - t.goldenPadding, t.gridWidth = t.svgWidth, t.translateY = this.lgRect.height + r + 10, t.translateX = o + (t.svgWidth - t.gridWidth) / 2;
              break;
            case "left":
              t.gridWidth = t.svgWidth - this.lgRect.width - a, t.gridHeight = i.chart.height !== "auto" ? t.svgHeight : t.gridWidth, t.translateY = r, t.translateX = o + this.lgRect.width + a;
              break;
            case "right":
              t.gridWidth = t.svgWidth - this.lgRect.width - a - 5, t.gridHeight = i.chart.height !== "auto" ? t.svgHeight : t.gridWidth, t.translateY = r, t.translateX = o + 10;
              break;
            default:
              throw new Error("Legend position not supported");
          }
        } }, { key: "conditionalChecksForAxisCoords", value: function(e, t, i) {
          var a = this.w, s = a.globals.hasXaxisGroups ? 2 : 1, r = i.height + e.height + t.height, o = a.globals.isMultiLineX ? 1.2 : a.globals.LINE_HEIGHT_RATIO, c = a.globals.rotateXLabels ? 22 : 10, d = a.globals.rotateXLabels && a.config.legend.position === "bottom" ? 10 : 0;
          this.xAxisHeight = r * o + s * c + d, this.xAxisWidth = e.width, this.xAxisHeight - t.height > a.config.xaxis.labels.maxHeight && (this.xAxisHeight = a.config.xaxis.labels.maxHeight), a.config.xaxis.labels.minHeight && this.xAxisHeight < a.config.xaxis.labels.minHeight && (this.xAxisHeight = a.config.xaxis.labels.minHeight), a.config.xaxis.floating && (this.xAxisHeight = 0);
          var g = 0, f = 0;
          a.config.yaxis.forEach(function(p) {
            g += p.labels.minWidth, f += p.labels.maxWidth;
          }), this.yAxisWidth < g && (this.yAxisWidth = g), this.yAxisWidth > f && (this.yAxisWidth = f);
        } }]), P;
      }(), os = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.lgCtx = e;
        }
        return A(P, [{ key: "getLegendStyles", value: function() {
          var e, t, i, a = document.createElement("style");
          a.setAttribute("type", "text/css");
          var s = ((e = this.lgCtx.ctx) === null || e === void 0 || (t = e.opts) === null || t === void 0 || (i = t.chart) === null || i === void 0 ? void 0 : i.nonce) || this.w.config.chart.nonce;
          s && a.setAttribute("nonce", s);
          var r = document.createTextNode(`	
    	
      .apexcharts-legend {	
        display: flex;	
        overflow: auto;	
        padding: 0 10px;	
      }	
      .apexcharts-legend.apx-legend-position-bottom, .apexcharts-legend.apx-legend-position-top {	
        flex-wrap: wrap	
      }	
      .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {	
        flex-direction: column;	
        bottom: 0;	
      }	
      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left, .apexcharts-legend.apx-legend-position-top.apexcharts-align-left, .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {	
        justify-content: flex-start;	
      }	
      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center, .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {	
        justify-content: center;  	
      }	
      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right, .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {	
        justify-content: flex-end;	
      }	
      .apexcharts-legend-series {	
        cursor: pointer;	
        line-height: normal;	
      }	
      .apexcharts-legend.apx-legend-position-bottom .apexcharts-legend-series, .apexcharts-legend.apx-legend-position-top .apexcharts-legend-series{	
        display: flex;	
        align-items: center;	
      }	
      .apexcharts-legend-text {	
        position: relative;	
        font-size: 14px;	
      }	
      .apexcharts-legend-text *, .apexcharts-legend-marker * {	
        pointer-events: none;	
      }	
      .apexcharts-legend-marker {	
        position: relative;	
        display: inline-block;	
        cursor: pointer;	
        margin-right: 3px;	
        border-style: solid;
      }	
      	
      .apexcharts-legend.apexcharts-align-right .apexcharts-legend-series, .apexcharts-legend.apexcharts-align-left .apexcharts-legend-series{	
        display: inline-block;	
      }	
      .apexcharts-legend-series.apexcharts-no-click {	
        cursor: auto;	
      }	
      .apexcharts-legend .apexcharts-hidden-zero-series, .apexcharts-legend .apexcharts-hidden-null-series {	
        display: none !important;	
      }	
      .apexcharts-inactive-legend {	
        opacity: 0.45;	
      }`);
          return a.appendChild(r), a;
        } }, { key: "getLegendBBox", value: function() {
          var e = this.w.globals.dom.baseEl.querySelector(".apexcharts-legend").getBoundingClientRect(), t = e.width;
          return { clwh: e.height, clww: t };
        } }, { key: "appendToForeignObject", value: function() {
          this.w.globals.dom.elLegendForeign.appendChild(this.getLegendStyles());
        } }, { key: "toggleDataSeries", value: function(e, t) {
          var i = this, a = this.w;
          if (a.globals.axisCharts || a.config.chart.type === "radialBar") {
            a.globals.resized = !0;
            var s = null, r = null;
            a.globals.risingSeries = [], a.globals.axisCharts ? (s = a.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(e, "']")), r = parseInt(s.getAttribute("data:realIndex"), 10)) : (s = a.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(e + 1, "']")), r = parseInt(s.getAttribute("rel"), 10) - 1), t ? [{ cs: a.globals.collapsedSeries, csi: a.globals.collapsedSeriesIndices }, { cs: a.globals.ancillaryCollapsedSeries, csi: a.globals.ancillaryCollapsedSeriesIndices }].forEach(function(g) {
              i.riseCollapsedSeries(g.cs, g.csi, r);
            }) : this.hideSeries({ seriesEl: s, realIndex: r });
          } else {
            var o = a.globals.dom.Paper.select(" .apexcharts-series[rel='".concat(e + 1, "'] path")), c = a.config.chart.type;
            if (c === "pie" || c === "polarArea" || c === "donut") {
              var d = a.config.plotOptions.pie.donut.labels;
              new X(this.lgCtx.ctx).pathMouseDown(o.members[0], null), this.lgCtx.ctx.pie.printDataLabelsInner(o.members[0].node, d);
            }
            o.fire("click");
          }
        } }, { key: "hideSeries", value: function(e) {
          var t = e.seriesEl, i = e.realIndex, a = this.w, s = M.clone(a.config.series);
          if (a.globals.axisCharts) {
            var r = !1;
            if (a.config.yaxis[i] && a.config.yaxis[i].show && a.config.yaxis[i].showAlways && (r = !0, a.globals.ancillaryCollapsedSeriesIndices.indexOf(i) < 0 && (a.globals.ancillaryCollapsedSeries.push({ index: i, data: s[i].data.slice(), type: t.parentNode.className.baseVal.split("-")[1] }), a.globals.ancillaryCollapsedSeriesIndices.push(i))), !r) {
              a.globals.collapsedSeries.push({ index: i, data: s[i].data.slice(), type: t.parentNode.className.baseVal.split("-")[1] }), a.globals.collapsedSeriesIndices.push(i);
              var o = a.globals.risingSeries.indexOf(i);
              a.globals.risingSeries.splice(o, 1);
            }
          } else
            a.globals.collapsedSeries.push({ index: i, data: s[i] }), a.globals.collapsedSeriesIndices.push(i);
          for (var c = t.childNodes, d = 0; d < c.length; d++)
            c[d].classList.contains("apexcharts-series-markers-wrap") && (c[d].classList.contains("apexcharts-hide") ? c[d].classList.remove("apexcharts-hide") : c[d].classList.add("apexcharts-hide"));
          a.globals.allSeriesCollapsed = a.globals.collapsedSeries.length === a.config.series.length, s = this._getSeriesBasedOnCollapsedState(s), this.lgCtx.ctx.updateHelpers._updateSeries(s, a.config.chart.animations.dynamicAnimation.enabled);
        } }, { key: "riseCollapsedSeries", value: function(e, t, i) {
          var a = this.w, s = M.clone(a.config.series);
          if (e.length > 0) {
            for (var r = 0; r < e.length; r++)
              e[r].index === i && (a.globals.axisCharts ? (s[i].data = e[r].data.slice(), e.splice(r, 1), t.splice(r, 1), a.globals.risingSeries.push(i)) : (s[i] = e[r].data, e.splice(r, 1), t.splice(r, 1), a.globals.risingSeries.push(i)));
            s = this._getSeriesBasedOnCollapsedState(s), this.lgCtx.ctx.updateHelpers._updateSeries(s, a.config.chart.animations.dynamicAnimation.enabled);
          }
        } }, { key: "_getSeriesBasedOnCollapsedState", value: function(e) {
          var t = this.w;
          return t.globals.axisCharts ? e.forEach(function(i, a) {
            t.globals.collapsedSeriesIndices.indexOf(a) > -1 && (e[a].data = []);
          }) : e.forEach(function(i, a) {
            t.globals.collapsedSeriesIndices.indexOf(a) > -1 && (e[a] = 0);
          }), e;
        } }]), P;
      }(), Oi = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.onLegendClick = this.onLegendClick.bind(this), this.onLegendHovered = this.onLegendHovered.bind(this), this.isBarsDistributed = this.w.config.chart.type === "bar" && this.w.config.plotOptions.bar.distributed && this.w.config.series.length === 1, this.legendHelpers = new os(this);
        }
        return A(P, [{ key: "init", value: function() {
          var e = this.w, t = e.globals, i = e.config;
          if ((i.legend.showForSingleSeries && t.series.length === 1 || this.isBarsDistributed || t.series.length > 1 || !t.axisCharts) && i.legend.show) {
            for (; t.dom.elLegendWrap.firstChild; )
              t.dom.elLegendWrap.removeChild(t.dom.elLegendWrap.firstChild);
            this.drawLegends(), M.isIE11() ? document.getElementsByTagName("head")[0].appendChild(this.legendHelpers.getLegendStyles()) : this.legendHelpers.appendToForeignObject(), i.legend.position === "bottom" || i.legend.position === "top" ? this.legendAlignHorizontal() : i.legend.position !== "right" && i.legend.position !== "left" || this.legendAlignVertical();
          }
        } }, { key: "drawLegends", value: function() {
          var e = this, t = this.w, i = t.config.legend.fontFamily, a = t.globals.seriesNames, s = t.globals.colors.slice();
          if (t.config.chart.type === "heatmap") {
            var r = t.config.plotOptions.heatmap.colorScale.ranges;
            a = r.map(function(U) {
              return U.name ? U.name : U.from + " - " + U.to;
            }), s = r.map(function(U) {
              return U.color;
            });
          } else
            this.isBarsDistributed && (a = t.globals.labels.slice());
          t.config.legend.customLegendItems.length && (a = t.config.legend.customLegendItems);
          for (var o = t.globals.legendFormatter, c = t.config.legend.inverseOrder, d = c ? a.length - 1 : 0; c ? d >= 0 : d <= a.length - 1; c ? d-- : d++) {
            var g, f = o(a[d], { seriesIndex: d, w: t }), p = !1, m = !1;
            if (t.globals.collapsedSeries.length > 0)
              for (var w = 0; w < t.globals.collapsedSeries.length; w++)
                t.globals.collapsedSeries[w].index === d && (p = !0);
            if (t.globals.ancillaryCollapsedSeriesIndices.length > 0)
              for (var C = 0; C < t.globals.ancillaryCollapsedSeriesIndices.length; C++)
                t.globals.ancillaryCollapsedSeriesIndices[C] === d && (m = !0);
            var k = document.createElement("span");
            k.classList.add("apexcharts-legend-marker");
            var E = t.config.legend.markers.offsetX, _ = t.config.legend.markers.offsetY, h = t.config.legend.markers.height, x = t.config.legend.markers.width, S = t.config.legend.markers.strokeWidth, L = t.config.legend.markers.strokeColor, R = t.config.legend.markers.radius, O = k.style;
            O.background = s[d], O.color = s[d], O.setProperty("background", s[d], "important"), t.config.legend.markers.fillColors && t.config.legend.markers.fillColors[d] && (O.background = t.config.legend.markers.fillColors[d]), t.globals.seriesColors[d] !== void 0 && (O.background = t.globals.seriesColors[d], O.color = t.globals.seriesColors[d]), O.height = Array.isArray(h) ? parseFloat(h[d]) + "px" : parseFloat(h) + "px", O.width = Array.isArray(x) ? parseFloat(x[d]) + "px" : parseFloat(x) + "px", O.left = (Array.isArray(E) ? parseFloat(E[d]) : parseFloat(E)) + "px", O.top = (Array.isArray(_) ? parseFloat(_[d]) : parseFloat(_)) + "px", O.borderWidth = Array.isArray(S) ? S[d] : S, O.borderColor = Array.isArray(L) ? L[d] : L, O.borderRadius = Array.isArray(R) ? parseFloat(R[d]) + "px" : parseFloat(R) + "px", t.config.legend.markers.customHTML && (Array.isArray(t.config.legend.markers.customHTML) ? t.config.legend.markers.customHTML[d] && (k.innerHTML = t.config.legend.markers.customHTML[d]()) : k.innerHTML = t.config.legend.markers.customHTML()), X.setAttrs(k, { rel: d + 1, "data:collapsed": p || m }), (p || m) && k.classList.add("apexcharts-inactive-legend");
            var Y = document.createElement("div"), N = document.createElement("span");
            N.classList.add("apexcharts-legend-text"), N.innerHTML = Array.isArray(f) ? f.join(" ") : f;
            var q = t.config.legend.labels.useSeriesColors ? t.globals.colors[d] : Array.isArray(t.config.legend.labels.colors) ? (g = t.config.legend.labels.colors) === null || g === void 0 ? void 0 : g[d] : t.config.legend.labels.colors;
            q || (q = t.config.chart.foreColor), N.style.color = q, N.style.fontSize = parseFloat(t.config.legend.fontSize) + "px", N.style.fontWeight = t.config.legend.fontWeight, N.style.fontFamily = i || t.config.chart.fontFamily, X.setAttrs(N, { rel: d + 1, i: d, "data:default-text": encodeURIComponent(f), "data:collapsed": p || m }), Y.appendChild(k), Y.appendChild(N);
            var Z = new $(this.ctx);
            t.config.legend.showForZeroSeries || Z.getSeriesTotalByIndex(d) === 0 && Z.seriesHaveSameValues(d) && !Z.isSeriesNull(d) && t.globals.collapsedSeriesIndices.indexOf(d) === -1 && t.globals.ancillaryCollapsedSeriesIndices.indexOf(d) === -1 && Y.classList.add("apexcharts-hidden-zero-series"), t.config.legend.showForNullSeries || Z.isSeriesNull(d) && t.globals.collapsedSeriesIndices.indexOf(d) === -1 && t.globals.ancillaryCollapsedSeriesIndices.indexOf(d) === -1 && Y.classList.add("apexcharts-hidden-null-series"), t.globals.dom.elLegendWrap.appendChild(Y), t.globals.dom.elLegendWrap.classList.add("apexcharts-align-".concat(t.config.legend.horizontalAlign)), t.globals.dom.elLegendWrap.classList.add("apx-legend-position-" + t.config.legend.position), Y.classList.add("apexcharts-legend-series"), Y.style.margin = "".concat(t.config.legend.itemMargin.vertical, "px ").concat(t.config.legend.itemMargin.horizontal, "px"), t.globals.dom.elLegendWrap.style.width = t.config.legend.width ? t.config.legend.width + "px" : "", t.globals.dom.elLegendWrap.style.height = t.config.legend.height ? t.config.legend.height + "px" : "", X.setAttrs(Y, { rel: d + 1, seriesName: M.escapeString(a[d]), "data:collapsed": p || m }), (p || m) && Y.classList.add("apexcharts-inactive-legend"), t.config.legend.onItemClick.toggleDataSeries || Y.classList.add("apexcharts-no-click");
          }
          t.globals.dom.elWrap.addEventListener("click", e.onLegendClick, !0), t.config.legend.onItemHover.highlightDataSeries && t.config.legend.customLegendItems.length === 0 && (t.globals.dom.elWrap.addEventListener("mousemove", e.onLegendHovered, !0), t.globals.dom.elWrap.addEventListener("mouseout", e.onLegendHovered, !0));
        } }, { key: "setLegendWrapXY", value: function(e, t) {
          var i = this.w, a = i.globals.dom.elLegendWrap, s = a.getBoundingClientRect(), r = 0, o = 0;
          if (i.config.legend.position === "bottom")
            o += i.globals.svgHeight - s.height / 2;
          else if (i.config.legend.position === "top") {
            var c = new st(this.ctx), d = c.dimHelpers.getTitleSubtitleCoords("title").height, g = c.dimHelpers.getTitleSubtitleCoords("subtitle").height;
            o = o + (d > 0 ? d - 10 : 0) + (g > 0 ? g - 10 : 0);
          }
          a.style.position = "absolute", r = r + e + i.config.legend.offsetX, o = o + t + i.config.legend.offsetY, a.style.left = r + "px", a.style.top = o + "px", i.config.legend.position === "bottom" ? (a.style.top = "auto", a.style.bottom = 5 - i.config.legend.offsetY + "px") : i.config.legend.position === "right" && (a.style.left = "auto", a.style.right = 25 + i.config.legend.offsetX + "px"), ["width", "height"].forEach(function(f) {
            a.style[f] && (a.style[f] = parseInt(i.config.legend[f], 10) + "px");
          });
        } }, { key: "legendAlignHorizontal", value: function() {
          var e = this.w;
          e.globals.dom.elLegendWrap.style.right = 0;
          var t = this.legendHelpers.getLegendBBox(), i = new st(this.ctx), a = i.dimHelpers.getTitleSubtitleCoords("title"), s = i.dimHelpers.getTitleSubtitleCoords("subtitle"), r = 0;
          e.config.legend.position === "bottom" ? r = -t.clwh / 1.8 : e.config.legend.position === "top" && (r = a.height + s.height + e.config.title.margin + e.config.subtitle.margin - 10), this.setLegendWrapXY(20, r);
        } }, { key: "legendAlignVertical", value: function() {
          var e = this.w, t = this.legendHelpers.getLegendBBox(), i = 0;
          e.config.legend.position === "left" && (i = 20), e.config.legend.position === "right" && (i = e.globals.svgWidth - t.clww - 10), this.setLegendWrapXY(i, 20);
        } }, { key: "onLegendHovered", value: function(e) {
          var t = this.w, i = e.target.classList.contains("apexcharts-legend-series") || e.target.classList.contains("apexcharts-legend-text") || e.target.classList.contains("apexcharts-legend-marker");
          if (t.config.chart.type === "heatmap" || this.isBarsDistributed) {
            if (i) {
              var a = parseInt(e.target.getAttribute("rel"), 10) - 1;
              this.ctx.events.fireEvent("legendHover", [this.ctx, a, this.w]), new de(this.ctx).highlightRangeInSeries(e, e.target);
            }
          } else
            !e.target.classList.contains("apexcharts-inactive-legend") && i && new de(this.ctx).toggleSeriesOnHover(e, e.target);
        } }, { key: "onLegendClick", value: function(e) {
          var t = this.w;
          if (!t.config.legend.customLegendItems.length && (e.target.classList.contains("apexcharts-legend-series") || e.target.classList.contains("apexcharts-legend-text") || e.target.classList.contains("apexcharts-legend-marker"))) {
            var i = parseInt(e.target.getAttribute("rel"), 10) - 1, a = e.target.getAttribute("data:collapsed") === "true", s = this.w.config.chart.events.legendClick;
            typeof s == "function" && s(this.ctx, i, this.w), this.ctx.events.fireEvent("legendClick", [this.ctx, i, this.w]);
            var r = this.w.config.legend.markers.onClick;
            typeof r == "function" && e.target.classList.contains("apexcharts-legend-marker") && (r(this.ctx, i, this.w), this.ctx.events.fireEvent("legendMarkerClick", [this.ctx, i, this.w])), t.config.chart.type !== "treemap" && t.config.chart.type !== "heatmap" && !this.isBarsDistributed && t.config.legend.onItemClick.toggleDataSeries && this.legendHelpers.toggleDataSeries(i, a);
          }
        } }]), P;
      }(), zi = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
          var t = this.w;
          this.ev = this.w.config.chart.events, this.selectedClass = "apexcharts-selected", this.localeValues = this.w.globals.locale.toolbar, this.minX = t.globals.minX, this.maxX = t.globals.maxX;
        }
        return A(P, [{ key: "createToolbar", value: function() {
          var e = this, t = this.w, i = function() {
            return document.createElement("div");
          }, a = i();
          if (a.setAttribute("class", "apexcharts-toolbar"), a.style.top = t.config.chart.toolbar.offsetY + "px", a.style.right = 3 - t.config.chart.toolbar.offsetX + "px", t.globals.dom.elWrap.appendChild(a), this.elZoom = i(), this.elZoomIn = i(), this.elZoomOut = i(), this.elPan = i(), this.elSelection = i(), this.elZoomReset = i(), this.elMenuIcon = i(), this.elMenu = i(), this.elCustomIcons = [], this.t = t.config.chart.toolbar.tools, Array.isArray(this.t.customIcons))
            for (var s = 0; s < this.t.customIcons.length; s++)
              this.elCustomIcons.push(i());
          var r = [], o = function(f, p, m) {
            var w = f.toLowerCase();
            e.t[w] && t.config.chart.zoom.enabled && r.push({ el: p, icon: typeof e.t[w] == "string" ? e.t[w] : m, title: e.localeValues[f], class: "apexcharts-".concat(w, "-icon") });
          };
          o("zoomIn", this.elZoomIn, `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <path d="M0 0h24v24H0z" fill="none"/>
    <path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
</svg>
`), o("zoomOut", this.elZoomOut, `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <path d="M0 0h24v24H0z" fill="none"/>
    <path d="M7 11v2h10v-2H7zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
</svg>
`);
          var c = function(f) {
            e.t[f] && t.config.chart[f].enabled && r.push({ el: f === "zoom" ? e.elZoom : e.elSelection, icon: typeof e.t[f] == "string" ? e.t[f] : f === "zoom" ? `<svg xmlns="http://www.w3.org/2000/svg" fill="#000000" height="24" viewBox="0 0 24 24" width="24">
    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M12 10h-2v2H9v-2H7V9h2V7h1v2h2v1z"/>
</svg>` : `<svg fill="#6E8192" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
    <path d="M0 0h24v24H0z" fill="none"/>
    <path d="M3 5h2V3c-1.1 0-2 .9-2 2zm0 8h2v-2H3v2zm4 8h2v-2H7v2zM3 9h2V7H3v2zm10-6h-2v2h2V3zm6 0v2h2c0-1.1-.9-2-2-2zM5 21v-2H3c0 1.1.9 2 2 2zm-2-4h2v-2H3v2zM9 3H7v2h2V3zm2 18h2v-2h-2v2zm8-8h2v-2h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2zm0-12h2V7h-2v2zm0 8h2v-2h-2v2zm-4 4h2v-2h-2v2zm0-16h2V3h-2v2z"/>
</svg>`, title: e.localeValues[f === "zoom" ? "selectionZoom" : "selection"], class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-".concat(f, "-icon") });
          };
          c("zoom"), c("selection"), this.t.pan && t.config.chart.zoom.enabled && r.push({ el: this.elPan, icon: typeof this.t.pan == "string" ? this.t.pan : `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" height="24" viewBox="0 0 24 24" width="24">
    <defs>
        <path d="M0 0h24v24H0z" id="a"/>
    </defs>
    <clipPath id="b">
        <use overflow="visible" xlink:href="#a"/>
    </clipPath>
    <path clip-path="url(#b)" d="M23 5.5V20c0 2.2-1.8 4-4 4h-7.3c-1.08 0-2.1-.43-2.85-1.19L1 14.83s1.26-1.23 1.3-1.25c.22-.19.49-.29.79-.29.22 0 .42.06.6.16.04.01 4.31 2.46 4.31 2.46V4c0-.83.67-1.5 1.5-1.5S11 3.17 11 4v7h1V1.5c0-.83.67-1.5 1.5-1.5S15 .67 15 1.5V11h1V2.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5V11h1V5.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5z"/>
</svg>`, title: this.localeValues.pan, class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-pan-icon" }), o("reset", this.elZoomReset, `<svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
    <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
    <path d="M0 0h24v24H0z" fill="none"/>
</svg>`), this.t.download && r.push({ el: this.elMenuIcon, icon: typeof this.t.download == "string" ? this.t.download : '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0V0z"/><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>', title: this.localeValues.menu, class: "apexcharts-menu-icon" });
          for (var d = 0; d < this.elCustomIcons.length; d++)
            r.push({ el: this.elCustomIcons[d], icon: this.t.customIcons[d].icon, title: this.t.customIcons[d].title, index: this.t.customIcons[d].index, class: "apexcharts-toolbar-custom-icon " + this.t.customIcons[d].class });
          r.forEach(function(f, p) {
            f.index && M.moveIndexInArray(r, p, f.index);
          });
          for (var g = 0; g < r.length; g++)
            X.setAttrs(r[g].el, { class: r[g].class, title: r[g].title }), r[g].el.innerHTML = r[g].icon, a.appendChild(r[g].el);
          this._createHamburgerMenu(a), t.globals.zoomEnabled ? this.elZoom.classList.add(this.selectedClass) : t.globals.panEnabled ? this.elPan.classList.add(this.selectedClass) : t.globals.selectionEnabled && this.elSelection.classList.add(this.selectedClass), this.addToolbarEventListeners();
        } }, { key: "_createHamburgerMenu", value: function(e) {
          this.elMenuItems = [], e.appendChild(this.elMenu), X.setAttrs(this.elMenu, { class: "apexcharts-menu" });
          for (var t = [{ name: "exportSVG", title: this.localeValues.exportToSVG }, { name: "exportPNG", title: this.localeValues.exportToPNG }, { name: "exportCSV", title: this.localeValues.exportToCSV }], i = 0; i < t.length; i++)
            this.elMenuItems.push(document.createElement("div")), this.elMenuItems[i].innerHTML = t[i].title, X.setAttrs(this.elMenuItems[i], { class: "apexcharts-menu-item ".concat(t[i].name), title: t[i].title }), this.elMenu.appendChild(this.elMenuItems[i]);
        } }, { key: "addToolbarEventListeners", value: function() {
          var e = this;
          this.elZoomReset.addEventListener("click", this.handleZoomReset.bind(this)), this.elSelection.addEventListener("click", this.toggleZoomSelection.bind(this, "selection")), this.elZoom.addEventListener("click", this.toggleZoomSelection.bind(this, "zoom")), this.elZoomIn.addEventListener("click", this.handleZoomIn.bind(this)), this.elZoomOut.addEventListener("click", this.handleZoomOut.bind(this)), this.elPan.addEventListener("click", this.togglePanning.bind(this)), this.elMenuIcon.addEventListener("click", this.toggleMenu.bind(this)), this.elMenuItems.forEach(function(i) {
            i.classList.contains("exportSVG") ? i.addEventListener("click", e.handleDownload.bind(e, "svg")) : i.classList.contains("exportPNG") ? i.addEventListener("click", e.handleDownload.bind(e, "png")) : i.classList.contains("exportCSV") && i.addEventListener("click", e.handleDownload.bind(e, "csv"));
          });
          for (var t = 0; t < this.t.customIcons.length; t++)
            this.elCustomIcons[t].addEventListener("click", this.t.customIcons[t].click.bind(this, this.ctx, this.ctx.w));
        } }, { key: "toggleZoomSelection", value: function(e) {
          this.ctx.getSyncedCharts().forEach(function(t) {
            t.ctx.toolbar.toggleOtherControls();
            var i = e === "selection" ? t.ctx.toolbar.elSelection : t.ctx.toolbar.elZoom, a = e === "selection" ? "selectionEnabled" : "zoomEnabled";
            t.w.globals[a] = !t.w.globals[a], i.classList.contains(t.ctx.toolbar.selectedClass) ? i.classList.remove(t.ctx.toolbar.selectedClass) : i.classList.add(t.ctx.toolbar.selectedClass);
          });
        } }, { key: "getToolbarIconsReference", value: function() {
          var e = this.w;
          this.elZoom || (this.elZoom = e.globals.dom.baseEl.querySelector(".apexcharts-zoom-icon")), this.elPan || (this.elPan = e.globals.dom.baseEl.querySelector(".apexcharts-pan-icon")), this.elSelection || (this.elSelection = e.globals.dom.baseEl.querySelector(".apexcharts-selection-icon"));
        } }, { key: "enableZoomPanFromToolbar", value: function(e) {
          this.toggleOtherControls(), e === "pan" ? this.w.globals.panEnabled = !0 : this.w.globals.zoomEnabled = !0;
          var t = e === "pan" ? this.elPan : this.elZoom, i = e === "pan" ? this.elZoom : this.elPan;
          t && t.classList.add(this.selectedClass), i && i.classList.remove(this.selectedClass);
        } }, { key: "togglePanning", value: function() {
          this.ctx.getSyncedCharts().forEach(function(e) {
            e.ctx.toolbar.toggleOtherControls(), e.w.globals.panEnabled = !e.w.globals.panEnabled, e.ctx.toolbar.elPan.classList.contains(e.ctx.toolbar.selectedClass) ? e.ctx.toolbar.elPan.classList.remove(e.ctx.toolbar.selectedClass) : e.ctx.toolbar.elPan.classList.add(e.ctx.toolbar.selectedClass);
          });
        } }, { key: "toggleOtherControls", value: function() {
          var e = this, t = this.w;
          t.globals.panEnabled = !1, t.globals.zoomEnabled = !1, t.globals.selectionEnabled = !1, this.getToolbarIconsReference(), [this.elPan, this.elSelection, this.elZoom].forEach(function(i) {
            i && i.classList.remove(e.selectedClass);
          });
        } }, { key: "handleZoomIn", value: function() {
          var e = this.w;
          e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY);
          var t = (this.minX + this.maxX) / 2, i = (this.minX + t) / 2, a = (this.maxX + t) / 2, s = this._getNewMinXMaxX(i, a);
          e.globals.disableZoomIn || this.zoomUpdateOptions(s.minX, s.maxX);
        } }, { key: "handleZoomOut", value: function() {
          var e = this.w;
          if (e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY), !(e.config.xaxis.type === "datetime" && new Date(this.minX).getUTCFullYear() < 1e3)) {
            var t = (this.minX + this.maxX) / 2, i = this.minX - (t - this.minX), a = this.maxX - (t - this.maxX), s = this._getNewMinXMaxX(i, a);
            e.globals.disableZoomOut || this.zoomUpdateOptions(s.minX, s.maxX);
          }
        } }, { key: "_getNewMinXMaxX", value: function(e, t) {
          var i = this.w.config.xaxis.convertedCatToNumeric;
          return { minX: i ? Math.floor(e) : e, maxX: i ? Math.floor(t) : t };
        } }, { key: "zoomUpdateOptions", value: function(e, t) {
          var i = this.w;
          if (e !== void 0 || t !== void 0) {
            if (!(i.config.xaxis.convertedCatToNumeric && (e < 1 && (e = 1, t = i.globals.dataPoints), t - e < 2))) {
              var a = { min: e, max: t }, s = this.getBeforeZoomRange(a);
              s && (a = s.xaxis);
              var r = { xaxis: a }, o = M.clone(i.globals.initialConfig.yaxis);
              i.config.chart.zoom.autoScaleYaxis && (o = new ze(this.ctx).autoScaleY(this.ctx, o, { xaxis: a })), i.config.chart.group || (r.yaxis = o), this.w.globals.zoomed = !0, this.ctx.updateHelpers._updateOptions(r, !1, this.w.config.chart.animations.dynamicAnimation.enabled), this.zoomCallback(a, o);
            }
          } else
            this.handleZoomReset();
        } }, { key: "zoomCallback", value: function(e, t) {
          typeof this.ev.zoomed == "function" && this.ev.zoomed(this.ctx, { xaxis: e, yaxis: t });
        } }, { key: "getBeforeZoomRange", value: function(e, t) {
          var i = null;
          return typeof this.ev.beforeZoom == "function" && (i = this.ev.beforeZoom(this, { xaxis: e, yaxis: t })), i;
        } }, { key: "toggleMenu", value: function() {
          var e = this;
          window.setTimeout(function() {
            e.elMenu.classList.contains("apexcharts-menu-open") ? e.elMenu.classList.remove("apexcharts-menu-open") : e.elMenu.classList.add("apexcharts-menu-open");
          }, 0);
        } }, { key: "handleDownload", value: function(e) {
          var t = this.w, i = new Se(this.ctx);
          switch (e) {
            case "svg":
              i.exportToSVG(this.ctx);
              break;
            case "png":
              i.exportToPng(this.ctx);
              break;
            case "csv":
              i.exportToCSV({ series: t.config.series, columnDelimiter: t.config.chart.toolbar.export.csv.columnDelimiter });
          }
        } }, { key: "handleZoomReset", value: function(e) {
          this.ctx.getSyncedCharts().forEach(function(t) {
            var i = t.w;
            if (i.globals.lastXAxis.min = i.globals.initialConfig.xaxis.min, i.globals.lastXAxis.max = i.globals.initialConfig.xaxis.max, t.updateHelpers.revertDefaultAxisMinMax(), typeof i.config.chart.events.beforeResetZoom == "function") {
              var a = i.config.chart.events.beforeResetZoom(t, i);
              a && t.updateHelpers.revertDefaultAxisMinMax(a);
            }
            typeof i.config.chart.events.zoomed == "function" && t.ctx.toolbar.zoomCallback({ min: i.config.xaxis.min, max: i.config.xaxis.max }), i.globals.zoomed = !1;
            var s = t.ctx.series.emptyCollapsedSeries(M.clone(i.globals.initialSeries));
            t.updateHelpers._updateSeries(s, i.config.chart.animations.dynamicAnimation.enabled);
          });
        } }, { key: "destroy", value: function() {
          this.elZoom = null, this.elZoomIn = null, this.elZoomOut = null, this.elPan = null, this.elSelection = null, this.elZoomReset = null, this.elMenuIcon = null;
        } }]), P;
      }(), ls = function(P) {
        z(t, P);
        var e = W(t);
        function t(i) {
          var a;
          return y(this, t), (a = e.call(this, i)).ctx = i, a.w = i.w, a.dragged = !1, a.graphics = new X(a.ctx), a.eventList = ["mousedown", "mouseleave", "mousemove", "touchstart", "touchmove", "mouseup", "touchend"], a.clientX = 0, a.clientY = 0, a.startX = 0, a.endX = 0, a.dragX = 0, a.startY = 0, a.endY = 0, a.dragY = 0, a.moveDirection = "none", a;
        }
        return A(t, [{ key: "init", value: function(i) {
          var a = this, s = i.xyRatios, r = this.w, o = this;
          this.xyRatios = s, this.zoomRect = this.graphics.drawRect(0, 0, 0, 0), this.selectionRect = this.graphics.drawRect(0, 0, 0, 0), this.gridRect = r.globals.dom.baseEl.querySelector(".apexcharts-grid"), this.zoomRect.node.classList.add("apexcharts-zoom-rect"), this.selectionRect.node.classList.add("apexcharts-selection-rect"), r.globals.dom.elGraphical.add(this.zoomRect), r.globals.dom.elGraphical.add(this.selectionRect), r.config.chart.selection.type === "x" ? this.slDraggableRect = this.selectionRect.draggable({ minX: 0, minY: 0, maxX: r.globals.gridWidth, maxY: r.globals.gridHeight }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : r.config.chart.selection.type === "y" ? this.slDraggableRect = this.selectionRect.draggable({ minX: 0, maxX: r.globals.gridWidth }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : this.slDraggableRect = this.selectionRect.draggable().on("dragmove", this.selectionDragging.bind(this, "dragging")), this.preselectedSelection(), this.hoverArea = r.globals.dom.baseEl.querySelector("".concat(r.globals.chartClass, " .apexcharts-svg")), this.hoverArea.classList.add("apexcharts-zoomable"), this.eventList.forEach(function(c) {
            a.hoverArea.addEventListener(c, o.svgMouseEvents.bind(o, s), { capture: !1, passive: !0 });
          });
        } }, { key: "destroy", value: function() {
          this.slDraggableRect && (this.slDraggableRect.draggable(!1), this.slDraggableRect.off(), this.selectionRect.off()), this.selectionRect = null, this.zoomRect = null, this.gridRect = null;
        } }, { key: "svgMouseEvents", value: function(i, a) {
          var s = this.w, r = this, o = this.ctx.toolbar, c = s.globals.zoomEnabled ? s.config.chart.zoom.type : s.config.chart.selection.type, d = s.config.chart.toolbar.autoSelected;
          if (a.shiftKey ? (this.shiftWasPressed = !0, o.enableZoomPanFromToolbar(d === "pan" ? "zoom" : "pan")) : this.shiftWasPressed && (o.enableZoomPanFromToolbar(d), this.shiftWasPressed = !1), a.target) {
            var g, f = a.target.classList;
            if (a.target.parentNode && a.target.parentNode !== null && (g = a.target.parentNode.classList), !(f.contains("apexcharts-selection-rect") || f.contains("apexcharts-legend-marker") || f.contains("apexcharts-legend-text") || g && g.contains("apexcharts-toolbar"))) {
              if (r.clientX = a.type === "touchmove" || a.type === "touchstart" ? a.touches[0].clientX : a.type === "touchend" ? a.changedTouches[0].clientX : a.clientX, r.clientY = a.type === "touchmove" || a.type === "touchstart" ? a.touches[0].clientY : a.type === "touchend" ? a.changedTouches[0].clientY : a.clientY, a.type === "mousedown" && a.which === 1) {
                var p = r.gridRect.getBoundingClientRect();
                r.startX = r.clientX - p.left, r.startY = r.clientY - p.top, r.dragged = !1, r.w.globals.mousedown = !0;
              }
              if ((a.type === "mousemove" && a.which === 1 || a.type === "touchmove") && (r.dragged = !0, s.globals.panEnabled ? (s.globals.selection = null, r.w.globals.mousedown && r.panDragging({ context: r, zoomtype: c, xyRatios: i })) : (r.w.globals.mousedown && s.globals.zoomEnabled || r.w.globals.mousedown && s.globals.selectionEnabled) && (r.selection = r.selectionDrawing({ context: r, zoomtype: c }))), a.type === "mouseup" || a.type === "touchend" || a.type === "mouseleave") {
                var m = r.gridRect.getBoundingClientRect();
                r.w.globals.mousedown && (r.endX = r.clientX - m.left, r.endY = r.clientY - m.top, r.dragX = Math.abs(r.endX - r.startX), r.dragY = Math.abs(r.endY - r.startY), (s.globals.zoomEnabled || s.globals.selectionEnabled) && r.selectionDrawn({ context: r, zoomtype: c }), s.globals.panEnabled && s.config.xaxis.convertedCatToNumeric && r.delayedPanScrolled()), s.globals.zoomEnabled && r.hideSelectionRect(this.selectionRect), r.dragged = !1, r.w.globals.mousedown = !1;
              }
              this.makeSelectionRectDraggable();
            }
          }
        } }, { key: "makeSelectionRectDraggable", value: function() {
          var i = this.w;
          if (this.selectionRect) {
            var a = this.selectionRect.node.getBoundingClientRect();
            a.width > 0 && a.height > 0 && this.slDraggableRect.selectize({ points: "l, r", pointSize: 8, pointType: "rect" }).resize({ constraint: { minX: 0, minY: 0, maxX: i.globals.gridWidth, maxY: i.globals.gridHeight } }).on("resizing", this.selectionDragging.bind(this, "resizing"));
          }
        } }, { key: "preselectedSelection", value: function() {
          var i = this.w, a = this.xyRatios;
          if (!i.globals.zoomEnabled) {
            if (i.globals.selection !== void 0 && i.globals.selection !== null)
              this.drawSelectionRect(i.globals.selection);
            else if (i.config.chart.selection.xaxis.min !== void 0 && i.config.chart.selection.xaxis.max !== void 0) {
              var s = (i.config.chart.selection.xaxis.min - i.globals.minX) / a.xRatio, r = i.globals.gridWidth - (i.globals.maxX - i.config.chart.selection.xaxis.max) / a.xRatio - s;
              i.globals.isRangeBar && (s = (i.config.chart.selection.xaxis.min - i.globals.yAxisScale[0].niceMin) / a.invertedYRatio, r = (i.config.chart.selection.xaxis.max - i.config.chart.selection.xaxis.min) / a.invertedYRatio);
              var o = { x: s, y: 0, width: r, height: i.globals.gridHeight, translateX: 0, translateY: 0, selectionEnabled: !0 };
              this.drawSelectionRect(o), this.makeSelectionRectDraggable(), typeof i.config.chart.events.selection == "function" && i.config.chart.events.selection(this.ctx, { xaxis: { min: i.config.chart.selection.xaxis.min, max: i.config.chart.selection.xaxis.max }, yaxis: {} });
            }
          }
        } }, { key: "drawSelectionRect", value: function(i) {
          var a = i.x, s = i.y, r = i.width, o = i.height, c = i.translateX, d = c === void 0 ? 0 : c, g = i.translateY, f = g === void 0 ? 0 : g, p = this.w, m = this.zoomRect, w = this.selectionRect;
          if (this.dragged || p.globals.selection !== null) {
            var C = { transform: "translate(" + d + ", " + f + ")" };
            p.globals.zoomEnabled && this.dragged && (r < 0 && (r = 1), m.attr({ x: a, y: s, width: r, height: o, fill: p.config.chart.zoom.zoomedArea.fill.color, "fill-opacity": p.config.chart.zoom.zoomedArea.fill.opacity, stroke: p.config.chart.zoom.zoomedArea.stroke.color, "stroke-width": p.config.chart.zoom.zoomedArea.stroke.width, "stroke-opacity": p.config.chart.zoom.zoomedArea.stroke.opacity }), X.setAttrs(m.node, C)), p.globals.selectionEnabled && (w.attr({ x: a, y: s, width: r > 0 ? r : 0, height: o > 0 ? o : 0, fill: p.config.chart.selection.fill.color, "fill-opacity": p.config.chart.selection.fill.opacity, stroke: p.config.chart.selection.stroke.color, "stroke-width": p.config.chart.selection.stroke.width, "stroke-dasharray": p.config.chart.selection.stroke.dashArray, "stroke-opacity": p.config.chart.selection.stroke.opacity }), X.setAttrs(w.node, C));
          }
        } }, { key: "hideSelectionRect", value: function(i) {
          i && i.attr({ x: 0, y: 0, width: 0, height: 0 });
        } }, { key: "selectionDrawing", value: function(i) {
          var a = i.context, s = i.zoomtype, r = this.w, o = a, c = this.gridRect.getBoundingClientRect(), d = o.startX - 1, g = o.startY, f = !1, p = !1, m = o.clientX - c.left - d, w = o.clientY - c.top - g, C = {};
          return Math.abs(m + d) > r.globals.gridWidth ? m = r.globals.gridWidth - d : o.clientX - c.left < 0 && (m = d), d > o.clientX - c.left && (f = !0, m = Math.abs(m)), g > o.clientY - c.top && (p = !0, w = Math.abs(w)), C = s === "x" ? { x: f ? d - m : d, y: 0, width: m, height: r.globals.gridHeight } : s === "y" ? { x: 0, y: p ? g - w : g, width: r.globals.gridWidth, height: w } : { x: f ? d - m : d, y: p ? g - w : g, width: m, height: w }, o.drawSelectionRect(C), o.selectionDragging("resizing"), C;
        } }, { key: "selectionDragging", value: function(i, a) {
          var s = this, r = this.w, o = this.xyRatios, c = this.selectionRect, d = 0;
          i === "resizing" && (d = 30);
          var g = function(p) {
            return parseFloat(c.node.getAttribute(p));
          }, f = { x: g("x"), y: g("y"), width: g("width"), height: g("height") };
          r.globals.selection = f, typeof r.config.chart.events.selection == "function" && r.globals.selectionEnabled && (clearTimeout(this.w.globals.selectionResizeTimer), this.w.globals.selectionResizeTimer = window.setTimeout(function() {
            var p, m, w, C, k = s.gridRect.getBoundingClientRect(), E = c.node.getBoundingClientRect();
            r.globals.isRangeBar ? (p = r.globals.yAxisScale[0].niceMin + (E.left - k.left) * o.invertedYRatio, m = r.globals.yAxisScale[0].niceMin + (E.right - k.left) * o.invertedYRatio, w = 0, C = 1) : (p = r.globals.xAxisScale.niceMin + (E.left - k.left) * o.xRatio, m = r.globals.xAxisScale.niceMin + (E.right - k.left) * o.xRatio, w = r.globals.yAxisScale[0].niceMin + (k.bottom - E.bottom) * o.yRatio[0], C = r.globals.yAxisScale[0].niceMax - (E.top - k.top) * o.yRatio[0]);
            var _ = { xaxis: { min: p, max: m }, yaxis: { min: w, max: C } };
            r.config.chart.events.selection(s.ctx, _), r.config.chart.brush.enabled && r.config.chart.events.brushScrolled !== void 0 && r.config.chart.events.brushScrolled(s.ctx, _);
          }, d));
        } }, { key: "selectionDrawn", value: function(i) {
          var a = i.context, s = i.zoomtype, r = this.w, o = a, c = this.xyRatios, d = this.ctx.toolbar;
          if (o.startX > o.endX) {
            var g = o.startX;
            o.startX = o.endX, o.endX = g;
          }
          if (o.startY > o.endY) {
            var f = o.startY;
            o.startY = o.endY, o.endY = f;
          }
          var p = void 0, m = void 0;
          r.globals.isRangeBar ? (p = r.globals.yAxisScale[0].niceMin + o.startX * c.invertedYRatio, m = r.globals.yAxisScale[0].niceMin + o.endX * c.invertedYRatio) : (p = r.globals.xAxisScale.niceMin + o.startX * c.xRatio, m = r.globals.xAxisScale.niceMin + o.endX * c.xRatio);
          var w = [], C = [];
          if (r.config.yaxis.forEach(function(R, O) {
            w.push(r.globals.yAxisScale[O].niceMax - c.yRatio[O] * o.startY), C.push(r.globals.yAxisScale[O].niceMax - c.yRatio[O] * o.endY);
          }), o.dragged && (o.dragX > 10 || o.dragY > 10) && p !== m) {
            if (r.globals.zoomEnabled) {
              var k = M.clone(r.globals.initialConfig.yaxis), E = M.clone(r.globals.initialConfig.xaxis);
              if (r.globals.zoomed = !0, r.config.xaxis.convertedCatToNumeric && (p = Math.floor(p), m = Math.floor(m), p < 1 && (p = 1, m = r.globals.dataPoints), m - p < 2 && (m = p + 1)), s !== "xy" && s !== "x" || (E = { min: p, max: m }), s !== "xy" && s !== "y" || k.forEach(function(R, O) {
                k[O].min = C[O], k[O].max = w[O];
              }), r.config.chart.zoom.autoScaleYaxis) {
                var _ = new ze(o.ctx);
                k = _.autoScaleY(o.ctx, k, { xaxis: E });
              }
              if (d) {
                var h = d.getBeforeZoomRange(E, k);
                h && (E = h.xaxis ? h.xaxis : E, k = h.yaxis ? h.yaxis : k);
              }
              var x = { xaxis: E };
              r.config.chart.group || (x.yaxis = k), o.ctx.updateHelpers._updateOptions(x, !1, o.w.config.chart.animations.dynamicAnimation.enabled), typeof r.config.chart.events.zoomed == "function" && d.zoomCallback(E, k);
            } else if (r.globals.selectionEnabled) {
              var S, L = null;
              S = { min: p, max: m }, s !== "xy" && s !== "y" || (L = M.clone(r.config.yaxis)).forEach(function(R, O) {
                L[O].min = C[O], L[O].max = w[O];
              }), r.globals.selection = o.selection, typeof r.config.chart.events.selection == "function" && r.config.chart.events.selection(o.ctx, { xaxis: S, yaxis: L });
            }
          }
        } }, { key: "panDragging", value: function(i) {
          var a = i.context, s = this.w, r = a;
          if (s.globals.lastClientPosition.x !== void 0) {
            var o = s.globals.lastClientPosition.x - r.clientX, c = s.globals.lastClientPosition.y - r.clientY;
            Math.abs(o) > Math.abs(c) && o > 0 ? this.moveDirection = "left" : Math.abs(o) > Math.abs(c) && o < 0 ? this.moveDirection = "right" : Math.abs(c) > Math.abs(o) && c > 0 ? this.moveDirection = "up" : Math.abs(c) > Math.abs(o) && c < 0 && (this.moveDirection = "down");
          }
          s.globals.lastClientPosition = { x: r.clientX, y: r.clientY };
          var d = s.globals.isRangeBar ? s.globals.minY : s.globals.minX, g = s.globals.isRangeBar ? s.globals.maxY : s.globals.maxX;
          s.config.xaxis.convertedCatToNumeric || r.panScrolled(d, g);
        } }, { key: "delayedPanScrolled", value: function() {
          var i = this.w, a = i.globals.minX, s = i.globals.maxX, r = (i.globals.maxX - i.globals.minX) / 2;
          this.moveDirection === "left" ? (a = i.globals.minX + r, s = i.globals.maxX + r) : this.moveDirection === "right" && (a = i.globals.minX - r, s = i.globals.maxX - r), a = Math.floor(a), s = Math.floor(s), this.updateScrolledChart({ xaxis: { min: a, max: s } }, a, s);
        } }, { key: "panScrolled", value: function(i, a) {
          var s = this.w, r = this.xyRatios, o = M.clone(s.globals.initialConfig.yaxis), c = r.xRatio, d = s.globals.minX, g = s.globals.maxX;
          s.globals.isRangeBar && (c = r.invertedYRatio, d = s.globals.minY, g = s.globals.maxY), this.moveDirection === "left" ? (i = d + s.globals.gridWidth / 15 * c, a = g + s.globals.gridWidth / 15 * c) : this.moveDirection === "right" && (i = d - s.globals.gridWidth / 15 * c, a = g - s.globals.gridWidth / 15 * c), s.globals.isRangeBar || (i < s.globals.initialMinX || a > s.globals.initialMaxX) && (i = d, a = g);
          var f = { min: i, max: a };
          s.config.chart.zoom.autoScaleYaxis && (o = new ze(this.ctx).autoScaleY(this.ctx, o, { xaxis: f }));
          var p = { xaxis: { min: i, max: a } };
          s.config.chart.group || (p.yaxis = o), this.updateScrolledChart(p, i, a);
        } }, { key: "updateScrolledChart", value: function(i, a, s) {
          var r = this.w;
          this.ctx.updateHelpers._updateOptions(i, !1, !1), typeof r.config.chart.events.scrolled == "function" && r.config.chart.events.scrolled(this.ctx, { xaxis: { min: a, max: s } });
        } }]), t;
      }(zi), Fi = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.ttCtx = e, this.ctx = e.ctx;
        }
        return A(P, [{ key: "getNearestValues", value: function(e) {
          var t = e.hoverArea, i = e.elGrid, a = e.clientX, s = e.clientY, r = this.w, o = i.getBoundingClientRect(), c = o.width, d = o.height, g = c / (r.globals.dataPoints - 1), f = d / r.globals.dataPoints, p = this.hasBars();
          !r.globals.comboCharts && !p || r.config.xaxis.convertedCatToNumeric || (g = c / r.globals.dataPoints);
          var m = a - o.left - r.globals.barPadForNumericAxis, w = s - o.top;
          m < 0 || w < 0 || m > c || w > d ? (t.classList.remove("hovering-zoom"), t.classList.remove("hovering-pan")) : r.globals.zoomEnabled ? (t.classList.remove("hovering-pan"), t.classList.add("hovering-zoom")) : r.globals.panEnabled && (t.classList.remove("hovering-zoom"), t.classList.add("hovering-pan"));
          var C = Math.round(m / g), k = Math.floor(w / f);
          p && !r.config.xaxis.convertedCatToNumeric && (C = Math.ceil(m / g), C -= 1);
          var E = null, _ = null, h = r.globals.seriesXvalues.map(function(O) {
            return O.filter(function(Y) {
              return M.isNumber(Y);
            });
          }), x = r.globals.seriesYvalues.map(function(O) {
            return O.filter(function(Y) {
              return M.isNumber(Y);
            });
          });
          if (r.globals.isXNumeric) {
            var S = this.ttCtx.getElGrid().getBoundingClientRect(), L = m * (S.width / c), R = w * (S.height / d);
            E = (_ = this.closestInMultiArray(L, R, h, x)).index, C = _.j, E !== null && (h = r.globals.seriesXvalues[E], C = (_ = this.closestInArray(L, h)).index);
          }
          return r.globals.capturedSeriesIndex = E === null ? -1 : E, (!C || C < 1) && (C = 0), r.globals.isBarHorizontal ? r.globals.capturedDataPointIndex = k : r.globals.capturedDataPointIndex = C, { capturedSeries: E, j: r.globals.isBarHorizontal ? k : C, hoverX: m, hoverY: w };
        } }, { key: "closestInMultiArray", value: function(e, t, i, a) {
          var s = this.w, r = 0, o = null, c = -1;
          s.globals.series.length > 1 ? r = this.getFirstActiveXArray(i) : o = 0;
          var d = i[r][0], g = Math.abs(e - d);
          if (i.forEach(function(m) {
            m.forEach(function(w, C) {
              var k = Math.abs(e - w);
              k <= g && (g = k, c = C);
            });
          }), c !== -1) {
            var f = a[r][c], p = Math.abs(t - f);
            o = r, a.forEach(function(m, w) {
              var C = Math.abs(t - m[c]);
              C <= p && (p = C, o = w);
            });
          }
          return { index: o, j: c };
        } }, { key: "getFirstActiveXArray", value: function(e) {
          for (var t = this.w, i = 0, a = e.map(function(r, o) {
            return r.length > 0 ? o : -1;
          }), s = 0; s < a.length; s++)
            if (a[s] !== -1 && t.globals.collapsedSeriesIndices.indexOf(s) === -1 && t.globals.ancillaryCollapsedSeriesIndices.indexOf(s) === -1) {
              i = a[s];
              break;
            }
          return i;
        } }, { key: "closestInArray", value: function(e, t) {
          for (var i = t[0], a = null, s = Math.abs(e - i), r = 0; r < t.length; r++) {
            var o = Math.abs(e - t[r]);
            o < s && (s = o, a = r);
          }
          return { index: a };
        } }, { key: "isXoverlap", value: function(e) {
          var t = [], i = this.w.globals.seriesX.filter(function(s) {
            return s[0] !== void 0;
          });
          if (i.length > 0)
            for (var a = 0; a < i.length - 1; a++)
              i[a][e] !== void 0 && i[a + 1][e] !== void 0 && i[a][e] !== i[a + 1][e] && t.push("unEqual");
          return t.length === 0;
        } }, { key: "isInitialSeriesSameLen", value: function() {
          for (var e = !0, t = this.w.globals.initialSeries, i = 0; i < t.length - 1; i++)
            if (t[i].data.length !== t[i + 1].data.length) {
              e = !1;
              break;
            }
          return e;
        } }, { key: "getBarsHeight", value: function(e) {
          return j(e).reduce(function(t, i) {
            return t + i.getBBox().height;
          }, 0);
        } }, { key: "getElMarkers", value: function(e) {
          return typeof e == "number" ? this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series[data\\:realIndex='".concat(e, "'] .apexcharts-series-markers-wrap > *")) : this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers-wrap > *");
        } }, { key: "getAllMarkers", value: function() {
          var e = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers-wrap");
          (e = j(e)).sort(function(i, a) {
            var s = Number(i.getAttribute("data:realIndex")), r = Number(a.getAttribute("data:realIndex"));
            return r < s ? 1 : r > s ? -1 : 0;
          });
          var t = [];
          return e.forEach(function(i) {
            t.push(i.querySelector(".apexcharts-marker"));
          }), t;
        } }, { key: "hasMarkers", value: function(e) {
          return this.getElMarkers(e).length > 0;
        } }, { key: "getElBars", value: function() {
          return this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-bar-series,  .apexcharts-candlestick-series, .apexcharts-boxPlot-series, .apexcharts-rangebar-series");
        } }, { key: "hasBars", value: function() {
          return this.getElBars().length > 0;
        } }, { key: "getHoverMarkerSize", value: function(e) {
          var t = this.w, i = t.config.markers.hover.size;
          return i === void 0 && (i = t.globals.markers.size[e] + t.config.markers.hover.sizeOffset), i;
        } }, { key: "toggleAllTooltipSeriesGroups", value: function(e) {
          var t = this.w, i = this.ttCtx;
          i.allTooltipSeriesGroups.length === 0 && (i.allTooltipSeriesGroups = t.globals.dom.baseEl.querySelectorAll(".apexcharts-tooltip-series-group"));
          for (var a = i.allTooltipSeriesGroups, s = 0; s < a.length; s++)
            e === "enable" ? (a[s].classList.add("apexcharts-active"), a[s].style.display = t.config.tooltip.items.display) : (a[s].classList.remove("apexcharts-active"), a[s].style.display = "none");
        } }]), P;
      }(), cs = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.ctx = e.ctx, this.ttCtx = e, this.tooltipUtil = new Fi(e);
        }
        return A(P, [{ key: "drawSeriesTexts", value: function(e) {
          var t = e.shared, i = t === void 0 || t, a = e.ttItems, s = e.i, r = s === void 0 ? 0 : s, o = e.j, c = o === void 0 ? null : o, d = e.y1, g = e.y2, f = e.e, p = this.w;
          p.config.tooltip.custom !== void 0 ? this.handleCustomTooltip({ i: r, j: c, y1: d, y2: g, w: p }) : this.toggleActiveInactiveSeries(i);
          var m = this.getValuesToPrint({ i: r, j: c });
          this.printLabels({ i: r, j: c, values: m, ttItems: a, shared: i, e: f });
          var w = this.ttCtx.getElTooltip();
          this.ttCtx.tooltipRect.ttWidth = w.getBoundingClientRect().width, this.ttCtx.tooltipRect.ttHeight = w.getBoundingClientRect().height;
        } }, { key: "printLabels", value: function(e) {
          var t, i = this, a = e.i, s = e.j, r = e.values, o = e.ttItems, c = e.shared, d = e.e, g = this.w, f = [], p = function(S) {
            return g.globals.seriesGoals[S] && g.globals.seriesGoals[S][s] && Array.isArray(g.globals.seriesGoals[S][s]);
          }, m = r.xVal, w = r.zVal, C = r.xAxisTTVal, k = "", E = g.globals.colors[a];
          s !== null && g.config.plotOptions.bar.distributed && (E = g.globals.colors[s]);
          for (var _ = function(S, L) {
            var R = i.getFormatters(a);
            k = i.getSeriesName({ fn: R.yLbTitleFormatter, index: a, seriesIndex: a, j: s }), g.config.chart.type === "treemap" && (k = R.yLbTitleFormatter(String(g.config.series[a].data[s].x), { series: g.globals.series, seriesIndex: a, dataPointIndex: s, w: g }));
            var O = g.config.tooltip.inverseOrder ? L : S;
            if (g.globals.axisCharts) {
              var Y = function(Z) {
                var U, se, he, me;
                return g.globals.isRangeData ? R.yLbFormatter((U = g.globals.seriesRangeStart) === null || U === void 0 || (se = U[Z]) === null || se === void 0 ? void 0 : se[s], { series: g.globals.seriesRangeStart, seriesIndex: Z, dataPointIndex: s, w: g }) + " - " + R.yLbFormatter((he = g.globals.seriesRangeEnd) === null || he === void 0 || (me = he[Z]) === null || me === void 0 ? void 0 : me[s], { series: g.globals.seriesRangeEnd, seriesIndex: Z, dataPointIndex: s, w: g }) : R.yLbFormatter(g.globals.series[Z][s], { series: g.globals.series, seriesIndex: Z, dataPointIndex: s, w: g });
              };
              if (c)
                R = i.getFormatters(O), k = i.getSeriesName({ fn: R.yLbTitleFormatter, index: O, seriesIndex: a, j: s }), E = g.globals.colors[O], t = Y(O), p(O) && (f = g.globals.seriesGoals[O][s].map(function(Z) {
                  return { attrs: Z, val: R.yLbFormatter(Z.value, { seriesIndex: O, dataPointIndex: s, w: g }) };
                }));
              else {
                var N, q = d == null || (N = d.target) === null || N === void 0 ? void 0 : N.getAttribute("fill");
                q && (E = q.indexOf("url") !== -1 ? document.querySelector(q.substr(4).slice(0, -1)).childNodes[0].getAttribute("stroke") : q), t = Y(a), p(a) && Array.isArray(g.globals.seriesGoals[a][s]) && (f = g.globals.seriesGoals[a][s].map(function(Z) {
                  return { attrs: Z, val: R.yLbFormatter(Z.value, { seriesIndex: a, dataPointIndex: s, w: g }) };
                }));
              }
            }
            s === null && (t = R.yLbFormatter(g.globals.series[a], u(u({}, g), {}, { seriesIndex: a, dataPointIndex: a }))), i.DOMHandling({ i: a, t: O, j: s, ttItems: o, values: { val: t, goalVals: f, xVal: m, xAxisTTVal: C, zVal: w }, seriesName: k, shared: c, pColor: E });
          }, h = 0, x = g.globals.series.length - 1; h < g.globals.series.length; h++, x--)
            _(h, x);
        } }, { key: "getFormatters", value: function(e) {
          var t, i = this.w, a = i.globals.yLabelFormatters[e];
          return i.globals.ttVal !== void 0 ? Array.isArray(i.globals.ttVal) ? (a = i.globals.ttVal[e] && i.globals.ttVal[e].formatter, t = i.globals.ttVal[e] && i.globals.ttVal[e].title && i.globals.ttVal[e].title.formatter) : (a = i.globals.ttVal.formatter, typeof i.globals.ttVal.title.formatter == "function" && (t = i.globals.ttVal.title.formatter)) : t = i.config.tooltip.y.title.formatter, typeof a != "function" && (a = i.globals.yLabelFormatters[0] ? i.globals.yLabelFormatters[0] : function(s) {
            return s;
          }), typeof t != "function" && (t = function(s) {
            return s;
          }), { yLbFormatter: a, yLbTitleFormatter: t };
        } }, { key: "getSeriesName", value: function(e) {
          var t = e.fn, i = e.index, a = e.seriesIndex, s = e.j, r = this.w;
          return t(String(r.globals.seriesNames[i]), { series: r.globals.series, seriesIndex: a, dataPointIndex: s, w: r });
        } }, { key: "DOMHandling", value: function(e) {
          e.i;
          var t = e.t, i = e.j, a = e.ttItems, s = e.values, r = e.seriesName, o = e.shared, c = e.pColor, d = this.w, g = this.ttCtx, f = s.val, p = s.goalVals, m = s.xVal, w = s.xAxisTTVal, C = s.zVal, k = null;
          k = a[t].children, d.config.tooltip.fillSeriesColor && (a[t].style.backgroundColor = c, k[0].style.display = "none"), g.showTooltipTitle && (g.tooltipTitle === null && (g.tooltipTitle = d.globals.dom.baseEl.querySelector(".apexcharts-tooltip-title")), g.tooltipTitle.innerHTML = m), g.isXAxisTooltipEnabled && (g.xaxisTooltipText.innerHTML = w !== "" ? w : m);
          var E = a[t].querySelector(".apexcharts-tooltip-text-y-label");
          E && (E.innerHTML = r || "");
          var _ = a[t].querySelector(".apexcharts-tooltip-text-y-value");
          _ && (_.innerHTML = f !== void 0 ? f : ""), k[0] && k[0].classList.contains("apexcharts-tooltip-marker") && (d.config.tooltip.marker.fillColors && Array.isArray(d.config.tooltip.marker.fillColors) && (c = d.config.tooltip.marker.fillColors[t]), k[0].style.backgroundColor = c), d.config.tooltip.marker.show || (k[0].style.display = "none");
          var h = a[t].querySelector(".apexcharts-tooltip-text-goals-label"), x = a[t].querySelector(".apexcharts-tooltip-text-goals-value");
          if (p.length && d.globals.seriesGoals[t]) {
            var S = function() {
              var O = "<div >", Y = "<div>";
              p.forEach(function(N, q) {
                O += ' <div style="display: flex"><span class="apexcharts-tooltip-marker" style="background-color: '.concat(N.attrs.strokeColor, '; height: 3px; border-radius: 0; top: 5px;"></span> ').concat(N.attrs.name, "</div>"), Y += "<div>".concat(N.val, "</div>");
              }), h.innerHTML = O + "</div>", x.innerHTML = Y + "</div>";
            };
            o ? d.globals.seriesGoals[t][i] && Array.isArray(d.globals.seriesGoals[t][i]) ? S() : (h.innerHTML = "", x.innerHTML = "") : S();
          } else
            h.innerHTML = "", x.innerHTML = "";
          if (C !== null && (a[t].querySelector(".apexcharts-tooltip-text-z-label").innerHTML = d.config.tooltip.z.title, a[t].querySelector(".apexcharts-tooltip-text-z-value").innerHTML = C !== void 0 ? C : ""), o && k[0]) {
            if (d.config.tooltip.hideEmptySeries) {
              var L = a[t].querySelector(".apexcharts-tooltip-marker"), R = a[t].querySelector(".apexcharts-tooltip-text");
              parseFloat(f) == 0 ? (L.style.display = "none", R.style.display = "none") : (L.style.display = "block", R.style.display = "block");
            }
            f == null || d.globals.ancillaryCollapsedSeriesIndices.indexOf(t) > -1 || d.globals.collapsedSeriesIndices.indexOf(t) > -1 ? k[0].parentNode.style.display = "none" : k[0].parentNode.style.display = d.config.tooltip.items.display;
          }
        } }, { key: "toggleActiveInactiveSeries", value: function(e) {
          var t = this.w;
          if (e)
            this.tooltipUtil.toggleAllTooltipSeriesGroups("enable");
          else {
            this.tooltipUtil.toggleAllTooltipSeriesGroups("disable");
            var i = t.globals.dom.baseEl.querySelector(".apexcharts-tooltip-series-group");
            i && (i.classList.add("apexcharts-active"), i.style.display = t.config.tooltip.items.display);
          }
        } }, { key: "getValuesToPrint", value: function(e) {
          var t = e.i, i = e.j, a = this.w, s = this.ctx.series.filteredSeriesX(), r = "", o = "", c = null, d = null, g = { series: a.globals.series, seriesIndex: t, dataPointIndex: i, w: a }, f = a.globals.ttZFormatter;
          i === null ? d = a.globals.series[t] : a.globals.isXNumeric && a.config.chart.type !== "treemap" ? (r = s[t][i], s[t].length === 0 && (r = s[this.tooltipUtil.getFirstActiveXArray(s)][i])) : r = a.globals.labels[i] !== void 0 ? a.globals.labels[i] : "";
          var p = r;
          return a.globals.isXNumeric && a.config.xaxis.type === "datetime" ? r = new Le(this.ctx).xLabelFormat(a.globals.ttKeyFormatter, p, p, { i: void 0, dateFormatter: new ue(this.ctx).formatDate, w: this.w }) : r = a.globals.isBarHorizontal ? a.globals.yLabelFormatters[0](p, g) : a.globals.xLabelFormatter(p, g), a.config.tooltip.x.formatter !== void 0 && (r = a.globals.ttKeyFormatter(p, g)), a.globals.seriesZ.length > 0 && a.globals.seriesZ[t].length > 0 && (c = f(a.globals.seriesZ[t][i], a)), o = typeof a.config.xaxis.tooltip.formatter == "function" ? a.globals.xaxisTooltipFormatter(p, g) : r, { val: Array.isArray(d) ? d.join(" ") : d, xVal: Array.isArray(r) ? r.join(" ") : r, xAxisTTVal: Array.isArray(o) ? o.join(" ") : o, zVal: c };
        } }, { key: "handleCustomTooltip", value: function(e) {
          var t = e.i, i = e.j, a = e.y1, s = e.y2, r = e.w, o = this.ttCtx.getElTooltip(), c = r.config.tooltip.custom;
          Array.isArray(c) && c[t] && (c = c[t]), o.innerHTML = c({ ctx: this.ctx, series: r.globals.series, seriesIndex: t, dataPointIndex: i, y1: a, y2: s, w: r });
        } }]), P;
      }(), Di = function() {
        function P(e) {
          y(this, P), this.ttCtx = e, this.ctx = e.ctx, this.w = e.w;
        }
        return A(P, [{ key: "moveXCrosshairs", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null, i = this.ttCtx, a = this.w, s = i.getElXCrosshairs(), r = e - i.xcrosshairsWidth / 2, o = a.globals.labels.slice().length;
          if (t !== null && (r = a.globals.gridWidth / o * t), s === null || a.globals.isBarHorizontal || (s.setAttribute("x", r), s.setAttribute("x1", r), s.setAttribute("x2", r), s.setAttribute("y2", a.globals.gridHeight), s.classList.add("apexcharts-active")), r < 0 && (r = 0), r > a.globals.gridWidth && (r = a.globals.gridWidth), i.isXAxisTooltipEnabled) {
            var c = r;
            a.config.xaxis.crosshairs.width !== "tickWidth" && a.config.xaxis.crosshairs.width !== "barWidth" || (c = r + i.xcrosshairsWidth / 2), this.moveXAxisTooltip(c);
          }
        } }, { key: "moveYCrosshairs", value: function(e) {
          var t = this.ttCtx;
          t.ycrosshairs !== null && X.setAttrs(t.ycrosshairs, { y1: e, y2: e }), t.ycrosshairsHidden !== null && X.setAttrs(t.ycrosshairsHidden, { y1: e, y2: e });
        } }, { key: "moveXAxisTooltip", value: function(e) {
          var t = this.w, i = this.ttCtx;
          if (i.xaxisTooltip !== null && i.xcrosshairsWidth !== 0) {
            i.xaxisTooltip.classList.add("apexcharts-active");
            var a = i.xaxisOffY + t.config.xaxis.tooltip.offsetY + t.globals.translateY + 1 + t.config.xaxis.offsetY;
            if (e -= i.xaxisTooltip.getBoundingClientRect().width / 2, !isNaN(e)) {
              e += t.globals.translateX;
              var s;
              s = new X(this.ctx).getTextRects(i.xaxisTooltipText.innerHTML), i.xaxisTooltipText.style.minWidth = s.width + "px", i.xaxisTooltip.style.left = e + "px", i.xaxisTooltip.style.top = a + "px";
            }
          }
        } }, { key: "moveYAxisTooltip", value: function(e) {
          var t = this.w, i = this.ttCtx;
          i.yaxisTTEls === null && (i.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxistooltip"));
          var a = parseInt(i.ycrosshairsHidden.getAttribute("y1"), 10), s = t.globals.translateY + a, r = i.yaxisTTEls[e].getBoundingClientRect().height, o = t.globals.translateYAxisX[e] - 2;
          t.config.yaxis[e].opposite && (o -= 26), s -= r / 2, t.globals.ignoreYAxisIndexes.indexOf(e) === -1 ? (i.yaxisTTEls[e].classList.add("apexcharts-active"), i.yaxisTTEls[e].style.top = s + "px", i.yaxisTTEls[e].style.left = o + t.config.yaxis[e].tooltip.offsetX + "px") : i.yaxisTTEls[e].classList.remove("apexcharts-active");
        } }, { key: "moveTooltip", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = this.w, s = this.ttCtx, r = s.getElTooltip(), o = s.tooltipRect, c = i !== null ? parseFloat(i) : 1, d = parseFloat(e) + c + 5, g = parseFloat(t) + c / 2;
          if (d > a.globals.gridWidth / 2 && (d = d - o.ttWidth - c - 10), d > a.globals.gridWidth - o.ttWidth - 10 && (d = a.globals.gridWidth - o.ttWidth), d < -20 && (d = -20), a.config.tooltip.followCursor) {
            var f = s.getElGrid().getBoundingClientRect();
            (d = s.e.clientX - f.left) > a.globals.gridWidth / 2 && (d -= s.tooltipRect.ttWidth), (g = s.e.clientY + a.globals.translateY - f.top) > a.globals.gridHeight / 2 && (g -= s.tooltipRect.ttHeight);
          } else
            a.globals.isBarHorizontal || o.ttHeight / 2 + g > a.globals.gridHeight && (g = a.globals.gridHeight - o.ttHeight + a.globals.translateY);
          isNaN(d) || (d += a.globals.translateX, r.style.left = d + "px", r.style.top = g + "px");
        } }, { key: "moveMarkers", value: function(e, t) {
          var i = this.w, a = this.ttCtx;
          if (i.globals.markers.size[e] > 0)
            for (var s = i.globals.dom.baseEl.querySelectorAll(" .apexcharts-series[data\\:realIndex='".concat(e, "'] .apexcharts-marker")), r = 0; r < s.length; r++)
              parseInt(s[r].getAttribute("rel"), 10) === t && (a.marker.resetPointsSize(), a.marker.enlargeCurrentPoint(t, s[r]));
          else
            a.marker.resetPointsSize(), this.moveDynamicPointOnHover(t, e);
        } }, { key: "moveDynamicPointOnHover", value: function(e, t) {
          var i, a, s = this.w, r = this.ttCtx, o = s.globals.pointsArray, c = r.tooltipUtil.getHoverMarkerSize(t), d = s.config.series[t].type;
          if (!d || d !== "column" && d !== "candlestick" && d !== "boxPlot") {
            i = o[t][e][0], a = o[t][e][1] ? o[t][e][1] : 0;
            var g = s.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(t, "'] .apexcharts-series-markers circle"));
            g && a < s.globals.gridHeight && a > 0 && (g.setAttribute("r", c), g.setAttribute("cx", i), g.setAttribute("cy", a)), this.moveXCrosshairs(i), r.fixedTooltip || this.moveTooltip(i, a, c);
          }
        } }, { key: "moveDynamicPointsOnHover", value: function(e) {
          var t, i = this.ttCtx, a = i.w, s = 0, r = 0, o = a.globals.pointsArray;
          t = new de(this.ctx).getActiveConfigSeriesIndex("asc", ["line", "area", "scatter", "bubble"]);
          var c = i.tooltipUtil.getHoverMarkerSize(t);
          o[t] && (s = o[t][e][0], r = o[t][e][1]);
          var d = i.tooltipUtil.getAllMarkers();
          if (d !== null)
            for (var g = 0; g < a.globals.series.length; g++) {
              var f = o[g];
              if (a.globals.comboCharts && f === void 0 && d.splice(g, 0, null), f && f.length) {
                var p = o[g][e][1], m = void 0;
                if (d[g].setAttribute("cx", s), a.config.chart.type === "rangeArea" && !a.globals.comboCharts) {
                  var w = e + a.globals.series[g].length;
                  m = o[g][w][1], p -= Math.abs(p - m) / 2;
                }
                p !== null && !isNaN(p) && p < a.globals.gridHeight + c && p + c > 0 ? (d[g] && d[g].setAttribute("r", c), d[g] && d[g].setAttribute("cy", p)) : d[g] && d[g].setAttribute("r", 0);
              }
            }
          this.moveXCrosshairs(s), i.fixedTooltip || this.moveTooltip(s, r || a.globals.gridHeight, c);
        } }, { key: "moveStickyTooltipOverBars", value: function(e, t) {
          var i = this.w, a = this.ttCtx, s = i.globals.columnSeries ? i.globals.columnSeries.length : i.globals.series.length, r = s >= 2 && s % 2 == 0 ? Math.floor(s / 2) : Math.floor(s / 2) + 1;
          i.globals.isBarHorizontal && (r = new de(this.ctx).getActiveConfigSeriesIndex("desc") + 1);
          var o = i.globals.dom.baseEl.querySelector(".apexcharts-bar-series .apexcharts-series[rel='".concat(r, "'] path[j='").concat(e, "'], .apexcharts-candlestick-series .apexcharts-series[rel='").concat(r, "'] path[j='").concat(e, "'], .apexcharts-boxPlot-series .apexcharts-series[rel='").concat(r, "'] path[j='").concat(e, "'], .apexcharts-rangebar-series .apexcharts-series[rel='").concat(r, "'] path[j='").concat(e, "']"));
          o || typeof t != "number" || (o = i.globals.dom.baseEl.querySelector(".apexcharts-bar-series .apexcharts-series[data\\:realIndex='".concat(t, "'] path[j='").concat(e, `'],
        .apexcharts-candlestick-series .apexcharts-series[data\\:realIndex='`).concat(t, "'] path[j='").concat(e, `'],
        .apexcharts-boxPlot-series .apexcharts-series[data\\:realIndex='`).concat(t, "'] path[j='").concat(e, `'],
        .apexcharts-rangebar-series .apexcharts-series[data\\:realIndex='`).concat(t, "'] path[j='").concat(e, "']")));
          var c = o ? parseFloat(o.getAttribute("cx")) : 0, d = o ? parseFloat(o.getAttribute("cy")) : 0, g = o ? parseFloat(o.getAttribute("barWidth")) : 0, f = a.getElGrid().getBoundingClientRect(), p = o && (o.classList.contains("apexcharts-candlestick-area") || o.classList.contains("apexcharts-boxPlot-area"));
          i.globals.isXNumeric ? (o && !p && (c -= s % 2 != 0 ? g / 2 : 0), o && p && i.globals.comboCharts && (c -= g / 2)) : i.globals.isBarHorizontal || (c = a.xAxisTicksPositions[e - 1] + a.dataPointsDividedWidth / 2, isNaN(c) && (c = a.xAxisTicksPositions[e] - a.dataPointsDividedWidth / 2)), i.globals.isBarHorizontal ? d -= a.tooltipRect.ttHeight : i.config.tooltip.followCursor ? d = a.e.clientY - f.top - a.tooltipRect.ttHeight / 2 : d + a.tooltipRect.ttHeight + 15 > i.globals.gridHeight && (d = i.globals.gridHeight), i.globals.isBarHorizontal || this.moveXCrosshairs(c), a.fixedTooltip || this.moveTooltip(c, d || i.globals.gridHeight);
        } }]), P;
      }(), hs = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.ttCtx = e, this.ctx = e.ctx, this.tooltipPosition = new Di(e);
        }
        return A(P, [{ key: "drawDynamicPoints", value: function() {
          var e = this.w, t = new X(this.ctx), i = new le(this.ctx), a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
          a = j(a), e.config.chart.stacked && a.sort(function(f, p) {
            return parseFloat(f.getAttribute("data:realIndex")) - parseFloat(p.getAttribute("data:realIndex"));
          });
          for (var s = 0; s < a.length; s++) {
            var r = a[s].querySelector(".apexcharts-series-markers-wrap");
            if (r !== null) {
              var o = void 0, c = "apexcharts-marker w".concat((Math.random() + 1).toString(36).substring(4));
              e.config.chart.type !== "line" && e.config.chart.type !== "area" || e.globals.comboCharts || e.config.tooltip.intersect || (c += " no-pointer-events");
              var d = i.getMarkerConfig({ cssClass: c, seriesIndex: Number(r.getAttribute("data:realIndex")) });
              (o = t.drawMarker(0, 0, d)).node.setAttribute("default-marker-size", 0);
              var g = document.createElementNS(e.globals.SVGNS, "g");
              g.classList.add("apexcharts-series-markers"), g.appendChild(o.node), r.appendChild(g);
            }
          }
        } }, { key: "enlargeCurrentPoint", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null, s = this.w;
          s.config.chart.type !== "bubble" && this.newPointSize(e, t);
          var r = t.getAttribute("cx"), o = t.getAttribute("cy");
          if (i !== null && a !== null && (r = i, o = a), this.tooltipPosition.moveXCrosshairs(r), !this.fixedTooltip) {
            if (s.config.chart.type === "radar") {
              var c = this.ttCtx.getElGrid().getBoundingClientRect();
              r = this.ttCtx.e.clientX - c.left;
            }
            this.tooltipPosition.moveTooltip(r, o, s.config.markers.hover.size);
          }
        } }, { key: "enlargePoints", value: function(e) {
          for (var t = this.w, i = this, a = this.ttCtx, s = e, r = t.globals.dom.baseEl.querySelectorAll(".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), o = t.config.markers.hover.size, c = 0; c < r.length; c++) {
            var d = r[c].getAttribute("rel"), g = r[c].getAttribute("index");
            if (o === void 0 && (o = t.globals.markers.size[g] + t.config.markers.hover.sizeOffset), s === parseInt(d, 10)) {
              i.newPointSize(s, r[c]);
              var f = r[c].getAttribute("cx"), p = r[c].getAttribute("cy");
              i.tooltipPosition.moveXCrosshairs(f), a.fixedTooltip || i.tooltipPosition.moveTooltip(f, p, o);
            } else
              i.oldPointSize(r[c]);
          }
        } }, { key: "newPointSize", value: function(e, t) {
          var i = this.w, a = i.config.markers.hover.size, s = e === 0 ? t.parentNode.firstChild : t.parentNode.lastChild;
          if (s.getAttribute("default-marker-size") !== "0") {
            var r = parseInt(s.getAttribute("index"), 10);
            a === void 0 && (a = i.globals.markers.size[r] + i.config.markers.hover.sizeOffset), a < 0 && (a = 0), s.setAttribute("r", a);
          }
        } }, { key: "oldPointSize", value: function(e) {
          var t = parseFloat(e.getAttribute("default-marker-size"));
          e.setAttribute("r", t);
        } }, { key: "resetPointsSize", value: function() {
          for (var e = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), t = 0; t < e.length; t++) {
            var i = parseFloat(e[t].getAttribute("default-marker-size"));
            M.isNumber(i) && i >= 0 ? e[t].setAttribute("r", i) : e[t].setAttribute("r", 0);
          }
        } }]), P;
      }(), ds = function() {
        function P(e) {
          y(this, P), this.w = e.w;
          var t = this.w;
          this.ttCtx = e, this.isVerticalGroupedRangeBar = !t.globals.isBarHorizontal && t.config.chart.type === "rangeBar" && t.config.plotOptions.bar.rangeBarGroupRows;
        }
        return A(P, [{ key: "getAttr", value: function(e, t) {
          return parseFloat(e.target.getAttribute(t));
        } }, { key: "handleHeatTreeTooltip", value: function(e) {
          var t = e.e, i = e.opt, a = e.x, s = e.y, r = e.type, o = this.ttCtx, c = this.w;
          if (t.target.classList.contains("apexcharts-".concat(r, "-rect"))) {
            var d = this.getAttr(t, "i"), g = this.getAttr(t, "j"), f = this.getAttr(t, "cx"), p = this.getAttr(t, "cy"), m = this.getAttr(t, "width"), w = this.getAttr(t, "height");
            if (o.tooltipLabels.drawSeriesTexts({ ttItems: i.ttItems, i: d, j: g, shared: !1, e: t }), c.globals.capturedSeriesIndex = d, c.globals.capturedDataPointIndex = g, a = f + o.tooltipRect.ttWidth / 2 + m, s = p + o.tooltipRect.ttHeight / 2 - w / 2, o.tooltipPosition.moveXCrosshairs(f + m / 2), a > c.globals.gridWidth / 2 && (a = f - o.tooltipRect.ttWidth / 2 + m), o.w.config.tooltip.followCursor) {
              var C = c.globals.dom.elWrap.getBoundingClientRect();
              a = c.globals.clientX - C.left - (a > c.globals.gridWidth / 2 ? o.tooltipRect.ttWidth : 0), s = c.globals.clientY - C.top - (s > c.globals.gridHeight / 2 ? o.tooltipRect.ttHeight : 0);
            }
          }
          return { x: a, y: s };
        } }, { key: "handleMarkerTooltip", value: function(e) {
          var t, i, a = e.e, s = e.opt, r = e.x, o = e.y, c = this.w, d = this.ttCtx;
          if (a.target.classList.contains("apexcharts-marker")) {
            var g = parseInt(s.paths.getAttribute("cx"), 10), f = parseInt(s.paths.getAttribute("cy"), 10), p = parseFloat(s.paths.getAttribute("val"));
            if (i = parseInt(s.paths.getAttribute("rel"), 10), t = parseInt(s.paths.parentNode.parentNode.parentNode.getAttribute("rel"), 10) - 1, d.intersect) {
              var m = M.findAncestor(s.paths, "apexcharts-series");
              m && (t = parseInt(m.getAttribute("data:realIndex"), 10));
            }
            if (d.tooltipLabels.drawSeriesTexts({ ttItems: s.ttItems, i: t, j: i, shared: !d.showOnIntersect && c.config.tooltip.shared, e: a }), a.type === "mouseup" && d.markerClick(a, t, i), c.globals.capturedSeriesIndex = t, c.globals.capturedDataPointIndex = i, r = g, o = f + c.globals.translateY - 1.4 * d.tooltipRect.ttHeight, d.w.config.tooltip.followCursor) {
              var w = d.getElGrid().getBoundingClientRect();
              o = d.e.clientY + c.globals.translateY - w.top;
            }
            p < 0 && (o = f), d.marker.enlargeCurrentPoint(i, s.paths, r, o);
          }
          return { x: r, y: o };
        } }, { key: "handleBarTooltip", value: function(e) {
          var t, i, a = e.e, s = e.opt, r = this.w, o = this.ttCtx, c = o.getElTooltip(), d = 0, g = 0, f = 0, p = this.getBarTooltipXY({ e: a, opt: s });
          t = p.i;
          var m = p.barHeight, w = p.j;
          r.globals.capturedSeriesIndex = t, r.globals.capturedDataPointIndex = w, r.globals.isBarHorizontal && o.tooltipUtil.hasBars() || !r.config.tooltip.shared ? (g = p.x, f = p.y, i = Array.isArray(r.config.stroke.width) ? r.config.stroke.width[t] : r.config.stroke.width, d = g) : r.globals.comboCharts || r.config.tooltip.shared || (d /= 2), isNaN(f) && (f = r.globals.svgHeight - o.tooltipRect.ttHeight);
          var C = parseInt(s.paths.parentNode.getAttribute("data:realIndex"), 10), k = r.globals.isMultipleYAxis ? r.config.yaxis[C] && r.config.yaxis[C].reversed : r.config.yaxis[0].reversed;
          if (g + o.tooltipRect.ttWidth > r.globals.gridWidth && !k ? g -= o.tooltipRect.ttWidth : g < 0 && (g = 0), o.w.config.tooltip.followCursor) {
            var E = o.getElGrid().getBoundingClientRect();
            f = o.e.clientY - E.top;
          }
          o.tooltip === null && (o.tooltip = r.globals.dom.baseEl.querySelector(".apexcharts-tooltip")), r.config.tooltip.shared || (r.globals.comboBarCount > 0 ? o.tooltipPosition.moveXCrosshairs(d + i / 2) : o.tooltipPosition.moveXCrosshairs(d)), !o.fixedTooltip && (!r.config.tooltip.shared || r.globals.isBarHorizontal && o.tooltipUtil.hasBars()) && (k && (g -= o.tooltipRect.ttWidth) < 0 && (g = 0), !k || r.globals.isBarHorizontal && o.tooltipUtil.hasBars() || (f = f + m - 2 * (r.globals.series[t][w] < 0 ? m : 0)), f = f + r.globals.translateY - o.tooltipRect.ttHeight / 2, c.style.left = g + r.globals.translateX + "px", c.style.top = f + "px");
        } }, { key: "getBarTooltipXY", value: function(e) {
          var t = this, i = e.e, a = e.opt, s = this.w, r = null, o = this.ttCtx, c = 0, d = 0, g = 0, f = 0, p = 0, m = i.target.classList;
          if (m.contains("apexcharts-bar-area") || m.contains("apexcharts-candlestick-area") || m.contains("apexcharts-boxPlot-area") || m.contains("apexcharts-rangebar-area")) {
            var w = i.target, C = w.getBoundingClientRect(), k = a.elGrid.getBoundingClientRect(), E = C.height;
            p = C.height;
            var _ = C.width, h = parseInt(w.getAttribute("cx"), 10), x = parseInt(w.getAttribute("cy"), 10);
            f = parseFloat(w.getAttribute("barWidth"));
            var S = i.type === "touchmove" ? i.touches[0].clientX : i.clientX;
            r = parseInt(w.getAttribute("j"), 10), c = parseInt(w.parentNode.getAttribute("rel"), 10) - 1;
            var L = w.getAttribute("data-range-y1"), R = w.getAttribute("data-range-y2");
            s.globals.comboCharts && (c = parseInt(w.parentNode.getAttribute("data:realIndex"), 10));
            var O = function(N) {
              return s.globals.isXNumeric ? h - _ / 2 : t.isVerticalGroupedRangeBar ? h + _ / 2 : h - o.dataPointsDividedWidth + _ / 2;
            }, Y = function() {
              return x - o.dataPointsDividedHeight + E / 2 - o.tooltipRect.ttHeight / 2;
            };
            o.tooltipLabels.drawSeriesTexts({ ttItems: a.ttItems, i: c, j: r, y1: L ? parseInt(L, 10) : null, y2: R ? parseInt(R, 10) : null, shared: !o.showOnIntersect && s.config.tooltip.shared, e: i }), s.config.tooltip.followCursor ? s.globals.isBarHorizontal ? (d = S - k.left + 15, g = Y()) : (d = O(), g = i.clientY - k.top - o.tooltipRect.ttHeight / 2 - 15) : s.globals.isBarHorizontal ? ((d = h) < o.xyRatios.baseLineInvertedY && (d = h - o.tooltipRect.ttWidth), g = Y()) : (d = O(), g = x);
          }
          return { x: d, y: g, barHeight: p, barWidth: f, i: c, j: r };
        } }]), P;
      }(), us = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.ttCtx = e;
        }
        return A(P, [{ key: "drawXaxisTooltip", value: function() {
          var e = this.w, t = this.ttCtx, i = e.config.xaxis.position === "bottom";
          t.xaxisOffY = i ? e.globals.gridHeight + 1 : -e.globals.xAxisHeight - e.config.xaxis.axisTicks.height + 3;
          var a = i ? "apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom" : "apexcharts-xaxistooltip apexcharts-xaxistooltip-top", s = e.globals.dom.elWrap;
          t.isXAxisTooltipEnabled && e.globals.dom.baseEl.querySelector(".apexcharts-xaxistooltip") === null && (t.xaxisTooltip = document.createElement("div"), t.xaxisTooltip.setAttribute("class", a + " apexcharts-theme-" + e.config.tooltip.theme), s.appendChild(t.xaxisTooltip), t.xaxisTooltipText = document.createElement("div"), t.xaxisTooltipText.classList.add("apexcharts-xaxistooltip-text"), t.xaxisTooltipText.style.fontFamily = e.config.xaxis.tooltip.style.fontFamily || e.config.chart.fontFamily, t.xaxisTooltipText.style.fontSize = e.config.xaxis.tooltip.style.fontSize, t.xaxisTooltip.appendChild(t.xaxisTooltipText));
        } }, { key: "drawYaxisTooltip", value: function() {
          for (var e = this.w, t = this.ttCtx, i = function(s) {
            var r = e.config.yaxis[s].opposite || e.config.yaxis[s].crosshairs.opposite;
            t.yaxisOffX = r ? e.globals.gridWidth + 1 : 1;
            var o = "apexcharts-yaxistooltip apexcharts-yaxistooltip-".concat(s, r ? " apexcharts-yaxistooltip-right" : " apexcharts-yaxistooltip-left");
            e.globals.yAxisSameScaleIndices.map(function(d, g) {
              d.map(function(f, p) {
                p === s && (o += e.config.yaxis[p].show ? " " : " apexcharts-yaxistooltip-hidden");
              });
            });
            var c = e.globals.dom.elWrap;
            e.globals.dom.baseEl.querySelector(".apexcharts-yaxistooltip apexcharts-yaxistooltip-".concat(s)) === null && (t.yaxisTooltip = document.createElement("div"), t.yaxisTooltip.setAttribute("class", o + " apexcharts-theme-" + e.config.tooltip.theme), c.appendChild(t.yaxisTooltip), s === 0 && (t.yaxisTooltipText = []), t.yaxisTooltipText[s] = document.createElement("div"), t.yaxisTooltipText[s].classList.add("apexcharts-yaxistooltip-text"), t.yaxisTooltip.appendChild(t.yaxisTooltipText[s]));
          }, a = 0; a < e.config.yaxis.length; a++)
            i(a);
        } }, { key: "setXCrosshairWidth", value: function() {
          var e = this.w, t = this.ttCtx, i = t.getElXCrosshairs();
          if (t.xcrosshairsWidth = parseInt(e.config.xaxis.crosshairs.width, 10), e.globals.comboCharts) {
            var a = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
            if (a !== null && e.config.xaxis.crosshairs.width === "barWidth") {
              var s = parseFloat(a.getAttribute("barWidth"));
              t.xcrosshairsWidth = s;
            } else if (e.config.xaxis.crosshairs.width === "tickWidth") {
              var r = e.globals.labels.length;
              t.xcrosshairsWidth = e.globals.gridWidth / r;
            }
          } else if (e.config.xaxis.crosshairs.width === "tickWidth") {
            var o = e.globals.labels.length;
            t.xcrosshairsWidth = e.globals.gridWidth / o;
          } else if (e.config.xaxis.crosshairs.width === "barWidth") {
            var c = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
            if (c !== null) {
              var d = parseFloat(c.getAttribute("barWidth"));
              t.xcrosshairsWidth = d;
            } else
              t.xcrosshairsWidth = 1;
          }
          e.globals.isBarHorizontal && (t.xcrosshairsWidth = 0), i !== null && t.xcrosshairsWidth > 0 && i.setAttribute("width", t.xcrosshairsWidth);
        } }, { key: "handleYCrosshair", value: function() {
          var e = this.w, t = this.ttCtx;
          t.ycrosshairs = e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs"), t.ycrosshairsHidden = e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs-hidden");
        } }, { key: "drawYaxisTooltipText", value: function(e, t, i) {
          var a = this.ttCtx, s = this.w, r = s.globals.yLabelFormatters[e];
          if (a.yaxisTooltips[e]) {
            var o = a.getElGrid().getBoundingClientRect(), c = (t - o.top) * i.yRatio[e], d = s.globals.maxYArr[e] - s.globals.minYArr[e], g = s.globals.minYArr[e] + (d - c);
            a.tooltipPosition.moveYCrosshairs(t - o.top), a.yaxisTooltipText[e].innerHTML = r(g), a.tooltipPosition.moveYAxisTooltip(e);
          }
        } }]), P;
      }(), Xi = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
          var t = this.w;
          this.tConfig = t.config.tooltip, this.tooltipUtil = new Fi(this), this.tooltipLabels = new cs(this), this.tooltipPosition = new Di(this), this.marker = new hs(this), this.intersect = new ds(this), this.axesTooltip = new us(this), this.showOnIntersect = this.tConfig.intersect, this.showTooltipTitle = this.tConfig.x.show, this.fixedTooltip = this.tConfig.fixed.enabled, this.xaxisTooltip = null, this.yaxisTTEls = null, this.isBarShared = !t.globals.isBarHorizontal && this.tConfig.shared, this.lastHoverTime = Date.now();
        }
        return A(P, [{ key: "getElTooltip", value: function(e) {
          return e || (e = this), e.w.globals.dom.baseEl ? e.w.globals.dom.baseEl.querySelector(".apexcharts-tooltip") : null;
        } }, { key: "getElXCrosshairs", value: function() {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-xcrosshairs");
        } }, { key: "getElGrid", value: function() {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-grid");
        } }, { key: "drawTooltip", value: function(e) {
          var t = this.w;
          this.xyRatios = e, this.isXAxisTooltipEnabled = t.config.xaxis.tooltip.enabled && t.globals.axisCharts, this.yaxisTooltips = t.config.yaxis.map(function(r, o) {
            return !!(r.show && r.tooltip.enabled && t.globals.axisCharts);
          }), this.allTooltipSeriesGroups = [], t.globals.axisCharts || (this.showTooltipTitle = !1);
          var i = document.createElement("div");
          if (i.classList.add("apexcharts-tooltip"), t.config.tooltip.cssClass && i.classList.add(t.config.tooltip.cssClass), i.classList.add("apexcharts-theme-".concat(this.tConfig.theme)), t.globals.dom.elWrap.appendChild(i), t.globals.axisCharts) {
            this.axesTooltip.drawXaxisTooltip(), this.axesTooltip.drawYaxisTooltip(), this.axesTooltip.setXCrosshairWidth(), this.axesTooltip.handleYCrosshair();
            var a = new Ee(this.ctx);
            this.xAxisTicksPositions = a.getXAxisTicksPositions();
          }
          if (!t.globals.comboCharts && !this.tConfig.intersect && t.config.chart.type !== "rangeBar" || this.tConfig.shared || (this.showOnIntersect = !0), t.config.markers.size !== 0 && t.globals.markers.largestSize !== 0 || this.marker.drawDynamicPoints(this), t.globals.collapsedSeries.length !== t.globals.series.length) {
            this.dataPointsDividedHeight = t.globals.gridHeight / t.globals.dataPoints, this.dataPointsDividedWidth = t.globals.gridWidth / t.globals.dataPoints, this.showTooltipTitle && (this.tooltipTitle = document.createElement("div"), this.tooltipTitle.classList.add("apexcharts-tooltip-title"), this.tooltipTitle.style.fontFamily = this.tConfig.style.fontFamily || t.config.chart.fontFamily, this.tooltipTitle.style.fontSize = this.tConfig.style.fontSize, i.appendChild(this.tooltipTitle));
            var s = t.globals.series.length;
            (t.globals.xyCharts || t.globals.comboCharts) && this.tConfig.shared && (s = this.showOnIntersect ? 1 : t.globals.series.length), this.legendLabels = t.globals.dom.baseEl.querySelectorAll(".apexcharts-legend-text"), this.ttItems = this.createTTElements(s), this.addSVGEvents();
          }
        } }, { key: "createTTElements", value: function(e) {
          for (var t = this, i = this.w, a = [], s = this.getElTooltip(), r = function(c) {
            var d = document.createElement("div");
            d.classList.add("apexcharts-tooltip-series-group"), d.style.order = i.config.tooltip.inverseOrder ? e - c : c + 1, t.tConfig.shared && t.tConfig.enabledOnSeries && Array.isArray(t.tConfig.enabledOnSeries) && t.tConfig.enabledOnSeries.indexOf(c) < 0 && d.classList.add("apexcharts-tooltip-series-group-hidden");
            var g = document.createElement("span");
            g.classList.add("apexcharts-tooltip-marker"), g.style.backgroundColor = i.globals.colors[c], d.appendChild(g);
            var f = document.createElement("div");
            f.classList.add("apexcharts-tooltip-text"), f.style.fontFamily = t.tConfig.style.fontFamily || i.config.chart.fontFamily, f.style.fontSize = t.tConfig.style.fontSize, ["y", "goals", "z"].forEach(function(p) {
              var m = document.createElement("div");
              m.classList.add("apexcharts-tooltip-".concat(p, "-group"));
              var w = document.createElement("span");
              w.classList.add("apexcharts-tooltip-text-".concat(p, "-label")), m.appendChild(w);
              var C = document.createElement("span");
              C.classList.add("apexcharts-tooltip-text-".concat(p, "-value")), m.appendChild(C), f.appendChild(m);
            }), d.appendChild(f), s.appendChild(d), a.push(d);
          }, o = 0; o < e; o++)
            r(o);
          return a;
        } }, { key: "addSVGEvents", value: function() {
          var e = this.w, t = e.config.chart.type, i = this.getElTooltip(), a = !(t !== "bar" && t !== "candlestick" && t !== "boxPlot" && t !== "rangeBar"), s = t === "area" || t === "line" || t === "scatter" || t === "bubble" || t === "radar", r = e.globals.dom.Paper.node, o = this.getElGrid();
          o && (this.seriesBound = o.getBoundingClientRect());
          var c, d = [], g = [], f = { hoverArea: r, elGrid: o, tooltipEl: i, tooltipY: d, tooltipX: g, ttItems: this.ttItems };
          if (e.globals.axisCharts && (s ? c = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series[data\\:longestSeries='true'] .apexcharts-marker") : a ? c = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series .apexcharts-bar-area, .apexcharts-series .apexcharts-candlestick-area, .apexcharts-series .apexcharts-boxPlot-area, .apexcharts-series .apexcharts-rangebar-area") : t !== "heatmap" && t !== "treemap" || (c = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series .apexcharts-heatmap, .apexcharts-series .apexcharts-treemap")), c && c.length))
            for (var p = 0; p < c.length; p++)
              d.push(c[p].getAttribute("cy")), g.push(c[p].getAttribute("cx"));
          if (e.globals.xyCharts && !this.showOnIntersect || e.globals.comboCharts && !this.showOnIntersect || a && this.tooltipUtil.hasBars() && this.tConfig.shared)
            this.addPathsEventListeners([r], f);
          else if (a && !e.globals.comboCharts || s && this.showOnIntersect)
            this.addDatapointEventsListeners(f);
          else if (!e.globals.axisCharts || t === "heatmap" || t === "treemap") {
            var m = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
            this.addPathsEventListeners(m, f);
          }
          if (this.showOnIntersect) {
            var w = e.globals.dom.baseEl.querySelectorAll(".apexcharts-line-series .apexcharts-marker, .apexcharts-area-series .apexcharts-marker");
            w.length > 0 && this.addPathsEventListeners(w, f), this.tooltipUtil.hasBars() && !this.tConfig.shared && this.addDatapointEventsListeners(f);
          }
        } }, { key: "drawFixedTooltipRect", value: function() {
          var e = this.w, t = this.getElTooltip(), i = t.getBoundingClientRect(), a = i.width + 10, s = i.height + 10, r = this.tConfig.fixed.offsetX, o = this.tConfig.fixed.offsetY, c = this.tConfig.fixed.position.toLowerCase();
          return c.indexOf("right") > -1 && (r = r + e.globals.svgWidth - a + 10), c.indexOf("bottom") > -1 && (o = o + e.globals.svgHeight - s - 10), t.style.left = r + "px", t.style.top = o + "px", { x: r, y: o, ttWidth: a, ttHeight: s };
        } }, { key: "addDatapointEventsListeners", value: function(e) {
          var t = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers .apexcharts-marker, .apexcharts-bar-area, .apexcharts-candlestick-area, .apexcharts-boxPlot-area, .apexcharts-rangebar-area");
          this.addPathsEventListeners(t, e);
        } }, { key: "addPathsEventListeners", value: function(e, t) {
          for (var i = this, a = function(r) {
            var o = { paths: e[r], tooltipEl: t.tooltipEl, tooltipY: t.tooltipY, tooltipX: t.tooltipX, elGrid: t.elGrid, hoverArea: t.hoverArea, ttItems: t.ttItems };
            ["mousemove", "mouseup", "touchmove", "mouseout", "touchend"].map(function(c) {
              return e[r].addEventListener(c, i.onSeriesHover.bind(i, o), { capture: !1, passive: !0 });
            });
          }, s = 0; s < e.length; s++)
            a(s);
        } }, { key: "onSeriesHover", value: function(e, t) {
          var i = this, a = Date.now() - this.lastHoverTime;
          a >= 100 ? this.seriesHover(e, t) : (clearTimeout(this.seriesHoverTimeout), this.seriesHoverTimeout = setTimeout(function() {
            i.seriesHover(e, t);
          }, 100 - a));
        } }, { key: "seriesHover", value: function(e, t) {
          var i = this;
          this.lastHoverTime = Date.now();
          var a = [], s = this.w;
          s.config.chart.group && (a = this.ctx.getGroupedCharts()), s.globals.axisCharts && (s.globals.minX === -1 / 0 && s.globals.maxX === 1 / 0 || s.globals.dataPoints === 0) || (a.length ? a.forEach(function(r) {
            var o = i.getElTooltip(r), c = { paths: e.paths, tooltipEl: o, tooltipY: e.tooltipY, tooltipX: e.tooltipX, elGrid: e.elGrid, hoverArea: e.hoverArea, ttItems: r.w.globals.tooltip.ttItems };
            r.w.globals.minX === i.w.globals.minX && r.w.globals.maxX === i.w.globals.maxX && r.w.globals.tooltip.seriesHoverByContext({ chartCtx: r, ttCtx: r.w.globals.tooltip, opt: c, e: t });
          }) : this.seriesHoverByContext({ chartCtx: this.ctx, ttCtx: this.w.globals.tooltip, opt: e, e: t }));
        } }, { key: "seriesHoverByContext", value: function(e) {
          var t = e.chartCtx, i = e.ttCtx, a = e.opt, s = e.e, r = t.w, o = this.getElTooltip();
          o && (i.tooltipRect = { x: 0, y: 0, ttWidth: o.getBoundingClientRect().width, ttHeight: o.getBoundingClientRect().height }, i.e = s, i.tooltipUtil.hasBars() && !r.globals.comboCharts && !i.isBarShared && this.tConfig.onDatasetHover.highlightDataSeries && new de(t).toggleSeriesOnHover(s, s.target.parentNode), i.fixedTooltip && i.drawFixedTooltipRect(), r.globals.axisCharts ? i.axisChartsTooltips({ e: s, opt: a, tooltipRect: i.tooltipRect }) : i.nonAxisChartsTooltips({ e: s, opt: a, tooltipRect: i.tooltipRect }));
        } }, { key: "axisChartsTooltips", value: function(e) {
          var t, i, a = e.e, s = e.opt, r = this.w, o = s.elGrid.getBoundingClientRect(), c = a.type === "touchmove" ? a.touches[0].clientX : a.clientX, d = a.type === "touchmove" ? a.touches[0].clientY : a.clientY;
          if (this.clientY = d, this.clientX = c, r.globals.capturedSeriesIndex = -1, r.globals.capturedDataPointIndex = -1, d < o.top || d > o.top + o.height)
            this.handleMouseOut(s);
          else {
            if (Array.isArray(this.tConfig.enabledOnSeries) && !r.config.tooltip.shared) {
              var g = parseInt(s.paths.getAttribute("index"), 10);
              if (this.tConfig.enabledOnSeries.indexOf(g) < 0)
                return void this.handleMouseOut(s);
            }
            var f = this.getElTooltip(), p = this.getElXCrosshairs(), m = r.globals.xyCharts || r.config.chart.type === "bar" && !r.globals.isBarHorizontal && this.tooltipUtil.hasBars() && this.tConfig.shared || r.globals.comboCharts && this.tooltipUtil.hasBars();
            if (a.type === "mousemove" || a.type === "touchmove" || a.type === "mouseup") {
              if (r.globals.collapsedSeries.length + r.globals.ancillaryCollapsedSeries.length === r.globals.series.length)
                return;
              p !== null && p.classList.add("apexcharts-active");
              var w = this.yaxisTooltips.filter(function(E) {
                return E === !0;
              });
              if (this.ycrosshairs !== null && w.length && this.ycrosshairs.classList.add("apexcharts-active"), m && !this.showOnIntersect)
                this.handleStickyTooltip(a, c, d, s);
              else if (r.config.chart.type === "heatmap" || r.config.chart.type === "treemap") {
                var C = this.intersect.handleHeatTreeTooltip({ e: a, opt: s, x: t, y: i, type: r.config.chart.type });
                t = C.x, i = C.y, f.style.left = t + "px", f.style.top = i + "px";
              } else
                this.tooltipUtil.hasBars() && this.intersect.handleBarTooltip({ e: a, opt: s }), this.tooltipUtil.hasMarkers() && this.intersect.handleMarkerTooltip({ e: a, opt: s, x: t, y: i });
              if (this.yaxisTooltips.length)
                for (var k = 0; k < r.config.yaxis.length; k++)
                  this.axesTooltip.drawYaxisTooltipText(k, d, this.xyRatios);
              s.tooltipEl.classList.add("apexcharts-active");
            } else
              a.type !== "mouseout" && a.type !== "touchend" || this.handleMouseOut(s);
          }
        } }, { key: "nonAxisChartsTooltips", value: function(e) {
          var t = e.e, i = e.opt, a = e.tooltipRect, s = this.w, r = i.paths.getAttribute("rel"), o = this.getElTooltip(), c = s.globals.dom.elWrap.getBoundingClientRect();
          if (t.type === "mousemove" || t.type === "touchmove") {
            o.classList.add("apexcharts-active"), this.tooltipLabels.drawSeriesTexts({ ttItems: i.ttItems, i: parseInt(r, 10) - 1, shared: !1 });
            var d = s.globals.clientX - c.left - a.ttWidth / 2, g = s.globals.clientY - c.top - a.ttHeight - 10;
            if (o.style.left = d + "px", o.style.top = g + "px", s.config.legend.tooltipHoverFormatter) {
              var f = r - 1, p = (0, s.config.legend.tooltipHoverFormatter)(this.legendLabels[f].getAttribute("data:default-text"), { seriesIndex: f, dataPointIndex: f, w: s });
              this.legendLabels[f].innerHTML = p;
            }
          } else
            t.type !== "mouseout" && t.type !== "touchend" || (o.classList.remove("apexcharts-active"), s.config.legend.tooltipHoverFormatter && this.legendLabels.forEach(function(m) {
              var w = m.getAttribute("data:default-text");
              m.innerHTML = decodeURIComponent(w);
            }));
        } }, { key: "handleStickyTooltip", value: function(e, t, i, a) {
          var s = this.w, r = this.tooltipUtil.getNearestValues({ context: this, hoverArea: a.hoverArea, elGrid: a.elGrid, clientX: t, clientY: i }), o = r.j, c = r.capturedSeries;
          s.globals.collapsedSeriesIndices.includes(c) && (c = null);
          var d = a.elGrid.getBoundingClientRect();
          if (r.hoverX < 0 || r.hoverX > d.width)
            this.handleMouseOut(a);
          else if (c !== null)
            this.handleStickyCapturedSeries(e, c, a, o);
          else if (this.tooltipUtil.isXoverlap(o) || s.globals.isBarHorizontal) {
            var g = s.globals.series.findIndex(function(f, p) {
              return !s.globals.collapsedSeriesIndices.includes(p);
            });
            this.create(e, this, g, o, a.ttItems);
          }
        } }, { key: "handleStickyCapturedSeries", value: function(e, t, i, a) {
          var s = this.w;
          if (!this.tConfig.shared && s.globals.series[t][a] === null)
            return void this.handleMouseOut(i);
          if (s.globals.series[t][a] !== void 0)
            this.tConfig.shared && this.tooltipUtil.isXoverlap(a) && this.tooltipUtil.isInitialSeriesSameLen() ? this.create(e, this, t, a, i.ttItems) : this.create(e, this, t, a, i.ttItems, !1);
          else if (this.tooltipUtil.isXoverlap(a)) {
            var r = s.globals.series.findIndex(function(o, c) {
              return !s.globals.collapsedSeriesIndices.includes(c);
            });
            this.create(e, this, r, a, i.ttItems);
          }
        } }, { key: "deactivateHoverFilter", value: function() {
          for (var e = this.w, t = new X(this.ctx), i = e.globals.dom.Paper.select(".apexcharts-bar-area"), a = 0; a < i.length; a++)
            t.pathMouseLeave(i[a]);
        } }, { key: "handleMouseOut", value: function(e) {
          var t = this.w, i = this.getElXCrosshairs();
          if (e.tooltipEl.classList.remove("apexcharts-active"), this.deactivateHoverFilter(), t.config.chart.type !== "bubble" && this.marker.resetPointsSize(), i !== null && i.classList.remove("apexcharts-active"), this.ycrosshairs !== null && this.ycrosshairs.classList.remove("apexcharts-active"), this.isXAxisTooltipEnabled && this.xaxisTooltip.classList.remove("apexcharts-active"), this.yaxisTooltips.length) {
            this.yaxisTTEls === null && (this.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxistooltip"));
            for (var a = 0; a < this.yaxisTTEls.length; a++)
              this.yaxisTTEls[a].classList.remove("apexcharts-active");
          }
          t.config.legend.tooltipHoverFormatter && this.legendLabels.forEach(function(s) {
            var r = s.getAttribute("data:default-text");
            s.innerHTML = decodeURIComponent(r);
          });
        } }, { key: "markerClick", value: function(e, t, i) {
          var a = this.w;
          typeof a.config.chart.events.markerClick == "function" && a.config.chart.events.markerClick(e, this.ctx, { seriesIndex: t, dataPointIndex: i, w: a }), this.ctx.events.fireEvent("markerClick", [e, this.ctx, { seriesIndex: t, dataPointIndex: i, w: a }]);
        } }, { key: "create", value: function(e, t, i, a, s) {
          var r, o, c, d, g, f, p, m, w, C, k, E, _, h, x, S, L = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : null, R = this.w, O = t;
          e.type === "mouseup" && this.markerClick(e, i, a), L === null && (L = this.tConfig.shared);
          var Y = this.tooltipUtil.hasMarkers(i), N = this.tooltipUtil.getElBars();
          if (R.config.legend.tooltipHoverFormatter) {
            var q = R.config.legend.tooltipHoverFormatter, Z = Array.from(this.legendLabels);
            Z.forEach(function(Ue) {
              var Ke = Ue.getAttribute("data:default-text");
              Ue.innerHTML = decodeURIComponent(Ke);
            });
            for (var U = 0; U < Z.length; U++) {
              var se = Z[U], he = parseInt(se.getAttribute("i"), 10), me = decodeURIComponent(se.getAttribute("data:default-text")), fe = q(me, { seriesIndex: L ? he : i, dataPointIndex: a, w: R });
              if (L)
                se.innerHTML = R.globals.collapsedSeriesIndices.indexOf(he) < 0 ? fe : me;
              else if (se.innerHTML = he === i ? fe : me, i === he)
                break;
            }
          }
          var Ce = u(u({ ttItems: s, i, j: a }, ((r = R.globals.seriesRange) === null || r === void 0 || (o = r[i]) === null || o === void 0 || (c = o[a]) === null || c === void 0 || (d = c.y[0]) === null || d === void 0 ? void 0 : d.y1) !== void 0 && { y1: (g = R.globals.seriesRange) === null || g === void 0 || (f = g[i]) === null || f === void 0 || (p = f[a]) === null || p === void 0 || (m = p.y[0]) === null || m === void 0 ? void 0 : m.y1 }), ((w = R.globals.seriesRange) === null || w === void 0 || (C = w[i]) === null || C === void 0 || (k = C[a]) === null || k === void 0 || (E = k.y[0]) === null || E === void 0 ? void 0 : E.y2) !== void 0 && { y2: (_ = R.globals.seriesRange) === null || _ === void 0 || (h = _[i]) === null || h === void 0 || (x = h[a]) === null || x === void 0 || (S = x.y[0]) === null || S === void 0 ? void 0 : S.y2 });
          if (L) {
            if (O.tooltipLabels.drawSeriesTexts(u(u({}, Ce), {}, { shared: !this.showOnIntersect && this.tConfig.shared })), Y)
              R.globals.markers.largestSize > 0 ? O.marker.enlargePoints(a) : O.tooltipPosition.moveDynamicPointsOnHover(a);
            else if (this.tooltipUtil.hasBars() && (this.barSeriesHeight = this.tooltipUtil.getBarsHeight(N), this.barSeriesHeight > 0)) {
              var Ne = new X(this.ctx), Ie = R.globals.dom.Paper.select(".apexcharts-bar-area[j='".concat(a, "']"));
              this.deactivateHoverFilter(), this.tooltipPosition.moveStickyTooltipOverBars(a, i);
              for (var Oe = 0; Oe < Ie.length; Oe++)
                Ne.pathMouseEnter(Ie[Oe]);
            }
          } else
            O.tooltipLabels.drawSeriesTexts(u({ shared: !1 }, Ce)), this.tooltipUtil.hasBars() && O.tooltipPosition.moveStickyTooltipOverBars(a, i), Y && O.tooltipPosition.moveMarkers(i, a);
        } }]), P;
      }(), gs = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.barCtx = e, this.totalFormatter = this.w.config.plotOptions.bar.dataLabels.total.formatter, this.totalFormatter || (this.totalFormatter = this.w.config.dataLabels.formatter);
        }
        return A(P, [{ key: "handleBarDataLabels", value: function(e) {
          var t = e.x, i = e.y, a = e.y1, s = e.y2, r = e.i, o = e.j, c = e.realIndex, d = e.groupIndex, g = e.series, f = e.barHeight, p = e.barWidth, m = e.barXPosition, w = e.barYPosition, C = e.visibleSeries, k = e.renderedPath, E = this.w, _ = new X(this.barCtx.ctx), h = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[c] : this.barCtx.strokeWidth, x = t + parseFloat(p * C), S = i + parseFloat(f * C);
          E.globals.isXNumeric && !E.globals.isBarHorizontal && (x = t + parseFloat(p * (C + 1)), S = i + parseFloat(f * (C + 1)) - h);
          var L, R = null, O = t, Y = i, N = {}, q = E.config.dataLabels, Z = this.barCtx.barOptions.dataLabels, U = this.barCtx.barOptions.dataLabels.total;
          w !== void 0 && this.barCtx.isRangeBar && (S = w, Y = w), m !== void 0 && this.barCtx.isVerticalGroupedRangeBar && (x = m, O = m);
          var se = q.offsetX, he = q.offsetY, me = { width: 0, height: 0 };
          if (E.config.dataLabels.enabled) {
            var fe = this.barCtx.series[r][o];
            me = _.getTextRects(E.globals.yLabelFormatters[0](fe), parseFloat(q.style.fontSize));
          }
          var Ce = { x: t, y: i, i: r, j: o, realIndex: c, groupIndex: d || -1, renderedPath: k, bcx: x, bcy: S, barHeight: f, barWidth: p, textRects: me, strokeWidth: h, dataLabelsX: O, dataLabelsY: Y, dataLabelsConfig: q, barDataLabelsConfig: Z, barTotalDataLabelsConfig: U, offX: se, offY: he };
          return N = this.barCtx.isHorizontal ? this.calculateBarsDataLabelsPosition(Ce) : this.calculateColumnsDataLabelsPosition(Ce), k.attr({ cy: N.bcy, cx: N.bcx, j: o, val: g[r][o], barHeight: f, barWidth: p }), L = this.drawCalculatedDataLabels({ x: N.dataLabelsX, y: N.dataLabelsY, val: this.barCtx.isRangeBar ? [a, s] : g[r][o], i: c, j: o, barWidth: p, barHeight: f, textRects: me, dataLabelsConfig: q }), E.config.chart.stacked && U.enabled && (R = this.drawTotalDataLabels({ x: N.totalDataLabelsX, y: N.totalDataLabelsY, barWidth: p, barHeight: f, realIndex: c, textAnchor: N.totalDataLabelsAnchor, val: this.getStackedTotalDataLabel({ realIndex: c, j: o }), dataLabelsConfig: q, barTotalDataLabelsConfig: U })), { dataLabels: L, totalDataLabels: R };
        } }, { key: "getStackedTotalDataLabel", value: function(e) {
          var t = e.realIndex, i = e.j, a = this.w, s = this.barCtx.stackedSeriesTotals[i];
          return this.totalFormatter && (s = this.totalFormatter(s, u(u({}, a), {}, { seriesIndex: t, dataPointIndex: i, w: a }))), s;
        } }, { key: "calculateColumnsDataLabelsPosition", value: function(e) {
          var t, i, a = this.w, s = e.i, r = e.j, o = e.realIndex, c = e.groupIndex, d = e.y, g = e.bcx, f = e.barWidth, p = e.barHeight, m = e.textRects, w = e.dataLabelsX, C = e.dataLabelsY, k = e.dataLabelsConfig, E = e.barDataLabelsConfig, _ = e.barTotalDataLabelsConfig, h = e.strokeWidth, x = e.offX, S = e.offY;
          p = Math.abs(p);
          var L = a.config.plotOptions.bar.dataLabels.orientation === "vertical", R = this.barCtx.barHelpers.getZeroValueEncounters({ i: s, j: r }).zeroEncounters;
          g = g - h / 2 + (c !== -1 ? c * f : 0);
          var O = a.globals.gridWidth / a.globals.dataPoints;
          this.barCtx.isVerticalGroupedRangeBar ? w += f / 2 : (w = a.globals.isXNumeric ? g - f / 2 + x : g - O + f / 2 + x, R > 0 && a.config.plotOptions.bar.hideZeroBarsWhenGrouped && (w -= f * R)), L && (w = w + m.height / 2 - h / 2 - 2);
          var Y = this.barCtx.series[s][r] < 0, N = d;
          switch (this.barCtx.isReversed && (N = d - p + (Y ? 2 * p : 0), d -= p), E.position) {
            case "center":
              C = L ? Y ? N - p / 2 + S : N + p / 2 - S : Y ? N - p / 2 + m.height / 2 + S : N + p / 2 + m.height / 2 - S;
              break;
            case "bottom":
              C = L ? Y ? N - p + S : N + p - S : Y ? N - p + m.height + h + S : N + p - m.height / 2 + h - S;
              break;
            case "top":
              C = L ? Y ? N + S : N - S : Y ? N - m.height / 2 - S : N + m.height + S;
          }
          if (this.barCtx.lastActiveBarSerieIndex === o && _.enabled) {
            var q = new X(this.barCtx.ctx).getTextRects(this.getStackedTotalDataLabel({ realIndex: o, j: r }), k.fontSize);
            t = Y ? N - q.height / 2 - S - _.offsetY + 18 : N + q.height + S + _.offsetY - 18, i = w + _.offsetX;
          }
          return a.config.chart.stacked || (C < 0 ? C = 0 + h : C + m.height / 3 > a.globals.gridHeight && (C = a.globals.gridHeight - h)), { bcx: g, bcy: d, dataLabelsX: w, dataLabelsY: C, totalDataLabelsX: i, totalDataLabelsY: t, totalDataLabelsAnchor: "middle" };
        } }, { key: "calculateBarsDataLabelsPosition", value: function(e) {
          var t = this.w, i = e.x, a = e.i, s = e.j, r = e.realIndex, o = e.groupIndex, c = e.bcy, d = e.barHeight, g = e.barWidth, f = e.textRects, p = e.dataLabelsX, m = e.strokeWidth, w = e.dataLabelsConfig, C = e.barDataLabelsConfig, k = e.barTotalDataLabelsConfig, E = e.offX, _ = e.offY, h = t.globals.gridHeight / t.globals.dataPoints;
          g = Math.abs(g);
          var x, S, L = (c += o !== -1 ? o * d : 0) - (this.barCtx.isRangeBar ? 0 : h) + d / 2 + f.height / 2 + _ - 3, R = "start", O = this.barCtx.series[a][s] < 0, Y = i;
          switch (this.barCtx.isReversed && (Y = i + g - (O ? 2 * g : 0), i = t.globals.gridWidth - g), C.position) {
            case "center":
              p = O ? Y + g / 2 - E : Math.max(f.width / 2, Y - g / 2) + E;
              break;
            case "bottom":
              p = O ? Y + g - m - Math.round(f.width / 2) - E : Y - g + m + Math.round(f.width / 2) + E;
              break;
            case "top":
              p = O ? Y - m + Math.round(f.width / 2) - E : Y - m - Math.round(f.width / 2) + E;
          }
          if (this.barCtx.lastActiveBarSerieIndex === r && k.enabled) {
            var N = new X(this.barCtx.ctx).getTextRects(this.getStackedTotalDataLabel({ realIndex: r, j: s }), w.fontSize);
            O ? (x = Y - m + Math.round(N.width / 2) - E - k.offsetX - 15, R = "end") : x = Y - m - Math.round(N.width / 2) + E + k.offsetX + 15, S = L + k.offsetY;
          }
          return t.config.chart.stacked || (p < 0 ? p = p + f.width + m : p + f.width / 2 > t.globals.gridWidth && (p = t.globals.gridWidth - f.width - m)), { bcx: i, bcy: c, dataLabelsX: p, dataLabelsY: L, totalDataLabelsX: x, totalDataLabelsY: S, totalDataLabelsAnchor: R };
        } }, { key: "drawCalculatedDataLabels", value: function(e) {
          var t = e.x, i = e.y, a = e.val, s = e.i, r = e.j, o = e.textRects, c = e.barHeight, d = e.barWidth, g = e.dataLabelsConfig, f = this.w, p = "rotate(0)";
          f.config.plotOptions.bar.dataLabels.orientation === "vertical" && (p = "rotate(-90, ".concat(t, ", ").concat(i, ")"));
          var m = new xe(this.barCtx.ctx), w = new X(this.barCtx.ctx), C = g.formatter, k = null, E = f.globals.collapsedSeriesIndices.indexOf(s) > -1;
          if (g.enabled && !E) {
            k = w.group({ class: "apexcharts-data-labels", transform: p });
            var _ = "";
            a !== void 0 && (_ = C(a, u(u({}, f), {}, { seriesIndex: s, dataPointIndex: r, w: f }))), !a && f.config.plotOptions.bar.hideZeroBarsWhenGrouped && (_ = "");
            var h = f.globals.series[s][r] < 0, x = f.config.plotOptions.bar.dataLabels.position;
            f.config.plotOptions.bar.dataLabels.orientation === "vertical" && (x === "top" && (g.textAnchor = h ? "end" : "start"), x === "center" && (g.textAnchor = "middle"), x === "bottom" && (g.textAnchor = h ? "end" : "start")), this.barCtx.isRangeBar && this.barCtx.barOptions.dataLabels.hideOverflowingLabels && d < w.getTextRects(_, parseFloat(g.style.fontSize)).width && (_ = ""), f.config.chart.stacked && this.barCtx.barOptions.dataLabels.hideOverflowingLabels && (this.barCtx.isHorizontal ? o.width / 1.6 > Math.abs(d) && (_ = "") : o.height / 1.6 > Math.abs(c) && (_ = ""));
            var S = u({}, g);
            this.barCtx.isHorizontal && a < 0 && (g.textAnchor === "start" ? S.textAnchor = "end" : g.textAnchor === "end" && (S.textAnchor = "start")), m.plotDataLabelsText({ x: t, y: i, text: _, i: s, j: r, parent: k, dataLabelsConfig: S, alwaysDrawDataLabel: !0, offsetCorrection: !0 });
          }
          return k;
        } }, { key: "drawTotalDataLabels", value: function(e) {
          var t, i = e.x, a = e.y, s = e.val, r = e.barWidth, o = e.barHeight, c = e.realIndex, d = e.textAnchor, g = e.barTotalDataLabelsConfig, f = this.w, p = new X(this.barCtx.ctx);
          return g.enabled && i !== void 0 && a !== void 0 && this.barCtx.lastActiveBarSerieIndex === c && (t = p.drawText({ x: i - (!f.globals.isBarHorizontal && f.globals.seriesGroups.length ? r / f.globals.seriesGroups.length : 0), y: a - (f.globals.isBarHorizontal && f.globals.seriesGroups.length ? o / f.globals.seriesGroups.length : 0), foreColor: g.style.color, text: s, textAnchor: d, fontFamily: g.style.fontFamily, fontSize: g.style.fontSize, fontWeight: g.style.fontWeight })), t;
        } }]), P;
      }(), fs = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.barCtx = e;
        }
        return A(P, [{ key: "initVariables", value: function(e) {
          var t = this.w;
          this.barCtx.series = e, this.barCtx.totalItems = 0, this.barCtx.seriesLen = 0, this.barCtx.visibleI = -1, this.barCtx.visibleItems = 1;
          for (var i = 0; i < e.length; i++)
            if (e[i].length > 0 && (this.barCtx.seriesLen = this.barCtx.seriesLen + 1, this.barCtx.totalItems += e[i].length), t.globals.isXNumeric)
              for (var a = 0; a < e[i].length; a++)
                t.globals.seriesX[i][a] > t.globals.minX && t.globals.seriesX[i][a] < t.globals.maxX && this.barCtx.visibleItems++;
            else
              this.barCtx.visibleItems = t.globals.dataPoints;
          this.barCtx.seriesLen === 0 && (this.barCtx.seriesLen = 1), this.barCtx.zeroSerieses = [], t.globals.comboCharts || this.checkZeroSeries({ series: e });
        } }, { key: "initialPositions", value: function() {
          var e, t, i, a, s, r, o, c, d = this.w, g = d.globals.dataPoints;
          this.barCtx.isRangeBar && (g = d.globals.labels.length);
          var f = this.barCtx.seriesLen;
          if (d.config.plotOptions.bar.rangeBarGroupRows && (f = 1), this.barCtx.isHorizontal)
            s = (i = d.globals.gridHeight / g) / f, d.globals.isXNumeric && (s = (i = d.globals.gridHeight / this.barCtx.totalItems) / this.barCtx.seriesLen), s = s * parseInt(this.barCtx.barOptions.barHeight, 10) / 100, String(this.barCtx.barOptions.barHeight).indexOf("%") === -1 && (s = parseInt(this.barCtx.barOptions.barHeight, 10)), c = this.barCtx.baseLineInvertedY + d.globals.padHorizontal + (this.barCtx.isReversed ? d.globals.gridWidth : 0) - (this.barCtx.isReversed ? 2 * this.barCtx.baseLineInvertedY : 0), this.barCtx.isFunnel && (c = d.globals.gridWidth / 2), t = (i - s * this.barCtx.seriesLen) / 2;
          else {
            if (a = d.globals.gridWidth / this.barCtx.visibleItems, d.config.xaxis.convertedCatToNumeric && (a = d.globals.gridWidth / d.globals.dataPoints), r = a / f * parseInt(this.barCtx.barOptions.columnWidth, 10) / 100, d.globals.isXNumeric) {
              var p = this.barCtx.xRatio;
              d.config.xaxis.convertedCatToNumeric && (p = this.barCtx.initialXRatio), d.globals.minXDiff && d.globals.minXDiff !== 0.5 && d.globals.minXDiff / p > 0 && (a = d.globals.minXDiff / p), (r = a / f * parseInt(this.barCtx.barOptions.columnWidth, 10) / 100) < 1 && (r = 1);
            }
            String(this.barCtx.barOptions.columnWidth).indexOf("%") === -1 && (r = parseInt(this.barCtx.barOptions.columnWidth, 10)), o = d.globals.gridHeight - this.barCtx.baseLineY[this.barCtx.yaxisIndex] - (this.barCtx.isReversed ? d.globals.gridHeight : 0) + (this.barCtx.isReversed ? 2 * this.barCtx.baseLineY[this.barCtx.yaxisIndex] : 0), e = d.globals.padHorizontal + (a - r * this.barCtx.seriesLen) / 2;
          }
          return d.globals.barHeight = s, d.globals.barWidth = r, { x: e, y: t, yDivision: i, xDivision: a, barHeight: s, barWidth: r, zeroH: o, zeroW: c };
        } }, { key: "initializeStackedPrevVars", value: function(e) {
          var t = e.w;
          t.globals.hasSeriesGroups ? t.globals.seriesGroups.forEach(function(i) {
            e[i] || (e[i] = {}), e[i].prevY = [], e[i].prevX = [], e[i].prevYF = [], e[i].prevXF = [], e[i].prevYVal = [], e[i].prevXVal = [];
          }) : (e.prevY = [], e.prevX = [], e.prevYF = [], e.prevXF = [], e.prevYVal = [], e.prevXVal = []);
        } }, { key: "initializeStackedXYVars", value: function(e) {
          var t = e.w;
          t.globals.hasSeriesGroups ? t.globals.seriesGroups.forEach(function(i) {
            e[i] || (e[i] = {}), e[i].xArrj = [], e[i].xArrjF = [], e[i].xArrjVal = [], e[i].yArrj = [], e[i].yArrjF = [], e[i].yArrjVal = [];
          }) : (e.xArrj = [], e.xArrjF = [], e.xArrjVal = [], e.yArrj = [], e.yArrjF = [], e.yArrjVal = []);
        } }, { key: "getPathFillColor", value: function(e, t, i, a) {
          var s, r, o, c, d = this.w, g = new ae(this.barCtx.ctx), f = null, p = this.barCtx.barOptions.distributed ? i : t;
          return this.barCtx.barOptions.colors.ranges.length > 0 && this.barCtx.barOptions.colors.ranges.map(function(m) {
            e[t][i] >= m.from && e[t][i] <= m.to && (f = m.color);
          }), d.config.series[t].data[i] && d.config.series[t].data[i].fillColor && (f = d.config.series[t].data[i].fillColor), g.fillPath({ seriesNumber: this.barCtx.barOptions.distributed ? p : a, dataPointIndex: i, color: f, value: e[t][i], fillConfig: (s = d.config.series[t].data[i]) === null || s === void 0 ? void 0 : s.fill, fillType: (r = d.config.series[t].data[i]) !== null && r !== void 0 && (o = r.fill) !== null && o !== void 0 && o.type ? (c = d.config.series[t].data[i]) === null || c === void 0 ? void 0 : c.fill.type : Array.isArray(d.config.fill.type) ? d.config.fill.type[t] : d.config.fill.type });
        } }, { key: "getStrokeWidth", value: function(e, t, i) {
          var a = 0, s = this.w;
          return this.barCtx.series[e][t] ? this.barCtx.isNullValue = !1 : this.barCtx.isNullValue = !0, s.config.stroke.show && (this.barCtx.isNullValue || (a = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[i] : this.barCtx.strokeWidth)), a;
        } }, { key: "shouldApplyRadius", value: function(e) {
          var t = this.w, i = !1;
          return t.config.plotOptions.bar.borderRadius > 0 && (t.config.chart.stacked && t.config.plotOptions.bar.borderRadiusWhenStacked === "last" ? this.barCtx.lastActiveBarSerieIndex === e && (i = !0) : i = !0), i;
        } }, { key: "barBackground", value: function(e) {
          var t = e.j, i = e.i, a = e.x1, s = e.x2, r = e.y1, o = e.y2, c = e.elSeries, d = this.w, g = new X(this.barCtx.ctx), f = new de(this.barCtx.ctx).getActiveConfigSeriesIndex();
          if (this.barCtx.barOptions.colors.backgroundBarColors.length > 0 && f === i) {
            t >= this.barCtx.barOptions.colors.backgroundBarColors.length && (t %= this.barCtx.barOptions.colors.backgroundBarColors.length);
            var p = this.barCtx.barOptions.colors.backgroundBarColors[t], m = g.drawRect(a !== void 0 ? a : 0, r !== void 0 ? r : 0, s !== void 0 ? s : d.globals.gridWidth, o !== void 0 ? o : d.globals.gridHeight, this.barCtx.barOptions.colors.backgroundBarRadius, p, this.barCtx.barOptions.colors.backgroundBarOpacity);
            c.add(m), m.node.classList.add("apexcharts-backgroundBar");
          }
        } }, { key: "getColumnPaths", value: function(e) {
          var t, i = e.barWidth, a = e.barXPosition, s = e.y1, r = e.y2, o = e.strokeWidth, c = e.seriesGroup, d = e.realIndex, g = e.i, f = e.j, p = e.w, m = new X(this.barCtx.ctx);
          (o = Array.isArray(o) ? o[d] : o) || (o = 0);
          var w = i, C = a;
          (t = p.config.series[d].data[f]) !== null && t !== void 0 && t.columnWidthOffset && (C = a - p.config.series[d].data[f].columnWidthOffset / 2, w = i + p.config.series[d].data[f].columnWidthOffset);
          var k = C, E = C + w;
          s += 1e-3, r += 1e-3;
          var _ = m.move(k, s), h = m.move(k, s), x = m.line(E - o, s);
          if (p.globals.previousPaths.length > 0 && (h = this.barCtx.getPreviousPath(d, f, !1)), _ = _ + m.line(k, r) + m.line(E - o, r) + m.line(E - o, s) + (p.config.plotOptions.bar.borderRadiusApplication === "around" ? " Z" : " z"), h = h + m.line(k, s) + x + x + x + x + x + m.line(k, s) + (p.config.plotOptions.bar.borderRadiusApplication === "around" ? " Z" : " z"), this.shouldApplyRadius(d) && (_ = m.roundPathCorners(_, p.config.plotOptions.bar.borderRadius)), p.config.chart.stacked) {
            var S = this.barCtx;
            p.globals.hasSeriesGroups && c && (S = this.barCtx[c]), S.yArrj.push(r), S.yArrjF.push(Math.abs(s - r)), S.yArrjVal.push(this.barCtx.series[g][f]);
          }
          return { pathTo: _, pathFrom: h };
        } }, { key: "getBarpaths", value: function(e) {
          var t, i = e.barYPosition, a = e.barHeight, s = e.x1, r = e.x2, o = e.strokeWidth, c = e.seriesGroup, d = e.realIndex, g = e.i, f = e.j, p = e.w, m = new X(this.barCtx.ctx);
          (o = Array.isArray(o) ? o[d] : o) || (o = 0);
          var w = i, C = a;
          (t = p.config.series[d].data[f]) !== null && t !== void 0 && t.barHeightOffset && (w = i - p.config.series[d].data[f].barHeightOffset / 2, C = a + p.config.series[d].data[f].barHeightOffset);
          var k = w, E = w + C;
          s += 1e-3, r += 1e-3;
          var _ = m.move(s, k), h = m.move(s, k);
          p.globals.previousPaths.length > 0 && (h = this.barCtx.getPreviousPath(d, f, !1));
          var x = m.line(s, E - o);
          if (_ = _ + m.line(r, k) + m.line(r, E - o) + x + (p.config.plotOptions.bar.borderRadiusApplication === "around" ? " Z" : " z"), h = h + m.line(s, k) + x + x + x + x + x + m.line(s, k) + (p.config.plotOptions.bar.borderRadiusApplication === "around" ? " Z" : " z"), this.shouldApplyRadius(d) && (_ = m.roundPathCorners(_, p.config.plotOptions.bar.borderRadius)), p.config.chart.stacked) {
            var S = this.barCtx;
            p.globals.hasSeriesGroups && c && (S = this.barCtx[c]), S.xArrj.push(r), S.xArrjF.push(Math.abs(s - r)), S.xArrjVal.push(this.barCtx.series[g][f]);
          }
          return { pathTo: _, pathFrom: h };
        } }, { key: "checkZeroSeries", value: function(e) {
          for (var t = e.series, i = this.w, a = 0; a < t.length; a++) {
            for (var s = 0, r = 0; r < t[i.globals.maxValsInArrayIndex].length; r++)
              s += t[a][r];
            s === 0 && this.barCtx.zeroSerieses.push(a);
          }
        } }, { key: "getXForValue", value: function(e, t) {
          var i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2] ? t : null;
          return e != null && (i = t + e / this.barCtx.invertedYRatio - 2 * (this.barCtx.isReversed ? e / this.barCtx.invertedYRatio : 0)), i;
        } }, { key: "getYForValue", value: function(e, t) {
          var i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2] ? t : null;
          return e != null && (i = t - e / this.barCtx.yRatio[this.barCtx.yaxisIndex] + 2 * (this.barCtx.isReversed ? e / this.barCtx.yRatio[this.barCtx.yaxisIndex] : 0)), i;
        } }, { key: "getGoalValues", value: function(e, t, i, a, s) {
          var r = this, o = this.w, c = [], d = function(p, m) {
            var w;
            c.push((T(w = {}, e, e === "x" ? r.getXForValue(p, t, !1) : r.getYForValue(p, i, !1)), T(w, "attrs", m), w));
          };
          if (o.globals.seriesGoals[a] && o.globals.seriesGoals[a][s] && Array.isArray(o.globals.seriesGoals[a][s]) && o.globals.seriesGoals[a][s].forEach(function(p) {
            d(p.value, p);
          }), this.barCtx.barOptions.isDumbbell && o.globals.seriesRange.length) {
            var g = this.barCtx.barOptions.dumbbellColors ? this.barCtx.barOptions.dumbbellColors : o.globals.colors, f = { strokeHeight: e === "x" ? 0 : o.globals.markers.size[a], strokeWidth: e === "x" ? o.globals.markers.size[a] : 0, strokeDashArray: 0, strokeLineCap: "round", strokeColor: Array.isArray(g[a]) ? g[a][0] : g[a] };
            d(o.globals.seriesRangeStart[a][s], f), d(o.globals.seriesRangeEnd[a][s], u(u({}, f), {}, { strokeColor: Array.isArray(g[a]) ? g[a][1] : g[a] }));
          }
          return c;
        } }, { key: "drawGoalLine", value: function(e) {
          var t = e.barXPosition, i = e.barYPosition, a = e.goalX, s = e.goalY, r = e.barWidth, o = e.barHeight, c = new X(this.barCtx.ctx), d = c.group({ className: "apexcharts-bar-goals-groups" });
          d.node.classList.add("apexcharts-element-hidden"), this.barCtx.w.globals.delayedElements.push({ el: d.node }), d.attr("clip-path", "url(#gridRectMarkerMask".concat(this.barCtx.w.globals.cuid, ")"));
          var g = null;
          return this.barCtx.isHorizontal ? Array.isArray(a) && a.forEach(function(f) {
            var p = f.attrs.strokeHeight !== void 0 ? f.attrs.strokeHeight : o / 2, m = i + p + o / 2;
            g = c.drawLine(f.x, m - 2 * p, f.x, m, f.attrs.strokeColor ? f.attrs.strokeColor : void 0, f.attrs.strokeDashArray, f.attrs.strokeWidth ? f.attrs.strokeWidth : 2, f.attrs.strokeLineCap), d.add(g);
          }) : Array.isArray(s) && s.forEach(function(f) {
            var p = f.attrs.strokeWidth !== void 0 ? f.attrs.strokeWidth : r / 2, m = t + p + r / 2;
            g = c.drawLine(m - 2 * p, f.y, m, f.y, f.attrs.strokeColor ? f.attrs.strokeColor : void 0, f.attrs.strokeDashArray, f.attrs.strokeHeight ? f.attrs.strokeHeight : 2, f.attrs.strokeLineCap), d.add(g);
          }), d;
        } }, { key: "drawBarShadow", value: function(e) {
          var t = e.prevPaths, i = e.currPaths, a = e.color, s = this.w, r = t.x, o = t.x1, c = t.barYPosition, d = i.x, g = i.x1, f = i.barYPosition, p = c + i.barHeight, m = new X(this.barCtx.ctx), w = new M(), C = m.move(o, p) + m.line(r, p) + m.line(d, f) + m.line(g, f) + m.line(o, p) + (s.config.plotOptions.bar.borderRadiusApplication === "around" ? " Z" : " z");
          return m.drawPath({ d: C, fill: w.shadeColor(0.5, M.rgb2hex(a)), stroke: "none", strokeWidth: 0, fillOpacity: 1, classes: "apexcharts-bar-shadows" });
        } }, { key: "getZeroValueEncounters", value: function(e) {
          var t = e.i, i = e.j, a = this.w, s = 0, r = 0;
          return a.globals.seriesPercent.forEach(function(o, c) {
            o[i] && s++, c < t && o[i] === 0 && r++;
          }), { nonZeroColumns: s, zeroEncounters: r };
        } }]), P;
      }(), bt = function() {
        function P(e, t) {
          y(this, P), this.ctx = e, this.w = e.w;
          var i = this.w;
          this.barOptions = i.config.plotOptions.bar, this.isHorizontal = this.barOptions.horizontal, this.strokeWidth = i.config.stroke.width, this.isNullValue = !1, this.isRangeBar = i.globals.seriesRange.length && this.isHorizontal, this.isVerticalGroupedRangeBar = !i.globals.isBarHorizontal && i.globals.seriesRange.length && i.config.plotOptions.bar.rangeBarGroupRows, this.isFunnel = this.barOptions.isFunnel, this.xyRatios = t, this.xyRatios !== null && (this.xRatio = t.xRatio, this.initialXRatio = t.initialXRatio, this.yRatio = t.yRatio, this.invertedXRatio = t.invertedXRatio, this.invertedYRatio = t.invertedYRatio, this.baseLineY = t.baseLineY, this.baseLineInvertedY = t.baseLineInvertedY), this.yaxisIndex = 0, this.seriesLen = 0, this.pathArr = [];
          var a = new de(this.ctx);
          this.lastActiveBarSerieIndex = a.getActiveConfigSeriesIndex("desc", ["bar", "column"]);
          var s = a.getBarSeriesIndices(), r = new $(this.ctx);
          this.stackedSeriesTotals = r.getStackedSeriesTotals(this.w.config.series.map(function(o, c) {
            return s.indexOf(c) === -1 ? c : -1;
          }).filter(function(o) {
            return o !== -1;
          })), this.barHelpers = new fs(this);
        }
        return A(P, [{ key: "draw", value: function(e, t) {
          var i = this.w, a = new X(this.ctx), s = new $(this.ctx, i);
          e = s.getLogSeries(e), this.series = e, this.yRatio = s.getLogYRatios(this.yRatio), this.barHelpers.initVariables(e);
          var r = a.group({ class: "apexcharts-bar-series apexcharts-plot-series" });
          i.config.dataLabels.enabled && this.totalItems > this.barOptions.dataLabels.maxItems && console.warn("WARNING: DataLabels are enabled but there are too many to display. This may cause performance issue when rendering - ApexCharts");
          for (var o = 0, c = 0; o < e.length; o++, c++) {
            var d, g, f, p, m = void 0, w = void 0, C = [], k = [], E = i.globals.comboCharts ? t[o] : o, _ = a.group({ class: "apexcharts-series", rel: o + 1, seriesName: M.escapeString(i.globals.seriesNames[E]), "data:realIndex": E });
            this.ctx.series.addCollapsedClassToSeries(_, E), e[o].length > 0 && (this.visibleI = this.visibleI + 1);
            var h = 0, x = 0;
            this.yRatio.length > 1 && (this.yaxisIndex = E), this.isReversed = i.config.yaxis[this.yaxisIndex] && i.config.yaxis[this.yaxisIndex].reversed;
            var S = this.barHelpers.initialPositions();
            w = S.y, h = S.barHeight, g = S.yDivision, p = S.zeroW, m = S.x, x = S.barWidth, d = S.xDivision, f = S.zeroH, this.horizontal || k.push(m + x / 2);
            var L = a.group({ class: "apexcharts-datalabels", "data:realIndex": E });
            i.globals.delayedElements.push({ el: L.node }), L.node.classList.add("apexcharts-element-hidden");
            var R = a.group({ class: "apexcharts-bar-goals-markers" }), O = a.group({ class: "apexcharts-bar-shadows" });
            i.globals.delayedElements.push({ el: O.node }), O.node.classList.add("apexcharts-element-hidden");
            for (var Y = 0; Y < i.globals.dataPoints; Y++) {
              var N = this.barHelpers.getStrokeWidth(o, Y, E), q = null, Z = { indexes: { i: o, j: Y, realIndex: E, bc: c }, x: m, y: w, strokeWidth: N, elSeries: _ };
              this.isHorizontal ? (q = this.drawBarPaths(u(u({}, Z), {}, { barHeight: h, zeroW: p, yDivision: g })), x = this.series[o][Y] / this.invertedYRatio) : (q = this.drawColumnPaths(u(u({}, Z), {}, { xDivision: d, barWidth: x, zeroH: f })), h = this.series[o][Y] / this.yRatio[this.yaxisIndex]);
              var U = this.barHelpers.getPathFillColor(e, o, Y, E);
              if (this.isFunnel && this.barOptions.isFunnel3d && this.pathArr.length && Y > 0) {
                var se = this.barHelpers.drawBarShadow({ color: typeof U == "string" && (U == null ? void 0 : U.indexOf("url")) === -1 ? U : M.hexToRgba(i.globals.colors[o]), prevPaths: this.pathArr[this.pathArr.length - 1], currPaths: q });
                se && O.add(se);
              }
              this.pathArr.push(q);
              var he = this.barHelpers.drawGoalLine({ barXPosition: q.barXPosition, barYPosition: q.barYPosition, goalX: q.goalX, goalY: q.goalY, barHeight: h, barWidth: x });
              he && R.add(he), w = q.y, m = q.x, Y > 0 && k.push(m + x / 2), C.push(w), this.renderSeries({ realIndex: E, pathFill: U, j: Y, i: o, pathFrom: q.pathFrom, pathTo: q.pathTo, strokeWidth: N, elSeries: _, x: m, y: w, series: e, barHeight: q.barHeight ? q.barHeight : h, barWidth: q.barWidth ? q.barWidth : x, elDataLabelsWrap: L, elGoalsMarkers: R, elBarShadows: O, visibleSeries: this.visibleI, type: "bar" });
            }
            i.globals.seriesXvalues[E] = k, i.globals.seriesYvalues[E] = C, r.add(_);
          }
          return r;
        } }, { key: "renderSeries", value: function(e) {
          var t = e.realIndex, i = e.pathFill, a = e.lineFill, s = e.j, r = e.i, o = e.groupIndex, c = e.pathFrom, d = e.pathTo, g = e.strokeWidth, f = e.elSeries, p = e.x, m = e.y, w = e.y1, C = e.y2, k = e.series, E = e.barHeight, _ = e.barWidth, h = e.barXPosition, x = e.barYPosition, S = e.elDataLabelsWrap, L = e.elGoalsMarkers, R = e.elBarShadows, O = e.visibleSeries, Y = e.type, N = this.w, q = new X(this.ctx);
          a || (a = this.barOptions.distributed ? N.globals.stroke.colors[s] : N.globals.stroke.colors[t]), N.config.series[r].data[s] && N.config.series[r].data[s].strokeColor && (a = N.config.series[r].data[s].strokeColor), this.isNullValue && (i = "none");
          var Z = s / N.config.chart.animations.animateGradually.delay * (N.config.chart.animations.speed / N.globals.dataPoints) / 2.4, U = q.renderPaths({ i: r, j: s, realIndex: t, pathFrom: c, pathTo: d, stroke: a, strokeWidth: g, strokeLineCap: N.config.stroke.lineCap, fill: i, animationDelay: Z, initialSpeed: N.config.chart.animations.speed, dataChangeSpeed: N.config.chart.animations.dynamicAnimation.speed, className: "apexcharts-".concat(Y, "-area") });
          U.attr("clip-path", "url(#gridRectMask".concat(N.globals.cuid, ")"));
          var se = N.config.forecastDataPoints;
          se.count > 0 && s >= N.globals.dataPoints - se.count && (U.node.setAttribute("stroke-dasharray", se.dashArray), U.node.setAttribute("stroke-width", se.strokeWidth), U.node.setAttribute("fill-opacity", se.fillOpacity)), w !== void 0 && C !== void 0 && (U.attr("data-range-y1", w), U.attr("data-range-y2", C)), new G(this.ctx).setSelectionFilter(U, t, s), f.add(U);
          var he = new gs(this).handleBarDataLabels({ x: p, y: m, y1: w, y2: C, i: r, j: s, series: k, realIndex: t, groupIndex: o, barHeight: E, barWidth: _, barXPosition: h, barYPosition: x, renderedPath: U, visibleSeries: O });
          return he.dataLabels !== null && S.add(he.dataLabels), he.totalDataLabels && S.add(he.totalDataLabels), f.add(S), L && f.add(L), R && f.add(R), f;
        } }, { key: "drawBarPaths", value: function(e) {
          var t, i = e.indexes, a = e.barHeight, s = e.strokeWidth, r = e.zeroW, o = e.x, c = e.y, d = e.yDivision, g = e.elSeries, f = this.w, p = i.i, m = i.j;
          if (f.globals.isXNumeric)
            t = (c = (f.globals.seriesX[p][m] - f.globals.minX) / this.invertedXRatio - a) + a * this.visibleI;
          else if (f.config.plotOptions.bar.hideZeroBarsWhenGrouped) {
            var w = 0, C = 0;
            f.globals.seriesPercent.forEach(function(E, _) {
              E[m] && w++, _ < p && E[m] === 0 && C++;
            }), w > 0 && (a = this.seriesLen * a / w), t = c + a * this.visibleI, t -= a * C;
          } else
            t = c + a * this.visibleI;
          this.isFunnel && (r -= (this.barHelpers.getXForValue(this.series[p][m], r) - r) / 2), o = this.barHelpers.getXForValue(this.series[p][m], r);
          var k = this.barHelpers.getBarpaths({ barYPosition: t, barHeight: a, x1: r, x2: o, strokeWidth: s, series: this.series, realIndex: i.realIndex, i: p, j: m, w: f });
          return f.globals.isXNumeric || (c += d), this.barHelpers.barBackground({ j: m, i: p, y1: t - a * this.visibleI, y2: a * this.seriesLen, elSeries: g }), { pathTo: k.pathTo, pathFrom: k.pathFrom, x1: r, x: o, y: c, goalX: this.barHelpers.getGoalValues("x", r, null, p, m), barYPosition: t, barHeight: a };
        } }, { key: "drawColumnPaths", value: function(e) {
          var t, i = e.indexes, a = e.x, s = e.y, r = e.xDivision, o = e.barWidth, c = e.zeroH, d = e.strokeWidth, g = e.elSeries, f = this.w, p = i.realIndex, m = i.i, w = i.j, C = i.bc;
          if (f.globals.isXNumeric) {
            var k = this.getBarXForNumericXAxis({ x: a, j: w, realIndex: p, barWidth: o });
            a = k.x, t = k.barXPosition;
          } else if (f.config.plotOptions.bar.hideZeroBarsWhenGrouped) {
            var E = this.barHelpers.getZeroValueEncounters({ i: m, j: w }), _ = E.nonZeroColumns, h = E.zeroEncounters;
            _ > 0 && (o = this.seriesLen * o / _), t = a + o * this.visibleI, t -= o * h;
          } else
            t = a + o * this.visibleI;
          s = this.barHelpers.getYForValue(this.series[m][w], c);
          var x = this.barHelpers.getColumnPaths({ barXPosition: t, barWidth: o, y1: c, y2: s, strokeWidth: d, series: this.series, realIndex: i.realIndex, i: m, j: w, w: f });
          return f.globals.isXNumeric || (a += r), this.barHelpers.barBackground({ bc: C, j: w, i: m, x1: t - d / 2 - o * this.visibleI, x2: o * this.seriesLen + d / 2, elSeries: g }), { pathTo: x.pathTo, pathFrom: x.pathFrom, x: a, y: s, goalY: this.barHelpers.getGoalValues("y", null, c, m, w), barXPosition: t, barWidth: o };
        } }, { key: "getBarXForNumericXAxis", value: function(e) {
          var t = e.x, i = e.barWidth, a = e.realIndex, s = e.j, r = this.w, o = a;
          return r.globals.seriesX[a].length || (o = r.globals.maxValsInArrayIndex), r.globals.seriesX[o][s] && (t = (r.globals.seriesX[o][s] - r.globals.minX) / this.xRatio - i * this.seriesLen / 2), { barXPosition: t + i * this.visibleI, x: t };
        } }, { key: "getPreviousPath", value: function(e, t) {
          for (var i, a = this.w, s = 0; s < a.globals.previousPaths.length; s++) {
            var r = a.globals.previousPaths[s];
            r.paths && r.paths.length > 0 && parseInt(r.realIndex, 10) === parseInt(e, 10) && a.globals.previousPaths[s].paths[t] !== void 0 && (i = a.globals.previousPaths[s].paths[t].d);
          }
          return i;
        } }]), P;
      }(), Yi = function(P) {
        z(t, P);
        var e = W(t);
        function t() {
          return y(this, t), e.apply(this, arguments);
        }
        return A(t, [{ key: "draw", value: function(i, a) {
          var s = this, r = this.w;
          this.graphics = new X(this.ctx), this.bar = new bt(this.ctx, this.xyRatios);
          var o = new $(this.ctx, r);
          i = o.getLogSeries(i), this.yRatio = o.getLogYRatios(this.yRatio), this.barHelpers.initVariables(i), r.config.chart.stackType === "100%" && (i = r.globals.seriesPercent.slice()), this.series = i, this.barHelpers.initializeStackedPrevVars(this);
          for (var c = this.graphics.group({ class: "apexcharts-bar-series apexcharts-plot-series" }), d = 0, g = 0, f = function(w, C) {
            var k = void 0, E = void 0, _ = void 0, h = void 0, x = -1;
            s.groupCtx = s, r.globals.seriesGroups.forEach(function(Ie, Oe) {
              Ie.indexOf(r.config.series[w].name) > -1 && (x = Oe);
            }), x !== -1 && (s.groupCtx = s[r.globals.seriesGroups[x]]);
            var S = [], L = [], R = r.globals.comboCharts ? a[w] : w;
            s.yRatio.length > 1 && (s.yaxisIndex = R), s.isReversed = r.config.yaxis[s.yaxisIndex] && r.config.yaxis[s.yaxisIndex].reversed;
            var O = s.graphics.group({ class: "apexcharts-series", seriesName: M.escapeString(r.globals.seriesNames[R]), rel: w + 1, "data:realIndex": R });
            s.ctx.series.addCollapsedClassToSeries(O, R);
            var Y = s.graphics.group({ class: "apexcharts-datalabels", "data:realIndex": R }), N = s.graphics.group({ class: "apexcharts-bar-goals-markers" }), q = 0, Z = 0, U = s.initialPositions(d, g, k, E, _, h);
            g = U.y, q = U.barHeight, E = U.yDivision, h = U.zeroW, d = U.x, Z = U.barWidth, k = U.xDivision, _ = U.zeroH, r.globals.barHeight = q, r.globals.barWidth = Z, s.barHelpers.initializeStackedXYVars(s), s.groupCtx.prevY.length === 1 && s.groupCtx.prevY[0].every(function(Ie) {
              return isNaN(Ie);
            }) && (s.groupCtx.prevY[0] = s.groupCtx.prevY[0].map(function(Ie) {
              return _;
            }), s.groupCtx.prevYF[0] = s.groupCtx.prevYF[0].map(function(Ie) {
              return 0;
            }));
            for (var se = 0; se < r.globals.dataPoints; se++) {
              var he = s.barHelpers.getStrokeWidth(w, se, R), me = { indexes: { i: w, j: se, realIndex: R, bc: C }, strokeWidth: he, x: d, y: g, elSeries: O, groupIndex: x, seriesGroup: r.globals.seriesGroups[x] }, fe = null;
              s.isHorizontal ? (fe = s.drawStackedBarPaths(u(u({}, me), {}, { zeroW: h, barHeight: q, yDivision: E })), Z = s.series[w][se] / s.invertedYRatio) : (fe = s.drawStackedColumnPaths(u(u({}, me), {}, { xDivision: k, barWidth: Z, zeroH: _ })), q = s.series[w][se] / s.yRatio[s.yaxisIndex]);
              var Ce = s.barHelpers.drawGoalLine({ barXPosition: fe.barXPosition, barYPosition: fe.barYPosition, goalX: fe.goalX, goalY: fe.goalY, barHeight: q, barWidth: Z });
              Ce && N.add(Ce), g = fe.y, d = fe.x, S.push(d), L.push(g);
              var Ne = s.barHelpers.getPathFillColor(i, w, se, R);
              O = s.renderSeries({ realIndex: R, pathFill: Ne, j: se, i: w, groupIndex: x, pathFrom: fe.pathFrom, pathTo: fe.pathTo, strokeWidth: he, elSeries: O, x: d, y: g, series: i, barHeight: q, barWidth: Z, elDataLabelsWrap: Y, elGoalsMarkers: N, type: "bar", visibleSeries: 0 });
            }
            r.globals.seriesXvalues[R] = S, r.globals.seriesYvalues[R] = L, s.groupCtx.prevY.push(s.groupCtx.yArrj), s.groupCtx.prevYF.push(s.groupCtx.yArrjF), s.groupCtx.prevYVal.push(s.groupCtx.yArrjVal), s.groupCtx.prevX.push(s.groupCtx.xArrj), s.groupCtx.prevXF.push(s.groupCtx.xArrjF), s.groupCtx.prevXVal.push(s.groupCtx.xArrjVal), c.add(O);
          }, p = 0, m = 0; p < i.length; p++, m++)
            f(p, m);
          return c;
        } }, { key: "initialPositions", value: function(i, a, s, r, o, c) {
          var d, g, f, p, m = this.w;
          return this.isHorizontal ? (f = (f = r = m.globals.gridHeight / m.globals.dataPoints) * parseInt(m.config.plotOptions.bar.barHeight, 10) / 100, String(m.config.plotOptions.bar.barHeight).indexOf("%") === -1 && (f = parseInt(m.config.plotOptions.bar.barHeight, 10)), c = this.baseLineInvertedY + m.globals.padHorizontal + (this.isReversed ? m.globals.gridWidth : 0) - (this.isReversed ? 2 * this.baseLineInvertedY : 0), a = (r - f) / 2) : (p = s = m.globals.gridWidth / m.globals.dataPoints, p = m.globals.isXNumeric && m.globals.dataPoints > 1 ? (s = m.globals.minXDiff / this.xRatio) * parseInt(this.barOptions.columnWidth, 10) / 100 : p * parseInt(m.config.plotOptions.bar.columnWidth, 10) / 100, String(m.config.plotOptions.bar.columnWidth).indexOf("%") === -1 && (p = parseInt(m.config.plotOptions.bar.columnWidth, 10)), o = m.globals.gridHeight - this.baseLineY[this.yaxisIndex] - (this.isReversed ? m.globals.gridHeight : 0) + (this.isReversed ? 2 * this.baseLineY[this.yaxisIndex] : 0), i = m.globals.padHorizontal + (s - p) / 2), { x: i, y: a, yDivision: r, xDivision: s, barHeight: (d = m.globals.seriesGroups) !== null && d !== void 0 && d.length ? f / m.globals.seriesGroups.length : f, barWidth: (g = m.globals.seriesGroups) !== null && g !== void 0 && g.length ? p / m.globals.seriesGroups.length : p, zeroH: o, zeroW: c };
        } }, { key: "drawStackedBarPaths", value: function(i) {
          for (var a, s = i.indexes, r = i.barHeight, o = i.strokeWidth, c = i.zeroW, d = i.x, g = i.y, f = i.groupIndex, p = i.seriesGroup, m = i.yDivision, w = i.elSeries, C = this.w, k = g + (f !== -1 ? f * r : 0), E = s.i, _ = s.j, h = 0, x = 0; x < this.groupCtx.prevXF.length; x++)
            h += this.groupCtx.prevXF[x][_];
          var S = E;
          if (p && (S = p.indexOf(C.config.series[E].name)), S > 0) {
            var L = c;
            this.groupCtx.prevXVal[S - 1][_] < 0 ? L = this.series[E][_] >= 0 ? this.groupCtx.prevX[S - 1][_] + h - 2 * (this.isReversed ? h : 0) : this.groupCtx.prevX[S - 1][_] : this.groupCtx.prevXVal[S - 1][_] >= 0 && (L = this.series[E][_] >= 0 ? this.groupCtx.prevX[S - 1][_] : this.groupCtx.prevX[S - 1][_] - h + 2 * (this.isReversed ? h : 0)), a = L;
          } else
            a = c;
          d = this.series[E][_] === null ? a : a + this.series[E][_] / this.invertedYRatio - 2 * (this.isReversed ? this.series[E][_] / this.invertedYRatio : 0);
          var R = this.barHelpers.getBarpaths({ barYPosition: k, barHeight: r, x1: a, x2: d, strokeWidth: o, series: this.series, realIndex: s.realIndex, seriesGroup: p, i: E, j: _, w: C });
          return this.barHelpers.barBackground({ j: _, i: E, y1: k, y2: r, elSeries: w }), g += m, { pathTo: R.pathTo, pathFrom: R.pathFrom, goalX: this.barHelpers.getGoalValues("x", c, null, E, _), barYPosition: k, x: d, y: g };
        } }, { key: "drawStackedColumnPaths", value: function(i) {
          var a = i.indexes, s = i.x, r = i.y, o = i.xDivision, c = i.barWidth, d = i.zeroH, g = i.groupIndex, f = i.seriesGroup, p = i.elSeries, m = this.w, w = a.i, C = a.j, k = a.bc;
          if (m.globals.isXNumeric) {
            var E = m.globals.seriesX[w][C];
            E || (E = 0), s = (E - m.globals.minX) / this.xRatio - c / 2, m.globals.seriesGroups.length && (s = (E - m.globals.minX) / this.xRatio - c / 2 * m.globals.seriesGroups.length);
          }
          for (var _, h = s + (g !== -1 ? g * c : 0), x = 0, S = 0; S < this.groupCtx.prevYF.length; S++)
            x += isNaN(this.groupCtx.prevYF[S][C]) ? 0 : this.groupCtx.prevYF[S][C];
          var L = w;
          if (f && (L = f.indexOf(m.config.series[w].name)), L > 0 && !m.globals.isXNumeric || L > 0 && m.globals.isXNumeric && m.globals.seriesX[w - 1][C] === m.globals.seriesX[w][C]) {
            var R, O, Y, N = Math.min(this.yRatio.length + 1, w + 1);
            if (this.groupCtx.prevY[L - 1] !== void 0 && this.groupCtx.prevY[L - 1].length)
              for (var q = 1; q < N; q++) {
                var Z;
                if (!isNaN((Z = this.groupCtx.prevY[L - q]) === null || Z === void 0 ? void 0 : Z[C])) {
                  Y = this.groupCtx.prevY[L - q][C];
                  break;
                }
              }
            for (var U = 1; U < N; U++) {
              var se, he;
              if (((se = this.groupCtx.prevYVal[L - U]) === null || se === void 0 ? void 0 : se[C]) < 0) {
                O = this.series[w][C] >= 0 ? Y - x + 2 * (this.isReversed ? x : 0) : Y;
                break;
              }
              if (((he = this.groupCtx.prevYVal[L - U]) === null || he === void 0 ? void 0 : he[C]) >= 0) {
                O = this.series[w][C] >= 0 ? Y : Y + x - 2 * (this.isReversed ? x : 0);
                break;
              }
            }
            O === void 0 && (O = m.globals.gridHeight), _ = (R = this.groupCtx.prevYF[0]) !== null && R !== void 0 && R.every(function(fe) {
              return fe === 0;
            }) && this.groupCtx.prevYF.slice(1, L).every(function(fe) {
              return fe.every(function(Ce) {
                return isNaN(Ce);
              });
            }) ? d : O;
          } else
            _ = d;
          r = this.series[w][C] ? _ - this.series[w][C] / this.yRatio[this.yaxisIndex] + 2 * (this.isReversed ? this.series[w][C] / this.yRatio[this.yaxisIndex] : 0) : _;
          var me = this.barHelpers.getColumnPaths({ barXPosition: h, barWidth: c, y1: _, y2: r, yRatio: this.yRatio[this.yaxisIndex], strokeWidth: this.strokeWidth, series: this.series, seriesGroup: f, realIndex: a.realIndex, i: w, j: C, w: m });
          return this.barHelpers.barBackground({ bc: k, j: C, i: w, x1: h, x2: c, elSeries: p }), s += o, { pathTo: me.pathTo, pathFrom: me.pathFrom, goalY: this.barHelpers.getGoalValues("y", null, d, w, C), barXPosition: h, x: m.globals.isXNumeric ? s - o : s, y: r };
        } }]), t;
      }(bt), ti = function(P) {
        z(t, P);
        var e = W(t);
        function t() {
          return y(this, t), e.apply(this, arguments);
        }
        return A(t, [{ key: "draw", value: function(i, a, s) {
          var r = this, o = this.w, c = new X(this.ctx), d = o.globals.comboCharts ? a : o.config.chart.type, g = new ae(this.ctx);
          this.candlestickOptions = this.w.config.plotOptions.candlestick, this.boxOptions = this.w.config.plotOptions.boxPlot, this.isHorizontal = o.config.plotOptions.bar.horizontal;
          var f = new $(this.ctx, o);
          i = f.getLogSeries(i), this.series = i, this.yRatio = f.getLogYRatios(this.yRatio), this.barHelpers.initVariables(i);
          for (var p = c.group({ class: "apexcharts-".concat(d, "-series apexcharts-plot-series") }), m = function(C) {
            r.isBoxPlot = o.config.chart.type === "boxPlot" || o.config.series[C].type === "boxPlot";
            var k, E, _, h, x = void 0, S = void 0, L = [], R = [], O = o.globals.comboCharts ? s[C] : C, Y = c.group({ class: "apexcharts-series", seriesName: M.escapeString(o.globals.seriesNames[O]), rel: C + 1, "data:realIndex": O });
            r.ctx.series.addCollapsedClassToSeries(Y, O), i[C].length > 0 && (r.visibleI = r.visibleI + 1);
            var N, q;
            r.yRatio.length > 1 && (r.yaxisIndex = O);
            var Z = r.barHelpers.initialPositions();
            S = Z.y, N = Z.barHeight, E = Z.yDivision, h = Z.zeroW, x = Z.x, q = Z.barWidth, k = Z.xDivision, _ = Z.zeroH, R.push(x + q / 2);
            for (var U = c.group({ class: "apexcharts-datalabels", "data:realIndex": O }), se = function(me) {
              var fe = r.barHelpers.getStrokeWidth(C, me, O), Ce = null, Ne = { indexes: { i: C, j: me, realIndex: O }, x, y: S, strokeWidth: fe, elSeries: Y };
              Ce = r.isHorizontal ? r.drawHorizontalBoxPaths(u(u({}, Ne), {}, { yDivision: E, barHeight: N, zeroW: h })) : r.drawVerticalBoxPaths(u(u({}, Ne), {}, { xDivision: k, barWidth: q, zeroH: _ })), S = Ce.y, x = Ce.x, me > 0 && R.push(x + q / 2), L.push(S), Ce.pathTo.forEach(function(Ie, Oe) {
                var Ue = !r.isBoxPlot && r.candlestickOptions.wick.useFillColor ? Ce.color[Oe] : o.globals.stroke.colors[C], Ke = g.fillPath({ seriesNumber: O, dataPointIndex: me, color: Ce.color[Oe], value: i[C][me] });
                r.renderSeries({ realIndex: O, pathFill: Ke, lineFill: Ue, j: me, i: C, pathFrom: Ce.pathFrom, pathTo: Ie, strokeWidth: fe, elSeries: Y, x, y: S, series: i, barHeight: N, barWidth: q, elDataLabelsWrap: U, visibleSeries: r.visibleI, type: o.config.chart.type });
              });
            }, he = 0; he < o.globals.dataPoints; he++)
              se(he);
            o.globals.seriesXvalues[O] = R, o.globals.seriesYvalues[O] = L, p.add(Y);
          }, w = 0; w < i.length; w++)
            m(w);
          return p;
        } }, { key: "drawVerticalBoxPaths", value: function(i) {
          var a = i.indexes, s = i.x;
          i.y;
          var r = i.xDivision, o = i.barWidth, c = i.zeroH, d = i.strokeWidth, g = this.w, f = new X(this.ctx), p = a.i, m = a.j, w = !0, C = g.config.plotOptions.candlestick.colors.upward, k = g.config.plotOptions.candlestick.colors.downward, E = "";
          this.isBoxPlot && (E = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
          var _ = this.yRatio[this.yaxisIndex], h = a.realIndex, x = this.getOHLCValue(h, m), S = c, L = c;
          x.o > x.c && (w = !1);
          var R = Math.min(x.o, x.c), O = Math.max(x.o, x.c), Y = x.m;
          g.globals.isXNumeric && (s = (g.globals.seriesX[h][m] - g.globals.minX) / this.xRatio - o / 2);
          var N = s + o * this.visibleI;
          this.series[p][m] === void 0 || this.series[p][m] === null ? (R = c, O = c) : (R = c - R / _, O = c - O / _, S = c - x.h / _, L = c - x.l / _, Y = c - x.m / _);
          var q = f.move(N, c), Z = f.move(N + o / 2, R);
          return g.globals.previousPaths.length > 0 && (Z = this.getPreviousPath(h, m, !0)), q = this.isBoxPlot ? [f.move(N, R) + f.line(N + o / 2, R) + f.line(N + o / 2, S) + f.line(N + o / 4, S) + f.line(N + o - o / 4, S) + f.line(N + o / 2, S) + f.line(N + o / 2, R) + f.line(N + o, R) + f.line(N + o, Y) + f.line(N, Y) + f.line(N, R + d / 2), f.move(N, Y) + f.line(N + o, Y) + f.line(N + o, O) + f.line(N + o / 2, O) + f.line(N + o / 2, L) + f.line(N + o - o / 4, L) + f.line(N + o / 4, L) + f.line(N + o / 2, L) + f.line(N + o / 2, O) + f.line(N, O) + f.line(N, Y) + "z"] : [f.move(N, O) + f.line(N + o / 2, O) + f.line(N + o / 2, S) + f.line(N + o / 2, O) + f.line(N + o, O) + f.line(N + o, R) + f.line(N + o / 2, R) + f.line(N + o / 2, L) + f.line(N + o / 2, R) + f.line(N, R) + f.line(N, O - d / 2)], Z += f.move(N, R), g.globals.isXNumeric || (s += r), { pathTo: q, pathFrom: Z, x: s, y: O, barXPosition: N, color: this.isBoxPlot ? E : w ? [C] : [k] };
        } }, { key: "drawHorizontalBoxPaths", value: function(i) {
          var a = i.indexes;
          i.x;
          var s = i.y, r = i.yDivision, o = i.barHeight, c = i.zeroW, d = i.strokeWidth, g = this.w, f = new X(this.ctx), p = a.i, m = a.j, w = this.boxOptions.colors.lower;
          this.isBoxPlot && (w = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
          var C = this.invertedYRatio, k = a.realIndex, E = this.getOHLCValue(k, m), _ = c, h = c, x = Math.min(E.o, E.c), S = Math.max(E.o, E.c), L = E.m;
          g.globals.isXNumeric && (s = (g.globals.seriesX[k][m] - g.globals.minX) / this.invertedXRatio - o / 2);
          var R = s + o * this.visibleI;
          this.series[p][m] === void 0 || this.series[p][m] === null ? (x = c, S = c) : (x = c + x / C, S = c + S / C, _ = c + E.h / C, h = c + E.l / C, L = c + E.m / C);
          var O = f.move(c, R), Y = f.move(x, R + o / 2);
          return g.globals.previousPaths.length > 0 && (Y = this.getPreviousPath(k, m, !0)), O = [f.move(x, R) + f.line(x, R + o / 2) + f.line(_, R + o / 2) + f.line(_, R + o / 2 - o / 4) + f.line(_, R + o / 2 + o / 4) + f.line(_, R + o / 2) + f.line(x, R + o / 2) + f.line(x, R + o) + f.line(L, R + o) + f.line(L, R) + f.line(x + d / 2, R), f.move(L, R) + f.line(L, R + o) + f.line(S, R + o) + f.line(S, R + o / 2) + f.line(h, R + o / 2) + f.line(h, R + o - o / 4) + f.line(h, R + o / 4) + f.line(h, R + o / 2) + f.line(S, R + o / 2) + f.line(S, R) + f.line(L, R) + "z"], Y += f.move(x, R), g.globals.isXNumeric || (s += r), { pathTo: O, pathFrom: Y, x: S, y: s, barYPosition: R, color: w };
        } }, { key: "getOHLCValue", value: function(i, a) {
          var s = this.w;
          return { o: this.isBoxPlot ? s.globals.seriesCandleH[i][a] : s.globals.seriesCandleO[i][a], h: this.isBoxPlot ? s.globals.seriesCandleO[i][a] : s.globals.seriesCandleH[i][a], m: s.globals.seriesCandleM[i][a], l: this.isBoxPlot ? s.globals.seriesCandleC[i][a] : s.globals.seriesCandleL[i][a], c: this.isBoxPlot ? s.globals.seriesCandleL[i][a] : s.globals.seriesCandleC[i][a] };
        } }]), t;
      }(bt), Ni = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "checkColorRange", value: function() {
          var e = this.w, t = !1, i = e.config.plotOptions[e.config.chart.type];
          return i.colorScale.ranges.length > 0 && i.colorScale.ranges.map(function(a, s) {
            a.from <= 0 && (t = !0);
          }), t;
        } }, { key: "getShadeColor", value: function(e, t, i, a) {
          var s = this.w, r = 1, o = s.config.plotOptions[e].shadeIntensity, c = this.determineColor(e, t, i);
          s.globals.hasNegs || a ? r = s.config.plotOptions[e].reverseNegativeShade ? c.percent < 0 ? c.percent / 100 * (1.25 * o) : (1 - c.percent / 100) * (1.25 * o) : c.percent <= 0 ? 1 - (1 + c.percent / 100) * o : (1 - c.percent / 100) * o : (r = 1 - c.percent / 100, e === "treemap" && (r = (1 - c.percent / 100) * (1.25 * o)));
          var d = c.color, g = new M();
          return s.config.plotOptions[e].enableShades && (d = this.w.config.theme.mode === "dark" ? M.hexToRgba(g.shadeColor(-1 * r, c.color), s.config.fill.opacity) : M.hexToRgba(g.shadeColor(r, c.color), s.config.fill.opacity)), { color: d, colorProps: c };
        } }, { key: "determineColor", value: function(e, t, i) {
          var a = this.w, s = a.globals.series[t][i], r = a.config.plotOptions[e], o = r.colorScale.inverse ? i : t;
          r.distributed && a.config.chart.type === "treemap" && (o = i);
          var c = a.globals.colors[o], d = null, g = Math.min.apply(Math, j(a.globals.series[t])), f = Math.max.apply(Math, j(a.globals.series[t]));
          r.distributed || e !== "heatmap" || (g = a.globals.minY, f = a.globals.maxY), r.colorScale.min !== void 0 && (g = r.colorScale.min < a.globals.minY ? r.colorScale.min : a.globals.minY, f = r.colorScale.max > a.globals.maxY ? r.colorScale.max : a.globals.maxY);
          var p = Math.abs(f) + Math.abs(g), m = 100 * s / (p === 0 ? p - 1e-6 : p);
          return r.colorScale.ranges.length > 0 && r.colorScale.ranges.map(function(w, C) {
            if (s >= w.from && s <= w.to) {
              c = w.color, d = w.foreColor ? w.foreColor : null, g = w.from, f = w.to;
              var k = Math.abs(f) + Math.abs(g);
              m = 100 * s / (k === 0 ? k - 1e-6 : k);
            }
          }), { color: c, foreColor: d, percent: m };
        } }, { key: "calculateDataLabels", value: function(e) {
          var t = e.text, i = e.x, a = e.y, s = e.i, r = e.j, o = e.colorProps, c = e.fontSize, d = this.w.config.dataLabels, g = new X(this.ctx), f = new xe(this.ctx), p = null;
          if (d.enabled) {
            p = g.group({ class: "apexcharts-data-labels" });
            var m = d.offsetX, w = d.offsetY, C = i + m, k = a + parseFloat(d.style.fontSize) / 3 + w;
            f.plotDataLabelsText({ x: C, y: k, text: t, i: s, j: r, color: o.foreColor, parent: p, fontSize: c, dataLabelsConfig: d });
          }
          return p;
        } }, { key: "addListeners", value: function(e) {
          var t = new X(this.ctx);
          e.node.addEventListener("mouseenter", t.pathMouseEnter.bind(this, e)), e.node.addEventListener("mouseleave", t.pathMouseLeave.bind(this, e)), e.node.addEventListener("mousedown", t.pathMouseDown.bind(this, e));
        } }]), P;
      }(), ps = function() {
        function P(e, t) {
          y(this, P), this.ctx = e, this.w = e.w, this.xRatio = t.xRatio, this.yRatio = t.yRatio, this.dynamicAnim = this.w.config.chart.animations.dynamicAnimation, this.helpers = new Ni(e), this.rectRadius = this.w.config.plotOptions.heatmap.radius, this.strokeWidth = this.w.config.stroke.show ? this.w.config.stroke.width : 0;
        }
        return A(P, [{ key: "draw", value: function(e) {
          var t = this.w, i = new X(this.ctx), a = i.group({ class: "apexcharts-heatmap" });
          a.attr("clip-path", "url(#gridRectMask".concat(t.globals.cuid, ")"));
          var s = t.globals.gridWidth / t.globals.dataPoints, r = t.globals.gridHeight / t.globals.series.length, o = 0, c = !1;
          this.negRange = this.helpers.checkColorRange();
          var d = e.slice();
          t.config.yaxis[0].reversed && (c = !0, d.reverse());
          for (var g = c ? 0 : d.length - 1; c ? g < d.length : g >= 0; c ? g++ : g--) {
            var f = i.group({ class: "apexcharts-series apexcharts-heatmap-series", seriesName: M.escapeString(t.globals.seriesNames[g]), rel: g + 1, "data:realIndex": g });
            if (this.ctx.series.addCollapsedClassToSeries(f, g), t.config.chart.dropShadow.enabled) {
              var p = t.config.chart.dropShadow;
              new G(this.ctx).dropShadow(f, p, g);
            }
            for (var m = 0, w = t.config.plotOptions.heatmap.shadeIntensity, C = 0; C < d[g].length; C++) {
              var k = this.helpers.getShadeColor(t.config.chart.type, g, C, this.negRange), E = k.color, _ = k.colorProps;
              t.config.fill.type === "image" && (E = new ae(this.ctx).fillPath({ seriesNumber: g, dataPointIndex: C, opacity: t.globals.hasNegs ? _.percent < 0 ? 1 - (1 + _.percent / 100) : w + _.percent / 100 : _.percent / 100, patternID: M.randomId(), width: t.config.fill.image.width ? t.config.fill.image.width : s, height: t.config.fill.image.height ? t.config.fill.image.height : r }));
              var h = this.rectRadius, x = i.drawRect(m, o, s, r, h);
              if (x.attr({ cx: m, cy: o }), x.node.classList.add("apexcharts-heatmap-rect"), f.add(x), x.attr({ fill: E, i: g, index: g, j: C, val: e[g][C], "stroke-width": this.strokeWidth, stroke: t.config.plotOptions.heatmap.useFillColorAsStroke ? E : t.globals.stroke.colors[0], color: E }), this.helpers.addListeners(x), t.config.chart.animations.enabled && !t.globals.dataChanged) {
                var S = 1;
                t.globals.resized || (S = t.config.chart.animations.speed), this.animateHeatMap(x, m, o, s, r, S);
              }
              if (t.globals.dataChanged) {
                var L = 1;
                if (this.dynamicAnim.enabled && t.globals.shouldAnimate) {
                  L = this.dynamicAnim.speed;
                  var R = t.globals.previousPaths[g] && t.globals.previousPaths[g][C] && t.globals.previousPaths[g][C].color;
                  R || (R = "rgba(255, 255, 255, 0)"), this.animateHeatColor(x, M.isColorHex(R) ? R : M.rgb2hex(R), M.isColorHex(E) ? E : M.rgb2hex(E), L);
                }
              }
              var O = (0, t.config.dataLabels.formatter)(t.globals.series[g][C], { value: t.globals.series[g][C], seriesIndex: g, dataPointIndex: C, w: t }), Y = this.helpers.calculateDataLabels({ text: O, x: m + s / 2, y: o + r / 2, i: g, j: C, colorProps: _, series: d });
              Y !== null && f.add(Y), m += s;
            }
            o += r, a.add(f);
          }
          var N = t.globals.yAxisScale[0].result.slice();
          return t.config.yaxis[0].reversed ? N.unshift("") : N.push(""), t.globals.yAxisScale[0].result = N, a;
        } }, { key: "animateHeatMap", value: function(e, t, i, a, s, r) {
          var o = new V(this.ctx);
          o.animateRect(e, { x: t + a / 2, y: i + s / 2, width: 0, height: 0 }, { x: t, y: i, width: a, height: s }, r, function() {
            o.animationCompleted(e);
          });
        } }, { key: "animateHeatColor", value: function(e, t, i, a) {
          e.attr({ fill: t }).animate(a).attr({ fill: i });
        } }]), P;
      }(), Hi = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "drawYAxisTexts", value: function(e, t, i, a) {
          var s = this.w, r = s.config.yaxis[0], o = s.globals.yLabelFormatters[0];
          return new X(this.ctx).drawText({ x: e + r.labels.offsetX, y: t + r.labels.offsetY, text: o(a, i), textAnchor: "middle", fontSize: r.labels.style.fontSize, fontFamily: r.labels.style.fontFamily, foreColor: Array.isArray(r.labels.style.colors) ? r.labels.style.colors[i] : r.labels.style.colors });
        } }]), P;
      }(), Bi = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
          var t = this.w;
          this.chartType = this.w.config.chart.type, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled, this.animBeginArr = [0], this.animDur = 0, this.donutDataLabels = this.w.config.plotOptions.pie.donut.labels, this.lineColorArr = t.globals.stroke.colors !== void 0 ? t.globals.stroke.colors : t.globals.colors, this.defaultSize = Math.min(t.globals.gridWidth, t.globals.gridHeight), this.centerY = this.defaultSize / 2, this.centerX = t.globals.gridWidth / 2, t.config.chart.type === "radialBar" ? this.fullAngle = 360 : this.fullAngle = Math.abs(t.config.plotOptions.pie.endAngle - t.config.plotOptions.pie.startAngle), this.initialAngle = t.config.plotOptions.pie.startAngle % this.fullAngle, t.globals.radialSize = this.defaultSize / 2.05 - t.config.stroke.width - (t.config.chart.sparkline.enabled ? 0 : t.config.chart.dropShadow.blur), this.donutSize = t.globals.radialSize * parseInt(t.config.plotOptions.pie.donut.size, 10) / 100, this.maxY = 0, this.sliceLabels = [], this.sliceSizes = [], this.prevSectorAngleArr = [];
        }
        return A(P, [{ key: "draw", value: function(e) {
          var t = this, i = this.w, a = new X(this.ctx);
          if (this.ret = a.group({ class: "apexcharts-pie" }), i.globals.noData)
            return this.ret;
          for (var s = 0, r = 0; r < e.length; r++)
            s += M.negToZero(e[r]);
          var o = [], c = a.group();
          s === 0 && (s = 1e-5), e.forEach(function(R) {
            t.maxY = Math.max(t.maxY, R);
          }), i.config.yaxis[0].max && (this.maxY = i.config.yaxis[0].max), i.config.grid.position === "back" && this.chartType === "polarArea" && this.drawPolarElements(this.ret);
          for (var d = 0; d < e.length; d++) {
            var g = this.fullAngle * M.negToZero(e[d]) / s;
            o.push(g), this.chartType === "polarArea" ? (o[d] = this.fullAngle / e.length, this.sliceSizes.push(i.globals.radialSize * e[d] / this.maxY)) : this.sliceSizes.push(i.globals.radialSize);
          }
          if (i.globals.dataChanged) {
            for (var f, p = 0, m = 0; m < i.globals.previousPaths.length; m++)
              p += M.negToZero(i.globals.previousPaths[m]);
            for (var w = 0; w < i.globals.previousPaths.length; w++)
              f = this.fullAngle * M.negToZero(i.globals.previousPaths[w]) / p, this.prevSectorAngleArr.push(f);
          }
          this.donutSize < 0 && (this.donutSize = 0);
          var C = i.config.plotOptions.pie.customScale, k = i.globals.gridWidth / 2, E = i.globals.gridHeight / 2, _ = k - i.globals.gridWidth / 2 * C, h = E - i.globals.gridHeight / 2 * C;
          if (this.chartType === "donut") {
            var x = a.drawCircle(this.donutSize);
            x.attr({ cx: this.centerX, cy: this.centerY, fill: i.config.plotOptions.pie.donut.background ? i.config.plotOptions.pie.donut.background : "transparent" }), c.add(x);
          }
          var S = this.drawArcs(o, e);
          if (this.sliceLabels.forEach(function(R) {
            S.add(R);
          }), c.attr({ transform: "translate(".concat(_, ", ").concat(h, ") scale(").concat(C, ")") }), c.add(S), this.ret.add(c), this.donutDataLabels.show) {
            var L = this.renderInnerDataLabels(this.donutDataLabels, { hollowSize: this.donutSize, centerX: this.centerX, centerY: this.centerY, opacity: this.donutDataLabels.show, translateX: _, translateY: h });
            this.ret.add(L);
          }
          return i.config.grid.position === "front" && this.chartType === "polarArea" && this.drawPolarElements(this.ret), this.ret;
        } }, { key: "drawArcs", value: function(e, t) {
          var i = this.w, a = new G(this.ctx), s = new X(this.ctx), r = new ae(this.ctx), o = s.group({ class: "apexcharts-slices" }), c = this.initialAngle, d = this.initialAngle, g = this.initialAngle, f = this.initialAngle;
          this.strokeWidth = i.config.stroke.show ? i.config.stroke.width : 0;
          for (var p = 0; p < e.length; p++) {
            var m = s.group({ class: "apexcharts-series apexcharts-pie-series", seriesName: M.escapeString(i.globals.seriesNames[p]), rel: p + 1, "data:realIndex": p });
            o.add(m), d = f, g = (c = g) + e[p], f = d + this.prevSectorAngleArr[p];
            var w = g < c ? this.fullAngle + g - c : g - c, C = r.fillPath({ seriesNumber: p, size: this.sliceSizes[p], value: t[p] }), k = this.getChangedPath(d, f), E = s.drawPath({ d: k, stroke: Array.isArray(this.lineColorArr) ? this.lineColorArr[p] : this.lineColorArr, strokeWidth: 0, fill: C, fillOpacity: i.config.fill.opacity, classes: "apexcharts-pie-area apexcharts-".concat(this.chartType.toLowerCase(), "-slice-").concat(p) });
            if (E.attr({ index: 0, j: p }), a.setSelectionFilter(E, 0, p), i.config.chart.dropShadow.enabled) {
              var _ = i.config.chart.dropShadow;
              a.dropShadow(E, _, p);
            }
            this.addListeners(E, this.donutDataLabels), X.setAttrs(E.node, { "data:angle": w, "data:startAngle": c, "data:strokeWidth": this.strokeWidth, "data:value": t[p] });
            var h = { x: 0, y: 0 };
            this.chartType === "pie" || this.chartType === "polarArea" ? h = M.polarToCartesian(this.centerX, this.centerY, i.globals.radialSize / 1.25 + i.config.plotOptions.pie.dataLabels.offset, (c + w / 2) % this.fullAngle) : this.chartType === "donut" && (h = M.polarToCartesian(this.centerX, this.centerY, (i.globals.radialSize + this.donutSize) / 2 + i.config.plotOptions.pie.dataLabels.offset, (c + w / 2) % this.fullAngle)), m.add(E);
            var x = 0;
            if (!this.initialAnim || i.globals.resized || i.globals.dataChanged ? this.animBeginArr.push(0) : ((x = w / this.fullAngle * i.config.chart.animations.speed) === 0 && (x = 1), this.animDur = x + this.animDur, this.animBeginArr.push(this.animDur)), this.dynamicAnim && i.globals.dataChanged ? this.animatePaths(E, { size: this.sliceSizes[p], endAngle: g, startAngle: c, prevStartAngle: d, prevEndAngle: f, animateStartingPos: !0, i: p, animBeginArr: this.animBeginArr, shouldSetPrevPaths: !0, dur: i.config.chart.animations.dynamicAnimation.speed }) : this.animatePaths(E, { size: this.sliceSizes[p], endAngle: g, startAngle: c, i: p, totalItems: e.length - 1, animBeginArr: this.animBeginArr, dur: x }), i.config.plotOptions.pie.expandOnClick && this.chartType !== "polarArea" && E.click(this.pieClicked.bind(this, p)), i.globals.selectedDataPoints[0] !== void 0 && i.globals.selectedDataPoints[0].indexOf(p) > -1 && this.pieClicked(p), i.config.dataLabels.enabled) {
              var S = h.x, L = h.y, R = 100 * w / this.fullAngle + "%";
              if (w !== 0 && i.config.plotOptions.pie.dataLabels.minAngleToShowLabel < e[p]) {
                var O = i.config.dataLabels.formatter;
                O !== void 0 && (R = O(i.globals.seriesPercent[p][0], { seriesIndex: p, w: i }));
                var Y = i.globals.dataLabels.style.colors[p], N = s.group({ class: "apexcharts-datalabels" }), q = s.drawText({ x: S, y: L, text: R, textAnchor: "middle", fontSize: i.config.dataLabels.style.fontSize, fontFamily: i.config.dataLabels.style.fontFamily, fontWeight: i.config.dataLabels.style.fontWeight, foreColor: Y });
                if (N.add(q), i.config.dataLabels.dropShadow.enabled) {
                  var Z = i.config.dataLabels.dropShadow;
                  a.dropShadow(q, Z);
                }
                q.node.classList.add("apexcharts-pie-label"), i.config.chart.animations.animate && i.globals.resized === !1 && (q.node.classList.add("apexcharts-pie-label-delay"), q.node.style.animationDelay = i.config.chart.animations.speed / 940 + "s"), this.sliceLabels.push(N);
              }
            }
          }
          return o;
        } }, { key: "addListeners", value: function(e, t) {
          var i = new X(this.ctx);
          e.node.addEventListener("mouseenter", i.pathMouseEnter.bind(this, e)), e.node.addEventListener("mouseleave", i.pathMouseLeave.bind(this, e)), e.node.addEventListener("mouseleave", this.revertDataLabelsInner.bind(this, e.node, t)), e.node.addEventListener("mousedown", i.pathMouseDown.bind(this, e)), this.donutDataLabels.total.showAlways || (e.node.addEventListener("mouseenter", this.printDataLabelsInner.bind(this, e.node, t)), e.node.addEventListener("mousedown", this.printDataLabelsInner.bind(this, e.node, t)));
        } }, { key: "animatePaths", value: function(e, t) {
          var i = this.w, a = t.endAngle < t.startAngle ? this.fullAngle + t.endAngle - t.startAngle : t.endAngle - t.startAngle, s = a, r = t.startAngle, o = t.startAngle;
          t.prevStartAngle !== void 0 && t.prevEndAngle !== void 0 && (r = t.prevEndAngle, s = t.prevEndAngle < t.prevStartAngle ? this.fullAngle + t.prevEndAngle - t.prevStartAngle : t.prevEndAngle - t.prevStartAngle), t.i === i.config.series.length - 1 && (a + o > this.fullAngle ? t.endAngle = t.endAngle - (a + o) : a + o < this.fullAngle && (t.endAngle = t.endAngle + (this.fullAngle - (a + o)))), a === this.fullAngle && (a = this.fullAngle - 0.01), this.animateArc(e, r, o, a, s, t);
        } }, { key: "animateArc", value: function(e, t, i, a, s, r) {
          var o, c = this, d = this.w, g = new V(this.ctx), f = r.size;
          (isNaN(t) || isNaN(s)) && (t = i, s = a, r.dur = 0);
          var p = a, m = i, w = t < i ? this.fullAngle + t - i : t - i;
          d.globals.dataChanged && r.shouldSetPrevPaths && r.prevEndAngle && (o = c.getPiePath({ me: c, startAngle: r.prevStartAngle, angle: r.prevEndAngle < r.prevStartAngle ? this.fullAngle + r.prevEndAngle - r.prevStartAngle : r.prevEndAngle - r.prevStartAngle, size: f }), e.attr({ d: o })), r.dur !== 0 ? e.animate(r.dur, d.globals.easing, r.animBeginArr[r.i]).afterAll(function() {
            c.chartType !== "pie" && c.chartType !== "donut" && c.chartType !== "polarArea" || this.animate(d.config.chart.animations.dynamicAnimation.speed).attr({ "stroke-width": c.strokeWidth }), r.i === d.config.series.length - 1 && g.animationCompleted(e);
          }).during(function(C) {
            p = w + (a - w) * C, r.animateStartingPos && (p = s + (a - s) * C, m = t - s + (i - (t - s)) * C), o = c.getPiePath({ me: c, startAngle: m, angle: p, size: f }), e.node.setAttribute("data:pathOrig", o), e.attr({ d: o });
          }) : (o = c.getPiePath({ me: c, startAngle: m, angle: a, size: f }), r.isTrack || (d.globals.animationEnded = !0), e.node.setAttribute("data:pathOrig", o), e.attr({ d: o, "stroke-width": c.strokeWidth }));
        } }, { key: "pieClicked", value: function(e) {
          var t, i = this.w, a = this, s = a.sliceSizes[e] + (i.config.plotOptions.pie.expandOnClick ? 4 : 0), r = i.globals.dom.Paper.select(".apexcharts-".concat(a.chartType.toLowerCase(), "-slice-").concat(e)).members[0];
          if (r.attr("data:pieClicked") !== "true") {
            var o = i.globals.dom.baseEl.getElementsByClassName("apexcharts-pie-area");
            Array.prototype.forEach.call(o, function(f) {
              f.setAttribute("data:pieClicked", "false");
              var p = f.getAttribute("data:pathOrig");
              p && f.setAttribute("d", p);
            }), r.attr("data:pieClicked", "true");
            var c = parseInt(r.attr("data:startAngle"), 10), d = parseInt(r.attr("data:angle"), 10);
            t = a.getPiePath({ me: a, startAngle: c, angle: d, size: s }), d !== 360 && r.plot(t);
          } else {
            r.attr({ "data:pieClicked": "false" }), this.revertDataLabelsInner(r.node, this.donutDataLabels);
            var g = r.attr("data:pathOrig");
            r.attr({ d: g });
          }
        } }, { key: "getChangedPath", value: function(e, t) {
          var i = "";
          return this.dynamicAnim && this.w.globals.dataChanged && (i = this.getPiePath({ me: this, startAngle: e, angle: t - e, size: this.size })), i;
        } }, { key: "getPiePath", value: function(e) {
          var t, i = e.me, a = e.startAngle, s = e.angle, r = e.size, o = new X(this.ctx), c = a, d = Math.PI * (c - 90) / 180, g = s + a;
          Math.ceil(g) >= this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle && (g = this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle - 0.01), Math.ceil(g) > this.fullAngle && (g -= this.fullAngle);
          var f = Math.PI * (g - 90) / 180, p = i.centerX + r * Math.cos(d), m = i.centerY + r * Math.sin(d), w = i.centerX + r * Math.cos(f), C = i.centerY + r * Math.sin(f), k = M.polarToCartesian(i.centerX, i.centerY, i.donutSize, g), E = M.polarToCartesian(i.centerX, i.centerY, i.donutSize, c), _ = s > 180 ? 1 : 0, h = ["M", p, m, "A", r, r, 0, _, 1, w, C];
          return t = i.chartType === "donut" ? [].concat(h, ["L", k.x, k.y, "A", i.donutSize, i.donutSize, 0, _, 0, E.x, E.y, "L", p, m, "z"]).join(" ") : i.chartType === "pie" || i.chartType === "polarArea" ? [].concat(h, ["L", i.centerX, i.centerY, "L", p, m]).join(" ") : [].concat(h).join(" "), o.roundPathCorners(t, 2 * this.strokeWidth);
        } }, { key: "drawPolarElements", value: function(e) {
          var t = this.w, i = new ze(this.ctx), a = new X(this.ctx), s = new Hi(this.ctx), r = a.group(), o = a.group(), c = i.niceScale(0, Math.ceil(this.maxY), t.config.yaxis[0].tickAmount, 0, !0), d = c.result.reverse(), g = c.result.length;
          this.maxY = c.niceMax;
          for (var f = t.globals.radialSize, p = f / (g - 1), m = 0; m < g - 1; m++) {
            var w = a.drawCircle(f);
            if (w.attr({ cx: this.centerX, cy: this.centerY, fill: "none", "stroke-width": t.config.plotOptions.polarArea.rings.strokeWidth, stroke: t.config.plotOptions.polarArea.rings.strokeColor }), t.config.yaxis[0].show) {
              var C = s.drawYAxisTexts(this.centerX, this.centerY - f + parseInt(t.config.yaxis[0].labels.style.fontSize, 10) / 2, m, d[m]);
              o.add(C);
            }
            r.add(w), f -= p;
          }
          this.drawSpokes(e), e.add(r), e.add(o);
        } }, { key: "renderInnerDataLabels", value: function(e, t) {
          var i = this.w, a = new X(this.ctx), s = a.group({ class: "apexcharts-datalabels-group", transform: "translate(".concat(t.translateX ? t.translateX : 0, ", ").concat(t.translateY ? t.translateY : 0, ") scale(").concat(i.config.plotOptions.pie.customScale, ")") }), r = e.total.show;
          s.node.style.opacity = t.opacity;
          var o, c, d = t.centerX, g = t.centerY;
          o = e.name.color === void 0 ? i.globals.colors[0] : e.name.color;
          var f = e.name.fontSize, p = e.name.fontFamily, m = e.name.fontWeight;
          c = e.value.color === void 0 ? i.config.chart.foreColor : e.value.color;
          var w = e.value.formatter, C = "", k = "";
          if (r ? (o = e.total.color, f = e.total.fontSize, p = e.total.fontFamily, m = e.total.fontWeight, k = e.total.label, C = e.total.formatter(i)) : i.globals.series.length === 1 && (C = w(i.globals.series[0], i), k = i.globals.seriesNames[0]), k && (k = e.name.formatter(k, e.total.show, i)), e.name.show) {
            var E = a.drawText({ x: d, y: g + parseFloat(e.name.offsetY), text: k, textAnchor: "middle", foreColor: o, fontSize: f, fontWeight: m, fontFamily: p });
            E.node.classList.add("apexcharts-datalabel-label"), s.add(E);
          }
          if (e.value.show) {
            var _ = e.name.show ? parseFloat(e.value.offsetY) + 16 : e.value.offsetY, h = a.drawText({ x: d, y: g + _, text: C, textAnchor: "middle", foreColor: c, fontWeight: e.value.fontWeight, fontSize: e.value.fontSize, fontFamily: e.value.fontFamily });
            h.node.classList.add("apexcharts-datalabel-value"), s.add(h);
          }
          return s;
        } }, { key: "printInnerLabels", value: function(e, t, i, a) {
          var s, r = this.w;
          a ? s = e.name.color === void 0 ? r.globals.colors[parseInt(a.parentNode.getAttribute("rel"), 10) - 1] : e.name.color : r.globals.series.length > 1 && e.total.show && (s = e.total.color);
          var o = r.globals.dom.baseEl.querySelector(".apexcharts-datalabel-label"), c = r.globals.dom.baseEl.querySelector(".apexcharts-datalabel-value");
          i = (0, e.value.formatter)(i, r), a || typeof e.total.formatter != "function" || (i = e.total.formatter(r));
          var d = t === e.total.label;
          t = e.name.formatter(t, d, r), o !== null && (o.textContent = t), c !== null && (c.textContent = i), o !== null && (o.style.fill = s);
        } }, { key: "printDataLabelsInner", value: function(e, t) {
          var i = this.w, a = e.getAttribute("data:value"), s = i.globals.seriesNames[parseInt(e.parentNode.getAttribute("rel"), 10) - 1];
          i.globals.series.length > 1 && this.printInnerLabels(t, s, a, e);
          var r = i.globals.dom.baseEl.querySelector(".apexcharts-datalabels-group");
          r !== null && (r.style.opacity = 1);
        } }, { key: "drawSpokes", value: function(e) {
          var t = this, i = this.w, a = new X(this.ctx), s = i.config.plotOptions.polarArea.spokes;
          if (s.strokeWidth !== 0) {
            for (var r = [], o = 360 / i.globals.series.length, c = 0; c < i.globals.series.length; c++)
              r.push(M.polarToCartesian(this.centerX, this.centerY, i.globals.radialSize, i.config.plotOptions.pie.startAngle + o * c));
            r.forEach(function(d, g) {
              var f = a.drawLine(d.x, d.y, t.centerX, t.centerY, Array.isArray(s.connectorColors) ? s.connectorColors[g] : s.connectorColors);
              e.add(f);
            });
          }
        } }, { key: "revertDataLabelsInner", value: function(e, t, i) {
          var a = this, s = this.w, r = s.globals.dom.baseEl.querySelector(".apexcharts-datalabels-group"), o = !1, c = s.globals.dom.baseEl.getElementsByClassName("apexcharts-pie-area"), d = function(p) {
            var m = p.makeSliceOut, w = p.printLabel;
            Array.prototype.forEach.call(c, function(C) {
              C.getAttribute("data:pieClicked") === "true" && (m && (o = !0), w && a.printDataLabelsInner(C, t));
            });
          };
          if (d({ makeSliceOut: !0, printLabel: !1 }), t.total.show && s.globals.series.length > 1)
            o && !t.total.showAlways ? d({ makeSliceOut: !1, printLabel: !0 }) : this.printInnerLabels(t, t.total.label, t.total.formatter(s));
          else if (d({ makeSliceOut: !1, printLabel: !0 }), !o)
            if (s.globals.selectedDataPoints.length && s.globals.series.length > 1)
              if (s.globals.selectedDataPoints[0].length > 0) {
                var g = s.globals.selectedDataPoints[0], f = s.globals.dom.baseEl.querySelector(".apexcharts-".concat(this.chartType.toLowerCase(), "-slice-").concat(g));
                this.printDataLabelsInner(f, t);
              } else
                r && s.globals.selectedDataPoints.length && s.globals.selectedDataPoints[0].length === 0 && (r.style.opacity = 0);
            else
              r && s.globals.series.length > 1 && (r.style.opacity = 0);
        } }]), P;
      }(), xs = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.chartType = this.w.config.chart.type, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled, this.animDur = 0;
          var t = this.w;
          this.graphics = new X(this.ctx), this.lineColorArr = t.globals.stroke.colors !== void 0 ? t.globals.stroke.colors : t.globals.colors, this.defaultSize = t.globals.svgHeight < t.globals.svgWidth ? t.globals.gridHeight + 1.5 * t.globals.goldenPadding : t.globals.gridWidth, this.isLog = t.config.yaxis[0].logarithmic, this.coreUtils = new $(this.ctx), this.maxValue = this.isLog ? this.coreUtils.getLogVal(t.globals.maxY, 0) : t.globals.maxY, this.minValue = this.isLog ? this.coreUtils.getLogVal(this.w.globals.minY, 0) : t.globals.minY, this.polygons = t.config.plotOptions.radar.polygons, this.strokeWidth = t.config.stroke.show ? t.config.stroke.width : 0, this.size = this.defaultSize / 2.1 - this.strokeWidth - t.config.chart.dropShadow.blur, t.config.xaxis.labels.show && (this.size = this.size - t.globals.xAxisLabelsWidth / 1.75), t.config.plotOptions.radar.size !== void 0 && (this.size = t.config.plotOptions.radar.size), this.dataRadiusOfPercent = [], this.dataRadius = [], this.angleArr = [], this.yaxisLabelsTextsPos = [];
        }
        return A(P, [{ key: "draw", value: function(e) {
          var t = this, i = this.w, a = new ae(this.ctx), s = [], r = new xe(this.ctx);
          e.length && (this.dataPointsLen = e[i.globals.maxValsInArrayIndex].length), this.disAngle = 2 * Math.PI / this.dataPointsLen;
          var o = i.globals.gridWidth / 2, c = i.globals.gridHeight / 2, d = o + i.config.plotOptions.radar.offsetX, g = c + i.config.plotOptions.radar.offsetY, f = this.graphics.group({ class: "apexcharts-radar-series apexcharts-plot-series", transform: "translate(".concat(d || 0, ", ").concat(g || 0, ")") }), p = [], m = null, w = null;
          if (this.yaxisLabels = this.graphics.group({ class: "apexcharts-yaxis" }), e.forEach(function(k, E) {
            var _ = k.length === i.globals.dataPoints, h = t.graphics.group().attr({ class: "apexcharts-series", "data:longestSeries": _, seriesName: M.escapeString(i.globals.seriesNames[E]), rel: E + 1, "data:realIndex": E });
            t.dataRadiusOfPercent[E] = [], t.dataRadius[E] = [], t.angleArr[E] = [], k.forEach(function(U, se) {
              var he = Math.abs(t.maxValue - t.minValue);
              U += Math.abs(t.minValue), t.isLog && (U = t.coreUtils.getLogVal(U, 0)), t.dataRadiusOfPercent[E][se] = U / he, t.dataRadius[E][se] = t.dataRadiusOfPercent[E][se] * t.size, t.angleArr[E][se] = se * t.disAngle;
            }), p = t.getDataPointsPos(t.dataRadius[E], t.angleArr[E]);
            var x = t.createPaths(p, { x: 0, y: 0 });
            m = t.graphics.group({ class: "apexcharts-series-markers-wrap apexcharts-element-hidden" }), w = t.graphics.group({ class: "apexcharts-datalabels", "data:realIndex": E }), i.globals.delayedElements.push({ el: m.node, index: E });
            var S = { i: E, realIndex: E, animationDelay: E, initialSpeed: i.config.chart.animations.speed, dataChangeSpeed: i.config.chart.animations.dynamicAnimation.speed, className: "apexcharts-radar", shouldClipToGrid: !1, bindEventsOnPaths: !1, stroke: i.globals.stroke.colors[E], strokeLineCap: i.config.stroke.lineCap }, L = null;
            i.globals.previousPaths.length > 0 && (L = t.getPreviousPath(E));
            for (var R = 0; R < x.linePathsTo.length; R++) {
              var O = t.graphics.renderPaths(u(u({}, S), {}, { pathFrom: L === null ? x.linePathsFrom[R] : L, pathTo: x.linePathsTo[R], strokeWidth: Array.isArray(t.strokeWidth) ? t.strokeWidth[E] : t.strokeWidth, fill: "none", drawShadow: !1 }));
              h.add(O);
              var Y = a.fillPath({ seriesNumber: E }), N = t.graphics.renderPaths(u(u({}, S), {}, { pathFrom: L === null ? x.areaPathsFrom[R] : L, pathTo: x.areaPathsTo[R], strokeWidth: 0, fill: Y, drawShadow: !1 }));
              if (i.config.chart.dropShadow.enabled) {
                var q = new G(t.ctx), Z = i.config.chart.dropShadow;
                q.dropShadow(N, Object.assign({}, Z, { noUserSpaceOnUse: !0 }), E);
              }
              h.add(N);
            }
            k.forEach(function(U, se) {
              var he = new le(t.ctx).getMarkerConfig({ cssClass: "apexcharts-marker", seriesIndex: E, dataPointIndex: se }), me = t.graphics.drawMarker(p[se].x, p[se].y, he);
              me.attr("rel", se), me.attr("j", se), me.attr("index", E), me.node.setAttribute("default-marker-size", he.pSize);
              var fe = t.graphics.group({ class: "apexcharts-series-markers" });
              fe && fe.add(me), m.add(fe), h.add(m);
              var Ce = i.config.dataLabels;
              if (Ce.enabled) {
                var Ne = Ce.formatter(i.globals.series[E][se], { seriesIndex: E, dataPointIndex: se, w: i });
                r.plotDataLabelsText({ x: p[se].x, y: p[se].y, text: Ne, textAnchor: "middle", i: E, j: E, parent: w, offsetCorrection: !1, dataLabelsConfig: u({}, Ce) });
              }
              h.add(w);
            }), s.push(h);
          }), this.drawPolygons({ parent: f }), i.config.xaxis.labels.show) {
            var C = this.drawXAxisTexts();
            f.add(C);
          }
          return s.forEach(function(k) {
            f.add(k);
          }), f.add(this.yaxisLabels), f;
        } }, { key: "drawPolygons", value: function(e) {
          for (var t = this, i = this.w, a = e.parent, s = new Hi(this.ctx), r = i.globals.yAxisScale[0].result.reverse(), o = r.length, c = [], d = this.size / (o - 1), g = 0; g < o; g++)
            c[g] = d * g;
          c.reverse();
          var f = [], p = [];
          c.forEach(function(m, w) {
            var C = M.getPolygonPos(m, t.dataPointsLen), k = "";
            C.forEach(function(E, _) {
              if (w === 0) {
                var h = t.graphics.drawLine(E.x, E.y, 0, 0, Array.isArray(t.polygons.connectorColors) ? t.polygons.connectorColors[_] : t.polygons.connectorColors);
                p.push(h);
              }
              _ === 0 && t.yaxisLabelsTextsPos.push({ x: E.x, y: E.y }), k += E.x + "," + E.y + " ";
            }), f.push(k);
          }), f.forEach(function(m, w) {
            var C = t.polygons.strokeColors, k = t.polygons.strokeWidth, E = t.graphics.drawPolygon(m, Array.isArray(C) ? C[w] : C, Array.isArray(k) ? k[w] : k, i.globals.radarPolygons.fill.colors[w]);
            a.add(E);
          }), p.forEach(function(m) {
            a.add(m);
          }), i.config.yaxis[0].show && this.yaxisLabelsTextsPos.forEach(function(m, w) {
            var C = s.drawYAxisTexts(m.x, m.y, w, r[w]);
            t.yaxisLabels.add(C);
          });
        } }, { key: "drawXAxisTexts", value: function() {
          var e = this, t = this.w, i = t.config.xaxis.labels, a = this.graphics.group({ class: "apexcharts-xaxis" }), s = M.getPolygonPos(this.size, this.dataPointsLen);
          return t.globals.labels.forEach(function(r, o) {
            var c = t.config.xaxis.labels.formatter, d = new xe(e.ctx);
            if (s[o]) {
              var g = e.getTextPos(s[o], e.size), f = c(r, { seriesIndex: -1, dataPointIndex: o, w: t });
              d.plotDataLabelsText({ x: g.newX, y: g.newY, text: f, textAnchor: g.textAnchor, i: o, j: o, parent: a, color: Array.isArray(i.style.colors) && i.style.colors[o] ? i.style.colors[o] : "#a8a8a8", dataLabelsConfig: u({ textAnchor: g.textAnchor, dropShadow: { enabled: !1 } }, i), offsetCorrection: !1 });
            }
          }), a;
        } }, { key: "createPaths", value: function(e, t) {
          var i = this, a = [], s = [], r = [], o = [];
          if (e.length) {
            s = [this.graphics.move(t.x, t.y)], o = [this.graphics.move(t.x, t.y)];
            var c = this.graphics.move(e[0].x, e[0].y), d = this.graphics.move(e[0].x, e[0].y);
            e.forEach(function(g, f) {
              c += i.graphics.line(g.x, g.y), d += i.graphics.line(g.x, g.y), f === e.length - 1 && (c += "Z", d += "Z");
            }), a.push(c), r.push(d);
          }
          return { linePathsFrom: s, linePathsTo: a, areaPathsFrom: o, areaPathsTo: r };
        } }, { key: "getTextPos", value: function(e, t) {
          var i = "middle", a = e.x, s = e.y;
          return Math.abs(e.x) >= 10 ? e.x > 0 ? (i = "start", a += 10) : e.x < 0 && (i = "end", a -= 10) : i = "middle", Math.abs(e.y) >= t - 10 && (e.y < 0 ? s -= 10 : e.y > 0 && (s += 10)), { textAnchor: i, newX: a, newY: s };
        } }, { key: "getPreviousPath", value: function(e) {
          for (var t = this.w, i = null, a = 0; a < t.globals.previousPaths.length; a++) {
            var s = t.globals.previousPaths[a];
            s.paths.length > 0 && parseInt(s.realIndex, 10) === parseInt(e, 10) && t.globals.previousPaths[a].paths[0] !== void 0 && (i = t.globals.previousPaths[a].paths[0].d);
          }
          return i;
        } }, { key: "getDataPointsPos", value: function(e, t) {
          var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.dataPointsLen;
          e = e || [], t = t || [];
          for (var a = [], s = 0; s < i; s++) {
            var r = {};
            r.x = e[s] * Math.sin(t[s]), r.y = -e[s] * Math.cos(t[s]), a.push(r);
          }
          return a;
        } }]), P;
      }(), ms = function(P) {
        z(t, P);
        var e = W(t);
        function t(i) {
          var a;
          y(this, t), (a = e.call(this, i)).ctx = i, a.w = i.w, a.animBeginArr = [0], a.animDur = 0;
          var s = a.w;
          return a.startAngle = s.config.plotOptions.radialBar.startAngle, a.endAngle = s.config.plotOptions.radialBar.endAngle, a.totalAngle = Math.abs(s.config.plotOptions.radialBar.endAngle - s.config.plotOptions.radialBar.startAngle), a.trackStartAngle = s.config.plotOptions.radialBar.track.startAngle, a.trackEndAngle = s.config.plotOptions.radialBar.track.endAngle, a.barLabels = a.w.config.plotOptions.radialBar.barLabels, a.donutDataLabels = a.w.config.plotOptions.radialBar.dataLabels, a.radialDataLabels = a.donutDataLabels, a.trackStartAngle || (a.trackStartAngle = a.startAngle), a.trackEndAngle || (a.trackEndAngle = a.endAngle), a.endAngle === 360 && (a.endAngle = 359.99), a.margin = parseInt(s.config.plotOptions.radialBar.track.margin, 10), a.onBarLabelClick = a.onBarLabelClick.bind(D(a)), a;
        }
        return A(t, [{ key: "draw", value: function(i) {
          var a = this.w, s = new X(this.ctx), r = s.group({ class: "apexcharts-radialbar" });
          if (a.globals.noData)
            return r;
          var o = s.group(), c = this.defaultSize / 2, d = a.globals.gridWidth / 2, g = this.defaultSize / 2.05;
          a.config.chart.sparkline.enabled || (g = g - a.config.stroke.width - a.config.chart.dropShadow.blur);
          var f = a.globals.fill.colors;
          if (a.config.plotOptions.radialBar.track.show) {
            var p = this.drawTracks({ size: g, centerX: d, centerY: c, colorArr: f, series: i });
            o.add(p);
          }
          var m = this.drawArcs({ size: g, centerX: d, centerY: c, colorArr: f, series: i }), w = 360;
          a.config.plotOptions.radialBar.startAngle < 0 && (w = this.totalAngle);
          var C = (360 - w) / 360;
          if (a.globals.radialSize = g - g * C, this.radialDataLabels.value.show) {
            var k = Math.max(this.radialDataLabels.value.offsetY, this.radialDataLabels.name.offsetY);
            a.globals.radialSize += k * C;
          }
          return o.add(m.g), a.config.plotOptions.radialBar.hollow.position === "front" && (m.g.add(m.elHollow), m.dataLabels && m.g.add(m.dataLabels)), r.add(o), r;
        } }, { key: "drawTracks", value: function(i) {
          var a = this.w, s = new X(this.ctx), r = s.group({ class: "apexcharts-tracks" }), o = new G(this.ctx), c = new ae(this.ctx), d = this.getStrokeWidth(i);
          i.size = i.size - d / 2;
          for (var g = 0; g < i.series.length; g++) {
            var f = s.group({ class: "apexcharts-radialbar-track apexcharts-track" });
            r.add(f), f.attr({ rel: g + 1 }), i.size = i.size - d - this.margin;
            var p = a.config.plotOptions.radialBar.track, m = c.fillPath({ seriesNumber: 0, size: i.size, fillColors: Array.isArray(p.background) ? p.background[g] : p.background, solid: !0 }), w = this.trackStartAngle, C = this.trackEndAngle;
            Math.abs(C) + Math.abs(w) >= 360 && (C = 360 - Math.abs(this.startAngle) - 0.1);
            var k = s.drawPath({ d: "", stroke: m, strokeWidth: d * parseInt(p.strokeWidth, 10) / 100, fill: "none", strokeOpacity: p.opacity, classes: "apexcharts-radialbar-area" });
            if (p.dropShadow.enabled) {
              var E = p.dropShadow;
              o.dropShadow(k, E);
            }
            f.add(k), k.attr("id", "apexcharts-radialbarTrack-" + g), this.animatePaths(k, { centerX: i.centerX, centerY: i.centerY, endAngle: C, startAngle: w, size: i.size, i: g, totalItems: 2, animBeginArr: 0, dur: 0, isTrack: !0, easing: a.globals.easing });
          }
          return r;
        } }, { key: "drawArcs", value: function(i) {
          var a = this.w, s = new X(this.ctx), r = new ae(this.ctx), o = new G(this.ctx), c = s.group(), d = this.getStrokeWidth(i);
          i.size = i.size - d / 2;
          var g = a.config.plotOptions.radialBar.hollow.background, f = i.size - d * i.series.length - this.margin * i.series.length - d * parseInt(a.config.plotOptions.radialBar.track.strokeWidth, 10) / 100 / 2, p = f - a.config.plotOptions.radialBar.hollow.margin;
          a.config.plotOptions.radialBar.hollow.image !== void 0 && (g = this.drawHollowImage(i, c, f, g));
          var m = this.drawHollow({ size: p, centerX: i.centerX, centerY: i.centerY, fill: g || "transparent" });
          if (a.config.plotOptions.radialBar.hollow.dropShadow.enabled) {
            var w = a.config.plotOptions.radialBar.hollow.dropShadow;
            o.dropShadow(m, w);
          }
          var C = 1;
          !this.radialDataLabels.total.show && a.globals.series.length > 1 && (C = 0);
          var k = null;
          this.radialDataLabels.show && (k = this.renderInnerDataLabels(this.radialDataLabels, { hollowSize: f, centerX: i.centerX, centerY: i.centerY, opacity: C })), a.config.plotOptions.radialBar.hollow.position === "back" && (c.add(m), k && c.add(k));
          var E = !1;
          a.config.plotOptions.radialBar.inverseOrder && (E = !0);
          for (var _ = E ? i.series.length - 1 : 0; E ? _ >= 0 : _ < i.series.length; E ? _-- : _++) {
            var h = s.group({ class: "apexcharts-series apexcharts-radial-series", seriesName: M.escapeString(a.globals.seriesNames[_]) });
            c.add(h), h.attr({ rel: _ + 1, "data:realIndex": _ }), this.ctx.series.addCollapsedClassToSeries(h, _), i.size = i.size - d - this.margin;
            var x = r.fillPath({ seriesNumber: _, size: i.size, value: i.series[_] }), S = this.startAngle, L = void 0, R = M.negToZero(i.series[_] > 100 ? 100 : i.series[_]) / 100, O = Math.round(this.totalAngle * R) + this.startAngle, Y = void 0;
            a.globals.dataChanged && (L = this.startAngle, Y = Math.round(this.totalAngle * M.negToZero(a.globals.previousPaths[_]) / 100) + L), Math.abs(O) + Math.abs(S) >= 360 && (O -= 0.01), Math.abs(Y) + Math.abs(L) >= 360 && (Y -= 0.01);
            var N = O - S, q = Array.isArray(a.config.stroke.dashArray) ? a.config.stroke.dashArray[_] : a.config.stroke.dashArray, Z = s.drawPath({ d: "", stroke: x, strokeWidth: d, fill: "none", fillOpacity: a.config.fill.opacity, classes: "apexcharts-radialbar-area apexcharts-radialbar-slice-" + _, strokeDashArray: q });
            if (X.setAttrs(Z.node, { "data:angle": N, "data:value": i.series[_] }), a.config.chart.dropShadow.enabled) {
              var U = a.config.chart.dropShadow;
              o.dropShadow(Z, U, _);
            }
            if (o.setSelectionFilter(Z, 0, _), this.addListeners(Z, this.radialDataLabels), h.add(Z), Z.attr({ index: 0, j: _ }), this.barLabels.enabled) {
              var se = M.polarToCartesian(i.centerX, i.centerY, i.size, S), he = this.barLabels.formatter(a.globals.seriesNames[_], { seriesIndex: _, w: a }), me = ["apexcharts-radialbar-label"];
              this.barLabels.onClick || me.push("apexcharts-no-click");
              var fe = this.barLabels.useSeriesColors ? a.globals.colors[_] : a.config.chart.foreColor;
              fe || (fe = a.config.chart.foreColor);
              var Ce = se.x - this.barLabels.margin, Ne = se.y, Ie = s.drawText({ x: Ce, y: Ne, text: he, textAnchor: "end", dominantBaseline: "middle", fontFamily: this.barLabels.fontFamily, fontWeight: this.barLabels.fontWeight, fontSize: this.barLabels.fontSize, foreColor: fe, cssClass: me.join(" ") });
              Ie.on("click", this.onBarLabelClick), Ie.attr({ rel: _ + 1 }), S !== 0 && Ie.attr({ "transform-origin": "".concat(Ce, " ").concat(Ne), transform: "rotate(".concat(S, " 0 0)") }), h.add(Ie);
            }
            var Oe = 0;
            !this.initialAnim || a.globals.resized || a.globals.dataChanged || (Oe = a.config.chart.animations.speed), a.globals.dataChanged && (Oe = a.config.chart.animations.dynamicAnimation.speed), this.animDur = Oe / (1.2 * i.series.length) + this.animDur, this.animBeginArr.push(this.animDur), this.animatePaths(Z, { centerX: i.centerX, centerY: i.centerY, endAngle: O, startAngle: S, prevEndAngle: Y, prevStartAngle: L, size: i.size, i: _, totalItems: 2, animBeginArr: this.animBeginArr, dur: Oe, shouldSetPrevPaths: !0, easing: a.globals.easing });
          }
          return { g: c, elHollow: m, dataLabels: k };
        } }, { key: "drawHollow", value: function(i) {
          var a = new X(this.ctx).drawCircle(2 * i.size);
          return a.attr({ class: "apexcharts-radialbar-hollow", cx: i.centerX, cy: i.centerY, r: i.size, fill: i.fill }), a;
        } }, { key: "drawHollowImage", value: function(i, a, s, r) {
          var o = this.w, c = new ae(this.ctx), d = M.randomId(), g = o.config.plotOptions.radialBar.hollow.image;
          if (o.config.plotOptions.radialBar.hollow.imageClipped)
            c.clippedImgArea({ width: s, height: s, image: g, patternID: "pattern".concat(o.globals.cuid).concat(d) }), r = "url(#pattern".concat(o.globals.cuid).concat(d, ")");
          else {
            var f = o.config.plotOptions.radialBar.hollow.imageWidth, p = o.config.plotOptions.radialBar.hollow.imageHeight;
            if (f === void 0 && p === void 0) {
              var m = o.globals.dom.Paper.image(g).loaded(function(C) {
                this.move(i.centerX - C.width / 2 + o.config.plotOptions.radialBar.hollow.imageOffsetX, i.centerY - C.height / 2 + o.config.plotOptions.radialBar.hollow.imageOffsetY);
              });
              a.add(m);
            } else {
              var w = o.globals.dom.Paper.image(g).loaded(function(C) {
                this.move(i.centerX - f / 2 + o.config.plotOptions.radialBar.hollow.imageOffsetX, i.centerY - p / 2 + o.config.plotOptions.radialBar.hollow.imageOffsetY), this.size(f, p);
              });
              a.add(w);
            }
          }
          return r;
        } }, { key: "getStrokeWidth", value: function(i) {
          var a = this.w;
          return i.size * (100 - parseInt(a.config.plotOptions.radialBar.hollow.size, 10)) / 100 / (i.series.length + 1) - this.margin;
        } }, { key: "onBarLabelClick", value: function(i) {
          var a = parseInt(i.target.getAttribute("rel"), 10) - 1, s = this.barLabels.onClick, r = this.w;
          s && s(r.globals.seriesNames[a], { w: r, seriesIndex: a });
        } }]), t;
      }(Bi), vs = function(P) {
        z(t, P);
        var e = W(t);
        function t() {
          return y(this, t), e.apply(this, arguments);
        }
        return A(t, [{ key: "draw", value: function(i, a) {
          var s = this.w, r = new X(this.ctx);
          this.rangeBarOptions = this.w.config.plotOptions.rangeBar, this.series = i, this.seriesRangeStart = s.globals.seriesRangeStart, this.seriesRangeEnd = s.globals.seriesRangeEnd, this.barHelpers.initVariables(i);
          for (var o = r.group({ class: "apexcharts-rangebar-series apexcharts-plot-series" }), c = 0; c < i.length; c++) {
            var d, g, f, p, m = void 0, w = void 0, C = s.globals.comboCharts ? a[c] : c, k = r.group({ class: "apexcharts-series", seriesName: M.escapeString(s.globals.seriesNames[C]), rel: c + 1, "data:realIndex": C });
            this.ctx.series.addCollapsedClassToSeries(k, C), i[c].length > 0 && (this.visibleI = this.visibleI + 1);
            var E = 0, _ = 0;
            this.yRatio.length > 1 && (this.yaxisIndex = C);
            var h = this.barHelpers.initialPositions();
            w = h.y, p = h.zeroW, m = h.x, _ = h.barWidth, E = h.barHeight, d = h.xDivision, g = h.yDivision, f = h.zeroH;
            for (var x = r.group({ class: "apexcharts-datalabels", "data:realIndex": C }), S = r.group({ class: "apexcharts-rangebar-goals-markers" }), L = 0; L < s.globals.dataPoints; L++) {
              var R, O = this.barHelpers.getStrokeWidth(c, L, C), Y = this.seriesRangeStart[c][L], N = this.seriesRangeEnd[c][L], q = null, Z = null, U = null, se = { x: m, y: w, strokeWidth: O, elSeries: k }, he = this.seriesLen;
              if (s.config.plotOptions.bar.rangeBarGroupRows && (he = 1), s.config.series[c].data[L] === void 0)
                break;
              if (this.isHorizontal) {
                U = w + E * this.visibleI;
                var me = (g - E * he) / 2;
                if (s.config.series[c].data[L].x) {
                  var fe = this.detectOverlappingBars({ i: c, j: L, barYPosition: U, srty: me, barHeight: E, yDivision: g, initPositions: h });
                  E = fe.barHeight, U = fe.barYPosition;
                }
                _ = (q = this.drawRangeBarPaths(u({ indexes: { i: c, j: L, realIndex: C }, barHeight: E, barYPosition: U, zeroW: p, yDivision: g, y1: Y, y2: N }, se))).barWidth;
              } else {
                s.globals.isXNumeric && (m = (s.globals.seriesX[c][L] - s.globals.minX) / this.xRatio - _ / 2), Z = m + _ * this.visibleI;
                var Ce = (d - _ * he) / 2;
                if (s.config.series[c].data[L].x) {
                  var Ne = this.detectOverlappingBars({ i: c, j: L, barXPosition: Z, srtx: Ce, barWidth: _, xDivision: d, initPositions: h });
                  _ = Ne.barWidth, Z = Ne.barXPosition;
                }
                E = (q = this.drawRangeColumnPaths(u({ indexes: { i: c, j: L, realIndex: C }, barWidth: _, barXPosition: Z, zeroH: f, xDivision: d }, se))).barHeight;
              }
              var Ie = this.barHelpers.drawGoalLine({ barXPosition: q.barXPosition, barYPosition: U, goalX: q.goalX, goalY: q.goalY, barHeight: E, barWidth: _ });
              Ie && S.add(Ie), w = q.y, m = q.x;
              var Oe = this.barHelpers.getPathFillColor(i, c, L, C), Ue = s.globals.stroke.colors[C];
              this.renderSeries((T(R = { realIndex: C, pathFill: Oe, lineFill: Ue, j: L, i: c, x: m, y: w, y1: Y, y2: N, pathFrom: q.pathFrom, pathTo: q.pathTo, strokeWidth: O, elSeries: k, series: i, barHeight: E, barWidth: _, barXPosition: Z, barYPosition: U }, "barWidth", _), T(R, "elDataLabelsWrap", x), T(R, "elGoalsMarkers", S), T(R, "visibleSeries", this.visibleI), T(R, "type", "rangebar"), R));
            }
            o.add(k);
          }
          return o;
        } }, { key: "detectOverlappingBars", value: function(i) {
          var a = i.i, s = i.j, r = i.barYPosition, o = i.barXPosition, c = i.srty, d = i.srtx, g = i.barHeight, f = i.barWidth, p = i.yDivision, m = i.xDivision, w = i.initPositions, C = this.w, k = [], E = C.config.series[a].data[s].rangeName, _ = C.config.series[a].data[s].x, h = Array.isArray(_) ? _.join(" ") : _, x = C.globals.labels.map(function(L) {
            return Array.isArray(L) ? L.join(" ") : L;
          }).indexOf(h), S = C.globals.seriesRange[a].findIndex(function(L) {
            return L.x === h && L.overlaps.length > 0;
          });
          return this.isHorizontal ? (r = C.config.plotOptions.bar.rangeBarGroupRows ? c + p * x : c + g * this.visibleI + p * x, S > -1 && !C.config.plotOptions.bar.rangeBarOverlap && (k = C.globals.seriesRange[a][S].overlaps).indexOf(E) > -1 && (r = (g = w.barHeight / k.length) * this.visibleI + p * (100 - parseInt(this.barOptions.barHeight, 10)) / 100 / 2 + g * (this.visibleI + k.indexOf(E)) + p * x)) : (x > -1 && (o = C.config.plotOptions.bar.rangeBarGroupRows ? d + m * x : d + f * this.visibleI + m * x), S > -1 && !C.config.plotOptions.bar.rangeBarOverlap && (k = C.globals.seriesRange[a][S].overlaps).indexOf(E) > -1 && (o = (f = w.barWidth / k.length) * this.visibleI + m * (100 - parseInt(this.barOptions.barWidth, 10)) / 100 / 2 + f * (this.visibleI + k.indexOf(E)) + m * x)), { barYPosition: r, barXPosition: o, barHeight: g, barWidth: f };
        } }, { key: "drawRangeColumnPaths", value: function(i) {
          var a = i.indexes, s = i.x, r = i.xDivision, o = i.barWidth, c = i.barXPosition, d = i.zeroH, g = this.w, f = a.i, p = a.j, m = this.yRatio[this.yaxisIndex], w = a.realIndex, C = this.getRangeValue(w, p), k = Math.min(C.start, C.end), E = Math.max(C.start, C.end);
          this.series[f][p] === void 0 || this.series[f][p] === null ? k = d : (k = d - k / m, E = d - E / m);
          var _ = Math.abs(E - k), h = this.barHelpers.getColumnPaths({ barXPosition: c, barWidth: o, y1: k, y2: E, strokeWidth: this.strokeWidth, series: this.seriesRangeEnd, realIndex: a.realIndex, i: w, j: p, w: g });
          if (g.globals.isXNumeric) {
            var x = this.getBarXForNumericXAxis({ x: s, j: p, realIndex: w, barWidth: o });
            s = x.x, c = x.barXPosition;
          } else
            s += r;
          return { pathTo: h.pathTo, pathFrom: h.pathFrom, barHeight: _, x: s, y: E, goalY: this.barHelpers.getGoalValues("y", null, d, f, p), barXPosition: c };
        } }, { key: "drawRangeBarPaths", value: function(i) {
          var a = i.indexes, s = i.y, r = i.y1, o = i.y2, c = i.yDivision, d = i.barHeight, g = i.barYPosition, f = i.zeroW, p = this.w, m = f + r / this.invertedYRatio, w = f + o / this.invertedYRatio, C = Math.abs(w - m), k = this.barHelpers.getBarpaths({ barYPosition: g, barHeight: d, x1: m, x2: w, strokeWidth: this.strokeWidth, series: this.seriesRangeEnd, i: a.realIndex, realIndex: a.realIndex, j: a.j, w: p });
          return p.globals.isXNumeric || (s += c), { pathTo: k.pathTo, pathFrom: k.pathFrom, barWidth: C, x: w, goalX: this.barHelpers.getGoalValues("x", f, null, a.realIndex, a.j), y: s };
        } }, { key: "getRangeValue", value: function(i, a) {
          var s = this.w;
          return { start: s.globals.seriesRangeStart[i][a], end: s.globals.seriesRangeEnd[i][a] };
        } }]), t;
      }(bt), bs = function() {
        function P(e) {
          y(this, P), this.w = e.w, this.lineCtx = e;
        }
        return A(P, [{ key: "sameValueSeriesFix", value: function(e, t) {
          var i = this.w;
          if ((i.config.fill.type === "gradient" || i.config.fill.type[e] === "gradient") && new $(this.lineCtx.ctx, i).seriesHaveSameValues(e)) {
            var a = t[e].slice();
            a[a.length - 1] = a[a.length - 1] + 1e-6, t[e] = a;
          }
          return t;
        } }, { key: "calculatePoints", value: function(e) {
          var t = e.series, i = e.realIndex, a = e.x, s = e.y, r = e.i, o = e.j, c = e.prevY, d = this.w, g = [], f = [];
          if (o === 0) {
            var p = this.lineCtx.categoryAxisCorrection + d.config.markers.offsetX;
            d.globals.isXNumeric && (p = (d.globals.seriesX[i][0] - d.globals.minX) / this.lineCtx.xRatio + d.config.markers.offsetX), g.push(p), f.push(M.isNumber(t[r][0]) ? c + d.config.markers.offsetY : null), g.push(a + d.config.markers.offsetX), f.push(M.isNumber(t[r][o + 1]) ? s + d.config.markers.offsetY : null);
          } else
            g.push(a + d.config.markers.offsetX), f.push(M.isNumber(t[r][o + 1]) ? s + d.config.markers.offsetY : null);
          return { x: g, y: f };
        } }, { key: "checkPreviousPaths", value: function(e) {
          for (var t = e.pathFromLine, i = e.pathFromArea, a = e.realIndex, s = this.w, r = 0; r < s.globals.previousPaths.length; r++) {
            var o = s.globals.previousPaths[r];
            (o.type === "line" || o.type === "area") && o.paths.length > 0 && parseInt(o.realIndex, 10) === parseInt(a, 10) && (o.type === "line" ? (this.lineCtx.appendPathFrom = !1, t = s.globals.previousPaths[r].paths[0].d) : o.type === "area" && (this.lineCtx.appendPathFrom = !1, i = s.globals.previousPaths[r].paths[0].d, s.config.stroke.show && s.globals.previousPaths[r].paths[1] && (t = s.globals.previousPaths[r].paths[1].d)));
          }
          return { pathFromLine: t, pathFromArea: i };
        } }, { key: "determineFirstPrevY", value: function(e) {
          var t, i, a = e.i, s = e.series, r = e.prevY, o = e.lineYPosition, c = this.w, d = c.config.chart.stacked && !c.globals.comboCharts || c.config.chart.stacked && c.globals.comboCharts && (!this.w.config.chart.stackOnlyBar || ((t = this.w.config.series[a]) === null || t === void 0 ? void 0 : t.type) === "bar");
          if (((i = s[a]) === null || i === void 0 ? void 0 : i[0]) !== void 0)
            r = (o = d && a > 0 ? this.lineCtx.prevSeriesY[a - 1][0] : this.lineCtx.zeroY) - s[a][0] / this.lineCtx.yRatio[this.lineCtx.yaxisIndex] + 2 * (this.lineCtx.isReversed ? s[a][0] / this.lineCtx.yRatio[this.lineCtx.yaxisIndex] : 0);
          else if (d && a > 0 && s[a][0] === void 0) {
            for (var g = a - 1; g >= 0; g--)
              if (s[g][0] !== null && s[g][0] !== void 0) {
                r = o = this.lineCtx.prevSeriesY[g][0];
                break;
              }
          }
          return { prevY: r, lineYPosition: o };
        } }]), P;
      }(), ys = function(P) {
        for (var e, t, i, a, s = function(g) {
          for (var f = [], p = g[0], m = g[1], w = f[0] = ai(p, m), C = 1, k = g.length - 1; C < k; C++)
            p = m, m = g[C + 1], f[C] = 0.5 * (w + (w = ai(p, m)));
          return f[C] = w, f;
        }(P), r = P.length - 1, o = [], c = 0; c < r; c++)
          i = ai(P[c], P[c + 1]), Math.abs(i) < 1e-6 ? s[c] = s[c + 1] = 0 : (a = (e = s[c] / i) * e + (t = s[c + 1] / i) * t) > 9 && (a = 3 * i / Math.sqrt(a), s[c] = a * e, s[c + 1] = a * t);
        for (var d = 0; d <= r; d++)
          a = (P[Math.min(r, d + 1)][0] - P[Math.max(0, d - 1)][0]) / (6 * (1 + s[d] * s[d])), o.push([a || 0, s[d] * a || 0]);
        return o;
      }, ii = function(P, e) {
        for (var t = "", i = 0; i < P.length; i++) {
          var a = P[i], s = P[i - 1], r = a.length, o = s == null ? void 0 : s.length;
          i > 1 && Math.abs(a[r - 2] - s[o - 2]) < e / 25 ? t += "L".concat(a[2], ", ").concat(a[3]) : r > 4 ? (t += "C".concat(a[0], ", ").concat(a[1]), t += ", ".concat(a[2], ", ").concat(a[3]), t += ", ".concat(a[4], ", ").concat(a[5])) : r > 2 && (t += "S".concat(a[0], ", ").concat(a[1]), t += ", ".concat(a[2], ", ").concat(a[3]));
        }
        return t;
      }, Wi = function(P) {
        var e = ys(P), t = P[1], i = P[0], a = [], s = e[1], r = e[0];
        a.push(i, [i[0] + r[0], i[1] + r[1], t[0] - s[0], t[1] - s[1], t[0], t[1]]);
        for (var o = 2, c = e.length; o < c; o++) {
          var d = P[o], g = e[o];
          a.push([d[0] - g[0], d[1] - g[1], d[0], d[1]]);
        }
        return a;
      };
      function ai(P, e) {
        return (e[1] - P[1]) / (e[0] - P[0]);
      }
      var si = function() {
        function P(e, t, i) {
          y(this, P), this.ctx = e, this.w = e.w, this.xyRatios = t, this.pointsChart = !(this.w.config.chart.type !== "bubble" && this.w.config.chart.type !== "scatter") || i, this.scatter = new pe(this.ctx), this.noNegatives = this.w.globals.minX === Number.MAX_VALUE, this.lineHelpers = new bs(this), this.markers = new le(this.ctx), this.prevSeriesY = [], this.categoryAxisCorrection = 0, this.yaxisIndex = 0;
        }
        return A(P, [{ key: "draw", value: function(e, t, i, a) {
          var s, r = this.w, o = new X(this.ctx), c = r.globals.comboCharts ? t : r.config.chart.type, d = o.group({ class: "apexcharts-".concat(c, "-series apexcharts-plot-series") }), g = new $(this.ctx, r);
          this.yRatio = this.xyRatios.yRatio, this.zRatio = this.xyRatios.zRatio, this.xRatio = this.xyRatios.xRatio, this.baseLineY = this.xyRatios.baseLineY, e = g.getLogSeries(e), this.yRatio = g.getLogYRatios(this.yRatio);
          for (var f = [], p = 0; p < e.length; p++) {
            e = this.lineHelpers.sameValueSeriesFix(p, e);
            var m = r.globals.comboCharts ? i[p] : p;
            this._initSerieVariables(e, p, m);
            var w = [], C = [], k = [], E = r.globals.padHorizontal + this.categoryAxisCorrection;
            this.ctx.series.addCollapsedClassToSeries(this.elSeries, m), r.globals.isXNumeric && r.globals.seriesX.length > 0 && (E = (r.globals.seriesX[m][0] - r.globals.minX) / this.xRatio), k.push(E);
            var _ = E, h = this.zeroY, x = this.zeroY;
            h = this.lineHelpers.determineFirstPrevY({ i: p, series: e, prevY: h, lineYPosition: 0 }).prevY, r.config.stroke.curve === "smooth" && e[p][0] === null ? w.push(null) : w.push(h), c === "rangeArea" && (x = this.lineHelpers.determineFirstPrevY({ i: p, series: a, prevY: x, lineYPosition: 0 }).prevY, C.push(x));
            var S = { type: c, series: e, realIndex: m, i: p, x: E, y: 1, pathsFrom: this._calculatePathsFrom({ type: c, series: e, i: p, realIndex: m, prevX: _, prevY: h, prevY2: x }), linePaths: [], areaPaths: [], seriesIndex: i, lineYPosition: 0, xArrj: k, yArrj: w, y2Arrj: C, seriesRangeEnd: a }, L = this._iterateOverDataPoints(u(u({}, S), {}, { iterations: c === "rangeArea" ? e[p].length - 1 : void 0, isRangeStart: !0 }));
            if (c === "rangeArea") {
              var R = this._calculatePathsFrom({ series: a, i: p, realIndex: m, prevX: _, prevY: x }), O = this._iterateOverDataPoints(u(u({}, S), {}, { series: a, pathsFrom: R, iterations: a[p].length - 1, isRangeStart: !1 }));
              L.linePaths[0] = O.linePath + L.linePath, L.pathFromLine = O.pathFromLine + L.pathFromLine;
            }
            this._handlePaths({ type: c, realIndex: m, i: p, paths: L }), this.elSeries.add(this.elPointsMain), this.elSeries.add(this.elDataLabelsWrap), f.push(this.elSeries);
          }
          if (((s = r.config.series[0]) === null || s === void 0 ? void 0 : s.zIndex) !== void 0 && f.sort(function(q, Z) {
            return Number(q.node.getAttribute("zIndex")) - Number(Z.node.getAttribute("zIndex"));
          }), r.config.chart.stacked)
            for (var Y = f.length; Y > 0; Y--)
              d.add(f[Y - 1]);
          else
            for (var N = 0; N < f.length; N++)
              d.add(f[N]);
          return d;
        } }, { key: "_initSerieVariables", value: function(e, t, i) {
          var a = this.w, s = new X(this.ctx);
          this.xDivision = a.globals.gridWidth / (a.globals.dataPoints - (a.config.xaxis.tickPlacement === "on" ? 1 : 0)), this.strokeWidth = Array.isArray(a.config.stroke.width) ? a.config.stroke.width[i] : a.config.stroke.width, this.yRatio.length > 1 && (this.yaxisIndex = i), this.isReversed = a.config.yaxis[this.yaxisIndex] && a.config.yaxis[this.yaxisIndex].reversed, this.zeroY = a.globals.gridHeight - this.baseLineY[this.yaxisIndex] - (this.isReversed ? a.globals.gridHeight : 0) + (this.isReversed ? 2 * this.baseLineY[this.yaxisIndex] : 0), this.areaBottomY = this.zeroY, (this.zeroY > a.globals.gridHeight || a.config.plotOptions.area.fillTo === "end") && (this.areaBottomY = a.globals.gridHeight), this.categoryAxisCorrection = this.xDivision / 2, this.elSeries = s.group({ class: "apexcharts-series", zIndex: a.config.series[i].zIndex !== void 0 ? a.config.series[i].zIndex : i, seriesName: M.escapeString(a.globals.seriesNames[i]) }), this.elPointsMain = s.group({ class: "apexcharts-series-markers-wrap", "data:realIndex": i }), this.elDataLabelsWrap = s.group({ class: "apexcharts-datalabels", "data:realIndex": i });
          var r = e[t].length === a.globals.dataPoints;
          this.elSeries.attr({ "data:longestSeries": r, rel: t + 1, "data:realIndex": i }), this.appendPathFrom = !0;
        } }, { key: "_calculatePathsFrom", value: function(e) {
          var t, i, a, s, r = e.type, o = e.series, c = e.i, d = e.realIndex, g = e.prevX, f = e.prevY, p = e.prevY2, m = this.w, w = new X(this.ctx);
          if (o[c][0] === null) {
            for (var C = 0; C < o[c].length; C++)
              if (o[c][C] !== null) {
                g = this.xDivision * C, f = this.zeroY - o[c][C] / this.yRatio[this.yaxisIndex], t = w.move(g, f), i = w.move(g, this.areaBottomY);
                break;
              }
          } else
            t = w.move(g, f), r === "rangeArea" && (t = w.move(g, p) + w.line(g, f)), i = w.move(g, this.areaBottomY) + w.line(g, f);
          if (a = w.move(-1, this.zeroY) + w.line(-1, this.zeroY), s = w.move(-1, this.zeroY) + w.line(-1, this.zeroY), m.globals.previousPaths.length > 0) {
            var k = this.lineHelpers.checkPreviousPaths({ pathFromLine: a, pathFromArea: s, realIndex: d });
            a = k.pathFromLine, s = k.pathFromArea;
          }
          return { prevX: g, prevY: f, linePath: t, areaPath: i, pathFromLine: a, pathFromArea: s };
        } }, { key: "_handlePaths", value: function(e) {
          var t = e.type, i = e.realIndex, a = e.i, s = e.paths, r = this.w, o = new X(this.ctx), c = new ae(this.ctx);
          this.prevSeriesY.push(s.yArrj), r.globals.seriesXvalues[i] = s.xArrj, r.globals.seriesYvalues[i] = s.yArrj;
          var d = r.config.forecastDataPoints;
          if (d.count > 0 && t !== "rangeArea") {
            var g = r.globals.seriesXvalues[i][r.globals.seriesXvalues[i].length - d.count - 1], f = o.drawRect(g, 0, r.globals.gridWidth, r.globals.gridHeight, 0);
            r.globals.dom.elForecastMask.appendChild(f.node);
            var p = o.drawRect(0, 0, g, r.globals.gridHeight, 0);
            r.globals.dom.elNonForecastMask.appendChild(p.node);
          }
          this.pointsChart || r.globals.delayedElements.push({ el: this.elPointsMain.node, index: i });
          var m = { i: a, realIndex: i, animationDelay: a, initialSpeed: r.config.chart.animations.speed, dataChangeSpeed: r.config.chart.animations.dynamicAnimation.speed, className: "apexcharts-".concat(t) };
          if (t === "area")
            for (var w = c.fillPath({ seriesNumber: i }), C = 0; C < s.areaPaths.length; C++) {
              var k = o.renderPaths(u(u({}, m), {}, { pathFrom: s.pathFromArea, pathTo: s.areaPaths[C], stroke: "none", strokeWidth: 0, strokeLineCap: null, fill: w }));
              this.elSeries.add(k);
            }
          if (r.config.stroke.show && !this.pointsChart) {
            var E = null;
            if (t === "line")
              E = c.fillPath({ seriesNumber: i, i: a });
            else if (r.config.stroke.fill.type === "solid")
              E = r.globals.stroke.colors[i];
            else {
              var _ = r.config.fill;
              r.config.fill = r.config.stroke.fill, E = c.fillPath({ seriesNumber: i, i: a }), r.config.fill = _;
            }
            for (var h = 0; h < s.linePaths.length; h++) {
              var x = E;
              t === "rangeArea" && (x = c.fillPath({ seriesNumber: i }));
              var S = u(u({}, m), {}, { pathFrom: s.pathFromLine, pathTo: s.linePaths[h], stroke: E, strokeWidth: this.strokeWidth, strokeLineCap: r.config.stroke.lineCap, fill: t === "rangeArea" ? x : "none" }), L = o.renderPaths(S);
              if (this.elSeries.add(L), L.attr("fill-rule", "evenodd"), d.count > 0 && t !== "rangeArea") {
                var R = o.renderPaths(S);
                R.node.setAttribute("stroke-dasharray", d.dashArray), d.strokeWidth && R.node.setAttribute("stroke-width", d.strokeWidth), this.elSeries.add(R), R.attr("clip-path", "url(#forecastMask".concat(r.globals.cuid, ")")), L.attr("clip-path", "url(#nonForecastMask".concat(r.globals.cuid, ")"));
              }
            }
          }
        } }, { key: "_iterateOverDataPoints", value: function(e) {
          var t, i = this, a = e.type, s = e.series, r = e.iterations, o = e.realIndex, c = e.i, d = e.x, g = e.y, f = e.pathsFrom, p = e.linePaths, m = e.areaPaths, w = e.seriesIndex, C = e.lineYPosition, k = e.xArrj, E = e.yArrj, _ = e.y2Arrj, h = e.isRangeStart, x = e.seriesRangeEnd, S = this.w, L = new X(this.ctx), R = this.yRatio, O = f.prevY, Y = f.linePath, N = f.areaPath, q = f.pathFromLine, Z = f.pathFromArea, U = M.isNumber(S.globals.minYArr[o]) ? S.globals.minYArr[o] : S.globals.minY;
          r || (r = S.globals.dataPoints > 1 ? S.globals.dataPoints - 1 : S.globals.dataPoints);
          for (var se = function(Ue, Ke) {
            return Ke - Ue / R[i.yaxisIndex] + 2 * (i.isReversed ? Ue / R[i.yaxisIndex] : 0);
          }, he = g, me = S.config.chart.stacked && !S.globals.comboCharts || S.config.chart.stacked && S.globals.comboCharts && (!this.w.config.chart.stackOnlyBar || ((t = this.w.config.series[o]) === null || t === void 0 ? void 0 : t.type) === "bar"), fe = 0; fe < r; fe++) {
            var Ce = s[c][fe + 1] === void 0 || s[c][fe + 1] === null;
            if (S.globals.isXNumeric) {
              var Ne = S.globals.seriesX[o][fe + 1];
              S.globals.seriesX[o][fe + 1] === void 0 && (Ne = S.globals.seriesX[o][r - 1]), d = (Ne - S.globals.minX) / this.xRatio;
            } else
              d += this.xDivision;
            me ? c > 0 && S.globals.collapsedSeries.length < S.config.series.length - 1 ? C = this.prevSeriesY[function(Ue) {
              for (var Ke = Ue, yt = 0; yt < S.globals.series.length; yt++)
                if (S.globals.collapsedSeriesIndices.indexOf(Ue) > -1) {
                  Ke--;
                  break;
                }
              return Ke >= 0 ? Ke : 0;
            }(c - 1)][fe + 1] : C = this.zeroY : C = this.zeroY, Ce ? g = se(U, C) : (g = se(s[c][fe + 1], C), a === "rangeArea" && (he = se(x[c][fe + 1], C))), k.push(d), Ce && S.config.stroke.curve === "smooth" ? E.push(null) : E.push(g), _.push(he);
            var Ie = this.lineHelpers.calculatePoints({ series: s, x: d, y: g, realIndex: o, i: c, j: fe, prevY: O }), Oe = this._createPaths({ type: a, series: s, i: c, realIndex: o, j: fe, x: d, y: g, y2: he, xArrj: k, yArrj: E, y2Arrj: _, linePath: Y, areaPath: N, linePaths: p, areaPaths: m, seriesIndex: w, isRangeStart: h });
            m = Oe.areaPaths, p = Oe.linePaths, N = Oe.areaPath, Y = Oe.linePath, !this.appendPathFrom || S.config.stroke.curve === "smooth" && a === "rangeArea" || (q += L.line(d, this.zeroY), Z += L.line(d, this.zeroY)), this.handleNullDataPoints(s, Ie, c, fe, o), this._handleMarkersAndLabels({ type: a, pointsPos: Ie, i: c, j: fe, realIndex: o, isRangeStart: h });
          }
          return { yArrj: E, xArrj: k, pathFromArea: Z, areaPaths: m, pathFromLine: q, linePaths: p, linePath: Y, areaPath: N };
        } }, { key: "_handleMarkersAndLabels", value: function(e) {
          var t = e.type, i = e.pointsPos, a = e.isRangeStart, s = e.i, r = e.j, o = e.realIndex, c = this.w, d = new xe(this.ctx);
          if (this.pointsChart)
            this.scatter.draw(this.elSeries, r, { realIndex: o, pointsPos: i, zRatio: this.zRatio, elParent: this.elPointsMain });
          else {
            c.globals.series[s].length > 1 && this.elPointsMain.node.classList.add("apexcharts-element-hidden");
            var g = this.markers.plotChartMarkers(i, o, r + 1);
            g !== null && this.elPointsMain.add(g);
          }
          var f = d.drawDataLabel({ type: t, isRangeStart: a, pos: i, i: o, j: r + 1 });
          f !== null && this.elDataLabelsWrap.add(f);
        } }, { key: "_createPaths", value: function(e) {
          var t = e.type, i = e.series, a = e.i, s = e.realIndex, r = e.j, o = e.x, c = e.y, d = e.xArrj, g = e.yArrj, f = e.y2, p = e.y2Arrj, m = e.linePath, w = e.areaPath, C = e.linePaths, k = e.areaPaths, E = e.seriesIndex, _ = e.isRangeStart, h = this.w, x = new X(this.ctx), S = h.config.stroke.curve, L = this.areaBottomY;
          if (Array.isArray(h.config.stroke.curve) && (S = Array.isArray(E) ? h.config.stroke.curve[E[a]] : h.config.stroke.curve[a]), t === "rangeArea" && (h.globals.hasNullValues || h.config.forecastDataPoints.count > 0) && S === "smooth" && (S = "straight"), S === "smooth") {
            var R = t === "rangeArea" ? d.length === h.globals.dataPoints : r === i[a].length - 2, O = d.map(function(he, me) {
              return [d[me], g[me]];
            }).filter(function(he) {
              return he[1] !== null;
            });
            if (R && O.length > 1) {
              var Y = Wi(O);
              if (m += ii(Y, h.globals.gridWidth), i[a][0] === null ? w = m : w += ii(Y, h.globals.gridWidth), t === "rangeArea" && _) {
                m += x.line(d[d.length - 1], p[p.length - 1]);
                var N = d.slice().reverse(), q = p.slice().reverse(), Z = N.map(function(he, me) {
                  return [N[me], q[me]];
                }), U = Wi(Z);
                w = m += ii(U, h.globals.gridWidth);
              } else
                w += x.line(O[O.length - 1][0], L) + x.line(O[0][0], L) + x.move(O[0][0], O[0][1]) + "z";
              C.push(m), k.push(w);
            }
          } else {
            if (i[a][r + 1] === null) {
              m += x.move(o, c);
              var se = h.globals.isXNumeric ? (h.globals.seriesX[s][r] - h.globals.minX) / this.xRatio : o - this.xDivision;
              w = w + x.line(se, L) + x.move(o, c) + "z";
            }
            i[a][r] === null && (m += x.move(o, c), w += x.move(o, L)), S === "stepline" ? (m = m + x.line(o, null, "H") + x.line(null, c, "V"), w = w + x.line(o, null, "H") + x.line(null, c, "V")) : S === "straight" && (m += x.line(o, c), w += x.line(o, c)), r === i[a].length - 2 && (w = w + x.line(o, L) + x.move(o, c) + "z", t === "rangeArea" && _ ? m = m + x.line(o, f) + x.move(o, f) + "z" : (C.push(m), k.push(w)));
          }
          return { linePaths: C, areaPaths: k, linePath: m, areaPath: w };
        } }, { key: "handleNullDataPoints", value: function(e, t, i, a, s) {
          var r = this.w;
          if (e[i][a] === null && r.config.markers.showNullDataPoints || e[i].length === 1) {
            var o = this.markers.plotChartMarkers(t, s, a + 1, this.strokeWidth - r.config.markers.strokeWidth / 2, !0);
            o !== null && this.elPointsMain.add(o);
          }
        } }]), P;
      }();
      window.TreemapSquared = {}, window.TreemapSquared.generate = function() {
        function P(o, c, d, g) {
          this.xoffset = o, this.yoffset = c, this.height = g, this.width = d, this.shortestEdge = function() {
            return Math.min(this.height, this.width);
          }, this.getCoordinates = function(f) {
            var p, m = [], w = this.xoffset, C = this.yoffset, k = s(f) / this.height, E = s(f) / this.width;
            if (this.width >= this.height)
              for (p = 0; p < f.length; p++)
                m.push([w, C, w + k, C + f[p] / k]), C += f[p] / k;
            else
              for (p = 0; p < f.length; p++)
                m.push([w, C, w + f[p] / E, C + E]), w += f[p] / E;
            return m;
          }, this.cutArea = function(f) {
            var p;
            if (this.width >= this.height) {
              var m = f / this.height, w = this.width - m;
              p = new P(this.xoffset + m, this.yoffset, w, this.height);
            } else {
              var C = f / this.width, k = this.height - C;
              p = new P(this.xoffset, this.yoffset + C, this.width, k);
            }
            return p;
          };
        }
        function e(o, c, d, g, f) {
          g = g === void 0 ? 0 : g, f = f === void 0 ? 0 : f;
          var p = t(function(m, w) {
            var C, k = [], E = w / s(m);
            for (C = 0; C < m.length; C++)
              k[C] = m[C] * E;
            return k;
          }(o, c * d), [], new P(g, f, c, d), []);
          return function(m) {
            var w, C, k = [];
            for (w = 0; w < m.length; w++)
              for (C = 0; C < m[w].length; C++)
                k.push(m[w][C]);
            return k;
          }(p);
        }
        function t(o, c, d, g) {
          var f, p, m;
          if (o.length !== 0)
            return f = d.shortestEdge(), function(w, C, k) {
              var E;
              if (w.length === 0)
                return !0;
              (E = w.slice()).push(C);
              var _ = i(w, k), h = i(E, k);
              return _ >= h;
            }(c, p = o[0], f) ? (c.push(p), t(o.slice(1), c, d, g)) : (m = d.cutArea(s(c), g), g.push(d.getCoordinates(c)), t(o, [], m, g)), g;
          g.push(d.getCoordinates(c));
        }
        function i(o, c) {
          var d = Math.min.apply(Math, o), g = Math.max.apply(Math, o), f = s(o);
          return Math.max(Math.pow(c, 2) * g / Math.pow(f, 2), Math.pow(f, 2) / (Math.pow(c, 2) * d));
        }
        function a(o) {
          return o && o.constructor === Array;
        }
        function s(o) {
          var c, d = 0;
          for (c = 0; c < o.length; c++)
            d += o[c];
          return d;
        }
        function r(o) {
          var c, d = 0;
          if (a(o[0]))
            for (c = 0; c < o.length; c++)
              d += r(o[c]);
          else
            d = s(o);
          return d;
        }
        return function o(c, d, g, f, p) {
          f = f === void 0 ? 0 : f, p = p === void 0 ? 0 : p;
          var m, w, C = [], k = [];
          if (a(c[0])) {
            for (w = 0; w < c.length; w++)
              C[w] = r(c[w]);
            for (m = e(C, d, g, f, p), w = 0; w < c.length; w++)
              k.push(o(c[w], m[w][2] - m[w][0], m[w][3] - m[w][1], m[w][0], m[w][1]));
          } else
            k = e(c, d, g, f, p);
          return k;
        };
      }();
      var ht, Xt, ws = function() {
        function P(e, t) {
          y(this, P), this.ctx = e, this.w = e.w, this.strokeWidth = this.w.config.stroke.width, this.helpers = new Ni(e), this.dynamicAnim = this.w.config.chart.animations.dynamicAnimation, this.labels = [];
        }
        return A(P, [{ key: "draw", value: function(e) {
          var t = this, i = this.w, a = new X(this.ctx), s = new ae(this.ctx), r = a.group({ class: "apexcharts-treemap" });
          if (i.globals.noData)
            return r;
          var o = [];
          return e.forEach(function(c) {
            var d = c.map(function(g) {
              return Math.abs(g);
            });
            o.push(d);
          }), this.negRange = this.helpers.checkColorRange(), i.config.series.forEach(function(c, d) {
            c.data.forEach(function(g) {
              Array.isArray(t.labels[d]) || (t.labels[d] = []), t.labels[d].push(g.x);
            });
          }), window.TreemapSquared.generate(o, i.globals.gridWidth, i.globals.gridHeight).forEach(function(c, d) {
            var g = a.group({ class: "apexcharts-series apexcharts-treemap-series", seriesName: M.escapeString(i.globals.seriesNames[d]), rel: d + 1, "data:realIndex": d });
            if (i.config.chart.dropShadow.enabled) {
              var f = i.config.chart.dropShadow;
              new G(t.ctx).dropShadow(r, f, d);
            }
            var p = a.group({ class: "apexcharts-data-labels" });
            c.forEach(function(m, w) {
              var C = m[0], k = m[1], E = m[2], _ = m[3], h = a.drawRect(C, k, E - C, _ - k, 0, "#fff", 1, t.strokeWidth, i.config.plotOptions.treemap.useFillColorAsStroke ? S : i.globals.stroke.colors[d]);
              h.attr({ cx: C, cy: k, index: d, i: d, j: w, width: E - C, height: _ - k });
              var x = t.helpers.getShadeColor(i.config.chart.type, d, w, t.negRange), S = x.color;
              i.config.series[d].data[w] !== void 0 && i.config.series[d].data[w].fillColor && (S = i.config.series[d].data[w].fillColor);
              var L = s.fillPath({ color: S, seriesNumber: d, dataPointIndex: w });
              h.node.classList.add("apexcharts-treemap-rect"), h.attr({ fill: L }), t.helpers.addListeners(h);
              var R = { x: C + (E - C) / 2, y: k + (_ - k) / 2, width: 0, height: 0 }, O = { x: C, y: k, width: E - C, height: _ - k };
              if (i.config.chart.animations.enabled && !i.globals.dataChanged) {
                var Y = 1;
                i.globals.resized || (Y = i.config.chart.animations.speed), t.animateTreemap(h, R, O, Y);
              }
              if (i.globals.dataChanged) {
                var N = 1;
                t.dynamicAnim.enabled && i.globals.shouldAnimate && (N = t.dynamicAnim.speed, i.globals.previousPaths[d] && i.globals.previousPaths[d][w] && i.globals.previousPaths[d][w].rect && (R = i.globals.previousPaths[d][w].rect), t.animateTreemap(h, R, O, N));
              }
              var q = t.getFontSize(m), Z = i.config.dataLabels.formatter(t.labels[d][w], { value: i.globals.series[d][w], seriesIndex: d, dataPointIndex: w, w: i });
              i.config.plotOptions.treemap.dataLabels.format === "truncate" && (q = parseInt(i.config.dataLabels.style.fontSize, 10), Z = t.truncateLabels(Z, q, C, k, E, _));
              var U = t.helpers.calculateDataLabels({ text: Z, x: (C + E) / 2, y: (k + _) / 2 + t.strokeWidth / 2 + q / 3, i: d, j: w, colorProps: x, fontSize: q, series: e });
              i.config.dataLabels.enabled && U && t.rotateToFitLabel(U, q, Z, C, k, E, _), g.add(h), U !== null && g.add(U);
            }), g.add(p), r.add(g);
          }), r;
        } }, { key: "getFontSize", value: function(e) {
          var t = this.w, i, a, s, r, o = function c(d) {
            var g, f = 0;
            if (Array.isArray(d[0]))
              for (g = 0; g < d.length; g++)
                f += c(d[g]);
            else
              for (g = 0; g < d.length; g++)
                f += d[g].length;
            return f;
          }(this.labels) / function c(d) {
            var g, f = 0;
            if (Array.isArray(d[0]))
              for (g = 0; g < d.length; g++)
                f += c(d[g]);
            else
              for (g = 0; g < d.length; g++)
                f += 1;
            return f;
          }(this.labels);
          return i = e[2] - e[0], a = e[3] - e[1], s = i * a, r = Math.pow(s, 0.5), Math.min(r / o, parseInt(t.config.dataLabels.style.fontSize, 10));
        } }, { key: "rotateToFitLabel", value: function(e, t, i, a, s, r, o) {
          var c = new X(this.ctx), d = c.getTextRects(i, t);
          if (d.width + this.w.config.stroke.width + 5 > r - a && d.width <= o - s) {
            var g = c.rotateAroundCenter(e.node);
            e.node.setAttribute("transform", "rotate(-90 ".concat(g.x, " ").concat(g.y, ") translate(").concat(d.height / 3, ")"));
          }
        } }, { key: "truncateLabels", value: function(e, t, i, a, s, r) {
          var o = new X(this.ctx), c = o.getTextRects(e, t).width + this.w.config.stroke.width + 5 > s - i && r - a > s - i ? r - a : s - i, d = o.getTextBasedOnMaxWidth({ text: e, maxWidth: c, fontSize: t });
          return e.length !== d.length && c / t < 5 ? "" : d;
        } }, { key: "animateTreemap", value: function(e, t, i, a) {
          var s = new V(this.ctx);
          s.animateRect(e, { x: t.x, y: t.y, width: t.width, height: t.height }, { x: i.x, y: i.y, width: i.width, height: i.height }, a, function() {
            s.animationCompleted(e);
          });
        } }]), P;
      }(), Ss = 86400, Cs = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w, this.timeScaleArray = [], this.utc = this.w.config.xaxis.labels.datetimeUTC;
        }
        return A(P, [{ key: "calculateTimeScaleTicks", value: function(e, t) {
          var i = this, a = this.w;
          if (a.globals.allSeriesCollapsed)
            return a.globals.labels = [], a.globals.timescaleLabels = [], [];
          var s = new ue(this.ctx), r = (t - e) / 864e5;
          this.determineInterval(r), a.globals.disableZoomIn = !1, a.globals.disableZoomOut = !1, r < 11574074074074075e-20 ? a.globals.disableZoomIn = !0 : r > 5e4 && (a.globals.disableZoomOut = !0);
          var o = s.getTimeUnitsfromTimestamp(e, t, this.utc), c = a.globals.gridWidth / r, d = c / 24, g = d / 60, f = g / 60, p = Math.floor(24 * r), m = Math.floor(1440 * r), w = Math.floor(r * Ss), C = Math.floor(r), k = Math.floor(r / 30), E = Math.floor(r / 365), _ = { minMillisecond: o.minMillisecond, minSecond: o.minSecond, minMinute: o.minMinute, minHour: o.minHour, minDate: o.minDate, minMonth: o.minMonth, minYear: o.minYear }, h = { firstVal: _, currentMillisecond: _.minMillisecond, currentSecond: _.minSecond, currentMinute: _.minMinute, currentHour: _.minHour, currentMonthDate: _.minDate, currentDate: _.minDate, currentMonth: _.minMonth, currentYear: _.minYear, daysWidthOnXAxis: c, hoursWidthOnXAxis: d, minutesWidthOnXAxis: g, secondsWidthOnXAxis: f, numberOfSeconds: w, numberOfMinutes: m, numberOfHours: p, numberOfDays: C, numberOfMonths: k, numberOfYears: E };
          switch (this.tickInterval) {
            case "years":
              this.generateYearScale(h);
              break;
            case "months":
            case "half_year":
              this.generateMonthScale(h);
              break;
            case "months_days":
            case "months_fortnight":
            case "days":
            case "week_days":
              this.generateDayScale(h);
              break;
            case "hours":
              this.generateHourScale(h);
              break;
            case "minutes_fives":
            case "minutes":
              this.generateMinuteScale(h);
              break;
            case "seconds_tens":
            case "seconds_fives":
            case "seconds":
              this.generateSecondScale(h);
          }
          var x = this.timeScaleArray.map(function(S) {
            var L = { position: S.position, unit: S.unit, year: S.year, day: S.day ? S.day : 1, hour: S.hour ? S.hour : 0, month: S.month + 1 };
            return S.unit === "month" ? u(u({}, L), {}, { day: 1, value: S.value + 1 }) : S.unit === "day" || S.unit === "hour" ? u(u({}, L), {}, { value: S.value }) : S.unit === "minute" ? u(u({}, L), {}, { value: S.value, minute: S.value }) : S.unit === "second" ? u(u({}, L), {}, { value: S.value, minute: S.minute, second: S.second }) : S;
          });
          return x.filter(function(S) {
            var L = 1, R = Math.ceil(a.globals.gridWidth / 120), O = S.value;
            a.config.xaxis.tickAmount !== void 0 && (R = a.config.xaxis.tickAmount), x.length > R && (L = Math.floor(x.length / R));
            var Y = !1, N = !1;
            switch (i.tickInterval) {
              case "years":
                S.unit === "year" && (Y = !0);
                break;
              case "half_year":
                L = 7, S.unit === "year" && (Y = !0);
                break;
              case "months":
                L = 1, S.unit === "year" && (Y = !0);
                break;
              case "months_fortnight":
                L = 15, S.unit !== "year" && S.unit !== "month" || (Y = !0), O === 30 && (N = !0);
                break;
              case "months_days":
                L = 10, S.unit === "month" && (Y = !0), O === 30 && (N = !0);
                break;
              case "week_days":
                L = 8, S.unit === "month" && (Y = !0);
                break;
              case "days":
                L = 1, S.unit === "month" && (Y = !0);
                break;
              case "hours":
                S.unit === "day" && (Y = !0);
                break;
              case "minutes_fives":
              case "seconds_fives":
                O % 5 != 0 && (N = !0);
                break;
              case "seconds_tens":
                O % 10 != 0 && (N = !0);
            }
            if (i.tickInterval === "hours" || i.tickInterval === "minutes_fives" || i.tickInterval === "seconds_tens" || i.tickInterval === "seconds_fives") {
              if (!N)
                return !0;
            } else if ((O % L == 0 || Y) && !N)
              return !0;
          });
        } }, { key: "recalcDimensionsBasedOnFormat", value: function(e, t) {
          var i = this.w, a = this.formatDates(e), s = this.removeOverlappingTS(a);
          i.globals.timescaleLabels = s.slice(), new st(this.ctx).plotCoords();
        } }, { key: "determineInterval", value: function(e) {
          var t = 24 * e, i = 60 * t;
          switch (!0) {
            case e / 365 > 5:
              this.tickInterval = "years";
              break;
            case e > 800:
              this.tickInterval = "half_year";
              break;
            case e > 180:
              this.tickInterval = "months";
              break;
            case e > 90:
              this.tickInterval = "months_fortnight";
              break;
            case e > 60:
              this.tickInterval = "months_days";
              break;
            case e > 30:
              this.tickInterval = "week_days";
              break;
            case e > 2:
              this.tickInterval = "days";
              break;
            case t > 2.4:
              this.tickInterval = "hours";
              break;
            case i > 15:
              this.tickInterval = "minutes_fives";
              break;
            case i > 5:
              this.tickInterval = "minutes";
              break;
            case i > 1:
              this.tickInterval = "seconds_tens";
              break;
            case 60 * i > 20:
              this.tickInterval = "seconds_fives";
              break;
            default:
              this.tickInterval = "seconds";
          }
        } }, { key: "generateYearScale", value: function(e) {
          var t = e.firstVal, i = e.currentMonth, a = e.currentYear, s = e.daysWidthOnXAxis, r = e.numberOfYears, o = t.minYear, c = 0, d = new ue(this.ctx), g = "year";
          if (t.minDate > 1 || t.minMonth > 0) {
            var f = d.determineRemainingDaysOfYear(t.minYear, t.minMonth, t.minDate);
            c = (d.determineDaysOfYear(t.minYear) - f + 1) * s, o = t.minYear + 1, this.timeScaleArray.push({ position: c, value: o, unit: g, year: o, month: M.monthMod(i + 1) });
          } else
            t.minDate === 1 && t.minMonth === 0 && this.timeScaleArray.push({ position: c, value: o, unit: g, year: a, month: M.monthMod(i + 1) });
          for (var p = o, m = c, w = 0; w < r; w++)
            p++, m = d.determineDaysOfYear(p - 1) * s + m, this.timeScaleArray.push({ position: m, value: p, unit: g, year: p, month: 1 });
        } }, { key: "generateMonthScale", value: function(e) {
          var t = e.firstVal, i = e.currentMonthDate, a = e.currentMonth, s = e.currentYear, r = e.daysWidthOnXAxis, o = e.numberOfMonths, c = a, d = 0, g = new ue(this.ctx), f = "month", p = 0;
          if (t.minDate > 1) {
            d = (g.determineDaysOfMonths(a + 1, t.minYear) - i + 1) * r, c = M.monthMod(a + 1);
            var m = s + p, w = M.monthMod(c), C = c;
            c === 0 && (f = "year", C = m, w = 1, m += p += 1), this.timeScaleArray.push({ position: d, value: C, unit: f, year: m, month: w });
          } else
            this.timeScaleArray.push({ position: d, value: c, unit: f, year: s, month: M.monthMod(a) });
          for (var k = c + 1, E = d, _ = 0, h = 1; _ < o; _++, h++) {
            (k = M.monthMod(k)) === 0 ? (f = "year", p += 1) : f = "month";
            var x = this._getYear(s, k, p);
            E = g.determineDaysOfMonths(k, x) * r + E;
            var S = k === 0 ? x : k;
            this.timeScaleArray.push({ position: E, value: S, unit: f, year: x, month: k === 0 ? 1 : k }), k++;
          }
        } }, { key: "generateDayScale", value: function(e) {
          var t = e.firstVal, i = e.currentMonth, a = e.currentYear, s = e.hoursWidthOnXAxis, r = e.numberOfDays, o = new ue(this.ctx), c = "day", d = t.minDate + 1, g = d, f = function(h, x, S) {
            return h > o.determineDaysOfMonths(x + 1, S) && (g = 1, c = "month", m = x += 1), x;
          }, p = (24 - t.minHour) * s, m = d, w = f(g, i, a);
          t.minHour === 0 && t.minDate === 1 ? (p = 0, m = M.monthMod(t.minMonth), c = "month", g = t.minDate) : t.minDate !== 1 && t.minHour === 0 && t.minMinute === 0 && (p = 0, d = t.minDate, m = d, w = f(g = d, i, a)), this.timeScaleArray.push({ position: p, value: m, unit: c, year: this._getYear(a, w, 0), month: M.monthMod(w), day: g });
          for (var C = p, k = 0; k < r; k++) {
            c = "day", w = f(g += 1, w, this._getYear(a, w, 0));
            var E = this._getYear(a, w, 0);
            C = 24 * s + C;
            var _ = g === 1 ? M.monthMod(w) : g;
            this.timeScaleArray.push({ position: C, value: _, unit: c, year: E, month: M.monthMod(w), day: _ });
          }
        } }, { key: "generateHourScale", value: function(e) {
          var t = e.firstVal, i = e.currentDate, a = e.currentMonth, s = e.currentYear, r = e.minutesWidthOnXAxis, o = e.numberOfHours, c = new ue(this.ctx), d = "hour", g = function(L, R) {
            return L > c.determineDaysOfMonths(R + 1, s) && (k = 1, R += 1), { month: R, date: k };
          }, f = function(L, R) {
            return L > c.determineDaysOfMonths(R + 1, s) ? R += 1 : R;
          }, p = 60 - (t.minMinute + t.minSecond / 60), m = p * r, w = t.minHour + 1, C = w;
          p === 60 && (m = 0, C = w = t.minHour);
          var k = i;
          C >= 24 && (C = 0, k += 1, d = "day");
          var E = g(k, a).month;
          E = f(k, E), this.timeScaleArray.push({ position: m, value: w, unit: d, day: k, hour: C, year: s, month: M.monthMod(E) }), C++;
          for (var _ = m, h = 0; h < o; h++) {
            d = "hour", C >= 24 && (C = 0, d = "day", E = g(k += 1, E).month, E = f(k, E));
            var x = this._getYear(s, E, 0);
            _ = 60 * r + _;
            var S = C === 0 ? k : C;
            this.timeScaleArray.push({ position: _, value: S, unit: d, hour: C, day: k, year: x, month: M.monthMod(E) }), C++;
          }
        } }, { key: "generateMinuteScale", value: function(e) {
          for (var t = e.currentMillisecond, i = e.currentSecond, a = e.currentMinute, s = e.currentHour, r = e.currentDate, o = e.currentMonth, c = e.currentYear, d = e.minutesWidthOnXAxis, g = e.secondsWidthOnXAxis, f = e.numberOfMinutes, p = a + 1, m = r, w = o, C = c, k = s, E = (60 - i - t / 1e3) * g, _ = 0; _ < f; _++)
            p >= 60 && (p = 0, (k += 1) === 24 && (k = 0)), this.timeScaleArray.push({ position: E, value: p, unit: "minute", hour: k, minute: p, day: m, year: this._getYear(C, w, 0), month: M.monthMod(w) }), E += d, p++;
        } }, { key: "generateSecondScale", value: function(e) {
          for (var t = e.currentMillisecond, i = e.currentSecond, a = e.currentMinute, s = e.currentHour, r = e.currentDate, o = e.currentMonth, c = e.currentYear, d = e.secondsWidthOnXAxis, g = e.numberOfSeconds, f = i + 1, p = a, m = r, w = o, C = c, k = s, E = (1e3 - t) / 1e3 * d, _ = 0; _ < g; _++)
            f >= 60 && (f = 0, ++p >= 60 && (p = 0, ++k === 24 && (k = 0))), this.timeScaleArray.push({ position: E, value: f, unit: "second", hour: k, minute: p, second: f, day: m, year: this._getYear(C, w, 0), month: M.monthMod(w) }), E += d, f++;
        } }, { key: "createRawDateString", value: function(e, t) {
          var i = e.year;
          return e.month === 0 && (e.month = 1), i += "-" + ("0" + e.month.toString()).slice(-2), e.unit === "day" ? i += e.unit === "day" ? "-" + ("0" + t).slice(-2) : "-01" : i += "-" + ("0" + (e.day ? e.day : "1")).slice(-2), e.unit === "hour" ? i += e.unit === "hour" ? "T" + ("0" + t).slice(-2) : "T00" : i += "T" + ("0" + (e.hour ? e.hour : "0")).slice(-2), e.unit === "minute" ? i += ":" + ("0" + t).slice(-2) : i += ":" + (e.minute ? ("0" + e.minute).slice(-2) : "00"), e.unit === "second" ? i += ":" + ("0" + t).slice(-2) : i += ":00", this.utc && (i += ".000Z"), i;
        } }, { key: "formatDates", value: function(e) {
          var t = this, i = this.w;
          return e.map(function(a) {
            var s = a.value.toString(), r = new ue(t.ctx), o = t.createRawDateString(a, s), c = r.getDate(r.parseDate(o));
            if (t.utc || (c = r.getDate(r.parseDateWithTimezone(o))), i.config.xaxis.labels.format === void 0) {
              var d = "dd MMM", g = i.config.xaxis.labels.datetimeFormatter;
              a.unit === "year" && (d = g.year), a.unit === "month" && (d = g.month), a.unit === "day" && (d = g.day), a.unit === "hour" && (d = g.hour), a.unit === "minute" && (d = g.minute), a.unit === "second" && (d = g.second), s = r.formatDate(c, d);
            } else
              s = r.formatDate(c, i.config.xaxis.labels.format);
            return { dateString: o, position: a.position, value: s, unit: a.unit, year: a.year, month: a.month };
          });
        } }, { key: "removeOverlappingTS", value: function(e) {
          var t, i = this, a = new X(this.ctx), s = !1;
          e.length > 0 && e[0].value && e.every(function(c) {
            return c.value.length === e[0].value.length;
          }) && (s = !0, t = a.getTextRects(e[0].value).width);
          var r = 0, o = e.map(function(c, d) {
            if (d > 0 && i.w.config.xaxis.labels.hideOverlappingLabels) {
              var g = s ? t : a.getTextRects(e[r].value).width, f = e[r].position;
              return c.position > f + g + 10 ? (r = d, c) : null;
            }
            return c;
          });
          return o = o.filter(function(c) {
            return c !== null;
          });
        } }, { key: "_getYear", value: function(e, t, i) {
          return e + Math.floor(t / 12) + i;
        } }]), P;
      }(), ks = function() {
        function P(e, t) {
          y(this, P), this.ctx = t, this.w = t.w, this.el = e;
        }
        return A(P, [{ key: "setupElements", value: function() {
          var e = this.w.globals, t = this.w.config, i = t.chart.type;
          e.axisCharts = ["line", "area", "bar", "rangeBar", "rangeArea", "candlestick", "boxPlot", "scatter", "bubble", "radar", "heatmap", "treemap"].indexOf(i) > -1, e.xyCharts = ["line", "area", "bar", "rangeBar", "rangeArea", "candlestick", "boxPlot", "scatter", "bubble"].indexOf(i) > -1, e.isBarHorizontal = (t.chart.type === "bar" || t.chart.type === "rangeBar" || t.chart.type === "boxPlot") && t.plotOptions.bar.horizontal, e.chartClass = ".apexcharts" + e.chartID, e.dom.baseEl = this.el, e.dom.elWrap = document.createElement("div"), X.setAttrs(e.dom.elWrap, { id: e.chartClass.substring(1), class: "apexcharts-canvas " + e.chartClass.substring(1) }), this.el.appendChild(e.dom.elWrap), e.dom.Paper = new window.SVG.Doc(e.dom.elWrap), e.dom.Paper.attr({ class: "apexcharts-svg", "xmlns:data": "ApexChartsNS", transform: "translate(".concat(t.chart.offsetX, ", ").concat(t.chart.offsetY, ")") }), e.dom.Paper.node.style.background = t.theme.mode !== "dark" || t.chart.background ? t.chart.background : "rgba(0, 0, 0, 0.8)", this.setSVGDimensions(), e.dom.elLegendForeign = document.createElementNS(e.SVGNS, "foreignObject"), X.setAttrs(e.dom.elLegendForeign, { x: 0, y: 0, width: e.svgWidth, height: e.svgHeight }), e.dom.elLegendWrap = document.createElement("div"), e.dom.elLegendWrap.classList.add("apexcharts-legend"), e.dom.elLegendWrap.setAttribute("xmlns", "http://www.w3.org/1999/xhtml"), e.dom.elLegendForeign.appendChild(e.dom.elLegendWrap), e.dom.Paper.node.appendChild(e.dom.elLegendForeign), e.dom.elGraphical = e.dom.Paper.group().attr({ class: "apexcharts-inner apexcharts-graphical" }), e.dom.elDefs = e.dom.Paper.defs(), e.dom.Paper.add(e.dom.elGraphical), e.dom.elGraphical.add(e.dom.elDefs);
        } }, { key: "plotChartType", value: function(e, t) {
          var i = this.w, a = i.config, s = i.globals, r = { series: [], i: [] }, o = { series: [], i: [] }, c = { series: [], i: [] }, d = { series: [], i: [] }, g = { series: [], i: [] }, f = { series: [], i: [] }, p = { series: [], i: [] }, m = { series: [], i: [] }, w = { series: [], seriesRangeEnd: [], i: [] };
          s.series.map(function(R, O) {
            var Y = 0;
            e[O].type !== void 0 ? (e[O].type === "column" || e[O].type === "bar" ? (s.series.length > 1 && a.plotOptions.bar.horizontal && console.warn("Horizontal bars are not supported in a mixed/combo chart. Please turn off `plotOptions.bar.horizontal`"), g.series.push(R), g.i.push(O), Y++, i.globals.columnSeries = g.series) : e[O].type === "area" ? (o.series.push(R), o.i.push(O), Y++) : e[O].type === "line" ? (r.series.push(R), r.i.push(O), Y++) : e[O].type === "scatter" ? (c.series.push(R), c.i.push(O)) : e[O].type === "bubble" ? (d.series.push(R), d.i.push(O), Y++) : e[O].type === "candlestick" ? (f.series.push(R), f.i.push(O), Y++) : e[O].type === "boxPlot" ? (p.series.push(R), p.i.push(O), Y++) : e[O].type === "rangeBar" ? (m.series.push(R), m.i.push(O), Y++) : e[O].type === "rangeArea" ? (w.series.push(s.seriesRangeStart[O]), w.seriesRangeEnd.push(s.seriesRangeEnd[O]), w.i.push(O), Y++) : console.warn("You have specified an unrecognized chart type. Available types for this property are line/area/column/bar/scatter/bubble/candlestick/boxPlot/rangeBar/rangeArea"), Y > 1 && (s.comboCharts = !0)) : (r.series.push(R), r.i.push(O));
          });
          var C = new si(this.ctx, t), k = new ti(this.ctx, t);
          this.ctx.pie = new Bi(this.ctx);
          var E = new ms(this.ctx);
          this.ctx.rangeBar = new vs(this.ctx, t);
          var _ = new xs(this.ctx), h = [];
          if (s.comboCharts) {
            if (o.series.length > 0 && h.push(C.draw(o.series, "area", o.i)), g.series.length > 0)
              if (i.config.chart.stacked) {
                var x = new Yi(this.ctx, t);
                h.push(x.draw(g.series, g.i));
              } else
                this.ctx.bar = new bt(this.ctx, t), h.push(this.ctx.bar.draw(g.series, g.i));
            if (w.series.length > 0 && h.push(C.draw(w.series, "rangeArea", w.i, w.seriesRangeEnd)), r.series.length > 0 && h.push(C.draw(r.series, "line", r.i)), f.series.length > 0 && h.push(k.draw(f.series, "candlestick", f.i)), p.series.length > 0 && h.push(k.draw(p.series, "boxPlot", p.i)), m.series.length > 0 && h.push(this.ctx.rangeBar.draw(m.series, m.i)), c.series.length > 0) {
              var S = new si(this.ctx, t, !0);
              h.push(S.draw(c.series, "scatter", c.i));
            }
            if (d.series.length > 0) {
              var L = new si(this.ctx, t, !0);
              h.push(L.draw(d.series, "bubble", d.i));
            }
          } else
            switch (a.chart.type) {
              case "line":
                h = C.draw(s.series, "line");
                break;
              case "area":
                h = C.draw(s.series, "area");
                break;
              case "bar":
                a.chart.stacked ? h = new Yi(this.ctx, t).draw(s.series) : (this.ctx.bar = new bt(this.ctx, t), h = this.ctx.bar.draw(s.series));
                break;
              case "candlestick":
                h = new ti(this.ctx, t).draw(s.series, "candlestick");
                break;
              case "boxPlot":
                h = new ti(this.ctx, t).draw(s.series, a.chart.type);
                break;
              case "rangeBar":
                h = this.ctx.rangeBar.draw(s.series);
                break;
              case "rangeArea":
                h = C.draw(s.seriesRangeStart, "rangeArea", void 0, s.seriesRangeEnd);
                break;
              case "heatmap":
                h = new ps(this.ctx, t).draw(s.series);
                break;
              case "treemap":
                h = new ws(this.ctx, t).draw(s.series);
                break;
              case "pie":
              case "donut":
              case "polarArea":
                h = this.ctx.pie.draw(s.series);
                break;
              case "radialBar":
                h = E.draw(s.series);
                break;
              case "radar":
                h = _.draw(s.series);
                break;
              default:
                h = C.draw(s.series);
            }
          return h;
        } }, { key: "setSVGDimensions", value: function() {
          var e = this.w.globals, t = this.w.config;
          e.svgWidth = t.chart.width, e.svgHeight = t.chart.height;
          var i = M.getDimensions(this.el), a = t.chart.width.toString().split(/[0-9]+/g).pop();
          a === "%" ? M.isNumber(i[0]) && (i[0].width === 0 && (i = M.getDimensions(this.el.parentNode)), e.svgWidth = i[0] * parseInt(t.chart.width, 10) / 100) : a !== "px" && a !== "" || (e.svgWidth = parseInt(t.chart.width, 10));
          var s = t.chart.height.toString().split(/[0-9]+/g).pop();
          if (e.svgHeight !== "auto" && e.svgHeight !== "")
            if (s === "%") {
              var r = M.getDimensions(this.el.parentNode);
              e.svgHeight = r[1] * parseInt(t.chart.height, 10) / 100;
            } else
              e.svgHeight = parseInt(t.chart.height, 10);
          else
            e.axisCharts ? e.svgHeight = e.svgWidth / 1.61 : e.svgHeight = e.svgWidth / 1.2;
          if (e.svgWidth < 0 && (e.svgWidth = 0), e.svgHeight < 0 && (e.svgHeight = 0), X.setAttrs(e.dom.Paper.node, { width: e.svgWidth, height: e.svgHeight }), s !== "%") {
            var o = t.chart.sparkline.enabled ? 0 : e.axisCharts ? t.chart.parentHeightOffset : 0;
            e.dom.Paper.node.parentNode.parentNode.style.minHeight = e.svgHeight + o + "px";
          }
          e.dom.elWrap.style.width = e.svgWidth + "px", e.dom.elWrap.style.height = e.svgHeight + "px";
        } }, { key: "shiftGraphPosition", value: function() {
          var e = this.w.globals, t = e.translateY, i = { transform: "translate(" + e.translateX + ", " + t + ")" };
          X.setAttrs(e.dom.elGraphical.node, i);
        } }, { key: "resizeNonAxisCharts", value: function() {
          var e = this.w, t = e.globals, i = 0, a = e.config.chart.sparkline.enabled ? 1 : 15;
          a += e.config.grid.padding.bottom, e.config.legend.position !== "top" && e.config.legend.position !== "bottom" || !e.config.legend.show || e.config.legend.floating || (i = new Oi(this.ctx).legendHelpers.getLegendBBox().clwh + 10);
          var s = e.globals.dom.baseEl.querySelector(".apexcharts-radialbar, .apexcharts-pie"), r = 2.05 * e.globals.radialSize;
          if (s && !e.config.chart.sparkline.enabled && e.config.plotOptions.radialBar.startAngle !== 0) {
            var o = M.getBoundingClientRect(s);
            r = o.bottom;
            var c = o.bottom - o.top;
            r = Math.max(2.05 * e.globals.radialSize, c);
          }
          var d = r + t.translateY + i + a;
          t.dom.elLegendForeign && t.dom.elLegendForeign.setAttribute("height", d), e.config.chart.height && String(e.config.chart.height).indexOf("%") > 0 || (t.dom.elWrap.style.height = d + "px", X.setAttrs(t.dom.Paper.node, { height: d }), t.dom.Paper.node.parentNode.parentNode.style.minHeight = d + "px");
        } }, { key: "coreCalculations", value: function() {
          new De(this.ctx).init();
        } }, { key: "resetGlobals", value: function() {
          var e = this, t = function() {
            return e.w.config.series.map(function(s) {
              return [];
            });
          }, i = new oe(), a = this.w.globals;
          i.initGlobalVars(a), a.seriesXvalues = t(), a.seriesYvalues = t();
        } }, { key: "isMultipleY", value: function() {
          if (this.w.config.yaxis.constructor === Array && this.w.config.yaxis.length > 1)
            return this.w.globals.isMultipleYAxis = !0, !0;
        } }, { key: "xySettings", value: function() {
          var e = null, t = this.w;
          if (t.globals.axisCharts) {
            if (t.config.xaxis.crosshairs.position === "back" && new Ye(this.ctx).drawXCrosshairs(), t.config.yaxis[0].crosshairs.position === "back" && new Ye(this.ctx).drawYCrosshairs(), t.config.xaxis.type === "datetime" && t.config.xaxis.labels.formatter === void 0) {
              this.ctx.timeScale = new Cs(this.ctx);
              var i = [];
              isFinite(t.globals.minX) && isFinite(t.globals.maxX) && !t.globals.isBarHorizontal ? i = this.ctx.timeScale.calculateTimeScaleTicks(t.globals.minX, t.globals.maxX) : t.globals.isBarHorizontal && (i = this.ctx.timeScale.calculateTimeScaleTicks(t.globals.minY, t.globals.maxY)), this.ctx.timeScale.recalcDimensionsBasedOnFormat(i);
            }
            e = new $(this.ctx).getCalculatedRatios();
          }
          return e;
        } }, { key: "updateSourceChart", value: function(e) {
          this.ctx.w.globals.selection = void 0, this.ctx.updateHelpers._updateOptions({ chart: { selection: { xaxis: { min: e.w.globals.minX, max: e.w.globals.maxX } } } }, !1, !1);
        } }, { key: "setupBrushHandler", value: function() {
          var e = this, t = this.w;
          if (t.config.chart.brush.enabled && typeof t.config.chart.events.selection != "function") {
            var i = Array.isArray(t.config.chart.brush.targets) || [t.config.chart.brush.target];
            i.forEach(function(a) {
              var s = ApexCharts.getChartByID(a);
              s.w.globals.brushSource = e.ctx, typeof s.w.config.chart.events.zoomed != "function" && (s.w.config.chart.events.zoomed = function() {
                e.updateSourceChart(s);
              }), typeof s.w.config.chart.events.scrolled != "function" && (s.w.config.chart.events.scrolled = function() {
                e.updateSourceChart(s);
              });
            }), t.config.chart.events.selection = function(a, s) {
              i.forEach(function(r) {
                var o = ApexCharts.getChartByID(r), c = M.clone(t.config.yaxis);
                if (t.config.chart.brush.autoScaleYaxis && o.w.globals.series.length === 1) {
                  var d = new ze(o);
                  c = d.autoScaleY(o, c, s);
                }
                var g = o.w.config.yaxis.reduce(function(f, p, m) {
                  return [].concat(j(f), [u(u({}, o.w.config.yaxis[m]), {}, { min: c[0].min, max: c[0].max })]);
                }, []);
                o.ctx.updateHelpers._updateOptions({ xaxis: { min: s.xaxis.min, max: s.xaxis.max }, yaxis: g }, !1, !1, !1, !1);
              });
            };
          }
        } }]), P;
      }(), As = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "_updateOptions", value: function(e) {
          var t = this, i = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], a = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], s = !(arguments.length > 3 && arguments[3] !== void 0) || arguments[3], r = arguments.length > 4 && arguments[4] !== void 0 && arguments[4];
          return new Promise(function(o) {
            var c = [t.ctx];
            s && (c = t.ctx.getSyncedCharts()), t.ctx.w.globals.isExecCalled && (c = [t.ctx], t.ctx.w.globals.isExecCalled = !1), c.forEach(function(d, g) {
              var f = d.w;
              if (f.globals.shouldAnimate = a, i || (f.globals.resized = !0, f.globals.dataChanged = !0, a && d.series.getPreviousPaths()), e && b(e) === "object" && (d.config = new Te(e), e = $.extendArrayProps(d.config, e, f), d.w.globals.chartID !== t.ctx.w.globals.chartID && delete e.series, f.config = M.extend(f.config, e), r && (f.globals.lastXAxis = e.xaxis ? M.clone(e.xaxis) : [], f.globals.lastYAxis = e.yaxis ? M.clone(e.yaxis) : [], f.globals.initialConfig = M.extend({}, f.config), f.globals.initialSeries = M.clone(f.config.series), e.series))) {
                for (var p = 0; p < f.globals.collapsedSeriesIndices.length; p++) {
                  var m = f.config.series[f.globals.collapsedSeriesIndices[p]];
                  f.globals.collapsedSeries[p].data = f.globals.axisCharts ? m.data.slice() : m;
                }
                for (var w = 0; w < f.globals.ancillaryCollapsedSeriesIndices.length; w++) {
                  var C = f.config.series[f.globals.ancillaryCollapsedSeriesIndices[w]];
                  f.globals.ancillaryCollapsedSeries[w].data = f.globals.axisCharts ? C.data.slice() : C;
                }
                d.series.emptyCollapsedSeries(f.config.series);
              }
              return d.update(e).then(function() {
                g === c.length - 1 && o(d);
              });
            });
          });
        } }, { key: "_updateSeries", value: function(e, t) {
          var i = this, a = arguments.length > 2 && arguments[2] !== void 0 && arguments[2];
          return new Promise(function(s) {
            var r, o = i.w;
            return o.globals.shouldAnimate = t, o.globals.dataChanged = !0, t && i.ctx.series.getPreviousPaths(), o.globals.axisCharts ? ((r = e.map(function(c, d) {
              return i._extendSeries(c, d);
            })).length === 0 && (r = [{ data: [] }]), o.config.series = r) : o.config.series = e.slice(), a && (o.globals.initialConfig.series = M.clone(o.config.series), o.globals.initialSeries = M.clone(o.config.series)), i.ctx.update().then(function() {
              s(i.ctx);
            });
          });
        } }, { key: "_extendSeries", value: function(e, t) {
          var i = this.w, a = i.config.series[t];
          return u(u({}, i.config.series[t]), {}, { name: e.name ? e.name : a == null ? void 0 : a.name, color: e.color ? e.color : a == null ? void 0 : a.color, type: e.type ? e.type : a == null ? void 0 : a.type, group: e.group ? e.group : a == null ? void 0 : a.group, data: e.data ? e.data : a == null ? void 0 : a.data, zIndex: e.zIndex !== void 0 ? e.zIndex : t });
        } }, { key: "toggleDataPointSelection", value: function(e, t) {
          var i = this.w, a = null, s = ".apexcharts-series[data\\:realIndex='".concat(e, "']");
          return i.globals.axisCharts ? a = i.globals.dom.Paper.select("".concat(s, " path[j='").concat(t, "'], ").concat(s, " circle[j='").concat(t, "'], ").concat(s, " rect[j='").concat(t, "']")).members[0] : t === void 0 && (a = i.globals.dom.Paper.select("".concat(s, " path[j='").concat(e, "']")).members[0], i.config.chart.type !== "pie" && i.config.chart.type !== "polarArea" && i.config.chart.type !== "donut" || this.ctx.pie.pieClicked(e)), a ? (new X(this.ctx).pathMouseDown(a, null), a.node ? a.node : null) : (console.warn("toggleDataPointSelection: Element not found"), null);
        } }, { key: "forceXAxisUpdate", value: function(e) {
          var t = this.w;
          if (["min", "max"].forEach(function(a) {
            e.xaxis[a] !== void 0 && (t.config.xaxis[a] = e.xaxis[a], t.globals.lastXAxis[a] = e.xaxis[a]);
          }), e.xaxis.categories && e.xaxis.categories.length && (t.config.xaxis.categories = e.xaxis.categories), t.config.xaxis.convertedCatToNumeric) {
            var i = new Me(e);
            e = i.convertCatToNumericXaxis(e, this.ctx);
          }
          return e;
        } }, { key: "forceYAxisUpdate", value: function(e) {
          return e.chart && e.chart.stacked && e.chart.stackType === "100%" && (Array.isArray(e.yaxis) ? e.yaxis.forEach(function(t, i) {
            e.yaxis[i].min = 0, e.yaxis[i].max = 100;
          }) : (e.yaxis.min = 0, e.yaxis.max = 100)), e;
        } }, { key: "revertDefaultAxisMinMax", value: function(e) {
          var t = this, i = this.w, a = i.globals.lastXAxis, s = i.globals.lastYAxis;
          e && e.xaxis && (a = e.xaxis), e && e.yaxis && (s = e.yaxis), i.config.xaxis.min = a.min, i.config.xaxis.max = a.max;
          var r = function(o) {
            s[o] !== void 0 && (i.config.yaxis[o].min = s[o].min, i.config.yaxis[o].max = s[o].max);
          };
          i.config.yaxis.map(function(o, c) {
            i.globals.zoomed || s[c] !== void 0 ? r(c) : t.ctx.opts.yaxis[c] !== void 0 && (o.min = t.ctx.opts.yaxis[c].min, o.max = t.ctx.opts.yaxis[c].max);
          });
        } }]), P;
      }();
      ht = typeof window < "u" ? window : void 0, Xt = function(P, e) {
        var t = (this !== void 0 ? this : P).SVG = function(h) {
          if (t.supported)
            return h = new t.Doc(h), t.parser.draw || t.prepare(), h;
        };
        if (t.ns = "http://www.w3.org/2000/svg", t.xmlns = "http://www.w3.org/2000/xmlns/", t.xlink = "http://www.w3.org/1999/xlink", t.svgjs = "http://svgjs.dev", t.supported = !0, !t.supported)
          return !1;
        t.did = 1e3, t.eid = function(h) {
          return "Svgjs" + g(h) + t.did++;
        }, t.create = function(h) {
          var x = e.createElementNS(this.ns, h);
          return x.setAttribute("id", this.eid(h)), x;
        }, t.extend = function() {
          var h, x;
          x = (h = [].slice.call(arguments)).pop();
          for (var S = h.length - 1; S >= 0; S--)
            if (h[S])
              for (var L in x)
                h[S].prototype[L] = x[L];
          t.Set && t.Set.inherit && t.Set.inherit();
        }, t.invent = function(h) {
          var x = typeof h.create == "function" ? h.create : function() {
            this.constructor.call(this, t.create(h.create));
          };
          return h.inherit && (x.prototype = new h.inherit()), h.extend && t.extend(x, h.extend), h.construct && t.extend(h.parent || t.Container, h.construct), x;
        }, t.adopt = function(h) {
          return h ? h.instance ? h.instance : ((x = h.nodeName == "svg" ? h.parentNode instanceof P.SVGElement ? new t.Nested() : new t.Doc() : h.nodeName == "linearGradient" ? new t.Gradient("linear") : h.nodeName == "radialGradient" ? new t.Gradient("radial") : t[g(h.nodeName)] ? new t[g(h.nodeName)]() : new t.Element(h)).type = h.nodeName, x.node = h, h.instance = x, x instanceof t.Doc && x.namespace().defs(), x.setData(JSON.parse(h.getAttribute("svgjs:data")) || {}), x) : null;
          var x;
        }, t.prepare = function() {
          var h = e.getElementsByTagName("body")[0], x = (h ? new t.Doc(h) : t.adopt(e.documentElement).nested()).size(2, 0);
          t.parser = { body: h || e.documentElement, draw: x.style("opacity:0;position:absolute;left:-100%;top:-100%;overflow:hidden").node, poly: x.polyline().node, path: x.path().node, native: t.create("svg") };
        }, t.parser = { native: t.create("svg") }, e.addEventListener("DOMContentLoaded", function() {
          t.parser.draw || t.prepare();
        }, !1), t.regex = { numberAndUnit: /^([+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?)([a-z%]*)$/i, hex: /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i, rgb: /rgb\((\d+),(\d+),(\d+)\)/, reference: /#([a-z0-9\-_]+)/i, transforms: /\)\s*,?\s*/, whitespace: /\s/g, isHex: /^#[a-f0-9]{3,6}$/i, isRgb: /^rgb\(/, isCss: /[^:]+:[^;]+;?/, isBlank: /^(\s+)?$/, isNumber: /^[+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i, isPercent: /^-?[\d\.]+%$/, isImage: /\.(jpg|jpeg|png|gif|svg)(\?[^=]+.*)?/i, delimiter: /[\s,]+/, hyphen: /([^e])\-/gi, pathLetters: /[MLHVCSQTAZ]/gi, isPathLetter: /[MLHVCSQTAZ]/i, numbersWithDots: /((\d?\.\d+(?:e[+-]?\d+)?)((?:\.\d+(?:e[+-]?\d+)?)+))+/gi, dots: /\./g }, t.utils = { map: function(h, x) {
          for (var S = h.length, L = [], R = 0; R < S; R++)
            L.push(x(h[R]));
          return L;
        }, filter: function(h, x) {
          for (var S = h.length, L = [], R = 0; R < S; R++)
            x(h[R]) && L.push(h[R]);
          return L;
        }, filterSVGElements: function(h) {
          return this.filter(h, function(x) {
            return x instanceof P.SVGElement;
          });
        } }, t.defaults = { attrs: { "fill-opacity": 1, "stroke-opacity": 1, "stroke-width": 0, "stroke-linejoin": "miter", "stroke-linecap": "butt", fill: "#000000", stroke: "#000000", opacity: 1, x: 0, y: 0, cx: 0, cy: 0, width: 0, height: 0, r: 0, rx: 0, ry: 0, offset: 0, "stop-opacity": 1, "stop-color": "#000000", "font-size": 16, "font-family": "Helvetica, Arial, sans-serif", "text-anchor": "start" } }, t.Color = function(h) {
          var x, S;
          this.r = 0, this.g = 0, this.b = 0, h && (typeof h == "string" ? t.regex.isRgb.test(h) ? (x = t.regex.rgb.exec(h.replace(t.regex.whitespace, "")), this.r = parseInt(x[1]), this.g = parseInt(x[2]), this.b = parseInt(x[3])) : t.regex.isHex.test(h) && (x = t.regex.hex.exec((S = h).length == 4 ? ["#", S.substring(1, 2), S.substring(1, 2), S.substring(2, 3), S.substring(2, 3), S.substring(3, 4), S.substring(3, 4)].join("") : S), this.r = parseInt(x[1], 16), this.g = parseInt(x[2], 16), this.b = parseInt(x[3], 16)) : b(h) === "object" && (this.r = h.r, this.g = h.g, this.b = h.b));
        }, t.extend(t.Color, { toString: function() {
          return this.toHex();
        }, toHex: function() {
          return "#" + f(this.r) + f(this.g) + f(this.b);
        }, toRgb: function() {
          return "rgb(" + [this.r, this.g, this.b].join() + ")";
        }, brightness: function() {
          return this.r / 255 * 0.3 + this.g / 255 * 0.59 + this.b / 255 * 0.11;
        }, morph: function(h) {
          return this.destination = new t.Color(h), this;
        }, at: function(h) {
          return this.destination ? (h = h < 0 ? 0 : h > 1 ? 1 : h, new t.Color({ r: ~~(this.r + (this.destination.r - this.r) * h), g: ~~(this.g + (this.destination.g - this.g) * h), b: ~~(this.b + (this.destination.b - this.b) * h) })) : this;
        } }), t.Color.test = function(h) {
          return h += "", t.regex.isHex.test(h) || t.regex.isRgb.test(h);
        }, t.Color.isRgb = function(h) {
          return h && typeof h.r == "number" && typeof h.g == "number" && typeof h.b == "number";
        }, t.Color.isColor = function(h) {
          return t.Color.isRgb(h) || t.Color.test(h);
        }, t.Array = function(h, x) {
          (h = (h || []).valueOf()).length == 0 && x && (h = x.valueOf()), this.value = this.parse(h);
        }, t.extend(t.Array, { toString: function() {
          return this.value.join(" ");
        }, valueOf: function() {
          return this.value;
        }, parse: function(h) {
          return h = h.valueOf(), Array.isArray(h) ? h : this.split(h);
        } }), t.PointArray = function(h, x) {
          t.Array.call(this, h, x || [[0, 0]]);
        }, t.PointArray.prototype = new t.Array(), t.PointArray.prototype.constructor = t.PointArray;
        for (var i = { M: function(h, x, S) {
          return x.x = S.x = h[0], x.y = S.y = h[1], ["M", x.x, x.y];
        }, L: function(h, x) {
          return x.x = h[0], x.y = h[1], ["L", h[0], h[1]];
        }, H: function(h, x) {
          return x.x = h[0], ["H", h[0]];
        }, V: function(h, x) {
          return x.y = h[0], ["V", h[0]];
        }, C: function(h, x) {
          return x.x = h[4], x.y = h[5], ["C", h[0], h[1], h[2], h[3], h[4], h[5]];
        }, Q: function(h, x) {
          return x.x = h[2], x.y = h[3], ["Q", h[0], h[1], h[2], h[3]];
        }, S: function(h, x) {
          return x.x = h[2], x.y = h[3], ["S", h[0], h[1], h[2], h[3]];
        }, Z: function(h, x, S) {
          return x.x = S.x, x.y = S.y, ["Z"];
        } }, a = "mlhvqtcsaz".split(""), s = 0, r = a.length; s < r; ++s)
          i[a[s]] = function(h) {
            return function(x, S, L) {
              if (h == "H")
                x[0] = x[0] + S.x;
              else if (h == "V")
                x[0] = x[0] + S.y;
              else if (h == "A")
                x[5] = x[5] + S.x, x[6] = x[6] + S.y;
              else
                for (var R = 0, O = x.length; R < O; ++R)
                  x[R] = x[R] + (R % 2 ? S.y : S.x);
              if (i && typeof i[h] == "function")
                return i[h](x, S, L);
            };
          }(a[s].toUpperCase());
        t.PathArray = function(h, x) {
          t.Array.call(this, h, x || [["M", 0, 0]]);
        }, t.PathArray.prototype = new t.Array(), t.PathArray.prototype.constructor = t.PathArray, t.extend(t.PathArray, { toString: function() {
          return function(h) {
            for (var x = 0, S = h.length, L = ""; x < S; x++)
              L += h[x][0], h[x][1] != null && (L += h[x][1], h[x][2] != null && (L += " ", L += h[x][2], h[x][3] != null && (L += " ", L += h[x][3], L += " ", L += h[x][4], h[x][5] != null && (L += " ", L += h[x][5], L += " ", L += h[x][6], h[x][7] != null && (L += " ", L += h[x][7])))));
            return L + " ";
          }(this.value);
        }, move: function(h, x) {
          var S = this.bbox();
          return S.x, S.y, this;
        }, at: function(h) {
          if (!this.destination)
            return this;
          for (var x = this.value, S = this.destination.value, L = [], R = new t.PathArray(), O = 0, Y = x.length; O < Y; O++) {
            L[O] = [x[O][0]];
            for (var N = 1, q = x[O].length; N < q; N++)
              L[O][N] = x[O][N] + (S[O][N] - x[O][N]) * h;
            L[O][0] === "A" && (L[O][4] = +(L[O][4] != 0), L[O][5] = +(L[O][5] != 0));
          }
          return R.value = L, R;
        }, parse: function(h) {
          if (h instanceof t.PathArray)
            return h.valueOf();
          var x, S = { M: 2, L: 2, H: 1, V: 1, C: 6, S: 4, Q: 4, T: 2, A: 7, Z: 0 };
          h = typeof h == "string" ? h.replace(t.regex.numbersWithDots, c).replace(t.regex.pathLetters, " $& ").replace(t.regex.hyphen, "$1 -").trim().split(t.regex.delimiter) : h.reduce(function(q, Z) {
            return [].concat.call(q, Z);
          }, []);
          var L = [], R = new t.Point(), O = new t.Point(), Y = 0, N = h.length;
          do
            t.regex.isPathLetter.test(h[Y]) ? (x = h[Y], ++Y) : x == "M" ? x = "L" : x == "m" && (x = "l"), L.push(i[x].call(null, h.slice(Y, Y += S[x.toUpperCase()]).map(parseFloat), R, O));
          while (N > Y);
          return L;
        }, bbox: function() {
          return t.parser.draw || t.prepare(), t.parser.path.setAttribute("d", this.toString()), t.parser.path.getBBox();
        } }), t.Number = t.invent({ create: function(h, x) {
          this.value = 0, this.unit = x || "", typeof h == "number" ? this.value = isNaN(h) ? 0 : isFinite(h) ? h : h < 0 ? -34e37 : 34e37 : typeof h == "string" ? (x = h.match(t.regex.numberAndUnit)) && (this.value = parseFloat(x[1]), x[5] == "%" ? this.value /= 100 : x[5] == "s" && (this.value *= 1e3), this.unit = x[5]) : h instanceof t.Number && (this.value = h.valueOf(), this.unit = h.unit);
        }, extend: { toString: function() {
          return (this.unit == "%" ? ~~(1e8 * this.value) / 1e6 : this.unit == "s" ? this.value / 1e3 : this.value) + this.unit;
        }, toJSON: function() {
          return this.toString();
        }, valueOf: function() {
          return this.value;
        }, plus: function(h) {
          return h = new t.Number(h), new t.Number(this + h, this.unit || h.unit);
        }, minus: function(h) {
          return h = new t.Number(h), new t.Number(this - h, this.unit || h.unit);
        }, times: function(h) {
          return h = new t.Number(h), new t.Number(this * h, this.unit || h.unit);
        }, divide: function(h) {
          return h = new t.Number(h), new t.Number(this / h, this.unit || h.unit);
        }, to: function(h) {
          var x = new t.Number(this);
          return typeof h == "string" && (x.unit = h), x;
        }, morph: function(h) {
          return this.destination = new t.Number(h), h.relative && (this.destination.value += this.value), this;
        }, at: function(h) {
          return this.destination ? new t.Number(this.destination).minus(this).times(h).plus(this) : this;
        } } }), t.Element = t.invent({ create: function(h) {
          this._stroke = t.defaults.attrs.stroke, this._event = null, this.dom = {}, (this.node = h) && (this.type = h.nodeName, this.node.instance = this, this._stroke = h.getAttribute("stroke") || this._stroke);
        }, extend: { x: function(h) {
          return this.attr("x", h);
        }, y: function(h) {
          return this.attr("y", h);
        }, cx: function(h) {
          return h == null ? this.x() + this.width() / 2 : this.x(h - this.width() / 2);
        }, cy: function(h) {
          return h == null ? this.y() + this.height() / 2 : this.y(h - this.height() / 2);
        }, move: function(h, x) {
          return this.x(h).y(x);
        }, center: function(h, x) {
          return this.cx(h).cy(x);
        }, width: function(h) {
          return this.attr("width", h);
        }, height: function(h) {
          return this.attr("height", h);
        }, size: function(h, x) {
          var S = p(this, h, x);
          return this.width(new t.Number(S.width)).height(new t.Number(S.height));
        }, clone: function(h) {
          this.writeDataToDom();
          var x = C(this.node.cloneNode(!0));
          return h ? h.add(x) : this.after(x), x;
        }, remove: function() {
          return this.parent() && this.parent().removeElement(this), this;
        }, replace: function(h) {
          return this.after(h).remove(), h;
        }, addTo: function(h) {
          return h.put(this);
        }, putIn: function(h) {
          return h.add(this);
        }, id: function(h) {
          return this.attr("id", h);
        }, show: function() {
          return this.style("display", "");
        }, hide: function() {
          return this.style("display", "none");
        }, visible: function() {
          return this.style("display") != "none";
        }, toString: function() {
          return this.attr("id");
        }, classes: function() {
          var h = this.attr("class");
          return h == null ? [] : h.trim().split(t.regex.delimiter);
        }, hasClass: function(h) {
          return this.classes().indexOf(h) != -1;
        }, addClass: function(h) {
          if (!this.hasClass(h)) {
            var x = this.classes();
            x.push(h), this.attr("class", x.join(" "));
          }
          return this;
        }, removeClass: function(h) {
          return this.hasClass(h) && this.attr("class", this.classes().filter(function(x) {
            return x != h;
          }).join(" ")), this;
        }, toggleClass: function(h) {
          return this.hasClass(h) ? this.removeClass(h) : this.addClass(h);
        }, reference: function(h) {
          return t.get(this.attr(h));
        }, parent: function(h) {
          var x = this;
          if (!x.node.parentNode)
            return null;
          if (x = t.adopt(x.node.parentNode), !h)
            return x;
          for (; x && x.node instanceof P.SVGElement; ) {
            if (typeof h == "string" ? x.matches(h) : x instanceof h)
              return x;
            if (!x.node.parentNode || x.node.parentNode.nodeName == "#document")
              return null;
            x = t.adopt(x.node.parentNode);
          }
        }, doc: function() {
          return this instanceof t.Doc ? this : this.parent(t.Doc);
        }, parents: function(h) {
          var x = [], S = this;
          do {
            if (!(S = S.parent(h)) || !S.node)
              break;
            x.push(S);
          } while (S.parent);
          return x;
        }, matches: function(h) {
          return function(x, S) {
            return (x.matches || x.matchesSelector || x.msMatchesSelector || x.mozMatchesSelector || x.webkitMatchesSelector || x.oMatchesSelector).call(x, S);
          }(this.node, h);
        }, native: function() {
          return this.node;
        }, svg: function(h) {
          var x = e.createElement("svg");
          if (!(h && this instanceof t.Parent))
            return x.appendChild(h = e.createElement("svg")), this.writeDataToDom(), h.appendChild(this.node.cloneNode(!0)), x.innerHTML.replace(/^<svg>/, "").replace(/<\/svg>$/, "");
          x.innerHTML = "<svg>" + h.replace(/\n/, "").replace(/<([\w:-]+)([^<]+?)\/>/g, "<$1$2></$1>") + "</svg>";
          for (var S = 0, L = x.firstChild.childNodes.length; S < L; S++)
            this.node.appendChild(x.firstChild.firstChild);
          return this;
        }, writeDataToDom: function() {
          return (this.each || this.lines) && (this.each ? this : this.lines()).each(function() {
            this.writeDataToDom();
          }), this.node.removeAttribute("svgjs:data"), Object.keys(this.dom).length && this.node.setAttribute("svgjs:data", JSON.stringify(this.dom)), this;
        }, setData: function(h) {
          return this.dom = h, this;
        }, is: function(h) {
          return function(x, S) {
            return x instanceof S;
          }(this, h);
        } } }), t.easing = { "-": function(h) {
          return h;
        }, "<>": function(h) {
          return -Math.cos(h * Math.PI) / 2 + 0.5;
        }, ">": function(h) {
          return Math.sin(h * Math.PI / 2);
        }, "<": function(h) {
          return 1 - Math.cos(h * Math.PI / 2);
        } }, t.morph = function(h) {
          return function(x, S) {
            return new t.MorphObj(x, S).at(h);
          };
        }, t.Situation = t.invent({ create: function(h) {
          this.init = !1, this.reversed = !1, this.reversing = !1, this.duration = new t.Number(h.duration).valueOf(), this.delay = new t.Number(h.delay).valueOf(), this.start = +/* @__PURE__ */ new Date() + this.delay, this.finish = this.start + this.duration, this.ease = h.ease, this.loop = 0, this.loops = !1, this.animations = {}, this.attrs = {}, this.styles = {}, this.transforms = [], this.once = {};
        } }), t.FX = t.invent({ create: function(h) {
          this._target = h, this.situations = [], this.active = !1, this.situation = null, this.paused = !1, this.lastPos = 0, this.pos = 0, this.absPos = 0, this._speed = 1;
        }, extend: { animate: function(h, x, S) {
          b(h) === "object" && (x = h.ease, S = h.delay, h = h.duration);
          var L = new t.Situation({ duration: h || 1e3, delay: S || 0, ease: t.easing[x || "-"] || x });
          return this.queue(L), this;
        }, target: function(h) {
          return h && h instanceof t.Element ? (this._target = h, this) : this._target;
        }, timeToAbsPos: function(h) {
          return (h - this.situation.start) / (this.situation.duration / this._speed);
        }, absPosToTime: function(h) {
          return this.situation.duration / this._speed * h + this.situation.start;
        }, startAnimFrame: function() {
          this.stopAnimFrame(), this.animationFrame = P.requestAnimationFrame((function() {
            this.step();
          }).bind(this));
        }, stopAnimFrame: function() {
          P.cancelAnimationFrame(this.animationFrame);
        }, start: function() {
          return !this.active && this.situation && (this.active = !0, this.startCurrent()), this;
        }, startCurrent: function() {
          return this.situation.start = +/* @__PURE__ */ new Date() + this.situation.delay / this._speed, this.situation.finish = this.situation.start + this.situation.duration / this._speed, this.initAnimations().step();
        }, queue: function(h) {
          return (typeof h == "function" || h instanceof t.Situation) && this.situations.push(h), this.situation || (this.situation = this.situations.shift()), this;
        }, dequeue: function() {
          return this.stop(), this.situation = this.situations.shift(), this.situation && (this.situation instanceof t.Situation ? this.start() : this.situation.call(this)), this;
        }, initAnimations: function() {
          var h, x = this.situation;
          if (x.init)
            return this;
          for (var S in x.animations) {
            h = this.target()[S](), Array.isArray(h) || (h = [h]), Array.isArray(x.animations[S]) || (x.animations[S] = [x.animations[S]]);
            for (var L = h.length; L--; )
              x.animations[S][L] instanceof t.Number && (h[L] = new t.Number(h[L])), x.animations[S][L] = h[L].morph(x.animations[S][L]);
          }
          for (var S in x.attrs)
            x.attrs[S] = new t.MorphObj(this.target().attr(S), x.attrs[S]);
          for (var S in x.styles)
            x.styles[S] = new t.MorphObj(this.target().style(S), x.styles[S]);
          return x.initialTransformation = this.target().matrixify(), x.init = !0, this;
        }, clearQueue: function() {
          return this.situations = [], this;
        }, clearCurrent: function() {
          return this.situation = null, this;
        }, stop: function(h, x) {
          var S = this.active;
          return this.active = !1, x && this.clearQueue(), h && this.situation && (!S && this.startCurrent(), this.atEnd()), this.stopAnimFrame(), this.clearCurrent();
        }, after: function(h) {
          var x = this.last();
          return this.target().on("finished.fx", function S(L) {
            L.detail.situation == x && (h.call(this, x), this.off("finished.fx", S));
          }), this._callStart();
        }, during: function(h) {
          var x = this.last(), S = function(L) {
            L.detail.situation == x && h.call(this, L.detail.pos, t.morph(L.detail.pos), L.detail.eased, x);
          };
          return this.target().off("during.fx", S).on("during.fx", S), this.after(function() {
            this.off("during.fx", S);
          }), this._callStart();
        }, afterAll: function(h) {
          var x = function S(L) {
            h.call(this), this.off("allfinished.fx", S);
          };
          return this.target().off("allfinished.fx", x).on("allfinished.fx", x), this._callStart();
        }, last: function() {
          return this.situations.length ? this.situations[this.situations.length - 1] : this.situation;
        }, add: function(h, x, S) {
          return this.last()[S || "animations"][h] = x, this._callStart();
        }, step: function(h) {
          var x, S, L;
          h || (this.absPos = this.timeToAbsPos(+/* @__PURE__ */ new Date())), this.situation.loops !== !1 ? (x = Math.max(this.absPos, 0), S = Math.floor(x), this.situation.loops === !0 || S < this.situation.loops ? (this.pos = x - S, L = this.situation.loop, this.situation.loop = S) : (this.absPos = this.situation.loops, this.pos = 1, L = this.situation.loop - 1, this.situation.loop = this.situation.loops), this.situation.reversing && (this.situation.reversed = this.situation.reversed != !!((this.situation.loop - L) % 2))) : (this.absPos = Math.min(this.absPos, 1), this.pos = this.absPos), this.pos < 0 && (this.pos = 0), this.situation.reversed && (this.pos = 1 - this.pos);
          var R = this.situation.ease(this.pos);
          for (var O in this.situation.once)
            O > this.lastPos && O <= R && (this.situation.once[O].call(this.target(), this.pos, R), delete this.situation.once[O]);
          return this.active && this.target().fire("during", { pos: this.pos, eased: R, fx: this, situation: this.situation }), this.situation ? (this.eachAt(), this.pos == 1 && !this.situation.reversed || this.situation.reversed && this.pos == 0 ? (this.stopAnimFrame(), this.target().fire("finished", { fx: this, situation: this.situation }), this.situations.length || (this.target().fire("allfinished"), this.situations.length || (this.target().off(".fx"), this.active = !1)), this.active ? this.dequeue() : this.clearCurrent()) : !this.paused && this.active && this.startAnimFrame(), this.lastPos = R, this) : this;
        }, eachAt: function() {
          var h, x = this, S = this.target(), L = this.situation;
          for (var R in L.animations)
            h = [].concat(L.animations[R]).map(function(N) {
              return typeof N != "string" && N.at ? N.at(L.ease(x.pos), x.pos) : N;
            }), S[R].apply(S, h);
          for (var R in L.attrs)
            h = [R].concat(L.attrs[R]).map(function(q) {
              return typeof q != "string" && q.at ? q.at(L.ease(x.pos), x.pos) : q;
            }), S.attr.apply(S, h);
          for (var R in L.styles)
            h = [R].concat(L.styles[R]).map(function(q) {
              return typeof q != "string" && q.at ? q.at(L.ease(x.pos), x.pos) : q;
            }), S.style.apply(S, h);
          if (L.transforms.length) {
            h = L.initialTransformation, R = 0;
            for (var O = L.transforms.length; R < O; R++) {
              var Y = L.transforms[R];
              Y instanceof t.Matrix ? h = Y.relative ? h.multiply(new t.Matrix().morph(Y).at(L.ease(this.pos))) : h.morph(Y).at(L.ease(this.pos)) : (Y.relative || Y.undo(h.extract()), h = h.multiply(Y.at(L.ease(this.pos))));
            }
            S.matrix(h);
          }
          return this;
        }, once: function(h, x, S) {
          var L = this.last();
          return S || (h = L.ease(h)), L.once[h] = x, this;
        }, _callStart: function() {
          return setTimeout((function() {
            this.start();
          }).bind(this), 0), this;
        } }, parent: t.Element, construct: { animate: function(h, x, S) {
          return (this.fx || (this.fx = new t.FX(this))).animate(h, x, S);
        }, delay: function(h) {
          return (this.fx || (this.fx = new t.FX(this))).delay(h);
        }, stop: function(h, x) {
          return this.fx && this.fx.stop(h, x), this;
        }, finish: function() {
          return this.fx && this.fx.finish(), this;
        } } }), t.MorphObj = t.invent({ create: function(h, x) {
          return t.Color.isColor(x) ? new t.Color(h).morph(x) : t.regex.delimiter.test(h) ? t.regex.pathLetters.test(h) ? new t.PathArray(h).morph(x) : new t.Array(h).morph(x) : t.regex.numberAndUnit.test(x) ? new t.Number(h).morph(x) : (this.value = h, void (this.destination = x));
        }, extend: { at: function(h, x) {
          return x < 1 ? this.value : this.destination;
        }, valueOf: function() {
          return this.value;
        } } }), t.extend(t.FX, { attr: function(h, x, S) {
          if (b(h) === "object")
            for (var L in h)
              this.attr(L, h[L]);
          else
            this.add(h, x, "attrs");
          return this;
        }, plot: function(h, x, S, L) {
          return arguments.length == 4 ? this.plot([h, x, S, L]) : this.add("plot", new (this.target()).morphArray(h));
        } }), t.Box = t.invent({ create: function(h, x, S, L) {
          if (!(b(h) !== "object" || h instanceof t.Element))
            return t.Box.call(this, h.left != null ? h.left : h.x, h.top != null ? h.top : h.y, h.width, h.height);
          var R;
          arguments.length == 4 && (this.x = h, this.y = x, this.width = S, this.height = L), (R = this).x == null && (R.x = 0, R.y = 0, R.width = 0, R.height = 0), R.w = R.width, R.h = R.height, R.x2 = R.x + R.width, R.y2 = R.y + R.height, R.cx = R.x + R.width / 2, R.cy = R.y + R.height / 2;
        } }), t.BBox = t.invent({ create: function(h) {
          if (t.Box.apply(this, [].slice.call(arguments)), h instanceof t.Element) {
            var x;
            try {
              if (!e.documentElement.contains) {
                for (var S = h.node; S.parentNode; )
                  S = S.parentNode;
                if (S != e)
                  throw new Error("Element not in the dom");
              }
              x = h.node.getBBox();
            } catch {
              if (h instanceof t.Shape) {
                t.parser.draw || t.prepare();
                var L = h.clone(t.parser.draw.instance).show();
                L && L.node && typeof L.node.getBBox == "function" && (x = L.node.getBBox()), L && typeof L.remove == "function" && L.remove();
              } else
                x = { x: h.node.clientLeft, y: h.node.clientTop, width: h.node.clientWidth, height: h.node.clientHeight };
            }
            t.Box.call(this, x);
          }
        }, inherit: t.Box, parent: t.Element, construct: { bbox: function() {
          return new t.BBox(this);
        } } }), t.BBox.prototype.constructor = t.BBox, t.Matrix = t.invent({ create: function(h) {
          var x = w([1, 0, 0, 1, 0, 0]);
          h = h === null ? x : h instanceof t.Element ? h.matrixify() : typeof h == "string" ? w(h.split(t.regex.delimiter).map(parseFloat)) : arguments.length == 6 ? w([].slice.call(arguments)) : Array.isArray(h) ? w(h) : h && b(h) === "object" ? h : x;
          for (var S = E.length - 1; S >= 0; --S)
            this[E[S]] = h[E[S]] != null ? h[E[S]] : x[E[S]];
        }, extend: { extract: function() {
          var h = m(this, 0, 1);
          m(this, 1, 0);
          var x = 180 / Math.PI * Math.atan2(h.y, h.x) - 90;
          return { x: this.e, y: this.f, transformedX: (this.e * Math.cos(x * Math.PI / 180) + this.f * Math.sin(x * Math.PI / 180)) / Math.sqrt(this.a * this.a + this.b * this.b), transformedY: (this.f * Math.cos(x * Math.PI / 180) + this.e * Math.sin(-x * Math.PI / 180)) / Math.sqrt(this.c * this.c + this.d * this.d), rotation: x, a: this.a, b: this.b, c: this.c, d: this.d, e: this.e, f: this.f, matrix: new t.Matrix(this) };
        }, clone: function() {
          return new t.Matrix(this);
        }, morph: function(h) {
          return this.destination = new t.Matrix(h), this;
        }, multiply: function(h) {
          return new t.Matrix(this.native().multiply(function(x) {
            return x instanceof t.Matrix || (x = new t.Matrix(x)), x;
          }(h).native()));
        }, inverse: function() {
          return new t.Matrix(this.native().inverse());
        }, translate: function(h, x) {
          return new t.Matrix(this.native().translate(h || 0, x || 0));
        }, native: function() {
          for (var h = t.parser.native.createSVGMatrix(), x = E.length - 1; x >= 0; x--)
            h[E[x]] = this[E[x]];
          return h;
        }, toString: function() {
          return "matrix(" + k(this.a) + "," + k(this.b) + "," + k(this.c) + "," + k(this.d) + "," + k(this.e) + "," + k(this.f) + ")";
        } }, parent: t.Element, construct: { ctm: function() {
          return new t.Matrix(this.node.getCTM());
        }, screenCTM: function() {
          if (this instanceof t.Nested) {
            var h = this.rect(1, 1), x = h.node.getScreenCTM();
            return h.remove(), new t.Matrix(x);
          }
          return new t.Matrix(this.node.getScreenCTM());
        } } }), t.Point = t.invent({ create: function(h, x) {
          var S;
          S = Array.isArray(h) ? { x: h[0], y: h[1] } : b(h) === "object" ? { x: h.x, y: h.y } : h != null ? { x: h, y: x ?? h } : { x: 0, y: 0 }, this.x = S.x, this.y = S.y;
        }, extend: { clone: function() {
          return new t.Point(this);
        }, morph: function(h, x) {
          return this.destination = new t.Point(h, x), this;
        } } }), t.extend(t.Element, { point: function(h, x) {
          return new t.Point(h, x).transform(this.screenCTM().inverse());
        } }), t.extend(t.Element, { attr: function(h, x, S) {
          if (h == null) {
            for (h = {}, S = (x = this.node.attributes).length - 1; S >= 0; S--)
              h[x[S].nodeName] = t.regex.isNumber.test(x[S].nodeValue) ? parseFloat(x[S].nodeValue) : x[S].nodeValue;
            return h;
          }
          if (b(h) === "object")
            for (var L in h)
              this.attr(L, h[L]);
          else if (x === null)
            this.node.removeAttribute(h);
          else {
            if (x == null)
              return (x = this.node.getAttribute(h)) == null ? t.defaults.attrs[h] : t.regex.isNumber.test(x) ? parseFloat(x) : x;
            h == "stroke-width" ? this.attr("stroke", parseFloat(x) > 0 ? this._stroke : null) : h == "stroke" && (this._stroke = x), h != "fill" && h != "stroke" || (t.regex.isImage.test(x) && (x = this.doc().defs().image(x, 0, 0)), x instanceof t.Image && (x = this.doc().defs().pattern(0, 0, function() {
              this.add(x);
            }))), typeof x == "number" ? x = new t.Number(x) : t.Color.isColor(x) ? x = new t.Color(x) : Array.isArray(x) && (x = new t.Array(x)), h == "leading" ? this.leading && this.leading(x) : typeof S == "string" ? this.node.setAttributeNS(S, h, x.toString()) : this.node.setAttribute(h, x.toString()), !this.rebuild || h != "font-size" && h != "x" || this.rebuild(h, x);
          }
          return this;
        } }), t.extend(t.Element, { transform: function(h, x) {
          var S;
          return b(h) !== "object" ? (S = new t.Matrix(this).extract(), typeof h == "string" ? S[h] : S) : (S = new t.Matrix(this), x = !!x || !!h.relative, h.a != null && (S = x ? S.multiply(new t.Matrix(h)) : new t.Matrix(h)), this.attr("transform", S));
        } }), t.extend(t.Element, { untransform: function() {
          return this.attr("transform", null);
        }, matrixify: function() {
          return (this.attr("transform") || "").split(t.regex.transforms).slice(0, -1).map(function(h) {
            var x = h.trim().split("(");
            return [x[0], x[1].split(t.regex.delimiter).map(function(S) {
              return parseFloat(S);
            })];
          }).reduce(function(h, x) {
            return x[0] == "matrix" ? h.multiply(w(x[1])) : h[x[0]].apply(h, x[1]);
          }, new t.Matrix());
        }, toParent: function(h) {
          if (this == h)
            return this;
          var x = this.screenCTM(), S = h.screenCTM().inverse();
          return this.addTo(h).untransform().transform(S.multiply(x)), this;
        }, toDoc: function() {
          return this.toParent(this.doc());
        } }), t.Transformation = t.invent({ create: function(h, x) {
          if (arguments.length > 1 && typeof x != "boolean")
            return this.constructor.call(this, [].slice.call(arguments));
          if (Array.isArray(h))
            for (var S = 0, L = this.arguments.length; S < L; ++S)
              this[this.arguments[S]] = h[S];
          else if (h && b(h) === "object")
            for (S = 0, L = this.arguments.length; S < L; ++S)
              this[this.arguments[S]] = h[this.arguments[S]];
          this.inversed = !1, x === !0 && (this.inversed = !0);
        } }), t.Translate = t.invent({ parent: t.Matrix, inherit: t.Transformation, create: function(h, x) {
          this.constructor.apply(this, [].slice.call(arguments));
        }, extend: { arguments: ["transformedX", "transformedY"], method: "translate" } }), t.extend(t.Element, { style: function(h, x) {
          if (arguments.length == 0)
            return this.node.style.cssText || "";
          if (arguments.length < 2)
            if (b(h) === "object")
              for (var S in h)
                this.style(S, h[S]);
            else {
              if (!t.regex.isCss.test(h))
                return this.node.style[d(h)];
              for (h = h.split(/\s*;\s*/).filter(function(L) {
                return !!L;
              }).map(function(L) {
                return L.split(/\s*:\s*/);
              }); x = h.pop(); )
                this.style(x[0], x[1]);
            }
          else
            this.node.style[d(h)] = x === null || t.regex.isBlank.test(x) ? "" : x;
          return this;
        } }), t.Parent = t.invent({ create: function(h) {
          this.constructor.call(this, h);
        }, inherit: t.Element, extend: { children: function() {
          return t.utils.map(t.utils.filterSVGElements(this.node.childNodes), function(h) {
            return t.adopt(h);
          });
        }, add: function(h, x) {
          return x == null ? this.node.appendChild(h.node) : h.node != this.node.childNodes[x] && this.node.insertBefore(h.node, this.node.childNodes[x]), this;
        }, put: function(h, x) {
          return this.add(h, x), h;
        }, has: function(h) {
          return this.index(h) >= 0;
        }, index: function(h) {
          return [].slice.call(this.node.childNodes).indexOf(h.node);
        }, get: function(h) {
          return t.adopt(this.node.childNodes[h]);
        }, first: function() {
          return this.get(0);
        }, last: function() {
          return this.get(this.node.childNodes.length - 1);
        }, each: function(h, x) {
          for (var S = this.children(), L = 0, R = S.length; L < R; L++)
            S[L] instanceof t.Element && h.apply(S[L], [L, S]), x && S[L] instanceof t.Container && S[L].each(h, x);
          return this;
        }, removeElement: function(h) {
          return this.node.removeChild(h.node), this;
        }, clear: function() {
          for (; this.node.hasChildNodes(); )
            this.node.removeChild(this.node.lastChild);
          return delete this._defs, this;
        }, defs: function() {
          return this.doc().defs();
        } } }), t.extend(t.Parent, { ungroup: function(h, x) {
          return x === 0 || this instanceof t.Defs || this.node == t.parser.draw || (h = h || (this instanceof t.Doc ? this : this.parent(t.Parent)), x = x || 1 / 0, this.each(function() {
            return this instanceof t.Defs ? this : this instanceof t.Parent ? this.ungroup(h, x - 1) : this.toParent(h);
          }), this.node.firstChild || this.remove()), this;
        }, flatten: function(h, x) {
          return this.ungroup(h, x);
        } }), t.Container = t.invent({ create: function(h) {
          this.constructor.call(this, h);
        }, inherit: t.Parent }), t.ViewBox = t.invent({ parent: t.Container, construct: {} }), ["click", "dblclick", "mousedown", "mouseup", "mouseover", "mouseout", "mousemove", "touchstart", "touchmove", "touchleave", "touchend", "touchcancel"].forEach(function(h) {
          t.Element.prototype[h] = function(x) {
            return t.on(this.node, h, x), this;
          };
        }), t.listeners = [], t.handlerMap = [], t.listenerId = 0, t.on = function(h, x, S, L, R) {
          var O = S.bind(L || h.instance || h), Y = (t.handlerMap.indexOf(h) + 1 || t.handlerMap.push(h)) - 1, N = x.split(".")[0], q = x.split(".")[1] || "*";
          t.listeners[Y] = t.listeners[Y] || {}, t.listeners[Y][N] = t.listeners[Y][N] || {}, t.listeners[Y][N][q] = t.listeners[Y][N][q] || {}, S._svgjsListenerId || (S._svgjsListenerId = ++t.listenerId), t.listeners[Y][N][q][S._svgjsListenerId] = O, h.addEventListener(N, O, R || { passive: !0 });
        }, t.off = function(h, x, S) {
          var L = t.handlerMap.indexOf(h), R = x && x.split(".")[0], O = x && x.split(".")[1], Y = "";
          if (L != -1)
            if (S) {
              if (typeof S == "function" && (S = S._svgjsListenerId), !S)
                return;
              t.listeners[L][R] && t.listeners[L][R][O || "*"] && (h.removeEventListener(R, t.listeners[L][R][O || "*"][S], !1), delete t.listeners[L][R][O || "*"][S]);
            } else if (O && R) {
              if (t.listeners[L][R] && t.listeners[L][R][O]) {
                for (var N in t.listeners[L][R][O])
                  t.off(h, [R, O].join("."), N);
                delete t.listeners[L][R][O];
              }
            } else if (O)
              for (var q in t.listeners[L])
                for (var Y in t.listeners[L][q])
                  O === Y && t.off(h, [q, O].join("."));
            else if (R) {
              if (t.listeners[L][R]) {
                for (var Y in t.listeners[L][R])
                  t.off(h, [R, Y].join("."));
                delete t.listeners[L][R];
              }
            } else {
              for (var q in t.listeners[L])
                t.off(h, q);
              delete t.listeners[L], delete t.handlerMap[L];
            }
        }, t.extend(t.Element, { on: function(h, x, S, L) {
          return t.on(this.node, h, x, S, L), this;
        }, off: function(h, x) {
          return t.off(this.node, h, x), this;
        }, fire: function(h, x) {
          return h instanceof P.Event ? this.node.dispatchEvent(h) : this.node.dispatchEvent(h = new t.CustomEvent(h, { detail: x, cancelable: !0 })), this._event = h, this;
        }, event: function() {
          return this._event;
        } }), t.Defs = t.invent({ create: "defs", inherit: t.Container }), t.G = t.invent({ create: "g", inherit: t.Container, extend: { x: function(h) {
          return h == null ? this.transform("x") : this.transform({ x: h - this.x() }, !0);
        } }, construct: { group: function() {
          return this.put(new t.G());
        } } }), t.Doc = t.invent({ create: function(h) {
          h && ((h = typeof h == "string" ? e.getElementById(h) : h).nodeName == "svg" ? this.constructor.call(this, h) : (this.constructor.call(this, t.create("svg")), h.appendChild(this.node), this.size("100%", "100%")), this.namespace().defs());
        }, inherit: t.Container, extend: { namespace: function() {
          return this.attr({ xmlns: t.ns, version: "1.1" }).attr("xmlns:xlink", t.xlink, t.xmlns).attr("xmlns:svgjs", t.svgjs, t.xmlns);
        }, defs: function() {
          var h;
          return this._defs || ((h = this.node.getElementsByTagName("defs")[0]) ? this._defs = t.adopt(h) : this._defs = new t.Defs(), this.node.appendChild(this._defs.node)), this._defs;
        }, parent: function() {
          return this.node.parentNode && this.node.parentNode.nodeName != "#document" ? this.node.parentNode : null;
        }, remove: function() {
          return this.parent() && this.parent().removeChild(this.node), this;
        }, clear: function() {
          for (; this.node.hasChildNodes(); )
            this.node.removeChild(this.node.lastChild);
          return delete this._defs, t.parser.draw && !t.parser.draw.parentNode && this.node.appendChild(t.parser.draw), this;
        }, clone: function(h) {
          this.writeDataToDom();
          var x = this.node, S = C(x.cloneNode(!0));
          return h ? (h.node || h).appendChild(S.node) : x.parentNode.insertBefore(S.node, x.nextSibling), S;
        } } }), t.extend(t.Element, {}), t.Gradient = t.invent({ create: function(h) {
          this.constructor.call(this, t.create(h + "Gradient")), this.type = h;
        }, inherit: t.Container, extend: { at: function(h, x, S) {
          return this.put(new t.Stop()).update(h, x, S);
        }, update: function(h) {
          return this.clear(), typeof h == "function" && h.call(this, this), this;
        }, fill: function() {
          return "url(#" + this.id() + ")";
        }, toString: function() {
          return this.fill();
        }, attr: function(h, x, S) {
          return h == "transform" && (h = "gradientTransform"), t.Container.prototype.attr.call(this, h, x, S);
        } }, construct: { gradient: function(h, x) {
          return this.defs().gradient(h, x);
        } } }), t.extend(t.Gradient, t.FX, { from: function(h, x) {
          return (this._target || this).type == "radial" ? this.attr({ fx: new t.Number(h), fy: new t.Number(x) }) : this.attr({ x1: new t.Number(h), y1: new t.Number(x) });
        }, to: function(h, x) {
          return (this._target || this).type == "radial" ? this.attr({ cx: new t.Number(h), cy: new t.Number(x) }) : this.attr({ x2: new t.Number(h), y2: new t.Number(x) });
        } }), t.extend(t.Defs, { gradient: function(h, x) {
          return this.put(new t.Gradient(h)).update(x);
        } }), t.Stop = t.invent({ create: "stop", inherit: t.Element, extend: { update: function(h) {
          return (typeof h == "number" || h instanceof t.Number) && (h = { offset: arguments[0], color: arguments[1], opacity: arguments[2] }), h.opacity != null && this.attr("stop-opacity", h.opacity), h.color != null && this.attr("stop-color", h.color), h.offset != null && this.attr("offset", new t.Number(h.offset)), this;
        } } }), t.Pattern = t.invent({ create: "pattern", inherit: t.Container, extend: { fill: function() {
          return "url(#" + this.id() + ")";
        }, update: function(h) {
          return this.clear(), typeof h == "function" && h.call(this, this), this;
        }, toString: function() {
          return this.fill();
        }, attr: function(h, x, S) {
          return h == "transform" && (h = "patternTransform"), t.Container.prototype.attr.call(this, h, x, S);
        } }, construct: { pattern: function(h, x, S) {
          return this.defs().pattern(h, x, S);
        } } }), t.extend(t.Defs, { pattern: function(h, x, S) {
          return this.put(new t.Pattern()).update(S).attr({ x: 0, y: 0, width: h, height: x, patternUnits: "userSpaceOnUse" });
        } }), t.Shape = t.invent({ create: function(h) {
          this.constructor.call(this, h);
        }, inherit: t.Element }), t.Symbol = t.invent({ create: "symbol", inherit: t.Container, construct: { symbol: function() {
          return this.put(new t.Symbol());
        } } }), t.Use = t.invent({ create: "use", inherit: t.Shape, extend: { element: function(h, x) {
          return this.attr("href", (x || "") + "#" + h, t.xlink);
        } }, construct: { use: function(h, x) {
          return this.put(new t.Use()).element(h, x);
        } } }), t.Rect = t.invent({ create: "rect", inherit: t.Shape, construct: { rect: function(h, x) {
          return this.put(new t.Rect()).size(h, x);
        } } }), t.Circle = t.invent({ create: "circle", inherit: t.Shape, construct: { circle: function(h) {
          return this.put(new t.Circle()).rx(new t.Number(h).divide(2)).move(0, 0);
        } } }), t.extend(t.Circle, t.FX, { rx: function(h) {
          return this.attr("r", h);
        }, ry: function(h) {
          return this.rx(h);
        } }), t.Ellipse = t.invent({ create: "ellipse", inherit: t.Shape, construct: { ellipse: function(h, x) {
          return this.put(new t.Ellipse()).size(h, x).move(0, 0);
        } } }), t.extend(t.Ellipse, t.Rect, t.FX, { rx: function(h) {
          return this.attr("rx", h);
        }, ry: function(h) {
          return this.attr("ry", h);
        } }), t.extend(t.Circle, t.Ellipse, { x: function(h) {
          return h == null ? this.cx() - this.rx() : this.cx(h + this.rx());
        }, y: function(h) {
          return h == null ? this.cy() - this.ry() : this.cy(h + this.ry());
        }, cx: function(h) {
          return h == null ? this.attr("cx") : this.attr("cx", h);
        }, cy: function(h) {
          return h == null ? this.attr("cy") : this.attr("cy", h);
        }, width: function(h) {
          return h == null ? 2 * this.rx() : this.rx(new t.Number(h).divide(2));
        }, height: function(h) {
          return h == null ? 2 * this.ry() : this.ry(new t.Number(h).divide(2));
        }, size: function(h, x) {
          var S = p(this, h, x);
          return this.rx(new t.Number(S.width).divide(2)).ry(new t.Number(S.height).divide(2));
        } }), t.Line = t.invent({ create: "line", inherit: t.Shape, extend: { array: function() {
          return new t.PointArray([[this.attr("x1"), this.attr("y1")], [this.attr("x2"), this.attr("y2")]]);
        }, plot: function(h, x, S, L) {
          return h == null ? this.array() : (h = x !== void 0 ? { x1: h, y1: x, x2: S, y2: L } : new t.PointArray(h).toLine(), this.attr(h));
        }, move: function(h, x) {
          return this.attr(this.array().move(h, x).toLine());
        }, size: function(h, x) {
          var S = p(this, h, x);
          return this.attr(this.array().size(S.width, S.height).toLine());
        } }, construct: { line: function(h, x, S, L) {
          return t.Line.prototype.plot.apply(this.put(new t.Line()), h != null ? [h, x, S, L] : [0, 0, 0, 0]);
        } } }), t.Polyline = t.invent({ create: "polyline", inherit: t.Shape, construct: { polyline: function(h) {
          return this.put(new t.Polyline()).plot(h || new t.PointArray());
        } } }), t.Polygon = t.invent({ create: "polygon", inherit: t.Shape, construct: { polygon: function(h) {
          return this.put(new t.Polygon()).plot(h || new t.PointArray());
        } } }), t.extend(t.Polyline, t.Polygon, { array: function() {
          return this._array || (this._array = new t.PointArray(this.attr("points")));
        }, plot: function(h) {
          return h == null ? this.array() : this.clear().attr("points", typeof h == "string" ? h : this._array = new t.PointArray(h));
        }, clear: function() {
          return delete this._array, this;
        }, move: function(h, x) {
          return this.attr("points", this.array().move(h, x));
        }, size: function(h, x) {
          var S = p(this, h, x);
          return this.attr("points", this.array().size(S.width, S.height));
        } }), t.extend(t.Line, t.Polyline, t.Polygon, { morphArray: t.PointArray, x: function(h) {
          return h == null ? this.bbox().x : this.move(h, this.bbox().y);
        }, y: function(h) {
          return h == null ? this.bbox().y : this.move(this.bbox().x, h);
        }, width: function(h) {
          var x = this.bbox();
          return h == null ? x.width : this.size(h, x.height);
        }, height: function(h) {
          var x = this.bbox();
          return h == null ? x.height : this.size(x.width, h);
        } }), t.Path = t.invent({ create: "path", inherit: t.Shape, extend: { morphArray: t.PathArray, array: function() {
          return this._array || (this._array = new t.PathArray(this.attr("d")));
        }, plot: function(h) {
          return h == null ? this.array() : this.clear().attr("d", typeof h == "string" ? h : this._array = new t.PathArray(h));
        }, clear: function() {
          return delete this._array, this;
        } }, construct: { path: function(h) {
          return this.put(new t.Path()).plot(h || new t.PathArray());
        } } }), t.Image = t.invent({ create: "image", inherit: t.Shape, extend: { load: function(h) {
          if (!h)
            return this;
          var x = this, S = new P.Image();
          return t.on(S, "load", function() {
            t.off(S);
            var L = x.parent(t.Pattern);
            L !== null && (x.width() == 0 && x.height() == 0 && x.size(S.width, S.height), L && L.width() == 0 && L.height() == 0 && L.size(x.width(), x.height()), typeof x._loaded == "function" && x._loaded.call(x, { width: S.width, height: S.height, ratio: S.width / S.height, url: h }));
          }), t.on(S, "error", function(L) {
            t.off(S), typeof x._error == "function" && x._error.call(x, L);
          }), this.attr("href", S.src = this.src = h, t.xlink);
        }, loaded: function(h) {
          return this._loaded = h, this;
        }, error: function(h) {
          return this._error = h, this;
        } }, construct: { image: function(h, x, S) {
          return this.put(new t.Image()).load(h).size(x || 0, S || x || 0);
        } } }), t.Text = t.invent({ create: function() {
          this.constructor.call(this, t.create("text")), this.dom.leading = new t.Number(1.3), this._rebuild = !0, this._build = !1, this.attr("font-family", t.defaults.attrs["font-family"]);
        }, inherit: t.Shape, extend: { x: function(h) {
          return h == null ? this.attr("x") : this.attr("x", h);
        }, text: function(h) {
          if (h === void 0) {
            h = "";
            for (var x = this.node.childNodes, S = 0, L = x.length; S < L; ++S)
              S != 0 && x[S].nodeType != 3 && t.adopt(x[S]).dom.newLined == 1 && (h += `
`), h += x[S].textContent;
            return h;
          }
          if (this.clear().build(!0), typeof h == "function")
            h.call(this, this);
          else {
            S = 0;
            for (var R = (h = h.split(`
`)).length; S < R; S++)
              this.tspan(h[S]).newLine();
          }
          return this.build(!1).rebuild();
        }, size: function(h) {
          return this.attr("font-size", h).rebuild();
        }, leading: function(h) {
          return h == null ? this.dom.leading : (this.dom.leading = new t.Number(h), this.rebuild());
        }, lines: function() {
          var h = (this.textPath && this.textPath() || this).node, x = t.utils.map(t.utils.filterSVGElements(h.childNodes), function(S) {
            return t.adopt(S);
          });
          return new t.Set(x);
        }, rebuild: function(h) {
          if (typeof h == "boolean" && (this._rebuild = h), this._rebuild) {
            var x = this, S = 0, L = this.dom.leading * new t.Number(this.attr("font-size"));
            this.lines().each(function() {
              this.dom.newLined && (x.textPath() || this.attr("x", x.attr("x")), this.text() == `
` ? S += L : (this.attr("dy", L + S), S = 0));
            }), this.fire("rebuild");
          }
          return this;
        }, build: function(h) {
          return this._build = !!h, this;
        }, setData: function(h) {
          return this.dom = h, this.dom.leading = new t.Number(h.leading || 1.3), this;
        } }, construct: { text: function(h) {
          return this.put(new t.Text()).text(h);
        }, plain: function(h) {
          return this.put(new t.Text()).plain(h);
        } } }), t.Tspan = t.invent({ create: "tspan", inherit: t.Shape, extend: { text: function(h) {
          return h == null ? this.node.textContent + (this.dom.newLined ? `
` : "") : (typeof h == "function" ? h.call(this, this) : this.plain(h), this);
        }, dx: function(h) {
          return this.attr("dx", h);
        }, dy: function(h) {
          return this.attr("dy", h);
        }, newLine: function() {
          var h = this.parent(t.Text);
          return this.dom.newLined = !0, this.dy(h.dom.leading * h.attr("font-size")).attr("x", h.x());
        } } }), t.extend(t.Text, t.Tspan, { plain: function(h) {
          return this._build === !1 && this.clear(), this.node.appendChild(e.createTextNode(h)), this;
        }, tspan: function(h) {
          var x = (this.textPath && this.textPath() || this).node, S = new t.Tspan();
          return this._build === !1 && this.clear(), x.appendChild(S.node), S.text(h);
        }, clear: function() {
          for (var h = (this.textPath && this.textPath() || this).node; h.hasChildNodes(); )
            h.removeChild(h.lastChild);
          return this;
        }, length: function() {
          return this.node.getComputedTextLength();
        } }), t.TextPath = t.invent({ create: "textPath", inherit: t.Parent, parent: t.Text, construct: { morphArray: t.PathArray, array: function() {
          var h = this.track();
          return h ? h.array() : null;
        }, plot: function(h) {
          var x = this.track(), S = null;
          return x && (S = x.plot(h)), h == null ? S : this;
        }, track: function() {
          var h = this.textPath();
          if (h)
            return h.reference("href");
        }, textPath: function() {
          if (this.node.firstChild && this.node.firstChild.nodeName == "textPath")
            return t.adopt(this.node.firstChild);
        } } }), t.Nested = t.invent({ create: function() {
          this.constructor.call(this, t.create("svg")), this.style("overflow", "visible");
        }, inherit: t.Container, construct: { nested: function() {
          return this.put(new t.Nested());
        } } });
        var o = { stroke: ["color", "width", "opacity", "linecap", "linejoin", "miterlimit", "dasharray", "dashoffset"], fill: ["color", "opacity", "rule"], prefix: function(h, x) {
          return x == "color" ? h : h + "-" + x;
        } };
        function c(h, x, S, L) {
          return S + L.replace(t.regex.dots, " .");
        }
        function d(h) {
          return h.toLowerCase().replace(/-(.)/g, function(x, S) {
            return S.toUpperCase();
          });
        }
        function g(h) {
          return h.charAt(0).toUpperCase() + h.slice(1);
        }
        function f(h) {
          var x = h.toString(16);
          return x.length == 1 ? "0" + x : x;
        }
        function p(h, x, S) {
          if (x == null || S == null) {
            var L = h.bbox();
            x == null ? x = L.width / L.height * S : S == null && (S = L.height / L.width * x);
          }
          return { width: x, height: S };
        }
        function m(h, x, S) {
          return { x: x * h.a + S * h.c + 0, y: x * h.b + S * h.d + 0 };
        }
        function w(h) {
          return { a: h[0], b: h[1], c: h[2], d: h[3], e: h[4], f: h[5] };
        }
        function C(h) {
          for (var x = h.childNodes.length - 1; x >= 0; x--)
            h.childNodes[x] instanceof P.SVGElement && C(h.childNodes[x]);
          return t.adopt(h).id(t.eid(h.nodeName));
        }
        function k(h) {
          return Math.abs(h) > 1e-37 ? h : 0;
        }
        ["fill", "stroke"].forEach(function(h) {
          var x = {};
          x[h] = function(S) {
            if (S === void 0)
              return this;
            if (typeof S == "string" || t.Color.isRgb(S) || S && typeof S.fill == "function")
              this.attr(h, S);
            else
              for (var L = o[h].length - 1; L >= 0; L--)
                S[o[h][L]] != null && this.attr(o.prefix(h, o[h][L]), S[o[h][L]]);
            return this;
          }, t.extend(t.Element, t.FX, x);
        }), t.extend(t.Element, t.FX, { translate: function(h, x) {
          return this.transform({ x: h, y: x });
        }, matrix: function(h) {
          return this.attr("transform", new t.Matrix(arguments.length == 6 ? [].slice.call(arguments) : h));
        }, opacity: function(h) {
          return this.attr("opacity", h);
        }, dx: function(h) {
          return this.x(new t.Number(h).plus(this instanceof t.FX ? 0 : this.x()), !0);
        }, dy: function(h) {
          return this.y(new t.Number(h).plus(this instanceof t.FX ? 0 : this.y()), !0);
        } }), t.extend(t.Path, { length: function() {
          return this.node.getTotalLength();
        }, pointAt: function(h) {
          return this.node.getPointAtLength(h);
        } }), t.Set = t.invent({ create: function(h) {
          Array.isArray(h) ? this.members = h : this.clear();
        }, extend: { add: function() {
          for (var h = [].slice.call(arguments), x = 0, S = h.length; x < S; x++)
            this.members.push(h[x]);
          return this;
        }, remove: function(h) {
          var x = this.index(h);
          return x > -1 && this.members.splice(x, 1), this;
        }, each: function(h) {
          for (var x = 0, S = this.members.length; x < S; x++)
            h.apply(this.members[x], [x, this.members]);
          return this;
        }, clear: function() {
          return this.members = [], this;
        }, length: function() {
          return this.members.length;
        }, has: function(h) {
          return this.index(h) >= 0;
        }, index: function(h) {
          return this.members.indexOf(h);
        }, get: function(h) {
          return this.members[h];
        }, first: function() {
          return this.get(0);
        }, last: function() {
          return this.get(this.members.length - 1);
        }, valueOf: function() {
          return this.members;
        } }, construct: { set: function(h) {
          return new t.Set(h);
        } } }), t.FX.Set = t.invent({ create: function(h) {
          this.set = h;
        } }), t.Set.inherit = function() {
          var h = [];
          for (var x in t.Shape.prototype)
            typeof t.Shape.prototype[x] == "function" && typeof t.Set.prototype[x] != "function" && h.push(x);
          for (var x in h.forEach(function(L) {
            t.Set.prototype[L] = function() {
              for (var R = 0, O = this.members.length; R < O; R++)
                this.members[R] && typeof this.members[R][L] == "function" && this.members[R][L].apply(this.members[R], arguments);
              return L == "animate" ? this.fx || (this.fx = new t.FX.Set(this)) : this;
            };
          }), h = [], t.FX.prototype)
            typeof t.FX.prototype[x] == "function" && typeof t.FX.Set.prototype[x] != "function" && h.push(x);
          h.forEach(function(S) {
            t.FX.Set.prototype[S] = function() {
              for (var L = 0, R = this.set.members.length; L < R; L++)
                this.set.members[L].fx[S].apply(this.set.members[L].fx, arguments);
              return this;
            };
          });
        }, t.extend(t.Element, {}), t.extend(t.Element, { remember: function(h, x) {
          if (b(arguments[0]) === "object")
            for (var S in h)
              this.remember(S, h[S]);
          else {
            if (arguments.length == 1)
              return this.memory()[h];
            this.memory()[h] = x;
          }
          return this;
        }, forget: function() {
          if (arguments.length == 0)
            this._memory = {};
          else
            for (var h = arguments.length - 1; h >= 0; h--)
              delete this.memory()[arguments[h]];
          return this;
        }, memory: function() {
          return this._memory || (this._memory = {});
        } }), t.get = function(h) {
          var x = e.getElementById(function(S) {
            var L = (S || "").toString().match(t.regex.reference);
            if (L)
              return L[1];
          }(h) || h);
          return t.adopt(x);
        }, t.select = function(h, x) {
          return new t.Set(t.utils.map((x || e).querySelectorAll(h), function(S) {
            return t.adopt(S);
          }));
        }, t.extend(t.Parent, { select: function(h) {
          return t.select(h, this.node);
        } });
        var E = "abcdef".split("");
        if (typeof P.CustomEvent != "function") {
          var _ = function(h, x) {
            x = x || { bubbles: !1, cancelable: !1, detail: void 0 };
            var S = e.createEvent("CustomEvent");
            return S.initCustomEvent(h, x.bubbles, x.cancelable, x.detail), S;
          };
          _.prototype = P.Event.prototype, t.CustomEvent = _;
        } else
          t.CustomEvent = P.CustomEvent;
        return t;
      }, b(n) === "object" ? v.exports = ht.document ? Xt(ht, ht.document) : function(P) {
        return Xt(P, P.document);
      } : ht.SVG = Xt(ht, ht.document), /*! svg.filter.js - v2.0.2 - 2016-02-24
        * https://github.com/wout/svg.filter.js
        * Copyright (c) 2016 Wout Fierens; Licensed MIT */
      (function() {
        SVG.Filter = SVG.invent({ create: "filter", inherit: SVG.Parent, extend: { source: "SourceGraphic", sourceAlpha: "SourceAlpha", background: "BackgroundImage", backgroundAlpha: "BackgroundAlpha", fill: "FillPaint", stroke: "StrokePaint", autoSetIn: !0, put: function(r, o) {
          return this.add(r, o), !r.attr("in") && this.autoSetIn && r.attr("in", this.source), r.attr("result") || r.attr("result", r), r;
        }, blend: function(r, o, c) {
          return this.put(new SVG.BlendEffect(r, o, c));
        }, colorMatrix: function(r, o) {
          return this.put(new SVG.ColorMatrixEffect(r, o));
        }, convolveMatrix: function(r) {
          return this.put(new SVG.ConvolveMatrixEffect(r));
        }, componentTransfer: function(r) {
          return this.put(new SVG.ComponentTransferEffect(r));
        }, composite: function(r, o, c) {
          return this.put(new SVG.CompositeEffect(r, o, c));
        }, flood: function(r, o) {
          return this.put(new SVG.FloodEffect(r, o));
        }, offset: function(r, o) {
          return this.put(new SVG.OffsetEffect(r, o));
        }, image: function(r) {
          return this.put(new SVG.ImageEffect(r));
        }, merge: function() {
          var r = [void 0];
          for (var o in arguments)
            r.push(arguments[o]);
          return this.put(new (SVG.MergeEffect.bind.apply(SVG.MergeEffect, r))());
        }, gaussianBlur: function(r, o) {
          return this.put(new SVG.GaussianBlurEffect(r, o));
        }, morphology: function(r, o) {
          return this.put(new SVG.MorphologyEffect(r, o));
        }, diffuseLighting: function(r, o, c) {
          return this.put(new SVG.DiffuseLightingEffect(r, o, c));
        }, displacementMap: function(r, o, c, d, g) {
          return this.put(new SVG.DisplacementMapEffect(r, o, c, d, g));
        }, specularLighting: function(r, o, c, d) {
          return this.put(new SVG.SpecularLightingEffect(r, o, c, d));
        }, tile: function() {
          return this.put(new SVG.TileEffect());
        }, turbulence: function(r, o, c, d, g) {
          return this.put(new SVG.TurbulenceEffect(r, o, c, d, g));
        }, toString: function() {
          return "url(#" + this.attr("id") + ")";
        } } }), SVG.extend(SVG.Defs, { filter: function(r) {
          var o = this.put(new SVG.Filter());
          return typeof r == "function" && r.call(o, o), o;
        } }), SVG.extend(SVG.Container, { filter: function(r) {
          return this.defs().filter(r);
        } }), SVG.extend(SVG.Element, SVG.G, SVG.Nested, { filter: function(r) {
          return this.filterer = r instanceof SVG.Element ? r : this.doc().filter(r), this.doc() && this.filterer.doc() !== this.doc() && this.doc().defs().add(this.filterer), this.attr("filter", this.filterer), this.filterer;
        }, unfilter: function(r) {
          return this.filterer && r === !0 && this.filterer.remove(), delete this.filterer, this.attr("filter", null);
        } }), SVG.Effect = SVG.invent({ create: function() {
          this.constructor.call(this);
        }, inherit: SVG.Element, extend: { in: function(r) {
          return r == null ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(0) || this.attr("in") : this.attr("in", r);
        }, result: function(r) {
          return r == null ? this.attr("result") : this.attr("result", r);
        }, toString: function() {
          return this.result();
        } } }), SVG.ParentEffect = SVG.invent({ create: function() {
          this.constructor.call(this);
        }, inherit: SVG.Parent, extend: { in: function(r) {
          return r == null ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(0) || this.attr("in") : this.attr("in", r);
        }, result: function(r) {
          return r == null ? this.attr("result") : this.attr("result", r);
        }, toString: function() {
          return this.result();
        } } });
        var P = { blend: function(r, o) {
          return this.parent() && this.parent().blend(this, r, o);
        }, colorMatrix: function(r, o) {
          return this.parent() && this.parent().colorMatrix(r, o).in(this);
        }, convolveMatrix: function(r) {
          return this.parent() && this.parent().convolveMatrix(r).in(this);
        }, componentTransfer: function(r) {
          return this.parent() && this.parent().componentTransfer(r).in(this);
        }, composite: function(r, o) {
          return this.parent() && this.parent().composite(this, r, o);
        }, flood: function(r, o) {
          return this.parent() && this.parent().flood(r, o);
        }, offset: function(r, o) {
          return this.parent() && this.parent().offset(r, o).in(this);
        }, image: function(r) {
          return this.parent() && this.parent().image(r);
        }, merge: function() {
          return this.parent() && this.parent().merge.apply(this.parent(), [this].concat(arguments));
        }, gaussianBlur: function(r, o) {
          return this.parent() && this.parent().gaussianBlur(r, o).in(this);
        }, morphology: function(r, o) {
          return this.parent() && this.parent().morphology(r, o).in(this);
        }, diffuseLighting: function(r, o, c) {
          return this.parent() && this.parent().diffuseLighting(r, o, c).in(this);
        }, displacementMap: function(r, o, c, d) {
          return this.parent() && this.parent().displacementMap(this, r, o, c, d);
        }, specularLighting: function(r, o, c, d) {
          return this.parent() && this.parent().specularLighting(r, o, c, d).in(this);
        }, tile: function() {
          return this.parent() && this.parent().tile().in(this);
        }, turbulence: function(r, o, c, d, g) {
          return this.parent() && this.parent().turbulence(r, o, c, d, g).in(this);
        } };
        SVG.extend(SVG.Effect, P), SVG.extend(SVG.ParentEffect, P), SVG.ChildEffect = SVG.invent({ create: function() {
          this.constructor.call(this);
        }, inherit: SVG.Element, extend: { in: function(r) {
          this.attr("in", r);
        } } });
        var e = { blend: function(r, o, c) {
          this.attr({ in: r, in2: o, mode: c || "normal" });
        }, colorMatrix: function(r, o) {
          r == "matrix" && (o = a(o)), this.attr({ type: r, values: o === void 0 ? null : o });
        }, convolveMatrix: function(r) {
          r = a(r), this.attr({ order: Math.sqrt(r.split(" ").length), kernelMatrix: r });
        }, composite: function(r, o, c) {
          this.attr({ in: r, in2: o, operator: c });
        }, flood: function(r, o) {
          this.attr("flood-color", r), o != null && this.attr("flood-opacity", o);
        }, offset: function(r, o) {
          this.attr({ dx: r, dy: o });
        }, image: function(r) {
          this.attr("href", r, SVG.xlink);
        }, displacementMap: function(r, o, c, d, g) {
          this.attr({ in: r, in2: o, scale: c, xChannelSelector: d, yChannelSelector: g });
        }, gaussianBlur: function(r, o) {
          r != null || o != null ? this.attr("stdDeviation", function(c) {
            if (!Array.isArray(c))
              return c;
            for (var d = 0, g = c.length, f = []; d < g; d++)
              f.push(c[d]);
            return f.join(" ");
          }(Array.prototype.slice.call(arguments))) : this.attr("stdDeviation", "0 0");
        }, morphology: function(r, o) {
          this.attr({ operator: r, radius: o });
        }, tile: function() {
        }, turbulence: function(r, o, c, d, g) {
          this.attr({ numOctaves: o, seed: c, stitchTiles: d, baseFrequency: r, type: g });
        } }, t = { merge: function() {
          var r;
          if (arguments[0] instanceof SVG.Set) {
            var o = this;
            arguments[0].each(function(d) {
              this instanceof SVG.MergeNode ? o.put(this) : (this instanceof SVG.Effect || this instanceof SVG.ParentEffect) && o.put(new SVG.MergeNode(this));
            });
          } else {
            r = Array.isArray(arguments[0]) ? arguments[0] : arguments;
            for (var c = 0; c < r.length; c++)
              r[c] instanceof SVG.MergeNode ? this.put(r[c]) : this.put(new SVG.MergeNode(r[c]));
          }
        }, componentTransfer: function(r) {
          if (this.rgb = new SVG.Set(), ["r", "g", "b", "a"].forEach((function(c) {
            this[c] = new SVG["Func" + c.toUpperCase()]("identity"), this.rgb.add(this[c]), this.node.appendChild(this[c].node);
          }).bind(this)), r)
            for (var o in r.rgb && (["r", "g", "b"].forEach((function(c) {
              this[c].attr(r.rgb);
            }).bind(this)), delete r.rgb), r)
              this[o].attr(r[o]);
        }, diffuseLighting: function(r, o, c) {
          this.attr({ surfaceScale: r, diffuseConstant: o, kernelUnitLength: c });
        }, specularLighting: function(r, o, c, d) {
          this.attr({ surfaceScale: r, diffuseConstant: o, specularExponent: c, kernelUnitLength: d });
        } }, i = { distantLight: function(r, o) {
          this.attr({ azimuth: r, elevation: o });
        }, pointLight: function(r, o, c) {
          this.attr({ x: r, y: o, z: c });
        }, spotLight: function(r, o, c, d, g, f) {
          this.attr({ x: r, y: o, z: c, pointsAtX: d, pointsAtY: g, pointsAtZ: f });
        }, mergeNode: function(r) {
          this.attr("in", r);
        } };
        function a(r) {
          return Array.isArray(r) && (r = new SVG.Array(r)), r.toString().replace(/^\s+/, "").replace(/\s+$/, "").replace(/\s+/g, " ");
        }
        function s() {
          var r = function() {
          };
          for (var o in typeof arguments[arguments.length - 1] == "function" && (r = arguments[arguments.length - 1], Array.prototype.splice.call(arguments, arguments.length - 1, 1)), arguments)
            for (var c in arguments[o])
              r(arguments[o][c], c, arguments[o]);
        }
        ["r", "g", "b", "a"].forEach(function(r) {
          i["Func" + r.toUpperCase()] = function(o) {
            switch (this.attr("type", o), o) {
              case "table":
                this.attr("tableValues", arguments[1]);
                break;
              case "linear":
                this.attr("slope", arguments[1]), this.attr("intercept", arguments[2]);
                break;
              case "gamma":
                this.attr("amplitude", arguments[1]), this.attr("exponent", arguments[2]), this.attr("offset", arguments[2]);
            }
          };
        }), s(e, function(r, o) {
          var c = o.charAt(0).toUpperCase() + o.slice(1);
          SVG[c + "Effect"] = SVG.invent({ create: function() {
            this.constructor.call(this, SVG.create("fe" + c)), r.apply(this, arguments), this.result(this.attr("id") + "Out");
          }, inherit: SVG.Effect, extend: {} });
        }), s(t, function(r, o) {
          var c = o.charAt(0).toUpperCase() + o.slice(1);
          SVG[c + "Effect"] = SVG.invent({ create: function() {
            this.constructor.call(this, SVG.create("fe" + c)), r.apply(this, arguments), this.result(this.attr("id") + "Out");
          }, inherit: SVG.ParentEffect, extend: {} });
        }), s(i, function(r, o) {
          var c = o.charAt(0).toUpperCase() + o.slice(1);
          SVG[c] = SVG.invent({ create: function() {
            this.constructor.call(this, SVG.create("fe" + c)), r.apply(this, arguments);
          }, inherit: SVG.ChildEffect, extend: {} });
        }), SVG.extend(SVG.MergeEffect, { in: function(r) {
          return r instanceof SVG.MergeNode ? this.add(r, 0) : this.add(new SVG.MergeNode(r), 0), this;
        } }), SVG.extend(SVG.CompositeEffect, SVG.BlendEffect, SVG.DisplacementMapEffect, { in2: function(r) {
          return r == null ? this.parent() && this.parent().select('[result="' + this.attr("in2") + '"]').get(0) || this.attr("in2") : this.attr("in2", r);
        } }), SVG.filter = { sepiatone: [0.343, 0.669, 0.119, 0, 0, 0.249, 0.626, 0.13, 0, 0, 0.172, 0.334, 0.111, 0, 0, 0, 0, 0, 1, 0] };
      }).call(void 0), function() {
        function P(s, r, o, c, d, g, f) {
          for (var p = s.slice(r, o || f), m = c.slice(d, g || f), w = 0, C = { pos: [0, 0], start: [0, 0] }, k = { pos: [0, 0], start: [0, 0] }; p[w] = e.call(C, p[w]), m[w] = e.call(k, m[w]), p[w][0] != m[w][0] || p[w][0] == "M" || p[w][0] == "A" && (p[w][4] != m[w][4] || p[w][5] != m[w][5]) ? (Array.prototype.splice.apply(p, [w, 1].concat(i.call(C, p[w]))), Array.prototype.splice.apply(m, [w, 1].concat(i.call(k, m[w])))) : (p[w] = t.call(C, p[w]), m[w] = t.call(k, m[w])), !(++w == p.length && w == m.length); )
            w == p.length && p.push(["C", C.pos[0], C.pos[1], C.pos[0], C.pos[1], C.pos[0], C.pos[1]]), w == m.length && m.push(["C", k.pos[0], k.pos[1], k.pos[0], k.pos[1], k.pos[0], k.pos[1]]);
          return { start: p, dest: m };
        }
        function e(s) {
          switch (s[0]) {
            case "z":
            case "Z":
              s[0] = "L", s[1] = this.start[0], s[2] = this.start[1];
              break;
            case "H":
              s[0] = "L", s[2] = this.pos[1];
              break;
            case "V":
              s[0] = "L", s[2] = s[1], s[1] = this.pos[0];
              break;
            case "T":
              s[0] = "Q", s[3] = s[1], s[4] = s[2], s[1] = this.reflection[1], s[2] = this.reflection[0];
              break;
            case "S":
              s[0] = "C", s[6] = s[4], s[5] = s[3], s[4] = s[2], s[3] = s[1], s[2] = this.reflection[1], s[1] = this.reflection[0];
          }
          return s;
        }
        function t(s) {
          var r = s.length;
          return this.pos = [s[r - 2], s[r - 1]], "SCQT".indexOf(s[0]) != -1 && (this.reflection = [2 * this.pos[0] - s[r - 4], 2 * this.pos[1] - s[r - 3]]), s;
        }
        function i(s) {
          var r = [s];
          switch (s[0]) {
            case "M":
              return this.pos = this.start = [s[1], s[2]], r;
            case "L":
              s[5] = s[3] = s[1], s[6] = s[4] = s[2], s[1] = this.pos[0], s[2] = this.pos[1];
              break;
            case "Q":
              s[6] = s[4], s[5] = s[3], s[4] = 1 * s[4] / 3 + 2 * s[2] / 3, s[3] = 1 * s[3] / 3 + 2 * s[1] / 3, s[2] = 1 * this.pos[1] / 3 + 2 * s[2] / 3, s[1] = 1 * this.pos[0] / 3 + 2 * s[1] / 3;
              break;
            case "A":
              r = function(o, c) {
                var d, g, f, p, m, w, C, k, E, _, h, x, S, L, R, O, Y, N, q, Z, U, se, he, me, fe, Ce, Ne = Math.abs(c[1]), Ie = Math.abs(c[2]), Oe = c[3] % 360, Ue = c[4], Ke = c[5], yt = c[6], ni = c[7], Ze = new SVG.Point(o), je = new SVG.Point(yt, ni), ji = [];
                if (Ne === 0 || Ie === 0 || Ze.x === je.x && Ze.y === je.y)
                  return [["C", Ze.x, Ze.y, je.x, je.y, je.x, je.y]];
                for (d = new SVG.Point((Ze.x - je.x) / 2, (Ze.y - je.y) / 2).transform(new SVG.Matrix().rotate(Oe)), (g = d.x * d.x / (Ne * Ne) + d.y * d.y / (Ie * Ie)) > 1 && (Ne *= g = Math.sqrt(g), Ie *= g), f = new SVG.Matrix().rotate(Oe).scale(1 / Ne, 1 / Ie).rotate(-Oe), Ze = Ze.transform(f), je = je.transform(f), p = [je.x - Ze.x, je.y - Ze.y], w = p[0] * p[0] + p[1] * p[1], m = Math.sqrt(w), p[0] /= m, p[1] /= m, C = w < 4 ? Math.sqrt(1 - w / 4) : 0, Ue === Ke && (C *= -1), k = new SVG.Point((je.x + Ze.x) / 2 + C * -p[1], (je.y + Ze.y) / 2 + C * p[0]), E = new SVG.Point(Ze.x - k.x, Ze.y - k.y), _ = new SVG.Point(je.x - k.x, je.y - k.y), h = Math.acos(E.x / Math.sqrt(E.x * E.x + E.y * E.y)), E.y < 0 && (h *= -1), x = Math.acos(_.x / Math.sqrt(_.x * _.x + _.y * _.y)), _.y < 0 && (x *= -1), Ke && h > x && (x += 2 * Math.PI), !Ke && h < x && (x -= 2 * Math.PI), L = Math.ceil(2 * Math.abs(h - x) / Math.PI), O = [], Y = h, S = (x - h) / L, R = 4 * Math.tan(S / 4) / 3, U = 0; U <= L; U++)
                  q = Math.cos(Y), N = Math.sin(Y), Z = new SVG.Point(k.x + q, k.y + N), O[U] = [new SVG.Point(Z.x + R * N, Z.y - R * q), Z, new SVG.Point(Z.x - R * N, Z.y + R * q)], Y += S;
                for (O[0][0] = O[0][1].clone(), O[O.length - 1][2] = O[O.length - 1][1].clone(), f = new SVG.Matrix().rotate(Oe).scale(Ne, Ie).rotate(-Oe), U = 0, se = O.length; U < se; U++)
                  O[U][0] = O[U][0].transform(f), O[U][1] = O[U][1].transform(f), O[U][2] = O[U][2].transform(f);
                for (U = 1, se = O.length; U < se; U++)
                  he = (Z = O[U - 1][2]).x, me = Z.y, fe = (Z = O[U][0]).x, Ce = Z.y, yt = (Z = O[U][1]).x, ni = Z.y, ji.push(["C", he, me, fe, Ce, yt, ni]);
                return ji;
              }(this.pos, s), s = r[0];
          }
          return s[0] = "C", this.pos = [s[5], s[6]], this.reflection = [2 * s[5] - s[3], 2 * s[6] - s[4]], r;
        }
        function a(s, r) {
          if (r === !1)
            return !1;
          for (var o = r, c = s.length; o < c; ++o)
            if (s[o][0] == "M")
              return o;
          return !1;
        }
        SVG.extend(SVG.PathArray, { morph: function(s) {
          for (var r = this.value, o = this.parse(s), c = 0, d = 0, g = !1, f = !1; c !== !1 || d !== !1; ) {
            var p;
            g = a(r, c !== !1 && c + 1), f = a(o, d !== !1 && d + 1), c === !1 && (c = (p = new SVG.PathArray(m.start).bbox()).height == 0 || p.width == 0 ? r.push(r[0]) - 1 : r.push(["M", p.x + p.width / 2, p.y + p.height / 2]) - 1), d === !1 && (d = (p = new SVG.PathArray(m.dest).bbox()).height == 0 || p.width == 0 ? o.push(o[0]) - 1 : o.push(["M", p.x + p.width / 2, p.y + p.height / 2]) - 1);
            var m = P(r, c, g, o, d, f);
            r = r.slice(0, c).concat(m.start, g === !1 ? [] : r.slice(g)), o = o.slice(0, d).concat(m.dest, f === !1 ? [] : o.slice(f)), c = g !== !1 && c + m.start.length, d = f !== !1 && d + m.dest.length;
          }
          return this.value = r, this.destination = new SVG.PathArray(), this.destination.value = o, this;
        } });
      }(), /*! svg.draggable.js - v2.2.2 - 2019-01-08
        * https://github.com/svgdotjs/svg.draggable.js
        * Copyright (c) 2019 Wout Fierens; Licensed MIT */
      (function() {
        function P(e) {
          e.remember("_draggable", this), this.el = e;
        }
        P.prototype.init = function(e, t) {
          var i = this;
          this.constraint = e, this.value = t, this.el.on("mousedown.drag", function(a) {
            i.start(a);
          }), this.el.on("touchstart.drag", function(a) {
            i.start(a);
          });
        }, P.prototype.transformPoint = function(e, t) {
          var i = (e = e || window.event).changedTouches && e.changedTouches[0] || e;
          return this.p.x = i.clientX - (t || 0), this.p.y = i.clientY, this.p.matrixTransform(this.m);
        }, P.prototype.getBBox = function() {
          var e = this.el.bbox();
          return this.el instanceof SVG.Nested && (e = this.el.rbox()), (this.el instanceof SVG.G || this.el instanceof SVG.Use || this.el instanceof SVG.Nested) && (e.x = this.el.x(), e.y = this.el.y()), e;
        }, P.prototype.start = function(e) {
          if (e.type != "click" && e.type != "mousedown" && e.type != "mousemove" || (e.which || e.buttons) == 1) {
            var t = this;
            if (this.el.fire("beforedrag", { event: e, handler: this }), !this.el.event().defaultPrevented) {
              e.preventDefault(), e.stopPropagation(), this.parent = this.parent || this.el.parent(SVG.Nested) || this.el.parent(SVG.Doc), this.p = this.parent.node.createSVGPoint(), this.m = this.el.node.getScreenCTM().inverse();
              var i, a = this.getBBox();
              if (this.el instanceof SVG.Text)
                switch (i = this.el.node.getComputedTextLength(), this.el.attr("text-anchor")) {
                  case "middle":
                    i /= 2;
                    break;
                  case "start":
                    i = 0;
                }
              this.startPoints = { point: this.transformPoint(e, i), box: a, transform: this.el.transform() }, SVG.on(window, "mousemove.drag", function(s) {
                t.drag(s);
              }), SVG.on(window, "touchmove.drag", function(s) {
                t.drag(s);
              }), SVG.on(window, "mouseup.drag", function(s) {
                t.end(s);
              }), SVG.on(window, "touchend.drag", function(s) {
                t.end(s);
              }), this.el.fire("dragstart", { event: e, p: this.startPoints.point, m: this.m, handler: this });
            }
          }
        }, P.prototype.drag = function(e) {
          var t = this.getBBox(), i = this.transformPoint(e), a = this.startPoints.box.x + i.x - this.startPoints.point.x, s = this.startPoints.box.y + i.y - this.startPoints.point.y, r = this.constraint, o = i.x - this.startPoints.point.x, c = i.y - this.startPoints.point.y;
          if (this.el.fire("dragmove", { event: e, p: i, m: this.m, handler: this }), this.el.event().defaultPrevented)
            return i;
          if (typeof r == "function") {
            var d = r.call(this.el, a, s, this.m);
            typeof d == "boolean" && (d = { x: d, y: d }), d.x === !0 ? this.el.x(a) : d.x !== !1 && this.el.x(d.x), d.y === !0 ? this.el.y(s) : d.y !== !1 && this.el.y(d.y);
          } else
            typeof r == "object" && (r.minX != null && a < r.minX ? o = (a = r.minX) - this.startPoints.box.x : r.maxX != null && a > r.maxX - t.width && (o = (a = r.maxX - t.width) - this.startPoints.box.x), r.minY != null && s < r.minY ? c = (s = r.minY) - this.startPoints.box.y : r.maxY != null && s > r.maxY - t.height && (c = (s = r.maxY - t.height) - this.startPoints.box.y), r.snapToGrid != null && (a -= a % r.snapToGrid, s -= s % r.snapToGrid, o -= o % r.snapToGrid, c -= c % r.snapToGrid), this.el instanceof SVG.G ? this.el.matrix(this.startPoints.transform).transform({ x: o, y: c }, !0) : this.el.move(a, s));
          return i;
        }, P.prototype.end = function(e) {
          var t = this.drag(e);
          this.el.fire("dragend", { event: e, p: t, m: this.m, handler: this }), SVG.off(window, "mousemove.drag"), SVG.off(window, "touchmove.drag"), SVG.off(window, "mouseup.drag"), SVG.off(window, "touchend.drag");
        }, SVG.extend(SVG.Element, { draggable: function(e, t) {
          typeof e != "function" && typeof e != "object" || (t = e, e = !0);
          var i = this.remember("_draggable") || new P(this);
          return (e = e === void 0 || e) ? i.init(t || {}, e) : (this.off("mousedown.drag"), this.off("touchstart.drag")), this;
        } });
      }).call(void 0), function() {
        function P(e) {
          this.el = e, e.remember("_selectHandler", this), this.pointSelection = { isSelected: !1 }, this.rectSelection = { isSelected: !1 }, this.pointsList = { lt: [0, 0], rt: ["width", 0], rb: ["width", "height"], lb: [0, "height"], t: ["width", 0], r: ["width", "height"], b: ["width", "height"], l: [0, "height"] }, this.pointCoord = function(t, i, a) {
            var s = typeof t != "string" ? t : i[t];
            return a ? s / 2 : s;
          }, this.pointCoords = function(t, i) {
            var a = this.pointsList[t];
            return { x: this.pointCoord(a[0], i, t === "t" || t === "b"), y: this.pointCoord(a[1], i, t === "r" || t === "l") };
          };
        }
        P.prototype.init = function(e, t) {
          var i = this.el.bbox();
          this.options = {};
          var a = this.el.selectize.defaults.points;
          for (var s in this.el.selectize.defaults)
            this.options[s] = this.el.selectize.defaults[s], t[s] !== void 0 && (this.options[s] = t[s]);
          var r = ["points", "pointsExclude"];
          for (var s in r) {
            var o = this.options[r[s]];
            typeof o == "string" ? o = o.length > 0 ? o.split(/\s*,\s*/i) : [] : typeof o == "boolean" && r[s] === "points" && (o = o ? a : []), this.options[r[s]] = o;
          }
          this.options.points = [a, this.options.points].reduce(function(c, d) {
            return c.filter(function(g) {
              return d.indexOf(g) > -1;
            });
          }), this.options.points = [this.options.points, this.options.pointsExclude].reduce(function(c, d) {
            return c.filter(function(g) {
              return d.indexOf(g) < 0;
            });
          }), this.parent = this.el.parent(), this.nested = this.nested || this.parent.group(), this.nested.matrix(new SVG.Matrix(this.el).translate(i.x, i.y)), this.options.deepSelect && ["line", "polyline", "polygon"].indexOf(this.el.type) !== -1 ? this.selectPoints(e) : this.selectRect(e), this.observe(), this.cleanup();
        }, P.prototype.selectPoints = function(e) {
          return this.pointSelection.isSelected = e, this.pointSelection.set || (this.pointSelection.set = this.parent.set(), this.drawPoints()), this;
        }, P.prototype.getPointArray = function() {
          var e = this.el.bbox();
          return this.el.array().valueOf().map(function(t) {
            return [t[0] - e.x, t[1] - e.y];
          });
        }, P.prototype.drawPoints = function() {
          for (var e = this, t = this.getPointArray(), i = 0, a = t.length; i < a; ++i) {
            var s = function(o) {
              return function(c) {
                (c = c || window.event).preventDefault ? c.preventDefault() : c.returnValue = !1, c.stopPropagation();
                var d = c.pageX || c.touches[0].pageX, g = c.pageY || c.touches[0].pageY;
                e.el.fire("point", { x: d, y: g, i: o, event: c });
              };
            }(i), r = this.drawPoint(t[i][0], t[i][1]).addClass(this.options.classPoints).addClass(this.options.classPoints + "_point").on("touchstart", s).on("mousedown", s);
            this.pointSelection.set.add(r);
          }
        }, P.prototype.drawPoint = function(e, t) {
          var i = this.options.pointType;
          switch (i) {
            case "circle":
              return this.drawCircle(e, t);
            case "rect":
              return this.drawRect(e, t);
            default:
              if (typeof i == "function")
                return i.call(this, e, t);
              throw new Error("Unknown " + i + " point type!");
          }
        }, P.prototype.drawCircle = function(e, t) {
          return this.nested.circle(this.options.pointSize).center(e, t);
        }, P.prototype.drawRect = function(e, t) {
          return this.nested.rect(this.options.pointSize, this.options.pointSize).center(e, t);
        }, P.prototype.updatePointSelection = function() {
          var e = this.getPointArray();
          this.pointSelection.set.each(function(t) {
            this.cx() === e[t][0] && this.cy() === e[t][1] || this.center(e[t][0], e[t][1]);
          });
        }, P.prototype.updateRectSelection = function() {
          var e = this, t = this.el.bbox();
          if (this.rectSelection.set.get(0).attr({ width: t.width, height: t.height }), this.options.points.length && this.options.points.map(function(a, s) {
            var r = e.pointCoords(a, t);
            e.rectSelection.set.get(s + 1).center(r.x, r.y);
          }), this.options.rotationPoint) {
            var i = this.rectSelection.set.length();
            this.rectSelection.set.get(i - 1).center(t.width / 2, 20);
          }
        }, P.prototype.selectRect = function(e) {
          var t = this, i = this.el.bbox();
          function a(o) {
            return function(c) {
              (c = c || window.event).preventDefault ? c.preventDefault() : c.returnValue = !1, c.stopPropagation();
              var d = c.pageX || c.touches[0].pageX, g = c.pageY || c.touches[0].pageY;
              t.el.fire(o, { x: d, y: g, event: c });
            };
          }
          if (this.rectSelection.isSelected = e, this.rectSelection.set = this.rectSelection.set || this.parent.set(), this.rectSelection.set.get(0) || this.rectSelection.set.add(this.nested.rect(i.width, i.height).addClass(this.options.classRect)), this.options.points.length && this.rectSelection.set.length() < 2 && (this.options.points.map(function(o, c) {
            var d = t.pointCoords(o, i), g = t.drawPoint(d.x, d.y).attr("class", t.options.classPoints + "_" + o).on("mousedown", a(o)).on("touchstart", a(o));
            t.rectSelection.set.add(g);
          }), this.rectSelection.set.each(function() {
            this.addClass(t.options.classPoints);
          })), this.options.rotationPoint && (this.options.points && !this.rectSelection.set.get(9) || !this.options.points && !this.rectSelection.set.get(1))) {
            var s = function(o) {
              (o = o || window.event).preventDefault ? o.preventDefault() : o.returnValue = !1, o.stopPropagation();
              var c = o.pageX || o.touches[0].pageX, d = o.pageY || o.touches[0].pageY;
              t.el.fire("rot", { x: c, y: d, event: o });
            }, r = this.drawPoint(i.width / 2, 20).attr("class", this.options.classPoints + "_rot").on("touchstart", s).on("mousedown", s);
            this.rectSelection.set.add(r);
          }
        }, P.prototype.handler = function() {
          var e = this.el.bbox();
          this.nested.matrix(new SVG.Matrix(this.el).translate(e.x, e.y)), this.rectSelection.isSelected && this.updateRectSelection(), this.pointSelection.isSelected && this.updatePointSelection();
        }, P.prototype.observe = function() {
          var e = this;
          if (MutationObserver)
            if (this.rectSelection.isSelected || this.pointSelection.isSelected)
              this.observerInst = this.observerInst || new MutationObserver(function() {
                e.handler();
              }), this.observerInst.observe(this.el.node, { attributes: !0 });
            else
              try {
                this.observerInst.disconnect(), delete this.observerInst;
              } catch {
              }
          else
            this.el.off("DOMAttrModified.select"), (this.rectSelection.isSelected || this.pointSelection.isSelected) && this.el.on("DOMAttrModified.select", function() {
              e.handler();
            });
        }, P.prototype.cleanup = function() {
          !this.rectSelection.isSelected && this.rectSelection.set && (this.rectSelection.set.each(function() {
            this.remove();
          }), this.rectSelection.set.clear(), delete this.rectSelection.set), !this.pointSelection.isSelected && this.pointSelection.set && (this.pointSelection.set.each(function() {
            this.remove();
          }), this.pointSelection.set.clear(), delete this.pointSelection.set), this.pointSelection.isSelected || this.rectSelection.isSelected || (this.nested.remove(), delete this.nested);
        }, SVG.extend(SVG.Element, { selectize: function(e, t) {
          return typeof e == "object" && (t = e, e = !0), (this.remember("_selectHandler") || new P(this)).init(e === void 0 || e, t || {}), this;
        } }), SVG.Element.prototype.selectize.defaults = { points: ["lt", "rt", "rb", "lb", "t", "r", "b", "l"], pointsExclude: [], classRect: "svg_select_boundingRect", classPoints: "svg_select_points", pointSize: 7, rotationPoint: !0, deepSelect: !1, pointType: "circle" };
      }(), function() {
        (function() {
          function P(e) {
            e.remember("_resizeHandler", this), this.el = e, this.parameters = {}, this.lastUpdateCall = null, this.p = e.doc().node.createSVGPoint();
          }
          P.prototype.transformPoint = function(e, t, i) {
            return this.p.x = e - (this.offset.x - window.pageXOffset), this.p.y = t - (this.offset.y - window.pageYOffset), this.p.matrixTransform(i || this.m);
          }, P.prototype._extractPosition = function(e) {
            return { x: e.clientX != null ? e.clientX : e.touches[0].clientX, y: e.clientY != null ? e.clientY : e.touches[0].clientY };
          }, P.prototype.init = function(e) {
            var t = this;
            if (this.stop(), e !== "stop") {
              for (var i in this.options = {}, this.el.resize.defaults)
                this.options[i] = this.el.resize.defaults[i], e[i] !== void 0 && (this.options[i] = e[i]);
              this.el.on("lt.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("rt.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("rb.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("lb.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("t.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("r.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("b.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("l.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("rot.resize", function(a) {
                t.resize(a || window.event);
              }), this.el.on("point.resize", function(a) {
                t.resize(a || window.event);
              }), this.update();
            }
          }, P.prototype.stop = function() {
            return this.el.off("lt.resize"), this.el.off("rt.resize"), this.el.off("rb.resize"), this.el.off("lb.resize"), this.el.off("t.resize"), this.el.off("r.resize"), this.el.off("b.resize"), this.el.off("l.resize"), this.el.off("rot.resize"), this.el.off("point.resize"), this;
          }, P.prototype.resize = function(e) {
            var t = this;
            this.m = this.el.node.getScreenCTM().inverse(), this.offset = { x: window.pageXOffset, y: window.pageYOffset };
            var i = this._extractPosition(e.detail.event);
            if (this.parameters = { type: this.el.type, p: this.transformPoint(i.x, i.y), x: e.detail.x, y: e.detail.y, box: this.el.bbox(), rotation: this.el.transform().rotation }, this.el.type === "text" && (this.parameters.fontSize = this.el.attr()["font-size"]), e.detail.i !== void 0) {
              var a = this.el.array().valueOf();
              this.parameters.i = e.detail.i, this.parameters.pointCoords = [a[e.detail.i][0], a[e.detail.i][1]];
            }
            switch (e.type) {
              case "lt":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r);
                  if (this.parameters.box.width - o[0] > 0 && this.parameters.box.height - o[1] > 0) {
                    if (this.parameters.type === "text")
                      return this.el.move(this.parameters.box.x + o[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - o[0]);
                    o = this.checkAspectRatio(o), this.el.move(this.parameters.box.x + o[0], this.parameters.box.y + o[1]).size(this.parameters.box.width - o[0], this.parameters.box.height - o[1]);
                  }
                };
                break;
              case "rt":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, 2);
                  if (this.parameters.box.width + o[0] > 0 && this.parameters.box.height - o[1] > 0) {
                    if (this.parameters.type === "text")
                      return this.el.move(this.parameters.box.x - o[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + o[0]);
                    o = this.checkAspectRatio(o, !0), this.el.move(this.parameters.box.x, this.parameters.box.y + o[1]).size(this.parameters.box.width + o[0], this.parameters.box.height - o[1]);
                  }
                };
                break;
              case "rb":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, 0);
                  if (this.parameters.box.width + o[0] > 0 && this.parameters.box.height + o[1] > 0) {
                    if (this.parameters.type === "text")
                      return this.el.move(this.parameters.box.x - o[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + o[0]);
                    o = this.checkAspectRatio(o), this.el.move(this.parameters.box.x, this.parameters.box.y).size(this.parameters.box.width + o[0], this.parameters.box.height + o[1]);
                  }
                };
                break;
              case "lb":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, 1);
                  if (this.parameters.box.width - o[0] > 0 && this.parameters.box.height + o[1] > 0) {
                    if (this.parameters.type === "text")
                      return this.el.move(this.parameters.box.x + o[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - o[0]);
                    o = this.checkAspectRatio(o, !0), this.el.move(this.parameters.box.x + o[0], this.parameters.box.y).size(this.parameters.box.width - o[0], this.parameters.box.height + o[1]);
                  }
                };
                break;
              case "t":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, 2);
                  if (this.parameters.box.height - o[1] > 0) {
                    if (this.parameters.type === "text")
                      return;
                    this.el.move(this.parameters.box.x, this.parameters.box.y + o[1]).height(this.parameters.box.height - o[1]);
                  }
                };
                break;
              case "r":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, 0);
                  if (this.parameters.box.width + o[0] > 0) {
                    if (this.parameters.type === "text")
                      return;
                    this.el.move(this.parameters.box.x, this.parameters.box.y).width(this.parameters.box.width + o[0]);
                  }
                };
                break;
              case "b":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, 0);
                  if (this.parameters.box.height + o[1] > 0) {
                    if (this.parameters.type === "text")
                      return;
                    this.el.move(this.parameters.box.x, this.parameters.box.y).height(this.parameters.box.height + o[1]);
                  }
                };
                break;
              case "l":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, 1);
                  if (this.parameters.box.width - o[0] > 0) {
                    if (this.parameters.type === "text")
                      return;
                    this.el.move(this.parameters.box.x + o[0], this.parameters.box.y).width(this.parameters.box.width - o[0]);
                  }
                };
                break;
              case "rot":
                this.calc = function(s, r) {
                  var o = s + this.parameters.p.x, c = r + this.parameters.p.y, d = Math.atan2(this.parameters.p.y - this.parameters.box.y - this.parameters.box.height / 2, this.parameters.p.x - this.parameters.box.x - this.parameters.box.width / 2), g = Math.atan2(c - this.parameters.box.y - this.parameters.box.height / 2, o - this.parameters.box.x - this.parameters.box.width / 2), f = this.parameters.rotation + 180 * (g - d) / Math.PI + this.options.snapToAngle / 2;
                  this.el.center(this.parameters.box.cx, this.parameters.box.cy).rotate(f - f % this.options.snapToAngle, this.parameters.box.cx, this.parameters.box.cy);
                };
                break;
              case "point":
                this.calc = function(s, r) {
                  var o = this.snapToGrid(s, r, this.parameters.pointCoords[0], this.parameters.pointCoords[1]), c = this.el.array().valueOf();
                  c[this.parameters.i][0] = this.parameters.pointCoords[0] + o[0], c[this.parameters.i][1] = this.parameters.pointCoords[1] + o[1], this.el.plot(c);
                };
            }
            this.el.fire("resizestart", { dx: this.parameters.x, dy: this.parameters.y, event: e }), SVG.on(window, "touchmove.resize", function(s) {
              t.update(s || window.event);
            }), SVG.on(window, "touchend.resize", function() {
              t.done();
            }), SVG.on(window, "mousemove.resize", function(s) {
              t.update(s || window.event);
            }), SVG.on(window, "mouseup.resize", function() {
              t.done();
            });
          }, P.prototype.update = function(e) {
            if (e) {
              var t = this._extractPosition(e), i = this.transformPoint(t.x, t.y), a = i.x - this.parameters.p.x, s = i.y - this.parameters.p.y;
              this.lastUpdateCall = [a, s], this.calc(a, s), this.el.fire("resizing", { dx: a, dy: s, event: e });
            } else
              this.lastUpdateCall && this.calc(this.lastUpdateCall[0], this.lastUpdateCall[1]);
          }, P.prototype.done = function() {
            this.lastUpdateCall = null, SVG.off(window, "mousemove.resize"), SVG.off(window, "mouseup.resize"), SVG.off(window, "touchmove.resize"), SVG.off(window, "touchend.resize"), this.el.fire("resizedone");
          }, P.prototype.snapToGrid = function(e, t, i, a) {
            var s;
            return a !== void 0 ? s = [(i + e) % this.options.snapToGrid, (a + t) % this.options.snapToGrid] : (i = i ?? 3, s = [(this.parameters.box.x + e + (1 & i ? 0 : this.parameters.box.width)) % this.options.snapToGrid, (this.parameters.box.y + t + (2 & i ? 0 : this.parameters.box.height)) % this.options.snapToGrid]), e < 0 && (s[0] -= this.options.snapToGrid), t < 0 && (s[1] -= this.options.snapToGrid), e -= Math.abs(s[0]) < this.options.snapToGrid / 2 ? s[0] : s[0] - (e < 0 ? -this.options.snapToGrid : this.options.snapToGrid), t -= Math.abs(s[1]) < this.options.snapToGrid / 2 ? s[1] : s[1] - (t < 0 ? -this.options.snapToGrid : this.options.snapToGrid), this.constraintToBox(e, t, i, a);
          }, P.prototype.constraintToBox = function(e, t, i, a) {
            var s, r, o = this.options.constraint || {};
            return a !== void 0 ? (s = i, r = a) : (s = this.parameters.box.x + (1 & i ? 0 : this.parameters.box.width), r = this.parameters.box.y + (2 & i ? 0 : this.parameters.box.height)), o.minX !== void 0 && s + e < o.minX && (e = o.minX - s), o.maxX !== void 0 && s + e > o.maxX && (e = o.maxX - s), o.minY !== void 0 && r + t < o.minY && (t = o.minY - r), o.maxY !== void 0 && r + t > o.maxY && (t = o.maxY - r), [e, t];
          }, P.prototype.checkAspectRatio = function(e, t) {
            if (!this.options.saveAspectRatio)
              return e;
            var i = e.slice(), a = this.parameters.box.width / this.parameters.box.height, s = this.parameters.box.width + e[0], r = this.parameters.box.height - e[1], o = s / r;
            return o < a ? (i[1] = s / a - this.parameters.box.height, t && (i[1] = -i[1])) : o > a && (i[0] = this.parameters.box.width - r * a, t && (i[0] = -i[0])), i;
          }, SVG.extend(SVG.Element, { resize: function(e) {
            return (this.remember("_resizeHandler") || new P(this)).init(e || {}), this;
          } }), SVG.Element.prototype.resize.defaults = { snapToAngle: 0.1, snapToGrid: 1, constraint: {}, saveAspectRatio: !1 };
        }).call(this);
      }(), window.Apex === void 0 && (window.Apex = {});
      var Vi = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "initModules", value: function() {
          this.ctx.publicMethods = ["updateOptions", "updateSeries", "appendData", "appendSeries", "isSeriesHidden", "toggleSeries", "showSeries", "hideSeries", "setLocale", "resetSeries", "zoomX", "toggleDataPointSelection", "dataURI", "exportToCSV", "addXaxisAnnotation", "addYaxisAnnotation", "addPointAnnotation", "clearAnnotations", "removeAnnotation", "paper", "destroy"], this.ctx.eventList = ["click", "mousedown", "mousemove", "mouseleave", "touchstart", "touchmove", "touchleave", "mouseup", "touchend"], this.ctx.animations = new V(this.ctx), this.ctx.axes = new Xe(this.ctx), this.ctx.core = new ks(this.ctx.el, this.ctx), this.ctx.config = new Te({}), this.ctx.data = new ve(this.ctx), this.ctx.grid = new Re(this.ctx), this.ctx.graphics = new X(this.ctx), this.ctx.coreUtils = new $(this.ctx), this.ctx.crosshairs = new Ye(this.ctx), this.ctx.events = new He(this.ctx), this.ctx.exports = new Se(this.ctx), this.ctx.localization = new Be(this.ctx), this.ctx.options = new ce(), this.ctx.responsive = new We(this.ctx), this.ctx.series = new de(this.ctx), this.ctx.theme = new tt(this.ctx), this.ctx.formatters = new Le(this.ctx), this.ctx.titleSubtitle = new Ge(this.ctx), this.ctx.legend = new Oi(this.ctx), this.ctx.toolbar = new zi(this.ctx), this.ctx.tooltip = new Xi(this.ctx), this.ctx.dimensions = new st(this.ctx), this.ctx.updateHelpers = new As(this.ctx), this.ctx.zoomPanSelection = new ls(this.ctx), this.ctx.w.globals.tooltip = new Xi(this.ctx);
        } }]), P;
      }(), Gi = function() {
        function P(e) {
          y(this, P), this.ctx = e, this.w = e.w;
        }
        return A(P, [{ key: "clear", value: function(e) {
          var t = e.isUpdating;
          this.ctx.zoomPanSelection && this.ctx.zoomPanSelection.destroy(), this.ctx.toolbar && this.ctx.toolbar.destroy(), this.ctx.animations = null, this.ctx.axes = null, this.ctx.annotations = null, this.ctx.core = null, this.ctx.data = null, this.ctx.grid = null, this.ctx.series = null, this.ctx.responsive = null, this.ctx.theme = null, this.ctx.formatters = null, this.ctx.titleSubtitle = null, this.ctx.legend = null, this.ctx.dimensions = null, this.ctx.options = null, this.ctx.crosshairs = null, this.ctx.zoomPanSelection = null, this.ctx.updateHelpers = null, this.ctx.toolbar = null, this.ctx.localization = null, this.ctx.w.globals.tooltip = null, this.clearDomElements({ isUpdating: t });
        } }, { key: "killSVG", value: function(e) {
          e.each(function(t, i) {
            this.removeClass("*"), this.off(), this.stop();
          }, !0), e.ungroup(), e.clear();
        } }, { key: "clearDomElements", value: function(e) {
          var t = this, i = e.isUpdating, a = this.w.globals.dom.Paper.node;
          a.parentNode && a.parentNode.parentNode && !i && (a.parentNode.parentNode.style.minHeight = "unset");
          var s = this.w.globals.dom.baseEl;
          s && this.ctx.eventList.forEach(function(o) {
            s.removeEventListener(o, t.ctx.events.documentEvent);
          });
          var r = this.w.globals.dom;
          if (this.ctx.el !== null)
            for (; this.ctx.el.firstChild; )
              this.ctx.el.removeChild(this.ctx.el.firstChild);
          this.killSVG(r.Paper), r.Paper.remove(), r.elWrap = null, r.elGraphical = null, r.elLegendWrap = null, r.elLegendForeign = null, r.baseEl = null, r.elGridRect = null, r.elGridRectMask = null, r.elGridRectMarkerMask = null, r.elForecastMask = null, r.elNonForecastMask = null, r.elDefs = null;
        } }]), P;
      }(), ri = /* @__PURE__ */ new WeakMap(), Ps = function() {
        function P(e, t) {
          y(this, P), this.opts = t, this.ctx = this, this.w = new Q(t).init(), this.el = e, this.w.globals.cuid = M.randomId(), this.w.globals.chartID = this.w.config.chart.id ? M.escapeString(this.w.config.chart.id) : this.w.globals.cuid, new Vi(this).initModules(), this.create = M.bind(this.create, this), this.windowResizeHandler = this._windowResizeHandler.bind(this), this.parentResizeHandler = this._parentResizeCallback.bind(this);
        }
        return A(P, [{ key: "render", value: function() {
          var e = this;
          return new Promise(function(t, i) {
            if (e.el !== null) {
              Apex._chartInstances === void 0 && (Apex._chartInstances = []), e.w.config.chart.id && Apex._chartInstances.push({ id: e.w.globals.chartID, group: e.w.config.chart.group, chart: e }), e.setLocale(e.w.config.chart.defaultLocale);
              var a = e.w.config.chart.events.beforeMount;
              if (typeof a == "function" && a(e, e.w), e.events.fireEvent("beforeMount", [e, e.w]), window.addEventListener("resize", e.windowResizeHandler), function(p, m) {
                var w = !1;
                if (p.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) {
                  var C = p.getBoundingClientRect();
                  p.style.display !== "none" && C.width !== 0 || (w = !0);
                }
                var k = new ResizeObserver(function(E) {
                  w && m.call(p, E), w = !0;
                });
                p.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? Array.from(p.children).forEach(function(E) {
                  return k.observe(E);
                }) : k.observe(p), ri.set(m, k);
              }(e.el.parentNode, e.parentResizeHandler), !e.css) {
                var s = e.el.getRootNode && e.el.getRootNode(), r = M.is("ShadowRoot", s), o = e.el.ownerDocument, c = o.getElementById("apexcharts-css");
                if (r || !c) {
                  var d;
                  e.css = document.createElement("style"), e.css.id = "apexcharts-css", e.css.textContent = `@keyframes opaque {
  0% {
      opacity: 0
  }

  to {
      opacity: 1
  }
}

@keyframes resizeanim {
  0%,to {
      opacity: 0
  }
}

.apexcharts-canvas {
  position: relative;
  user-select: none
}

.apexcharts-canvas ::-webkit-scrollbar {
  -webkit-appearance: none;
  width: 6px
}

.apexcharts-canvas ::-webkit-scrollbar-thumb {
  border-radius: 4px;
  background-color: rgba(0,0,0,.5);
  box-shadow: 0 0 1px rgba(255,255,255,.5);
  -webkit-box-shadow: 0 0 1px rgba(255,255,255,.5)
}

.apexcharts-inner {
  position: relative
}

.apexcharts-text tspan {
  font-family: inherit
}

.legend-mouseover-inactive {
  transition: .15s ease all;
  opacity: .2
}

.apexcharts-legend-text {
  padding-left: 15px;
  margin-left: -15px;
}

.apexcharts-series-collapsed {
  opacity: 0
}

.apexcharts-tooltip {
  border-radius: 5px;
  box-shadow: 2px 2px 6px -4px #999;
  cursor: default;
  font-size: 14px;
  left: 62px;
  opacity: 0;
  pointer-events: none;
  position: absolute;
  top: 20px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  white-space: nowrap;
  z-index: 12;
  transition: .15s ease all
}

.apexcharts-tooltip.apexcharts-active {
  opacity: 1;
  transition: .15s ease all
}

.apexcharts-tooltip.apexcharts-theme-light {
  border: 1px solid #e3e3e3;
  background: rgba(255,255,255,.96)
}

.apexcharts-tooltip.apexcharts-theme-dark {
  color: #fff;
  background: rgba(30,30,30,.8)
}

.apexcharts-tooltip * {
  font-family: inherit
}

.apexcharts-tooltip-title {
  padding: 6px;
  font-size: 15px;
  margin-bottom: 4px
}

.apexcharts-tooltip.apexcharts-theme-light .apexcharts-tooltip-title {
  background: #eceff1;
  border-bottom: 1px solid #ddd
}

.apexcharts-tooltip.apexcharts-theme-dark .apexcharts-tooltip-title {
  background: rgba(0,0,0,.7);
  border-bottom: 1px solid #333
}

.apexcharts-tooltip-text-goals-value,.apexcharts-tooltip-text-y-value,.apexcharts-tooltip-text-z-value {
  display: inline-block;
  margin-left: 5px;
  font-weight: 600
}

.apexcharts-tooltip-text-goals-label:empty,.apexcharts-tooltip-text-goals-value:empty,.apexcharts-tooltip-text-y-label:empty,.apexcharts-tooltip-text-y-value:empty,.apexcharts-tooltip-text-z-value:empty,.apexcharts-tooltip-title:empty {
  display: none
}

.apexcharts-tooltip-text-goals-label,.apexcharts-tooltip-text-goals-value {
  padding: 6px 0 5px
}

.apexcharts-tooltip-goals-group,.apexcharts-tooltip-text-goals-label,.apexcharts-tooltip-text-goals-value {
  display: flex
}

.apexcharts-tooltip-text-goals-label:not(:empty),.apexcharts-tooltip-text-goals-value:not(:empty) {
  margin-top: -6px
}

.apexcharts-tooltip-marker {
  width: 12px;
  height: 12px;
  position: relative;
  top: 0;
  margin-right: 10px;
  border-radius: 50%
}

.apexcharts-tooltip-series-group {
  padding: 0 10px;
  display: none;
  text-align: left;
  justify-content: left;
  align-items: center
}

.apexcharts-tooltip-series-group.apexcharts-active .apexcharts-tooltip-marker {
  opacity: 1
}

.apexcharts-tooltip-series-group.apexcharts-active,.apexcharts-tooltip-series-group:last-child {
  padding-bottom: 4px
}

.apexcharts-tooltip-series-group-hidden {
  opacity: 0;
  height: 0;
  line-height: 0;
  padding: 0!important
}

.apexcharts-tooltip-y-group {
  padding: 6px 0 5px
}

.apexcharts-custom-tooltip,.apexcharts-tooltip-box {
  padding: 4px 8px
}

.apexcharts-tooltip-boxPlot {
  display: flex;
  flex-direction: column-reverse
}

.apexcharts-tooltip-box>div {
  margin: 4px 0
}

.apexcharts-tooltip-box span.value {
  font-weight: 700
}

.apexcharts-tooltip-rangebar {
  padding: 5px 8px
}

.apexcharts-tooltip-rangebar .category {
  font-weight: 600;
  color: #777
}

.apexcharts-tooltip-rangebar .series-name {
  font-weight: 700;
  display: block;
  margin-bottom: 5px
}

.apexcharts-xaxistooltip,.apexcharts-yaxistooltip {
  opacity: 0;
  pointer-events: none;
  color: #373d3f;
  font-size: 13px;
  text-align: center;
  border-radius: 2px;
  position: absolute;
  z-index: 10;
  background: #eceff1;
  border: 1px solid #90a4ae
}

.apexcharts-xaxistooltip {
  padding: 9px 10px;
  transition: .15s ease all
}

.apexcharts-xaxistooltip.apexcharts-theme-dark {
  background: rgba(0,0,0,.7);
  border: 1px solid rgba(0,0,0,.5);
  color: #fff
}

.apexcharts-xaxistooltip:after,.apexcharts-xaxistooltip:before {
  left: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none
}

.apexcharts-xaxistooltip:after {
  border-color: transparent;
  border-width: 6px;
  margin-left: -6px
}

.apexcharts-xaxistooltip:before {
  border-color: transparent;
  border-width: 7px;
  margin-left: -7px
}

.apexcharts-xaxistooltip-bottom:after,.apexcharts-xaxistooltip-bottom:before {
  bottom: 100%
}

.apexcharts-xaxistooltip-top:after,.apexcharts-xaxistooltip-top:before {
  top: 100%
}

.apexcharts-xaxistooltip-bottom:after {
  border-bottom-color: #eceff1
}

.apexcharts-xaxistooltip-bottom:before {
  border-bottom-color: #90a4ae
}

.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:after,.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:before {
  border-bottom-color: rgba(0,0,0,.5)
}

.apexcharts-xaxistooltip-top:after {
  border-top-color: #eceff1
}

.apexcharts-xaxistooltip-top:before {
  border-top-color: #90a4ae
}

.apexcharts-xaxistooltip-top.apexcharts-theme-dark:after,.apexcharts-xaxistooltip-top.apexcharts-theme-dark:before {
  border-top-color: rgba(0,0,0,.5)
}

.apexcharts-xaxistooltip.apexcharts-active {
  opacity: 1;
  transition: .15s ease all
}

.apexcharts-yaxistooltip {
  padding: 4px 10px
}

.apexcharts-yaxistooltip.apexcharts-theme-dark {
  background: rgba(0,0,0,.7);
  border: 1px solid rgba(0,0,0,.5);
  color: #fff
}

.apexcharts-yaxistooltip:after,.apexcharts-yaxistooltip:before {
  top: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none
}

.apexcharts-yaxistooltip:after {
  border-color: transparent;
  border-width: 6px;
  margin-top: -6px
}

.apexcharts-yaxistooltip:before {
  border-color: transparent;
  border-width: 7px;
  margin-top: -7px
}

.apexcharts-yaxistooltip-left:after,.apexcharts-yaxistooltip-left:before {
  left: 100%
}

.apexcharts-yaxistooltip-right:after,.apexcharts-yaxistooltip-right:before {
  right: 100%
}

.apexcharts-yaxistooltip-left:after {
  border-left-color: #eceff1
}

.apexcharts-yaxistooltip-left:before {
  border-left-color: #90a4ae
}

.apexcharts-yaxistooltip-left.apexcharts-theme-dark:after,.apexcharts-yaxistooltip-left.apexcharts-theme-dark:before {
  border-left-color: rgba(0,0,0,.5)
}

.apexcharts-yaxistooltip-right:after {
  border-right-color: #eceff1
}

.apexcharts-yaxistooltip-right:before {
  border-right-color: #90a4ae
}

.apexcharts-yaxistooltip-right.apexcharts-theme-dark:after,.apexcharts-yaxistooltip-right.apexcharts-theme-dark:before {
  border-right-color: rgba(0,0,0,.5)
}

.apexcharts-yaxistooltip.apexcharts-active {
  opacity: 1
}

.apexcharts-yaxistooltip-hidden {
  display: none
}

.apexcharts-xcrosshairs,.apexcharts-ycrosshairs {
  pointer-events: none;
  opacity: 0;
  transition: .15s ease all
}

.apexcharts-xcrosshairs.apexcharts-active,.apexcharts-ycrosshairs.apexcharts-active {
  opacity: 1;
  transition: .15s ease all
}

.apexcharts-ycrosshairs-hidden {
  opacity: 0
}

.apexcharts-selection-rect {
  cursor: move
}

.svg_select_boundingRect,.svg_select_points_rot {
  pointer-events: none;
  opacity: 0;
  visibility: hidden
}

.apexcharts-selection-rect+g .svg_select_boundingRect,.apexcharts-selection-rect+g .svg_select_points_rot {
  opacity: 0;
  visibility: hidden
}

.apexcharts-selection-rect+g .svg_select_points_l,.apexcharts-selection-rect+g .svg_select_points_r {
  cursor: ew-resize;
  opacity: 1;
  visibility: visible
}

.svg_select_points {
  fill: #efefef;
  stroke: #333;
  rx: 2
}

.apexcharts-svg.apexcharts-zoomable.hovering-zoom {
  cursor: crosshair
}

.apexcharts-svg.apexcharts-zoomable.hovering-pan {
  cursor: move
}

.apexcharts-menu-icon,.apexcharts-pan-icon,.apexcharts-reset-icon,.apexcharts-selection-icon,.apexcharts-toolbar-custom-icon,.apexcharts-zoom-icon,.apexcharts-zoomin-icon,.apexcharts-zoomout-icon {
  cursor: pointer;
  width: 20px;
  height: 20px;
  line-height: 24px;
  color: #6e8192;
  text-align: center
}

.apexcharts-menu-icon svg,.apexcharts-reset-icon svg,.apexcharts-zoom-icon svg,.apexcharts-zoomin-icon svg,.apexcharts-zoomout-icon svg {
  fill: #6e8192
}

.apexcharts-selection-icon svg {
  fill: #444;
  transform: scale(.76)
}

.apexcharts-theme-dark .apexcharts-menu-icon svg,.apexcharts-theme-dark .apexcharts-pan-icon svg,.apexcharts-theme-dark .apexcharts-reset-icon svg,.apexcharts-theme-dark .apexcharts-selection-icon svg,.apexcharts-theme-dark .apexcharts-toolbar-custom-icon svg,.apexcharts-theme-dark .apexcharts-zoom-icon svg,.apexcharts-theme-dark .apexcharts-zoomin-icon svg,.apexcharts-theme-dark .apexcharts-zoomout-icon svg {
  fill: #f3f4f5
}

.apexcharts-canvas .apexcharts-reset-zoom-icon.apexcharts-selected svg,.apexcharts-canvas .apexcharts-selection-icon.apexcharts-selected svg,.apexcharts-canvas .apexcharts-zoom-icon.apexcharts-selected svg {
  fill: #008ffb
}

.apexcharts-theme-light .apexcharts-menu-icon:hover svg,.apexcharts-theme-light .apexcharts-reset-icon:hover svg,.apexcharts-theme-light .apexcharts-selection-icon:not(.apexcharts-selected):hover svg,.apexcharts-theme-light .apexcharts-zoom-icon:not(.apexcharts-selected):hover svg,.apexcharts-theme-light .apexcharts-zoomin-icon:hover svg,.apexcharts-theme-light .apexcharts-zoomout-icon:hover svg {
  fill: #333
}

.apexcharts-menu-icon,.apexcharts-selection-icon {
  position: relative
}

.apexcharts-reset-icon {
  margin-left: 5px
}

.apexcharts-menu-icon,.apexcharts-reset-icon,.apexcharts-zoom-icon {
  transform: scale(.85)
}

.apexcharts-zoomin-icon,.apexcharts-zoomout-icon {
  transform: scale(.7)
}

.apexcharts-zoomout-icon {
  margin-right: 3px
}

.apexcharts-pan-icon {
  transform: scale(.62);
  position: relative;
  left: 1px;
  top: 0
}

.apexcharts-pan-icon svg {
  fill: #fff;
  stroke: #6e8192;
  stroke-width: 2
}

.apexcharts-pan-icon.apexcharts-selected svg {
  stroke: #008ffb
}

.apexcharts-pan-icon:not(.apexcharts-selected):hover svg {
  stroke: #333
}

.apexcharts-toolbar {
  position: absolute;
  z-index: 11;
  max-width: 176px;
  text-align: right;
  border-radius: 3px;
  padding: 0 6px 2px;
  display: flex;
  justify-content: space-between;
  align-items: center
}

.apexcharts-menu {
  background: #fff;
  position: absolute;
  top: 100%;
  border: 1px solid #ddd;
  border-radius: 3px;
  padding: 3px;
  right: 10px;
  opacity: 0;
  min-width: 110px;
  transition: .15s ease all;
  pointer-events: none
}

.apexcharts-menu.apexcharts-menu-open {
  opacity: 1;
  pointer-events: all;
  transition: .15s ease all
}

.apexcharts-menu-item {
  padding: 6px 7px;
  font-size: 12px;
  cursor: pointer
}

.apexcharts-theme-light .apexcharts-menu-item:hover {
  background: #eee
}

.apexcharts-theme-dark .apexcharts-menu {
  background: rgba(0,0,0,.7);
  color: #fff
}

@media screen and (min-width:768px) {
  .apexcharts-canvas:hover .apexcharts-toolbar {
      opacity: 1
  }
}

.apexcharts-canvas .apexcharts-element-hidden,.apexcharts-datalabel.apexcharts-element-hidden,.apexcharts-hide .apexcharts-series-points {
  opacity: 0
}

.apexcharts-hidden-element-shown {
  opacity: 1;
  transition: 0.25s ease all;
}
.apexcharts-datalabel,.apexcharts-datalabel-label,.apexcharts-datalabel-value,.apexcharts-datalabels,.apexcharts-pie-label {
  cursor: default;
  pointer-events: none
}

.apexcharts-pie-label-delay {
  opacity: 0;
  animation-name: opaque;
  animation-duration: .3s;
  animation-fill-mode: forwards;
  animation-timing-function: ease
}

.apexcharts-radialbar-label {
  cursor: pointer;
}

.apexcharts-annotation-rect,.apexcharts-area-series .apexcharts-area,.apexcharts-area-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,.apexcharts-gridline,.apexcharts-line,.apexcharts-line-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,.apexcharts-point-annotation-label,.apexcharts-radar-series path,.apexcharts-radar-series polygon,.apexcharts-toolbar svg,.apexcharts-tooltip .apexcharts-marker,.apexcharts-xaxis-annotation-label,.apexcharts-yaxis-annotation-label,.apexcharts-zoom-rect {
  pointer-events: none
}

.apexcharts-marker {
  transition: .15s ease all
}

.resize-triggers {
  animation: 1ms resizeanim;
  visibility: hidden;
  opacity: 0;
  height: 100%;
  width: 100%;
  overflow: hidden
}

.contract-trigger:before,.resize-triggers,.resize-triggers>div {
  content: " ";
  display: block;
  position: absolute;
  top: 0;
  left: 0
}

.resize-triggers>div {
  height: 100%;
  width: 100%;
  background: #eee;
  overflow: auto
}

.contract-trigger:before {
  overflow: hidden;
  width: 200%;
  height: 200%
}

.apexcharts-bar-goals-markers{
  pointer-events: none
}

.apexcharts-bar-shadows{
  pointer-events: none
}

.apexcharts-rangebar-goals-markers{
  pointer-events: none
}`;
                  var g = ((d = e.opts.chart) === null || d === void 0 ? void 0 : d.nonce) || e.w.config.chart.nonce;
                  g && e.css.setAttribute("nonce", g), r ? s.prepend(e.css) : o.head.appendChild(e.css);
                }
              }
              var f = e.create(e.w.config.series, {});
              if (!f)
                return t(e);
              e.mount(f).then(function() {
                typeof e.w.config.chart.events.mounted == "function" && e.w.config.chart.events.mounted(e, e.w), e.events.fireEvent("mounted", [e, e.w]), t(f);
              }).catch(function(p) {
                i(p);
              });
            } else
              i(new Error("Element not found"));
          });
        } }, { key: "create", value: function(e, t) {
          var i = this.w;
          new Vi(this).initModules();
          var a = this.w.globals;
          if (a.noData = !1, a.animationEnded = !1, this.responsive.checkResponsiveConfig(t), i.config.xaxis.convertedCatToNumeric && new Me(i.config).convertCatToNumericXaxis(i.config, this.ctx), this.el === null || (this.core.setupElements(), i.config.chart.type === "treemap" && (i.config.grid.show = !1, i.config.yaxis[0].show = !1), a.svgWidth === 0))
            return a.animationEnded = !0, null;
          var s = $.checkComboSeries(e);
          a.comboCharts = s.comboCharts, a.comboBarCount = s.comboBarCount;
          var r = e.every(function(g) {
            return g.data && g.data.length === 0;
          });
          (e.length === 0 || r) && this.series.handleNoData(), this.events.setupEventHandlers(), this.data.parseData(e), this.theme.init(), new le(this).setGlobalMarkerSize(), this.formatters.setLabelFormatters(), this.titleSubtitle.draw(), a.noData && a.collapsedSeries.length !== a.series.length && !i.config.legend.showForSingleSeries || this.legend.init(), this.series.hasAllSeriesEqualX(), a.axisCharts && (this.core.coreCalculations(), i.config.xaxis.type !== "category" && this.formatters.setLabelFormatters(), this.ctx.toolbar.minX = i.globals.minX, this.ctx.toolbar.maxX = i.globals.maxX), this.formatters.heatmapLabelFormatters(), new $(this).getLargestMarkerSize(), this.dimensions.plotCoords();
          var o = this.core.xySettings();
          this.grid.createGridMask();
          var c = this.core.plotChartType(e, o), d = new xe(this);
          return d.bringForward(), i.config.dataLabels.background.enabled && d.dataLabelsBackground(), this.core.shiftGraphPosition(), { elGraph: c, xyRatios: o, dimensions: { plot: { left: i.globals.translateX, top: i.globals.translateY, width: i.globals.gridWidth, height: i.globals.gridHeight } } };
        } }, { key: "mount", value: function() {
          var e = this, t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null, i = this, a = i.w;
          return new Promise(function(s, r) {
            if (i.el === null)
              return r(new Error("Not enough data to display or target element not found"));
            (t === null || a.globals.allSeriesCollapsed) && i.series.handleNoData(), i.grid = new Re(i);
            var o, c, d = i.grid.drawGrid();
            if (i.annotations = new ge(i), i.annotations.drawImageAnnos(), i.annotations.drawTextAnnos(), a.config.grid.position === "back" && (d && a.globals.dom.elGraphical.add(d.el), d != null && (o = d.elGridBorders) !== null && o !== void 0 && o.node && a.globals.dom.elGraphical.add(d.elGridBorders)), Array.isArray(t.elGraph))
              for (var g = 0; g < t.elGraph.length; g++)
                a.globals.dom.elGraphical.add(t.elGraph[g]);
            else
              a.globals.dom.elGraphical.add(t.elGraph);
            a.config.grid.position === "front" && (d && a.globals.dom.elGraphical.add(d.el), d != null && (c = d.elGridBorders) !== null && c !== void 0 && c.node && a.globals.dom.elGraphical.add(d.elGridBorders)), a.config.xaxis.crosshairs.position === "front" && i.crosshairs.drawXCrosshairs(), a.config.yaxis[0].crosshairs.position === "front" && i.crosshairs.drawYCrosshairs(), a.config.chart.type !== "treemap" && i.axes.drawAxis(a.config.chart.type, d);
            var f = new Ee(e.ctx, d), p = new _e(e.ctx, d);
            if (d !== null && (f.xAxisLabelCorrections(d.xAxisTickWidth), p.setYAxisTextAlignments(), a.config.yaxis.map(function(w, C) {
              a.globals.ignoreYAxisIndexes.indexOf(C) === -1 && p.yAxisTitleRotate(C, w.opposite);
            })), i.annotations.drawAxesAnnotations(), !a.globals.noData) {
              if (a.config.tooltip.enabled && !a.globals.noData && i.w.globals.tooltip.drawTooltip(t.xyRatios), a.globals.axisCharts && (a.globals.isXNumeric || a.config.xaxis.convertedCatToNumeric || a.globals.isRangeBar))
                (a.config.chart.zoom.enabled || a.config.chart.selection && a.config.chart.selection.enabled || a.config.chart.pan && a.config.chart.pan.enabled) && i.zoomPanSelection.init({ xyRatios: t.xyRatios });
              else {
                var m = a.config.chart.toolbar.tools;
                ["zoom", "zoomin", "zoomout", "selection", "pan", "reset"].forEach(function(w) {
                  m[w] = !1;
                });
              }
              a.config.chart.toolbar.show && !a.globals.allSeriesCollapsed && i.toolbar.createToolbar();
            }
            a.globals.memory.methodsToExec.length > 0 && a.globals.memory.methodsToExec.forEach(function(w) {
              w.method(w.params, !1, w.context);
            }), a.globals.axisCharts || a.globals.noData || i.core.resizeNonAxisCharts(), s(i);
          });
        } }, { key: "destroy", value: function() {
          var e, t;
          window.removeEventListener("resize", this.windowResizeHandler), this.el.parentNode, e = this.parentResizeHandler, (t = ri.get(e)) && (t.disconnect(), ri.delete(e));
          var i = this.w.config.chart.id;
          i && Apex._chartInstances.forEach(function(a, s) {
            a.id === M.escapeString(i) && Apex._chartInstances.splice(s, 1);
          }), new Gi(this.ctx).clear({ isUpdating: !1 });
        } }, { key: "updateOptions", value: function(e) {
          var t = this, i = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], a = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], s = !(arguments.length > 3 && arguments[3] !== void 0) || arguments[3], r = !(arguments.length > 4 && arguments[4] !== void 0) || arguments[4], o = this.w;
          return o.globals.selection = void 0, e.series && (this.series.resetSeries(!1, !0, !1), e.series.length && e.series[0].data && (e.series = e.series.map(function(c, d) {
            return t.updateHelpers._extendSeries(c, d);
          })), this.updateHelpers.revertDefaultAxisMinMax()), e.xaxis && (e = this.updateHelpers.forceXAxisUpdate(e)), e.yaxis && (e = this.updateHelpers.forceYAxisUpdate(e)), o.globals.collapsedSeriesIndices.length > 0 && this.series.clearPreviousPaths(), e.theme && (e = this.theme.updateThemeOptions(e)), this.updateHelpers._updateOptions(e, i, a, s, r);
        } }, { key: "updateSeries", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2];
          return this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this.updateHelpers._updateSeries(e, t, i);
        } }, { key: "appendSeries", value: function(e) {
          var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], a = this.w.config.series.slice();
          return a.push(e), this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this.updateHelpers._updateSeries(a, t, i);
        } }, { key: "appendData", value: function(e) {
          var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = this;
          i.w.globals.dataChanged = !0, i.series.getPreviousPaths();
          for (var a = i.w.config.series.slice(), s = 0; s < a.length; s++)
            if (e[s] !== null && e[s] !== void 0)
              for (var r = 0; r < e[s].data.length; r++)
                a[s].data.push(e[s].data[r]);
          return i.w.config.series = a, t && (i.w.globals.initialSeries = M.clone(i.w.config.series)), this.update();
        } }, { key: "update", value: function(e) {
          var t = this;
          return new Promise(function(i, a) {
            new Gi(t.ctx).clear({ isUpdating: !0 });
            var s = t.create(t.w.config.series, e);
            if (!s)
              return i(t);
            t.mount(s).then(function() {
              typeof t.w.config.chart.events.updated == "function" && t.w.config.chart.events.updated(t, t.w), t.events.fireEvent("updated", [t, t.w]), t.w.globals.isDirty = !0, i(t);
            }).catch(function(r) {
              a(r);
            });
          });
        } }, { key: "getSyncedCharts", value: function() {
          var e = this.getGroupedCharts(), t = [this];
          return e.length && (t = [], e.forEach(function(i) {
            t.push(i);
          })), t;
        } }, { key: "getGroupedCharts", value: function() {
          var e = this;
          return Apex._chartInstances.filter(function(t) {
            if (t.group)
              return !0;
          }).map(function(t) {
            return e.w.config.chart.group === t.group ? t.chart : e;
          });
        } }, { key: "toggleSeries", value: function(e) {
          return this.series.toggleSeries(e);
        } }, { key: "highlightSeriesOnLegendHover", value: function(e, t) {
          return this.series.toggleSeriesOnHover(e, t);
        } }, { key: "showSeries", value: function(e) {
          this.series.showSeries(e);
        } }, { key: "hideSeries", value: function(e) {
          this.series.hideSeries(e);
        } }, { key: "isSeriesHidden", value: function(e) {
          this.series.isSeriesHidden(e);
        } }, { key: "resetSeries", value: function() {
          var e = !(arguments.length > 0 && arguments[0] !== void 0) || arguments[0], t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1];
          this.series.resetSeries(e, t);
        } }, { key: "addEventListener", value: function(e, t) {
          this.events.addEventListener(e, t);
        } }, { key: "removeEventListener", value: function(e, t) {
          this.events.removeEventListener(e, t);
        } }, { key: "addXaxisAnnotation", value: function(e) {
          var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0, a = this;
          i && (a = i), a.annotations.addXaxisAnnotationExternal(e, t, a);
        } }, { key: "addYaxisAnnotation", value: function(e) {
          var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0, a = this;
          i && (a = i), a.annotations.addYaxisAnnotationExternal(e, t, a);
        } }, { key: "addPointAnnotation", value: function(e) {
          var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0, a = this;
          i && (a = i), a.annotations.addPointAnnotationExternal(e, t, a);
        } }, { key: "clearAnnotations", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : void 0, t = this;
          e && (t = e), t.annotations.clearAnnotations(t);
        } }, { key: "removeAnnotation", value: function(e) {
          var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : void 0, i = this;
          t && (i = t), i.annotations.removeAnnotation(i, e);
        } }, { key: "getChartArea", value: function() {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner");
        } }, { key: "getSeriesTotalXRange", value: function(e, t) {
          return this.coreUtils.getSeriesTotalsXRange(e, t);
        } }, { key: "getHighestValueInSeries", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
          return new De(this.ctx).getMinYMaxY(e).highestY;
        } }, { key: "getLowestValueInSeries", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
          return new De(this.ctx).getMinYMaxY(e).lowestY;
        } }, { key: "getSeriesTotal", value: function() {
          return this.w.globals.seriesTotals;
        } }, { key: "toggleDataPointSelection", value: function(e, t) {
          return this.updateHelpers.toggleDataPointSelection(e, t);
        } }, { key: "zoomX", value: function(e, t) {
          this.ctx.toolbar.zoomUpdateOptions(e, t);
        } }, { key: "setLocale", value: function(e) {
          this.localization.setCurrentLocaleValues(e);
        } }, { key: "dataURI", value: function(e) {
          return new Se(this.ctx).dataURI(e);
        } }, { key: "exportToCSV", value: function() {
          var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          return new Se(this.ctx).exportToCSV(e);
        } }, { key: "paper", value: function() {
          return this.w.globals.dom.Paper;
        } }, { key: "_parentResizeCallback", value: function() {
          this.w.globals.animationEnded && this.w.config.chart.redrawOnParentResize && this._windowResize();
        } }, { key: "_windowResize", value: function() {
          var e = this;
          clearTimeout(this.w.globals.resizeTimer), this.w.globals.resizeTimer = window.setTimeout(function() {
            e.w.globals.resized = !0, e.w.globals.dataChanged = !1, e.ctx.update();
          }, 150);
        } }, { key: "_windowResizeHandler", value: function() {
          var e = this.w.config.chart.redrawOnWindowResize;
          typeof e == "function" && (e = e()), e && this._windowResize();
        } }], [{ key: "getChartByID", value: function(e) {
          var t = M.escapeString(e);
          if (Apex._chartInstances) {
            var i = Apex._chartInstances.filter(function(a) {
              return a.id === t;
            })[0];
            return i && i.chart;
          }
        } }, { key: "initOnLoad", value: function() {
          for (var e = document.querySelectorAll("[data-apexcharts]"), t = 0; t < e.length; t++)
            new P(e[t], JSON.parse(e[t].getAttribute("data-options"))).render();
        } }, { key: "exec", value: function(e, t) {
          var i = this.getChartByID(e);
          if (i) {
            i.w.globals.isExecCalled = !0;
            var a = null;
            if (i.publicMethods.indexOf(t) !== -1) {
              for (var s = arguments.length, r = new Array(s > 2 ? s - 2 : 0), o = 2; o < s; o++)
                r[o - 2] = arguments[o];
              a = i[t].apply(i, r);
            }
            return a;
          }
        } }, { key: "merge", value: function(e, t) {
          return M.extend(e, t);
        } }]), P;
      }();
      return Ps;
    });
  }(Ht, Ht.exports)), Ht.exports;
}
(function(v, n) {
  (function(l, u) {
    v.exports = u($n());
  })(Kt, function(l) {
    l = l && l.hasOwnProperty("default") ? l.default : l;
    function u(A) {
      return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? u = function(T) {
        return typeof T;
      } : u = function(T) {
        return T && typeof Symbol == "function" && T.constructor === Symbol && T !== Symbol.prototype ? "symbol" : typeof T;
      }, u(A);
    }
    function b(A, T, z) {
      return T in A ? Object.defineProperty(A, T, {
        value: z,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : A[T] = z, A;
    }
    var y = {
      props: {
        options: {
          type: Object
        },
        type: {
          type: String
        },
        series: {
          type: Array,
          required: !0,
          default: function() {
            return [];
          }
        },
        width: {
          default: "100%"
        },
        height: {
          default: "auto"
        }
      },
      data: function() {
        return {
          chart: null
        };
      },
      beforeMount: function() {
        window.ApexCharts = l;
      },
      mounted: function() {
        this.init();
      },
      created: function() {
        var T = this;
        this.$watch("options", function(H) {
          !T.chart && H ? T.init() : T.chart.updateOptions(T.options);
        }), this.$watch("series", function(H) {
          !T.chart && H ? T.init() : T.chart.updateSeries(T.series);
        });
        var z = ["type", "width", "height"];
        z.forEach(function(H) {
          T.$watch(H, function() {
            T.refresh();
          });
        });
      },
      beforeDestroy: function() {
        this.chart && this.destroy();
      },
      render: function(T) {
        return T("div");
      },
      methods: {
        init: function() {
          var T = this, z = {
            chart: {
              type: this.type || this.options.chart.type || "line",
              height: this.height,
              width: this.width,
              events: {}
            },
            series: this.series
          };
          Object.keys(this.$listeners).forEach(function(F) {
            z.chart.events[F] = T.$listeners[F];
          });
          var H = this.extend(this.options, z);
          return this.chart = new l(this.$el, H), this.chart.render();
        },
        isObject: function(T) {
          return T && u(T) === "object" && !Array.isArray(T) && T != null;
        },
        extend: function(T, z) {
          var H = this;
          typeof Object.assign != "function" && function() {
            Object.assign = function(D) {
              if (D == null)
                throw new TypeError("Cannot convert undefined or null to object");
              for (var W = Object(D), B = 1; B < arguments.length; B++) {
                var j = arguments[B];
                if (j != null)
                  for (var ee in j)
                    j.hasOwnProperty(ee) && (W[ee] = j[ee]);
              }
              return W;
            };
          }();
          var F = Object.assign({}, T);
          return this.isObject(T) && this.isObject(z) && Object.keys(z).forEach(function(D) {
            H.isObject(z[D]) ? D in T ? F[D] = H.extend(T[D], z[D]) : Object.assign(F, b({}, D, z[D])) : Object.assign(F, b({}, D, z[D]));
          }), F;
        },
        refresh: function() {
          return this.destroy(), this.init();
        },
        destroy: function() {
          this.chart.destroy();
        },
        updateSeries: function(T, z) {
          return this.chart.updateSeries(T, z);
        },
        updateOptions: function(T, z, H, F) {
          return this.chart.updateOptions(T, z, H, F);
        },
        toggleSeries: function(T) {
          return this.chart.toggleSeries(T);
        },
        showSeries: function(T) {
          this.chart.showSeries(T);
        },
        hideSeries: function(T) {
          this.chart.hideSeries(T);
        },
        appendSeries: function(T, z) {
          return this.chart.appendSeries(T, z);
        },
        resetSeries: function() {
          this.chart.resetSeries();
        },
        zoomX: function(T, z) {
          this.chart.zoomX(T, z);
        },
        toggleDataPointSelection: function(T, z) {
          this.chart.toggleDataPointSelection(T, z);
        },
        appendData: function(T) {
          return this.chart.appendData(T);
        },
        addText: function(T) {
          this.chart.addText(T);
        },
        addImage: function(T) {
          this.chart.addImage(T);
        },
        addShape: function(T) {
          this.chart.addShape(T);
        },
        dataURI: function() {
          return this.chart.dataURI();
        },
        setLocale: function(T) {
          return this.chart.setLocale(T);
        },
        addXaxisAnnotation: function(T, z) {
          this.chart.addXaxisAnnotation(T, z);
        },
        addYaxisAnnotation: function(T, z) {
          this.chart.addYaxisAnnotation(T, z);
        },
        addPointAnnotation: function(T, z) {
          this.chart.addPointAnnotation(T, z);
        },
        removeAnnotation: function(T, z) {
          this.chart.removeAnnotation(T, z);
        },
        clearAnnotations: function() {
          this.chart.clearAnnotations();
        }
      }
    }, I = y;
    return window.ApexCharts = l, I.install = function(A) {
      A.ApexCharts = l, window.ApexCharts = l, Object.defineProperty(A.prototype, "$apexcharts", {
        get: function() {
          return l;
        }
      });
    }, I;
  });
})(as);
var qn = as.exports;
const ss = /* @__PURE__ */ Ii(qn), Un = ft({
  name: "CoTwoResult",
  components: {
    VcsLabel: gt,
    VcsButton: Ut,
    VDialog: _t,
    VueApexCharts: ss,
    VContainer: mt,
    VCard: Ot,
    VIcon: Pt,
    VRow: pt,
    VCol: xt,
    VDivider: Mi,
    VcsFormattedNumber: Rt
  },
  props: {
    coTwoSavings: {
      type: Map,
      required: !0
    },
    coTwoCosts: {
      type: Map,
      required: !0
    },
    chartTheme: {
      type: String,
      required: !0
    },
    hasSelectedModules: {
      type: Boolean,
      required: !0
    },
    germanPowerMixYear: {
      type: Number,
      required: !0
    }
  },
  setup(v) {
    var W;
    const n = Zt("vcsApp"), l = (W = Pi()) == null ? void 0 : W.proxy, u = Pe(!1), b = Pe(Fe("primary")), y = Pe(Fe("base", "darken1")), I = Pe(Fe("base", "lighten4")), A = n.themeChanged.addEventListener(() => {
      b.value = Fe("primary"), I.value = Fe("base", "lighten4"), y.value = Fe("base", "darken1");
    }), T = be(() => v.coTwoCosts.size ? [...v.coTwoCosts.values()].reduce(
      (B, j) => B + j
    ) : 0), z = be(() => v.coTwoSavings.size ? [...v.coTwoSavings.values()].reduce(
      (B, j) => B + j
    ) : 0), H = be(() => {
      let B = 0;
      return v.coTwoSavings.forEach((j, ee) => {
        const te = v.coTwoCosts.get(ee) || 0;
        te !== 0 && j !== 0 && (B = ee + te / (te + j) - 1);
      }), B;
    }), F = be(() => ({
      chart: {
        id: "coTwoChart",
        stacked: !0,
        background: "rgba(0, 0, 0, 0)",
        toolbar: {
          tools: {
            download: Ci
          }
        }
      },
      dataLabels: {
        enabled: !1
      },
      plotOptions: {
        bar: {
          borderRadius: 1,
          horizontal: !0
        }
      },
      colors: [y.value, b.value],
      xaxis: {
        categories: [...v.coTwoSavings.keys()],
        labels: {
          formatter(B) {
            return `${B} kg`;
          }
        }
      },
      yaxis: {
        labels: {
          formatter(B) {
            return `${B}. ${l == null ? void 0 : l.$t("solarRevenue.cotwo.chart.yUnit").toString()}`;
          }
        }
      },
      tooltip: {
        y: {
          formatter(B) {
            return `${B} kg`;
          }
        }
      },
      theme: {
        mode: v.chartTheme
      },
      grid: {
        show: !1
      },
      legend: {
        position: "top",
        horizontalAlign: "left",
        labels: {
          useSeriesColors: !0
        }
      },
      stroke: {
        show: !0,
        width: 1,
        colors: [I.value]
      }
    })), D = be(() => [
      {
        name: l == null ? void 0 : l.$t("solarRevenue.cotwo.chart.seriesEmission"),
        data: [...v.coTwoCosts.values()].map((B) => B | 0).map(Math.abs)
      },
      {
        name: l == null ? void 0 : l.$t("solarRevenue.cotwo.chart.seriesSavings"),
        data: [...v.coTwoSavings.values()].map((B) => B | 0).map(Math.abs)
      }
    ]);
    return Da(() => {
      A();
    }), {
      dialog: u,
      options: F,
      series: D,
      amortization: H,
      totalCoTwoSavings: z,
      totalCoTwoEmission: T
    };
  }
});
var Zn = function() {
  var n = this, l = n._self._c;
  return n._self._setupProxy, l("v-dialog", { attrs: { width: "600px" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: u }) {
    return [l("VcsButton", n._g({ attrs: { icon: "mdi-open-in-new", disabled: !n.hasSelectedModules } }, u))];
  } }]), model: { value: n.dialog, callback: function(u) {
    n.dialog = u;
  }, expression: "dialog" } }, [l("v-card", [l("v-container", { staticClass: "px-5 py-1" }, [l("h3", { staticClass: "d-flex align-center px-0 py-3" }, [l("v-icon", { staticClass: "mr-1 text--primary", attrs: { size: "16" } }, [n._v("mdi-molecule-co2")]), l("span", { staticClass: "d-inline-block user-select-none font-weight-bold text--primary" }, [n._v(" " + n._s(n.$t("solarRevenue.cotwo.title")) + " ")])], 1), n.coTwoSavings.size > 0 ? l("VueApexCharts", { key: n.chartTheme, attrs: { type: "bar", options: n.options, series: n.series, height: "500" } }) : n._e(), l("v-divider"), l("v-row", { staticClass: "px-0 py-0 font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-start" }, [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.cotwo.totalEmission")))])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("VcsLabel", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.totalCoTwoEmission, unit: "kg", "fraction-digits": 0 } })], 1)], 1)], 1), l("v-row", { staticClass: "px-0 py-0 font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-start" }, [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.cotwo.totalSavings")))])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("VcsLabel", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.totalCoTwoSavings, unit: "kg", "fraction-digits": 0 } })], 1)], 1)], 1), l("v-divider"), l("v-row", { staticClass: "px-1 py-1", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "text-justify" }, [n._v(" " + n._s(n.$t("solarRevenue.cotwo.text1")) + " ")])], 1), n.amortization > 0 ? l("v-row", { staticClass: "px-1 py-1", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "text-justify d-flex justify-center font-weight-bold" }, [n._v(" " + n._s(n.$t("solarRevenue.cotwo.text2")) + " ")])], 1) : n._e(), n.amortization > 0 ? l("v-row", { staticClass: "px-1 py-1", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-center font-weight-bold text--primary" }, [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.amortization, unit: n.$t("solarRevenue.cotwo.unit").toString(), "fraction-digits": 2 } })], 1)], 1) : n._e(), n.amortization <= 0 ? l("v-row", { staticClass: "px-1 py-1", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "text-justify d-flex justify-center font-weight-bold" }, [n._v(" " + n._s(n.$t("solarRevenue.cotwo.text3")) + " ")])], 1) : n._e(), l("v-row", { staticClass: "px-1 pt-1 pb-3", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "text-justify" }, [n._v(" " + n._s(n.$t("solarRevenue.cotwo.text4", { germanPowerMixYear: n.germanPowerMixYear })) + " ")])], 1)], 1)], 1)], 1);
}, Jn = [], Kn = /* @__PURE__ */ vt(
  Un,
  Zn,
  Jn,
  !1,
  null,
  null,
  null,
  null
);
const Qn = Kn.exports, eo = ft({
  name: "ProfitabilityResult",
  components: {
    VcsLabel: gt,
    VcsSelect: Oa,
    VueApexCharts: ss,
    VcsButton: Ut,
    VRow: pt,
    VDialog: _t,
    VCard: Ot,
    VContainer: mt,
    VIcon: Pt,
    VCol: xt
  },
  props: {
    maintenanceCosts: {
      type: Map,
      required: !0
    },
    gridConsumptionPrice: {
      type: Map,
      required: !0
    },
    repaymentRate: {
      type: Map,
      required: !0
    },
    interestAmount: {
      type: Map,
      required: !0
    },
    directConsumptionPrice: {
      type: Map,
      required: !0
    },
    storageConsumptionPrice: {
      type: Map,
      required: !0
    },
    gridSupplyPrice: {
      type: Map,
      required: !0
    },
    chartTheme: {
      type: String,
      required: !0
    },
    liquidity: {
      type: Map,
      required: !0
    },
    isFinance: {
      type: Boolean,
      required: !0
    },
    hasSelectedModules: {
      type: Boolean,
      required: !0
    },
    lifeTime: {
      type: Number,
      required: !0
    }
  },
  setup(v) {
    var X;
    const n = Zt("vcsApp"), l = (X = Pi()) == null ? void 0 : X.proxy, u = Pe(!1), b = be(() => [
      { value: "revenue", text: l == null ? void 0 : l.$t("solarRevenue.prof.type.revenue") },
      {
        value: "liquidity",
        text: l == null ? void 0 : l.$t("solarRevenue.prof.type.liquidity")
      }
    ]), y = Pe("revenue"), I = Pe(Fe("primary")), A = Pe(Fe("primary", "lighten1")), T = Pe(Fe("primary", "darken1")), z = Pe(Fe("primary", "darken2")), H = Pe(Fe("base", "lighten4")), F = Pe(Fe("base", "darken1")), D = Pe(Fe("base", "darken2")), W = Pe(Fe("base", "darken3")), B = Pe(Fe("base", "darken4")), j = n.themeChanged.addEventListener(() => {
      I.value = Fe("primary"), A.value = Fe("primary", "lighten1"), T.value = Fe("primary", "darken1"), z.value = Fe("primary", "darken2"), H.value = Fe("base", "lighten4"), F.value = Fe("base", "darken1"), D.value = Fe("base", "darken2"), W.value = Fe("base", "darken3"), B.value = Fe("base", "darken4");
    }), ee = be(() => [
      {
        name: l == null ? void 0 : l.$t("solarRevenue.prof.chart.liquidity.series"),
        data: [...v.liquidity.values()].map(($) => $ | 0)
      }
    ]), te = be(() => {
      const $ = [
        {
          name: l == null ? void 0 : l.$t("solarRevenue.prof.chart.plan.maintenanceCosts"),
          group: "expenses",
          data: [...v.maintenanceCosts.values()].map((ie) => ie | 0).map(Math.abs)
        },
        {
          name: l == null ? void 0 : l.$t("solarRevenue.prof.chart.plan.gridConsumptionPrice"),
          group: "expenses",
          data: [...v.gridConsumptionPrice.values()].map((ie) => ie | 0).map(Math.abs)
        }
      ], K = [
        {
          name: l == null ? void 0 : l.$t("solarRevenue.prof.chart.plan.repaymentRate"),
          group: "expenses",
          data: [...v.repaymentRate.values()].map((ie) => ie | 0).map(Math.abs),
          color: W.value
        },
        {
          name: l == null ? void 0 : l.$t("solarRevenue.prof.chart.plan.interestAmount"),
          group: "expenses",
          data: [...v.interestAmount.values()].map((ie) => ie | 0).map(Math.abs)
        }
      ], J = [
        {
          name: l == null ? void 0 : l.$t("solarRevenue.prof.chart.plan.directConsumptionPrice"),
          group: "income",
          data: [...v.directConsumptionPrice.values()].map((ie) => ie | 0).map(Math.abs)
        },
        {
          name: l == null ? void 0 : l.$t(
            "solarRevenue.prof.chart.plan.storageConsumptionPrice"
          ),
          group: "income",
          data: [...v.storageConsumptionPrice.values()].map((ie) => ie | 0).map(Math.abs)
        },
        {
          name: l == null ? void 0 : l.$t("solarRevenue.prof.chart.plan.gridSupplyPrice"),
          group: "income",
          data: [...v.gridSupplyPrice.values()].map((ie) => ie | 0).map(Math.abs)
        }
      ];
      return v.isFinance ? [...$, ...K, ...J] : [...$, ...J];
    }), M = be(() => ({
      chart: {
        id: "liquidity",
        background: "rgba(0, 0, 0, 0)",
        toolbar: {
          tools: {
            download: Ci
          }
        }
      },
      dataLabels: {
        enabled: !1
      },
      plotOptions: {
        bar: {
          borderRadius: 1,
          horizontal: !0
        }
      },
      colors: [
        function({ value: K }) {
          return K < 0 ? F.value : I.value;
        }
      ],
      xaxis: {
        categories: [...v.liquidity.keys()],
        labels: {
          formatter($) {
            return `${$} €`;
          }
        }
      },
      yaxis: {
        labels: {
          formatter($) {
            return `${$}. ${l == null ? void 0 : l.$t("solarRevenue.prof.chart.yUnit").toString()}`;
          }
        }
      },
      tooltip: {
        y: {
          formatter($) {
            return `${$} €`;
          }
        }
      },
      theme: {
        mode: v.chartTheme
      },
      grid: {
        show: !1
      },
      legend: {
        position: "top",
        horizontalAlign: "left",
        labels: {
          useSeriesColors: !0
        }
      },
      stroke: {
        show: !0,
        width: 1,
        colors: [H.value]
      }
    })), V = be(() => {
      const $ = [F.value, D.value], K = [W.value, B.value], J = [
        A.value,
        T.value,
        z.value
      ];
      return v.isFinance ? [...$, ...K, ...J] : [...$, ...J];
    }), G = be(() => ({
      chart: {
        id: "revenueChart",
        stacked: !0,
        background: "rgba(0, 0, 0, 0)",
        toolbar: {
          tools: {
            download: Ci
          }
        }
      },
      dataLabels: {
        enabled: !1
      },
      plotOptions: {
        bar: {
          borderRadius: 1,
          horizontal: !0
        }
      },
      colors: V.value,
      xaxis: {
        categories: [...v.directConsumptionPrice.keys()],
        labels: {
          formatter($) {
            return `${$} €`;
          }
        }
      },
      yaxis: {
        labels: {
          formatter($) {
            return `${$}. ${l == null ? void 0 : l.$t("solarRevenue.prof.chart.yUnit").toString()}`;
          }
        }
      },
      tooltip: {
        y: {
          formatter($) {
            return `${$} €`;
          }
        }
      },
      theme: {
        mode: v.chartTheme
      },
      grid: {
        show: !1
      },
      legend: {
        position: "top",
        horizontalAlign: "left",
        labels: {
          useSeriesColors: !0
        }
      },
      stroke: {
        show: !0,
        width: 1,
        colors: [H.value]
      }
    }));
    return Da(() => {
      j();
    }), {
      dialog: u,
      options: G,
      series: te,
      liquidityOptions: M,
      liquiditySeries: ee,
      chartTypes: b,
      selectedChartType: y
    };
  }
});
var to = function() {
  var n = this, l = n._self._c;
  return n._self._setupProxy, l("v-dialog", { attrs: { width: "700px" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: u }) {
    return [l("VcsButton", n._g({ attrs: { icon: "mdi-open-in-new", disabled: !n.hasSelectedModules } }, u))];
  } }]), model: { value: n.dialog, callback: function(u) {
    n.dialog = u;
  }, expression: "dialog" } }, [l("v-card", [l("v-container", { staticClass: "px-5 py-1" }, [l("h3", { staticClass: "d-flex align-center px-0 py-3" }, [l("v-icon", { staticClass: "mr-1 text--primary", attrs: { size: "16" } }, [n._v("mdi-finance")]), l("span", { staticClass: "d-inline-block user-select-none font-weight-bold text--primary" }, [n._v(" " + n._s(n.$t("solarRevenue.prof.title")) + " ")])], 1), l("v-row", [l("v-col", { staticClass: "d-flex justify-center" }, [l("v-card", { staticClass: "my-1 elevation-0 rounded-0 borderCard justify-center d-flex pa-1", attrs: { outlined: "", width: "600px" } }, [n._v(" " + n._s(n.$t("solarRevenue.prof.description", { lifeTime: n.lifeTime })) + " ")])], 1)], 1), l("v-row", { staticClass: "px-0 py-1 d-flex justify-center", attrs: { "no-gutters": "" } }, [l("v-col", { attrs: { cols: "5" } }, [l("VcsLabel", { staticClass: "font-weight-bold" }, [n._v(" " + n._s(n.$t("solarRevenue.prof.typeLabel")) + " ")])], 1), l("v-col", { attrs: { cols: "4" } }, [l("VcsSelect", { attrs: { id: "chartTypeRevenue", items: n.chartTypes }, model: { value: n.selectedChartType, callback: function(u) {
    n.selectedChartType = u;
  }, expression: "selectedChartType" } })], 1)], 1), n.selectedChartType === "revenue" ? l("VueApexCharts", { key: n.chartTheme && n.isFinance, attrs: { type: "bar", options: n.options, series: n.series, height: "600" } }) : n._e(), n.selectedChartType === "liquidity" ? l("VueApexCharts", { key: n.chartTheme, attrs: { type: "bar", options: n.liquidityOptions, series: n.liquiditySeries, height: "600" } }) : n._e()], 1)], 1)], 1);
}, io = [], ao = /* @__PURE__ */ vt(
  eo,
  to,
  io,
  !1,
  null,
  "e6655eec",
  null,
  null
);
const so = ao.exports, ro = [
  {
    text: "solarRevenue.finance.header.year",
    value: "year"
  },
  {
    text: "solarRevenue.finance.header.annuity",
    value: "annuity"
  },
  {
    text: "solarRevenue.finance.header.repaymentRate",
    value: "repaymentRate"
  },
  {
    text: "solarRevenue.finance.header.remainingDept",
    value: "remainingDept"
  },
  {
    text: "solarRevenue.finance.header.interestAmount",
    value: "interestAmount"
  }
], no = ft({
  name: "FinanceResult",
  components: {
    VcsLabel: gt,
    VcsButton: Ut,
    VRow: pt,
    VDialog: _t,
    VCard: Ot,
    VCol: xt,
    VcsDataTable: Ai,
    VContainer: mt,
    VIcon: Pt,
    VDivider: Mi,
    VcsFormattedNumber: Rt
  },
  props: {
    annuity: {
      type: Map,
      required: !0
    },
    remainingDept: {
      type: Map,
      required: !0
    },
    repaymentRate: {
      type: Map,
      required: !0
    },
    interestAmount: {
      type: Map,
      required: !0
    },
    isFinance: {
      type: Boolean,
      required: !0
    },
    creditAmount: {
      type: Number,
      required: !0
    },
    creditInterest: {
      type: Number,
      required: !0
    },
    creditPeriod: {
      type: Number,
      required: !0
    },
    hasSelectedModules: {
      type: Boolean,
      required: !0
    }
  },
  setup(v) {
    const n = Pe(!1), l = ro, u = be(() => {
      const y = [];
      return v.annuity.forEach((I, A) => {
        y.push({
          year: A,
          annuity: I,
          remainingDept: v.remainingDept.get(A) || 0,
          repaymentRate: v.repaymentRate.get(A) || 0,
          interestAmount: v.interestAmount.get(A) || 0
        });
      }), y;
    }), b = be(() => [...v.annuity.values()].reduce((y, I) => y + I));
    return {
      dialog: n,
      localFinance: u,
      headers: l,
      creditCosts: b
    };
  }
});
var oo = function() {
  var n = this, l = n._self._c;
  return n._self._setupProxy, l("v-dialog", { attrs: { width: "600px" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: u }) {
    return [l("VcsButton", n._g({ attrs: { icon: "mdi-open-in-new", disabled: !n.hasSelectedModules || !n.isFinance } }, u))];
  } }]), model: { value: n.dialog, callback: function(u) {
    n.dialog = u;
  }, expression: "dialog" } }, [l("v-card", [l("v-container", { staticClass: "px-5 py-1" }, [l("h3", { staticClass: "d-flex align-center px-0 py-3" }, [l("v-icon", { staticClass: "mr-1 text--primary", attrs: { size: "16" } }, [n._v("mdi-currency-eur")]), l("span", { staticClass: "d-inline-block user-select-none font-weight-bold text--primary" }, [n._v(" " + n._s(n.$t("solarRevenue.finance.title")) + " ")])], 1), l("v-row", { staticClass: "px-0 py-3", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-center" }, [l("v-card", { staticClass: "my-1 elevation-0 rounded-0 borderCard", attrs: { outlined: "", width: "400px" } }, [l("v-row", { staticClass: "align-center font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.finance.creditAmount")) + ":")])], 1), l("v-col", { attrs: { cols: "9" } }, [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.creditAmount, unit: "€", "fraction-digits": 2 } })], 1)], 1), l("v-row", { staticClass: "align-center font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.finance.creditInterest")) + ":")])], 1), l("v-col", { attrs: { cols: "9" } }, [l("VcsLabel", [n._v(" " + n._s(n.creditInterest) + " % ")])], 1)], 1), l("v-row", { staticClass: "align-center font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.finance.creditPeriod")) + ":")])], 1), l("v-col", { attrs: { cols: "9" } }, [n._v(" " + n._s(n.creditPeriod) + " " + n._s(n.$t("solarRevenue.finance.creditPeriodUnit")))])], 1)], 1)], 1)], 1), l("v-row", { staticClass: "px-0 py-3", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-center" }, [l("vcs-data-table", { staticClass: "elevation-0", attrs: { items: n.localFinance, "item-key": "year", "show-select": !1, "single-select": !1, "show-searchbar": !1, headers: n.headers }, scopedSlots: n._u([{ key: "item", fn: function({ item: u }) {
    return [l("tr", [l("td", [n._v(" " + n._s(u.year) + " ")]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.annuity, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.repaymentRate, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.remainingDept, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.interestAmount, unit: "€", "fraction-digits": 2 } })], 1)])];
  } }]), model: { value: n.localFinance, callback: function(u) {
    n.localFinance = u;
  }, expression: "localFinance" } })], 1)], 1), l("v-divider"), l("v-row", { staticClass: "px-0 pt-3 font-weight-bold", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-start" }, [l("VcsLabel", [n._v(n._s(n.$t("solarRevenue.finance.creditTotal")))])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("VcsLabel", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.creditCosts, unit: "€", "fraction-digits": 2 } })], 1)], 1)], 1), l("v-row", { staticClass: "px-0 py-3", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex text-justify" }, [n._v(" " + n._s(n.$t("solarRevenue.finance.text")))])], 1)], 1)], 1)], 1);
}, lo = [], co = /* @__PURE__ */ vt(
  no,
  oo,
  lo,
  !1,
  null,
  "524b6dc3",
  null,
  null
);
const ho = co.exports, uo = [
  {
    text: "solarRevenue.keydata.energyHeader.year",
    value: "year"
  },
  {
    text: "solarRevenue.keydata.energyHeader.solarPowerYield",
    value: "solarPowerYield",
    toolTip: "[kWh]"
  },
  {
    text: "solarRevenue.keydata.energyHeader.electricityDemand",
    value: "electricityDemand",
    toolTip: "[kWh]"
  },
  {
    text: "solarRevenue.keydata.energyHeader.storageLosses",
    value: "storageLosses",
    toolTip: "[kWh]"
  },
  {
    text: "solarRevenue.keydata.energyHeader.directConsumption",
    value: "directConsumption",
    toolTip: "[kWh]"
  },
  {
    text: "solarRevenue.keydata.energyHeader.storageConsumption",
    value: "storageConsumption",
    toolTip: "[kWh]"
  },
  {
    text: "solarRevenue.keydata.energyHeader.gridConsumption",
    value: "gridConsumption",
    toolTip: "[kWh]"
  },
  {
    text: "solarRevenue.keydata.energyHeader.gridSupply",
    value: "gridSupply",
    toolTip: "[kWh]"
  }
], go = [
  {
    text: "solarRevenue.keydata.environmentalBalanceHeader.year",
    value: "year"
  },
  {
    text: "solarRevenue.keydata.environmentalBalanceHeader.coTwoSavings",
    value: "coTwoSavings",
    toolTip: "[kg]"
  }
], fo = [
  {
    text: "solarRevenue.keydata.energyPriceHeader.year",
    value: "year"
  },
  {
    text: "solarRevenue.keydata.energyPriceHeader.maintenanceCosts",
    value: "maintenanceCosts",
    toolTip: "[€]"
  },
  {
    text: "solarRevenue.keydata.energyPriceHeader.gridConsumptionPrice",
    value: "gridConsumptionPrice",
    toolTip: "[€]"
  },
  {
    text: "solarRevenue.keydata.energyPriceHeader.directConsumptionPrice",
    value: "directConsumptionPrice",
    toolTip: "[€]"
  },
  {
    text: "solarRevenue.keydata.energyPriceHeader.storageConsumptionPrice",
    value: "storageConsumptionPrice",
    toolTip: "[€]"
  },
  {
    text: "solarRevenue.keydata.energyPriceHeader.gridSupplyPrice",
    value: "gridSupplyPrice",
    toolTip: "[€]"
  },
  {
    text: "solarRevenue.keydata.energyPriceHeader.liquidity",
    value: "liquidity",
    toolTip: "[€]"
  }
], po = ft({
  name: "KeyDataResult",
  methods: { sumValues: Za },
  components: {
    VcsButton: Ut,
    VRow: pt,
    VCol: xt,
    VDialog: _t,
    VCard: Ot,
    VSheet: Ya,
    VContainer: mt,
    VcsDataTable: Ai,
    VIcon: Pt,
    VTooltip: Na,
    VcsSelect: Oa,
    VcsLabel: gt,
    VcsFormattedNumber: Rt
  },
  props: {
    maintenanceCosts: {
      type: Map,
      required: !0
    },
    gridConsumptionPrice: {
      type: Map,
      required: !0
    },
    directConsumptionPrice: {
      type: Map,
      required: !0
    },
    storageConsumptionPrice: {
      type: Map,
      required: !0
    },
    gridSupplyPrice: {
      type: Map,
      required: !0
    },
    coTwoSavings: {
      type: Map,
      required: !0
    },
    solarPowerYield: {
      type: Map,
      required: !0
    },
    liquidity: {
      type: Map,
      required: !0
    },
    electricityDemand: {
      type: Map,
      required: !0
    },
    storageLosses: {
      type: Map,
      required: !0
    },
    directConsumption: {
      type: Map,
      required: !0
    },
    storageConsumption: {
      type: Map,
      required: !0
    },
    gridConsumption: {
      type: Map,
      required: !0
    },
    gridSupply: {
      type: Map,
      required: !0
    },
    hasSelectedModules: {
      type: Boolean,
      required: !0
    }
  },
  setup(v) {
    var F;
    const n = Pe(!1), l = (F = Pi()) == null ? void 0 : F.proxy, u = uo, b = fo, y = go, I = be(() => [
      { value: "energy", text: l == null ? void 0 : l.$t("solarRevenue.keydata.type.energy") },
      {
        value: "energyCosts",
        text: l == null ? void 0 : l.$t("solarRevenue.keydata.type.energyCosts")
      },
      {
        value: "environmentalBalance",
        text: l == null ? void 0 : l.$t("solarRevenue.keydata.type.environmentalBalance")
      }
    ]), A = Pe("energy"), T = be(() => {
      const D = [];
      return v.coTwoSavings.forEach((W, B) => {
        D.push({
          year: B,
          coTwoSavings: W
        });
      }), D;
    }), z = be(() => {
      const D = [];
      return v.solarPowerYield.forEach((W, B) => {
        D.push({
          year: B,
          solarPowerYield: W,
          electricityDemand: v.electricityDemand.get(B) || 0,
          storageLosses: v.storageLosses.get(B) || 0,
          directConsumption: v.directConsumption.get(B) || 0,
          storageConsumption: v.storageConsumption.get(B) || 0,
          gridConsumption: v.gridConsumption.get(B) || 0,
          gridSupply: v.gridSupply.get(B) || 0
        });
      }), D;
    }), H = be(() => {
      const D = [];
      return v.maintenanceCosts.forEach((W, B) => {
        D.push({
          year: B,
          maintenanceCosts: W,
          gridConsumptionPrice: v.gridConsumptionPrice.get(B) || 0,
          directConsumptionPrice: v.directConsumptionPrice.get(B) || 0,
          storageConsumptionPrice: v.storageConsumptionPrice.get(B) || 0,
          gridSupplyPrice: v.gridSupplyPrice.get(B) || 0,
          liquidity: v.liquidity.get(B) || 0
        });
      }), D;
    });
    return {
      dialog: n,
      localEnergyBalance: z,
      energyHeaders: u,
      selectedChartType: A,
      chartTypes: I,
      localEnergyPriceBalance: H,
      energyPriceHeaders: b,
      localEnvironmentalBalance: T,
      environmentalBalanceHeaders: y
    };
  }
});
var xo = function() {
  var n = this, l = n._self._c;
  return n._self._setupProxy, l("v-sheet", [l("v-row", { attrs: { "no-gutters": "" } }, [l("v-dialog", { attrs: { width: "1100px" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: u }) {
    return [l("VcsButton", n._g({ attrs: { icon: "mdi-open-in-new", disabled: !n.hasSelectedModules } }, u))];
  } }]), model: { value: n.dialog, callback: function(u) {
    n.dialog = u;
  }, expression: "dialog" } }, [l("v-card", [l("v-container", { staticClass: "px-5 py-1" }, [l("h3", { staticClass: "d-flex align-center px-0 py-3" }, [l("v-icon", { staticClass: "mr-1 text--primary", attrs: { size: "16" } }, [n._v("mdi-file-chart-outline")]), l("span", { staticClass: "d-inline-block user-select-none font-weight-bold text--primary" }, [n._v(" " + n._s(n.$t("solarRevenue.keydata.title")) + " ")])], 1), l("v-row", [l("v-col", { staticClass: "d-flex justify-center" }, [l("v-card", { staticClass: "my-1 elevation-0 rounded-0 borderCard justify-center d-flex pa-1", attrs: { outlined: "", width: "700px" } }, [n._v(" " + n._s(n.$t("solarRevenue.keydata.description")) + " ")])], 1)], 1), l("v-row", { staticClass: "px-0 py-1 d-flex justify-center", attrs: { "no-gutters": "" } }, [l("v-col", { attrs: { cols: "3" } }, [l("VcsLabel", { staticClass: "font-weight-bold" }, [n._v(n._s(n.$t("solarRevenue.keydata.typeLabel")))])], 1), l("v-col", { attrs: { cols: "5" } }, [l("VcsSelect", { attrs: { id: "chartTypeEnergy", items: n.chartTypes }, model: { value: n.selectedChartType, callback: function(u) {
    n.selectedChartType = u;
  }, expression: "selectedChartType" } })], 1)], 1), l("v-row", { staticClass: "px-0 py-3", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-center" }, [n.selectedChartType === "environmentalBalance" ? l("vcs-data-table", { staticClass: "elevation-0", attrs: { items: n.localEnvironmentalBalance, "item-key": "year", "show-select": !1, "single-select": !1, "show-searchbar": !1, headers: n.environmentalBalanceHeaders }, scopedSlots: n._u([n._l(n.environmentalBalanceHeaders, function(u, b) {
    return { key: `header.${u.value}`, fn: function({ header: y }) {
      return [y.toolTip !== void 0 ? l("v-tooltip", { key: b, attrs: { bottom: "" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: I }) {
        return [l("span", n._g({}, I), [n._v(n._s(y.text))])];
      } }], null, !0) }, [l("span", [n._v(n._s(y.toolTip))])]) : l("span", { key: b }, [n._v(n._s(y.text))])];
    } };
  }), { key: "item", fn: function({ item: u }) {
    return [l("tr", [l("td", [n._v(n._s(u.year))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.coTwoSavings, unit: "kg", "fraction-digits": 0 } })], 1)])];
  } }, { key: "body.append", fn: function() {
    return [l("tr", { staticClass: "font-weight-bold text--primary" }, [l("td", [n._v(n._s(n.$t("solarRevenue.keydata.total") + " *"))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.coTwoSavings.values()]), unit: "kg", "fraction-digits": 0 } })], 1)])];
  }, proxy: !0 }], null, !0), model: { value: n.localEnvironmentalBalance, callback: function(u) {
    n.localEnvironmentalBalance = u;
  }, expression: "localEnvironmentalBalance" } }) : n._e(), n.selectedChartType === "energy" ? l("vcs-data-table", { staticClass: "elevation-0", attrs: { items: n.localEnergyBalance, "item-key": "year", "show-select": !1, "single-select": !1, "show-searchbar": !1, headers: n.energyHeaders }, scopedSlots: n._u([n._l(n.energyHeaders, function(u, b) {
    return { key: `header.${u.value}`, fn: function({ header: y }) {
      return [y.toolTip !== void 0 ? l("v-tooltip", { key: b, attrs: { bottom: "" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: I }) {
        return [l("span", n._g({}, I), [n._v(n._s(y.text))])];
      } }], null, !0) }, [l("span", [n._v(n._s(y.toolTip))])]) : l("span", { key: b }, [n._v(n._s(y.text))])];
    } };
  }), { key: "item", fn: function({ item: u }) {
    return [l("tr", [l("td", [n._v(n._s(u.year))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.solarPowerYield, unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.electricityDemand, unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.storageLosses, unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.directConsumption, unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.storageConsumption, unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.gridConsumption, unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.gridSupply, unit: "kWh", "fraction-digits": 0 } })], 1)])];
  } }, { key: "body.append", fn: function() {
    return [l("tr", { staticClass: "font-weight-bold text--primary" }, [l("td", [n._v(n._s(n.$t("solarRevenue.keydata.total") + " *"))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.solarPowerYield.values()]), unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.electricityDemand.values()]), unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.storageLosses.values()]), unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.directConsumption.values()]), unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.storageConsumption.values()]), unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.gridConsumption.values()]), unit: "kWh", "fraction-digits": 0 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.gridSupply.values()]), unit: "kWh", "fraction-digits": 0 } })], 1)])];
  }, proxy: !0 }], null, !0), model: { value: n.localEnergyBalance, callback: function(u) {
    n.localEnergyBalance = u;
  }, expression: "localEnergyBalance" } }) : n._e(), n.selectedChartType === "energyCosts" ? l("vcs-data-table", { staticClass: "elevation-0", attrs: { items: n.localEnergyPriceBalance, "item-key": "year", "show-select": !1, "single-select": !1, "show-searchbar": !1, headers: n.energyPriceHeaders }, scopedSlots: n._u([n._l(n.energyPriceHeaders, function(u, b) {
    return { key: `header.${u.value}`, fn: function({ header: y }) {
      return [y.toolTip !== void 0 ? l("v-tooltip", { key: b, attrs: { bottom: "" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: I }) {
        return [l("span", n._g({}, I), [n._v(n._s(y.text))])];
      } }], null, !0) }, [l("span", [n._v(n._s(y.toolTip))])]) : l("span", { key: b }, [n._v(n._s(y.text))])];
    } };
  }), { key: "item", fn: function({ item: u }) {
    return [l("tr", [l("td", [n._v(n._s(u.year))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.maintenanceCosts, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.gridConsumptionPrice, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.directConsumptionPrice, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.storageConsumptionPrice, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.gridSupplyPrice, unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.liquidity, unit: "€", "fraction-digits": 2 } })], 1)])];
  } }, { key: "body.append", fn: function() {
    return [l("tr", { staticClass: "font-weight-bold text--primary" }, [l("td", [n._v(n._s(n.$t("solarRevenue.keydata.total") + " *"))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.maintenanceCosts.values()]), unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.gridConsumptionPrice.values()]), unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.directConsumptionPrice.values()]), unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.storageConsumptionPrice.values()]), unit: "€", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues([...n.gridSupplyPrice.values()]), unit: "€", "fraction-digits": 2 } })], 1), l("td")])];
  }, proxy: !0 }], null, !0), model: { value: n.localEnergyPriceBalance, callback: function(u) {
    n.localEnergyPriceBalance = u;
  }, expression: "localEnergyPriceBalance" } }) : n._e()], 1)], 1), l("v-row", { staticClass: "px-0 py-1", attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "d-flex justify-center" }, [l("VcsLabel", { staticClass: "font-weight-bold" }, [n._v(" " + n._s(n.$t("solarRevenue.keydata.hint")) + " ")]), l("VcsLabel", [n._v(" " + n._s(n.$t("solarRevenue.keydata.hintText")) + " ")])], 1)], 1)], 1)], 1)], 1)], 1)], 1);
}, mo = [], vo = /* @__PURE__ */ vt(
  po,
  xo,
  mo,
  !1,
  null,
  "7c4bc481",
  null,
  null
);
const bo = vo.exports;
function yo(v, n, l, u) {
  return v * l / 100 * (1 - n.degradation / 100 * (u - 1));
}
function rs(v, n) {
  return v.solarIrradiation * (v.efficiency / 100) * (1 - v.degradation / 100 * (n - 1));
}
function wo(v, n, l) {
  return rs(v, n) * l;
}
function So(v, n) {
  return v.kwp * n;
}
function Co(v) {
  return v.costs * v.kwp;
}
function Ia(v, n, l, u) {
  return n * l / 100 * (1 - u / 100 * (v - 1));
}
class ko {
  constructor(n, l) {
    Ve(this, "_amortizationPeriod");
    Ve(this, "_config");
    Ve(this, "_selectedModules");
    this._config = l, this._selectedModules = n, this._amortizationPeriod = l.value.adminOptions.amortizationPeriod;
  }
  liquidity(n) {
    let l = 0;
    const u = this.gridSupplyPrice(n), b = this.directConsumptionPrice(), y = this.storageConsumptionPrice(n), I = this.maintenanceCosts(), A = this.gridConsumptionPrice(n), T = this.repaymentRate(n), z = this.annuity(n), H = /* @__PURE__ */ new Map();
    for (let F = 1; F <= this._amortizationPeriod; F++) {
      const D = (u.get(F) || 0) + (b.get(F) || 0) + (y.get(F) || 0), W = (I.get(F) || 0) + (A.get(F) || 0) + (T.get(F) || 0) + (z.get(F) || 0);
      H.set(F, l + D - W), l = D - W;
    }
    return H;
  }
  gridSupply(n) {
    const l = this.solarPowerYield(), u = this.directConsumption(), b = this.storageConsumption(n), y = /* @__PURE__ */ new Map();
    for (let I = 1; I <= this._amortizationPeriod; I++)
      y.set(
        I,
        (l.get(I) || 0) - (u.get(I) || 0) - (b.get(I) || 0)
      );
    return y;
  }
  gridConsumption(n) {
    const l = this.directConsumption(), u = this.storageConsumption(n), b = /* @__PURE__ */ new Map();
    for (let y = 1; y <= this._amortizationPeriod; y++)
      b.set(
        y,
        this._config.value.userOptions.electricityDemand - (l.get(y) || 0) - (u.get(y) || 0)
      );
    return b;
  }
  gridSupplyPrice(n) {
    const l = this.gridSupply(n), u = /* @__PURE__ */ new Map();
    for (let b = 1; b <= this._amortizationPeriod; b++)
      u.set(
        b,
        (l.get(b) || 0) * this._config.value.userOptions.feedInTariff
      );
    return u;
  }
  gridConsumptionPrice(n) {
    const l = this.gridConsumption(n), u = /* @__PURE__ */ new Map();
    for (let b = 1; b <= this._amortizationPeriod; b++) {
      const y = gi(
        (l.get(b) || 0) * this._config.value.userOptions.gridPurchaseCosts * (1 + this._config.value.userOptions.electricityPriceIncrease / 100) ** (b - 1)
      );
      u.set(b, y);
    }
    return u;
  }
  storageConsumptionPrice(n) {
    const l = this.storageConsumption(n), u = /* @__PURE__ */ new Map();
    for (let b = 1; b <= this._amortizationPeriod; b++) {
      const y = gi(
        (l.get(b) || 0) * this._config.value.userOptions.gridPurchaseCosts * (1 + this._config.value.userOptions.electricityPriceIncrease / 100) ** (b - 1)
      );
      u.set(b, y);
    }
    return u;
  }
  directConsumptionPrice() {
    const n = this.directConsumption(), l = /* @__PURE__ */ new Map();
    for (let u = 1; u <= this._amortizationPeriod; u++) {
      const b = gi(
        (n.get(u) || 0) * this._config.value.userOptions.gridPurchaseCosts * (1 + this._config.value.userOptions.electricityPriceIncrease / 100) ** (u - 1)
      );
      l.set(u, b);
    }
    return l;
  }
  creditAmount() {
    return this.investmentCosts() - this._config.value.userOptions.equityCapital;
  }
  investmentCosts() {
    return this._selectedModules.value.length ? this._selectedModules.value.map((n) => Co(n)).reduce((n, l) => n + l) : 0;
  }
  maintenanceCosts() {
    const n = /* @__PURE__ */ new Map(), l = this.investmentCosts();
    for (let u = 1; u <= this._amortizationPeriod; u++)
      n.set(
        u,
        l * this._config.value.adminOptions.maintenancePortion / 100
      );
    return n;
  }
  solarPowerYield() {
    if (this._selectedModules.value.length) {
      const n = /* @__PURE__ */ new Map();
      for (let l = 1; l <= this._amortizationPeriod; l++)
        n.set(
          l,
          this._selectedModules.value.map((u) => rs(u, l)).reduce((u, b) => u + b)
        );
      return n;
    } else
      return /* @__PURE__ */ new Map();
  }
  costs() {
    return this._selectedModules.value.map((l) => So(
      l,
      this._config.value.adminOptions.solarManufacture
    )).reduce((l, u) => l + u);
  }
  savings(n) {
    return this._selectedModules.value.map(
      (u) => wo(
        u,
        n,
        this._config.value.adminOptions.germanPowerMix
      )
    ).reduce((u, b) => u + b);
  }
  coTwoCosts() {
    if (this._selectedModules.value.length) {
      const n = this.coTwoSavings(), l = /* @__PURE__ */ new Map();
      let u = this.costs();
      for (let b = 1; b <= this._amortizationPeriod; b++) {
        const y = this.savings(b);
        if (y <= u)
          l.set(b, y);
        else {
          const I = y - (n.get(b) || 0);
          l.set(b, I);
        }
        u = u - y <= 0 ? 0 : u - y;
      }
      return l;
    } else
      return /* @__PURE__ */ new Map();
  }
  coTwoSavings() {
    if (this._selectedModules.value.length) {
      const n = /* @__PURE__ */ new Map();
      let l = this.costs();
      for (let u = 1; u <= this._amortizationPeriod; u++) {
        const b = this.savings(u);
        b <= l ? n.set(u, 0) : n.set(u, b - l), l = l - b <= 0 ? 0 : l - b;
      }
      return n;
    } else
      return /* @__PURE__ */ new Map();
  }
  electricityDemand() {
    const n = /* @__PURE__ */ new Map();
    for (let l = 1; l <= this._amortizationPeriod; l++)
      n.set(
        l,
        this._config.value.userOptions.electricityDemand
      );
    return n;
  }
  storageLosses(n) {
    const l = /* @__PURE__ */ new Map();
    for (let u = 1; u <= this._amortizationPeriod; u++)
      l.set(
        u,
        n.isStorageConsumption ? Ia(
          u,
          this._config.value.userOptions.electricityDemand,
          this._config.value.userOptions.storageConsumptionPortion,
          this._config.value.adminOptions.storageDegradation
        ) * this._config.value.adminOptions.storageLosses / 100 : 0
      );
    return l;
  }
  storageConsumption(n) {
    const l = /* @__PURE__ */ new Map();
    for (let u = 1; u <= this._amortizationPeriod; u++)
      l.set(
        u,
        n.isStorageConsumption ? Ia(
          u,
          this._config.value.userOptions.electricityDemand,
          this._config.value.userOptions.storageConsumptionPortion,
          this._config.value.adminOptions.storageDegradation
        ) : 0
      );
    return l;
  }
  directConsumption() {
    if (this._selectedModules.value.length) {
      const n = /* @__PURE__ */ new Map();
      for (let l = 1; l <= this._amortizationPeriod; l++)
        n.set(
          l,
          this._selectedModules.value.map(
            (u) => yo(
              this._config.value.userOptions.electricityDemand,
              u,
              this._config.value.userOptions.directConsumptionPortion,
              l
            )
          ).reduce((u, b) => u + b)
        );
      return n;
    } else
      return /* @__PURE__ */ new Map();
  }
  annuity(n) {
    const l = /* @__PURE__ */ new Map(), u = this.creditAmount();
    for (let b = 1; b <= this._config.value.userOptions.creditPeriod; b++)
      l.set(
        b,
        n.isFinance ? u * (this._config.value.userOptions.creditInterest / 100 * (1 + this._config.value.userOptions.creditInterest / 100) ** this._config.value.userOptions.creditPeriod) / ((1 + this._config.value.userOptions.creditInterest / 100) ** this._config.value.userOptions.creditPeriod - 1) : 0
      );
    return l;
  }
  remainingDept(n) {
    const l = /* @__PURE__ */ new Map(), u = this.creditAmount();
    for (let b = 1; b <= this._config.value.userOptions.creditPeriod; b++)
      l.set(
        b,
        n.isFinance ? u * ((1 + this._config.value.userOptions.creditInterest / 100) ** this._config.value.userOptions.creditPeriod - (1 + this._config.value.userOptions.creditInterest / 100) ** b) / ((1 + this._config.value.userOptions.creditInterest / 100) ** this._config.value.userOptions.creditPeriod - 1) : 0
      );
    return l;
  }
  repaymentRate(n) {
    const l = /* @__PURE__ */ new Map(), u = this.creditAmount();
    for (let b = 1; b <= this._config.value.userOptions.creditPeriod; b++)
      l.set(
        b,
        n.isFinance ? u * (this._config.value.userOptions.creditInterest / 100 * (1 + this._config.value.userOptions.creditInterest / 100) ** (b - 1)) / ((1 + this._config.value.userOptions.creditInterest / 100) ** this._config.value.userOptions.creditPeriod - 1) : 0
      );
    return l;
  }
  interestAmount(n) {
    const l = /* @__PURE__ */ new Map(), u = this.creditAmount();
    for (let b = 1; b <= this._config.value.userOptions.creditPeriod; b++)
      l.set(
        b,
        n.isFinance ? u * (this._config.value.userOptions.creditInterest / 100 * ((1 + this._config.value.userOptions.creditInterest / 100) ** this._config.value.userOptions.creditPeriod - (1 + this._config.value.userOptions.creditInterest / 100) ** (b - 1))) / ((1 + this._config.value.userOptions.creditInterest / 100) ** this._config.value.userOptions.creditPeriod - 1) : 0
      );
    return l;
  }
}
class Ao {
  constructor(n) {
    Ve(this, "_revenueStrategy");
    this._revenueStrategy = n;
  }
  solarPowerYield(n) {
    return this._revenueStrategy.solarPowerYield(n);
  }
  coTwoSavings(n) {
    return this._revenueStrategy.coTwoSavings(n);
  }
  coTwoCosts(n) {
    return this._revenueStrategy.coTwoCosts(n);
  }
  electricityDemand(n) {
    return this._revenueStrategy.electricityDemand(n);
  }
  directConsumption(n) {
    return this._revenueStrategy.directConsumption(n);
  }
  investmentCosts(n) {
    return this._revenueStrategy.investmentCosts(n);
  }
  creditAmount(n) {
    return this._revenueStrategy.creditAmount(n);
  }
  gridPurchasePrice(n) {
    return this._revenueStrategy.gridConsumptionPrice(n);
  }
  annuity(n) {
    return this._revenueStrategy.annuity(n);
  }
  remainingDept(n) {
    return this._revenueStrategy.remainingDept(n);
  }
  repaymentRate(n) {
    return this._revenueStrategy.repaymentRate(n);
  }
  interestAmount(n) {
    return this._revenueStrategy.interestAmount(n);
  }
  storageLosses(n) {
    return this._revenueStrategy.storageLosses(n);
  }
  storageConsumption(n) {
    return this._revenueStrategy.storageConsumption(n);
  }
  gridConsumption(n) {
    return this._revenueStrategy.gridConsumption(n);
  }
  gridSupply(n) {
    return this._revenueStrategy.gridSupply(n);
  }
  gridSupplyPrice(n) {
    return this._revenueStrategy.gridSupplyPrice(n);
  }
  maintenanceCosts(n) {
    return this._revenueStrategy.maintenanceCosts(n);
  }
  gridConsumptionPrice(n) {
    return this._revenueStrategy.gridConsumptionPrice(n);
  }
  directConsumptionPrice(n) {
    return this._revenueStrategy.directConsumptionPrice(n);
  }
  storageConsumptionPrice(n) {
    return this._revenueStrategy.storageConsumptionPrice(n);
  }
  liquidity(n) {
    return this._revenueStrategy.liquidity(n);
  }
}
const Po = [
  {
    text: "solarRevenue.solarSelector.table.id",
    value: "featureId"
  },
  {
    text: "solarRevenue.solarSelector.table.area",
    value: "area",
    toolTip: "[m²]"
  },
  {
    text: "solarRevenue.solarSelector.table.yield",
    value: "solarIrradiation",
    toolTip: "[kWh/a]"
  },
  {
    text: "solarRevenue.solarSelector.table.calculated",
    sortable: !1,
    toolTip: "[%]"
  },
  {
    text: "solarRevenue.solarSelector.table.actions",
    value: "actions",
    sortable: !1
  }
], Lo = ft({
  name: "SolarSelector",
  methods: { sumValues: Za },
  components: {
    KeyDataResult: bo,
    FinanceResult: ho,
    ProfitabilityResult: so,
    CoTwoResult: Qn,
    SolarRevenue: jn,
    VContainer: mt,
    VIcon: Pt,
    VcsDataTable: Ai,
    VSheet: Ya,
    VcsFormSection: za,
    VcsLabel: gt,
    VRow: pt,
    VCol: xt,
    VcsActionButtonList: Rs,
    VTooltip: Na,
    VProgressLinear: js,
    VcsFormButton: Ra,
    VcsFormattedNumber: Rt
  },
  setup() {
    const v = Pe(Fe("primary")), n = Zt("vcsApp"), l = n.plugins.getByKey(At), { selectedModules: u } = l, { chartTheme: b } = l, { vcSolarInteraction: y } = l, I = Pe(
      JSON.parse(JSON.stringify(l.config))
    ), A = Pe("vcsolar"), T = Po, z = Pe(!0), H = Pe(!0), F = be(
      () => u.value.length > 0
    ), D = Pe(!1), W = new ko(
      u,
      I
    ), B = new Ao(W), j = async () => {
      D.value = !0;
      try {
        await is(
          u.value,
          n,
          I.value.globalSettings.isDebug
        );
      } catch {
        n.notifier.add({
          type: ki.WARNING,
          message: "solarRevenue.nasa"
        });
      }
      D.value = !1;
    }, ee = be(() => B.coTwoSavings()), te = be(() => B.coTwoCosts()), M = be(() => B.solarPowerYield()), V = be(() => B.directConsumptionPrice()), G = be(() => B.storageConsumptionPrice({
      isStorageConsumption: H.value
    })), X = be(() => B.storageLosses({
      isStorageConsumption: H.value
    })), $ = be(() => B.directConsumption()), K = be(() => B.storageConsumption({
      isStorageConsumption: H.value
    })), J = be(() => B.gridConsumption({
      isStorageConsumption: H.value
    })), ie = be(() => B.gridSupply({
      isStorageConsumption: H.value
    })), re = be(() => B.gridSupplyPrice({
      isStorageConsumption: H.value
    })), ne = be(() => B.electricityDemand()), ce = be(() => B.investmentCosts()), ge = be(() => B.creditAmount()), ue = be(() => B.annuity({ isFinance: z.value })), Le = be(() => B.remainingDept({ isFinance: z.value })), ke = be(() => B.repaymentRate({ isFinance: z.value })), Ae = be(() => B.interestAmount({ isFinance: z.value })), Me = be(() => B.maintenanceCosts()), Te = be(() => B.gridConsumptionPrice({
      isStorageConsumption: H.value
    })), oe = be(() => B.liquidity({
      isStorageConsumption: H.value,
      isFinance: z.value
    })), Q = [
      {
        name: "clearSelectedModules",
        icon: "mdi-home-remove-outline",
        title: "solarRevenue.solarSelector.selection",
        callback() {
          y == null || y.clear();
        }
      }
    ], ae = () => {
      I.value.userOptions.directConsumptionPortion + I.value.userOptions.storageConsumptionPortion > 100 && (I.value.userOptions.storageConsumptionPortion = 100 - I.value.userOptions.directConsumptionPortion);
    }, le = () => {
      I.value.userOptions.directConsumptionPortion + I.value.userOptions.storageConsumptionPortion > 100 && (I.value.userOptions.directConsumptionPortion = 100 - I.value.userOptions.storageConsumptionPortion);
    };
    return dt(
      () => I.value.userOptions.directConsumptionPortion,
      () => ae()
    ), dt(
      () => I.value.userOptions.storageConsumptionPortion,
      () => le()
    ), {
      primary: v,
      solarCalculationType: A,
      selectedModules: u,
      headers: T,
      tableHeaderActions: Q,
      solarContext: B,
      coTwoSavings: ee,
      coTwoCosts: te,
      electricityDemand: ne,
      solarOptions: I,
      investmentCosts: ce,
      creditAmount: ge,
      annuity: ue,
      remainingDept: Le,
      repaymentRate: ke,
      interestAmount: Ae,
      isFinance: z,
      solarPowerYield: M,
      storageConsumption: K,
      storageLosses: X,
      gridConsumption: J,
      gridSupply: ie,
      directConsumption: $,
      isStorageConsumption: H,
      maintenanceCosts: Me,
      gridConsumptionPrice: Te,
      directConsumptionPrice: V,
      storageConsumptionPrice: G,
      gridSupplyPrice: re,
      chartTheme: b,
      liquidity: oe,
      hasSelectedModules: F,
      calculateSolarIrradiation: j,
      calculateLoading: D
    };
  }
});
var Mo = function() {
  var n = this, l = n._self._c;
  return n._self._setupProxy, l("v-sheet", [l("VcsFormSection", { attrs: { heading: "solarRevenue.solarSelector.method", "start-open": "", expandable: "" }, scopedSlots: n._u([{ key: "default", fn: function() {
    return [l("v-container", [l("v-row", { staticClass: "pb-2", attrs: { "no-gutters": "" } }, [n.solarOptions.globalSettings.isVcSolar ? l("v-col", [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.helpMethod")) + " ")]) : n._e(), n.solarOptions.globalSettings.isVcSolar ? n._e() : l("v-col", [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.helpMethodArea")) + " ")])], 1), l("v-row", { attrs: { "no-gutters": "" } }, [n.solarOptions.globalSettings.isVcSolar ? l("v-col", { staticClass: "font-weight-bold", attrs: { cols: "4" } }, [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.selectArea")) + " ")]) : n._e(), n.solarOptions.globalSettings.isVcSolar ? l("v-col", [l("v-icon", [n._v("mdi-home-roof")])], 1) : n._e(), l("v-col", { staticClass: "font-weight-bold", attrs: { cols: "4" } }, [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.drawArea")) + " ")]), l("v-col", [l("v-icon", [n._v("mdi-view-grid-plus-outline")])], 1)], 1), l("v-row", { staticClass: "pt-2", attrs: { "no-gutters": "" } }, [n.solarOptions.globalSettings.isVcSolar ? l("v-col", [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.helpMethod2")) + " ")]) : n._e()], 1)], 1)];
  }, proxy: !0 }]) }), l("VcsFormSection", { attrs: { heading: "solarRevenue.solarSelector.modulesList", "header-actions": n.tableHeaderActions, "help-text": "solarRevenue.solarSelector.helpModulesList", "start-open": "", expandable: "" }, scopedSlots: n._u([{ key: "default", fn: function() {
    return [l("vcs-data-table", { attrs: { items: n.selectedModules, "item-key": "featureId", "show-select": !1, "single-select": !1, "show-searchbar": !1, headers: n.headers, "no-data-text": n.$t("solarRevenue.solarSelector.finance") }, scopedSlots: n._u([n._l(n.headers, function(u, b) {
      return { key: `header.${u.value}`, fn: function({ header: y }) {
        return [y.toolTip !== void 0 ? l("v-tooltip", { key: b, attrs: { bottom: "" }, scopedSlots: n._u([{ key: "activator", fn: function({ on: I }) {
          return [l("span", n._g({}, I), [n._v(n._s(y.text))])];
        } }], null, !0) }, [l("span", [n._v(n._s(y.toolTip))])]) : l("span", { key: b }, [n._v(n._s(y.text))])];
      } };
    }), { key: "item", fn: function({ item: u }) {
      return [l("tr", [l("td", [n._v(n._s(u.featureId))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.area, unit: "m²", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: u.solarIrradiation * u.efficiency / 100, unit: "kWh/a", "fraction-digits": 0 } })], 1), l("td", [l("v-progress-linear", { attrs: { color: "primary", height: "15" }, scopedSlots: n._u([{ key: "default", fn: function({ value: b }) {
        return [n._v(" " + n._s(Math.ceil(b)) + "% ")];
      } }], null, !0), model: { value: u.calculatedProgress.progress, callback: function(b) {
        n.$set(u.calculatedProgress, "progress", b);
      }, expression: "item.calculatedProgress.progress" } })], 1), l("td", [u.actions ? l("VcsActionButtonList", { attrs: { actions: u.actions, "block-overflow": !0, "overflow-count": 2 } }) : n._e()], 1)])];
    } }, { key: "body.append", fn: function() {
      return [l("tr", { staticClass: "font-weight-bold text--primary" }, [l("td", [n._v(n._s(n.$t("solarRevenue.solarSelector.total")))]), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues(n.selectedModules.map((u) => u.area)), unit: "m²", "fraction-digits": 2 } })], 1), l("td", [l("VcsFormattedNumber", { attrs: { id: "formattedNumber", value: n.sumValues(
        n.selectedModules.map(
          (u) => u.solarIrradiation * u.efficiency / 100
        )
      ), unit: "kWh/a", "fraction-digits": 0 } })], 1)])];
    }, proxy: !0 }], null, !0) })];
  }, proxy: !0 }]) }), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", { staticClass: "py-3 justify-center d-flex" }, [l("vcs-form-button", { attrs: { small: "", loading: n.calculateLoading }, on: { click: function(u) {
    return n.calculateSolarIrradiation();
  } } }, [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.calculate")) + " ")])], 1)], 1), l("VcsFormSection", { attrs: { heading: "solarRevenue.solarSelector.results", "help-text": "solarRevenue.solarSelector.helpResults", "start-open": "", expandable: "" }, scopedSlots: n._u([{ key: "default", fn: function() {
    return [l("v-container", [l("SolarRevenue", { attrs: { "is-storage-consumption": n.isStorageConsumption, "is-finance": n.isFinance, "solar-options": n.solarOptions, "credit-amount": n.creditAmount, "investment-costs": n.investmentCosts, "selected-modules": n.selectedModules }, on: { "update-solar-options": (u) => n.solarOptions = u, "update-isFinance": (u) => n.isFinance = u, "update-isStorageConsumption": (u) => n.isStorageConsumption = u } }), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { "html-for": "selectInput", dense: !0 } }, [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.revenueCalculation")))])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("ProfitabilityResult", { attrs: { "maintenance-costs": n.maintenanceCosts, "grid-consumption-price": n.gridConsumptionPrice, "repayment-rate": n.repaymentRate, "interest-amount": n.interestAmount, "grid-supply-price": n.gridSupplyPrice, "direct-consumption-price": n.directConsumptionPrice, "storage-consumption-price": n.storageConsumptionPrice, "chart-theme": n.chartTheme, liquidity: n.liquidity, "is-finance": n.isFinance, "has-selected-modules": n.hasSelectedModules, "life-time": n.solarOptions.adminOptions.amortizationPeriod } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { "html-for": "selectInput", dense: !0 } }, [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.finance")) + " ")])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("FinanceResult", { attrs: { "credit-amount": n.creditAmount, "credit-interest": n.solarOptions.userOptions.creditInterest, "credit-period": n.solarOptions.userOptions.creditPeriod, "is-finance": n.isFinance, annuity: n.annuity, "interest-amount": n.interestAmount, "remaining-dept": n.remainingDept, "repayment-rate": n.repaymentRate, "has-selected-modules": n.hasSelectedModules } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { "html-for": "selectInput", dense: !0 } }, [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.coTwoSavings")) + " ")])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("CoTwoResult", { attrs: { "chart-theme": n.chartTheme, "co-two-savings": n.coTwoSavings, "co-two-costs": n.coTwoCosts, "has-selected-modules": n.hasSelectedModules, "german-power-mix-year": n.solarOptions.adminOptions.germanPowerMixYear } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { "html-for": "selectInput", dense: !0 } }, [n._v(" " + n._s(n.$t("solarRevenue.solarSelector.keyData")) + " ")])], 1), l("v-col", { staticClass: "d-flex justify-end" }, [l("KeyDataResult", { attrs: { "co-two-savings": n.coTwoSavings, "solar-power-yield": n.solarPowerYield, "electricity-demand": n.electricityDemand, "storage-losses": n.storageLosses, "direct-consumption": n.directConsumption, "storage-consumption": n.storageConsumption, "grid-consumption": n.gridConsumption, "grid-supply": n.gridSupply, "has-selected-modules": n.hasSelectedModules, "maintenance-costs": n.maintenanceCosts, "grid-consumption-price": n.gridConsumptionPrice, "direct-consumption-price": n.directConsumptionPrice, "storage-consumption-price": n.storageConsumptionPrice, "grid-supply-price": n.gridSupplyPrice, liquidity: n.liquidity } })], 1)], 1)], 1)];
  }, proxy: !0 }]) })], 1);
}, Eo = [], Io = /* @__PURE__ */ vt(
  Lo,
  Mo,
  Eo,
  !1,
  null,
  "582a4321",
  null,
  null
);
const To = Io.exports;
function Ro(v) {
  const n = v.getProperty("attributes"), l = pn(
    n,
    ([b]) => b.includes("globalRadMonths")
  );
  return Object.values(l).reduce(
    (b, y) => b + y,
    0
  );
}
function ns(v, n) {
  return v * n;
}
class _o extends Xs {
  constructor(l, u, b, y) {
    super(Ys.CLICK);
    Ve(this, "_selectedModules");
    Ve(this, "_app");
    Ve(this, "_localFeatureTrack");
    Ve(this, "_vcSolarOptions");
    Ve(this, "_solarLayerName");
    this._vcSolarOptions = b, this._selectedModules = u || [], this._app = l, this._localFeatureTrack = [], this._solarLayerName = y, this.setActive(!0);
  }
  _highlightFeature(l) {
    var u;
    (u = this.solarLayer) == null || u.featureVisibility.highlight({
      [l.getId()]: new Ui({
        fill: { color: [0, 0, 0, 0.5] },
        stroke: { color: [0, 0, 255, 1], width: 100, lineDashOffset: 10 }
      })
    });
  }
  highlightFeatures() {
    this._selectedModules.value.forEach((l) => {
      var u;
      (u = this.solarLayer) == null || u.featureVisibility.highlight({
        [l.id]: new Ui({
          fill: { color: [0, 0, 0, 0.5] },
          stroke: { color: [0, 0, 255, 1], width: 100, lineDashOffset: 10 }
        })
      });
    });
  }
  _unHighLightFeatures() {
    this._selectedModules.value.forEach((l) => {
      var u;
      (u = this.solarLayer) == null || u.featureVisibility.unHighlight([l.id]);
    });
  }
  _removeFeature(l) {
    var u;
    this._selectedModules.value = this._selectedModules.value.filter(
      (b) => b.featureId !== l.featureId
    ), this._localFeatureTrack = this._localFeatureTrack.filter(
      (b) => b !== l.featureId
    ), (u = this.solarLayer) == null || u.featureVisibility.unHighlight([l.getId()]);
  }
  _selectFeature(l) {
    if (this._localFeatureTrack.indexOf(l.featureId) === -1) {
      const u = l.getProperty("attributes");
      if (u.solarArea) {
        const b = {
          id: l.getId(),
          featureId: l.featureId,
          area: u.solarArea || -9999,
          efficiency: this._vcSolarOptions.efficiency,
          costs: this._vcSolarOptions.costs,
          kwp: ns(this._vcSolarOptions.kwpPerArea, u.solarArea),
          solarIrradiation: Ro(l) || 0,
          degradation: this._vcSolarOptions.degradation,
          calculatedProgress: {
            numberCurrentRays: 0,
            numberTotalRays: 0,
            progress: 100
          },
          actions: [
            {
              name: "removeSolarModule",
              title: "solarRevenue.solarSelector.remove",
              icon: "$vcsTrashCan",
              callback: () => {
                this._removeFeature(l), this.highlightFeatures();
              }
            }
          ]
        };
        this._selectedModules.value.push(b), this._localFeatureTrack.push(l.featureId), this._highlightFeature(l);
      } else
        this._app.notifier.add({
          type: ki.INFO,
          message: "solarRevenue.solarSelector.noVCSolar"
        });
    } else
      this._removeFeature(l);
  }
  pipe(l) {
    return l.feature && l.feature instanceof Us && this._selectFeature(l.feature), Promise.resolve(l);
  }
  clear() {
    var l;
    this._unHighLightFeatures(), this._selectedModules.value = [], this._localFeatureTrack = [], (l = this._app.layers.getByKey("_solarAreaLayer")) == null || l.removeAllFeatures();
  }
  destroy() {
    super.destroy(), this.clear();
  }
  get solarLayer() {
    return this._app.layers.getByKey(
      this._solarLayerName
    );
  }
}
const It = "solar-selector";
function Oo(v) {
  const { action: n } = _s(
    {
      name: "solarRevenue.name",
      icon: "mdi-solar-power",
      title: "solarRevenue.tooltip"
    },
    {
      id: It,
      component: To,
      slot: Os.DYNAMIC_LEFT,
      state: {
        headerTitle: "solarRevenue.name"
      },
      position: {
        width: "430px",
        height: "800px"
      }
    },
    v.windowManager,
    At
  );
  return v.navbarManager.add(
    {
      id: "solarID",
      action: n
    },
    At,
    zs.TOOL
  ), v.maps.mapActivated.addEventListener(
    (u) => {
      u instanceof Xa ? n.disabled = !1 : (v.windowManager.has(It) && v.windowManager.remove(It), n.disabled = !0);
    }
  );
}
function zo(v, n, l, u) {
  let b, y = 1, I;
  const A = v.layers.getByKey("_solarAreaLayer") ? v.layers.getByKey("_solarAreaLayer") : new Zi({
    name: "_solarAreaLayer",
    projection: Ns.toJSON(),
    zIndex: Hs - 1,
    vectorProperties: {
      altitudeMode: "absolute"
    }
  });
  v.layers.add(A), Bs(A);
  const T = (D) => {
    D.code === "Escape" && A.getFeatures() && b !== void 0 && (I.finish(), A.removeFeaturesById([b]), n.value = n.value.filter(
      (W) => W.id !== b
    ));
  }, z = (D) => {
    b = D.getId();
  }, H = {
    name: "areaAction",
    title: "solarRevenue.solarSelector.drawArea",
    icon: "mdi-view-grid-plus-outline",
    active: !1,
    async callback() {
      this.active ? (I.stop(), window.removeEventListener("keydown", T), v.maps.eventHandler.featureInteraction.pullPickedPosition = 0, this.active = !1) : (A instanceof Zi && (await A.activate(), window.addEventListener("keydown", T), v.maps.eventHandler.featureInteraction.pullPickedPosition = 0.05, I = Ws(v, A, Vs.Polygon), I.featureCreated.addEventListener(z), I.stopped.addEventListener(() => {
        this.active = !1;
      }), I.creationFinished.addEventListener((D) => {
        if (D) {
          const W = Yn(D, v), B = {
            id: D.getId() || 0,
            featureId: y,
            area: W.solarArea,
            efficiency: l.efficiency,
            costs: l.costs,
            kwp: ns(
              l.kwpPerArea,
              W.solarArea
            ),
            solarIrradiation: W.globalRad,
            degradation: l.degradation,
            solarSurface: W,
            calculatedProgress: {
              numberTotalRays: 0,
              numberCurrentRays: 0,
              progress: 0
            },
            actions: [
              {
                name: "removeSolarModule",
                title: "solarRevenue.solarSelector.remove",
                icon: "$vcsTrashCan",
                callback: () => {
                  D.getId() && A.removeFeaturesById([
                    D.getId()
                  ]), n.value = n.value.filter(
                    (j) => j.id !== D.getId()
                  );
                }
              },
              {
                name: "calculateSolarModule",
                icon: "mdi-refresh-circle",
                title: "solarRevenue.solarSelector.recalculate",
                async callback() {
                  this.icon = "$vcsProgress", await ts(
                    B,
                    v,
                    u
                  ), this.icon = "mdi-refresh-circle";
                }
              }
            ]
          };
          n.value.push(B), y += 1;
        }
      })), this.active = !0);
    }
  };
  return v.toolboxManager.add(
    {
      id: "solarArea",
      type: Fa.SINGLE,
      action: H
    },
    At
  ), () => {
    I.stop(), v.layers.remove(A), window.removeEventListener("keydown", T);
  };
}
function Fo(v, n) {
  let l = () => {
  };
  const { eventHandler: u } = v.maps, b = {
    name: "vcSolarAction",
    title: "solarRevenue.solarSelector.selectArea",
    icon: "mdi-home-roof",
    active: !1,
    async callback() {
      this.active ? (l(), this.active = !1) : (v.featureInfo.clear(), n.setActive(!0), n.highlightFeatures(), l = u.addExclusiveInteraction(
        n,
        () => {
          this.active = !1;
        }
      ), this.active = !0, n.solarLayer && await n.solarLayer.activate());
    }
  };
  return v.toolboxManager.add(
    {
      id: "vcSolar",
      type: Fa.SINGLE,
      action: b
    },
    At
  ), () => {
    l();
  };
}
const Do = ft({
  name: "SolarConfigEditor",
  title: "Solar Editor",
  // heading displayed on editor window
  components: {
    VcsCheckbox: Ta,
    VRow: pt,
    VCol: xt,
    VContainer: mt,
    VcsLabel: gt,
    VcsFormSection: za,
    AbstractConfigEditor: Fs,
    VcsTextField: _a
  },
  props: {
    getConfig: {
      type: Function,
      required: !0
    },
    setConfig: {
      type: Function,
      required: !0
    }
  },
  setup(v) {
    const n = Pe(Et()), l = Et();
    return v.getConfig().then((u) => {
      n.value = fn(l, u);
    }).catch((u) => console.error(u)), {
      localConfig: n,
      async apply() {
        await v.setConfig(n.value);
      }
    };
  }
});
var Xo = function() {
  var n = this, l = n._self._c;
  return n._self._setupProxy, l("AbstractConfigEditor", n._b({ on: { submit: n.apply } }, "AbstractConfigEditor", { ...n.$attrs, ...n.$props }, !1), [l("VcsFormSection", { attrs: { heading: "admin options", expandable: "", "start-open": !0 } }, [l("v-container", { staticClass: "py-0 px-1" }, [l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.germanPowerMix")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "germanPowerMix", dense: "" }, model: { value: n.localConfig.adminOptions.germanPowerMix, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "germanPowerMix", n._n(u));
  }, expression: "localConfig.adminOptions.germanPowerMix" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.germanPowerMixYear")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "germanPowerMixYear", dense: "" }, model: { value: n.localConfig.adminOptions.germanPowerMixYear, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "germanPowerMixYear", n._n(u));
  }, expression: "localConfig.adminOptions.germanPowerMixYear" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.solarManufacture")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "solarManufacture", dense: "" }, model: { value: n.localConfig.adminOptions.solarManufacture, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "solarManufacture", n._n(u));
  }, expression: "localConfig.adminOptions.solarManufacture" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.electricityDemandPerPerson")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "electricityDemandPerPerson", dense: "" }, model: { value: n.localConfig.adminOptions.electricityDemandPerPerson, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "electricityDemandPerPerson", n._n(u));
  }, expression: `
              localConfig.adminOptions.electricityDemandPerPerson
            ` } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.electricityDemandHeatPump")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "electricityDemandHeatPump", dense: "" }, model: { value: n.localConfig.adminOptions.electricityDemandHeatPump, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "electricityDemandHeatPump", n._n(u));
  }, expression: `
              localConfig.adminOptions.electricityDemandHeatPump
            ` } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.electricityDemandCar")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "electricityDemandCar", dense: "" }, model: { value: n.localConfig.adminOptions.electricityDemandCar, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "electricityDemandCar", n._n(u));
  }, expression: "localConfig.adminOptions.electricityDemandCar" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.storageDegradation")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "storageDegradation", dense: "" }, model: { value: n.localConfig.adminOptions.storageDegradation, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "storageDegradation", n._n(u));
  }, expression: "localConfig.adminOptions.storageDegradation" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.storageLosses")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "storageLosses", dense: "" }, model: { value: n.localConfig.adminOptions.storageLosses, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "storageLosses", n._n(u));
  }, expression: "localConfig.adminOptions.storageLosses" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.amortizationPeriod")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "amortizationPeriod", dense: "" }, model: { value: n.localConfig.adminOptions.amortizationPeriod, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "amortizationPeriod", n._n(u));
  }, expression: "localConfig.adminOptions.amortizationPeriod" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.admin.maintenancePortion")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "maintenancePortion", dense: "" }, model: { value: n.localConfig.adminOptions.maintenancePortion, callback: function(u) {
    n.$set(n.localConfig.adminOptions, "maintenancePortion", n._n(u));
  }, expression: "localConfig.adminOptions.maintenancePortion" } })], 1)], 1)], 1)], 1), l("VcsFormSection", { attrs: { heading: "user options", expandable: "", "start-open": !0 } }, [l("v-container", { staticClass: "py-0 px-1" }, [l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.numberOfPersons")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "numberOfPersons", dense: "" }, model: { value: n.localConfig.userOptions.numberOfPersons, callback: function(u) {
    n.$set(n.localConfig.userOptions, "numberOfPersons", n._n(u));
  }, expression: "localConfig.userOptions.numberOfPersons" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.livingSpace")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "livingSpace", dense: "" }, model: { value: n.localConfig.userOptions.livingSpace, callback: function(u) {
    n.$set(n.localConfig.userOptions, "livingSpace", n._n(u));
  }, expression: "localConfig.userOptions.livingSpace" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.annualDrivingDistance")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "annualDrivingDistance", dense: "" }, model: { value: n.localConfig.userOptions.annualDrivingDistance, callback: function(u) {
    n.$set(n.localConfig.userOptions, "annualDrivingDistance", n._n(u));
  }, expression: "localConfig.userOptions.annualDrivingDistance" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.directConsumptionPortion")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "directConsumptionPortion", dense: "" }, model: { value: n.localConfig.userOptions.directConsumptionPortion, callback: function(u) {
    n.$set(n.localConfig.userOptions, "directConsumptionPortion", n._n(u));
  }, expression: "localConfig.userOptions.directConsumptionPortion" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.storageConsumptionPortion")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "storageConsumptionPortion", dense: "" }, model: { value: n.localConfig.userOptions.storageConsumptionPortion, callback: function(u) {
    n.$set(n.localConfig.userOptions, "storageConsumptionPortion", n._n(u));
  }, expression: "localConfig.userOptions.storageConsumptionPortion" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.gridPurchaseCosts")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "gridPurchaseCosts", dense: "" }, model: { value: n.localConfig.userOptions.gridPurchaseCosts, callback: function(u) {
    n.$set(n.localConfig.userOptions, "gridPurchaseCosts", n._n(u));
  }, expression: "localConfig.userOptions.gridPurchaseCosts" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.feedInTariff")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "feedInTariff", dense: "" }, model: { value: n.localConfig.userOptions.feedInTariff, callback: function(u) {
    n.$set(n.localConfig.userOptions, "feedInTariff", n._n(u));
  }, expression: "localConfig.userOptions.feedInTariff" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.electricityPriceIncrease")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "electricityPriceIncrease", dense: "" }, model: { value: n.localConfig.userOptions.electricityPriceIncrease, callback: function(u) {
    n.$set(n.localConfig.userOptions, "electricityPriceIncrease", n._n(u));
  }, expression: "localConfig.userOptions.electricityPriceIncrease" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.equityCapital")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "equityCapital", dense: "" }, model: { value: n.localConfig.userOptions.equityCapital, callback: function(u) {
    n.$set(n.localConfig.userOptions, "equityCapital", n._n(u));
  }, expression: "localConfig.userOptions.equityCapital" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.creditPeriod")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "creditPeriod", dense: "" }, model: { value: n.localConfig.userOptions.creditPeriod, callback: function(u) {
    n.$set(n.localConfig.userOptions, "creditPeriod", n._n(u));
  }, expression: "localConfig.userOptions.creditPeriod" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.creditInterest")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "creditInterest", dense: "" }, model: { value: n.localConfig.userOptions.creditInterest, callback: function(u) {
    n.$set(n.localConfig.userOptions, "creditInterest", n._n(u));
  }, expression: "localConfig.userOptions.creditInterest" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.user.electricityDemand")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "electricityDemand", dense: "" }, model: { value: n.localConfig.userOptions.electricityDemand, callback: function(u) {
    n.$set(n.localConfig.userOptions, "electricityDemand", n._n(u));
  }, expression: "localConfig.userOptions.electricityDemand" } })], 1)], 1)], 1)], 1), l("VcsFormSection", { attrs: { heading: "global options", expandable: "", "start-open": !0 } }, [l("v-container", { staticClass: "py-0 px-1" }, [l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.global.isVcSolar")) + " ")])], 1), l("v-col", [l("VcsCheckbox", { attrs: { id: "isVcSolar", dense: "" }, model: { value: n.localConfig.globalSettings.isVcSolar, callback: function(u) {
    n.$set(n.localConfig.globalSettings, "isVcSolar", u);
  }, expression: "localConfig.globalSettings.isVcSolar" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.global.solarLayerName")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "solarLayerName", dense: "" }, model: { value: n.localConfig.globalSettings.solarLayerName, callback: function(u) {
    n.$set(n.localConfig.globalSettings, "solarLayerName", u);
  }, expression: "localConfig.globalSettings.solarLayerName" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.global.isDebug")) + " ")])], 1), l("v-col", [l("VcsCheckbox", { attrs: { id: "isDebug", dense: "" }, model: { value: n.localConfig.globalSettings.isDebug, callback: function(u) {
    n.$set(n.localConfig.globalSettings, "isDebug", u);
  }, expression: "localConfig.globalSettings.isDebug" } })], 1)], 1)], 1)], 1), l("VcsFormSection", { attrs: { heading: "vcSolar options", expandable: "", "start-open": !0 } }, [l("v-container", { staticClass: "py-0 px-1" }, [l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.vcSolar.efficiency")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "efficiency", dense: "" }, model: { value: n.localConfig.vcSolarOptions.efficiency, callback: function(u) {
    n.$set(n.localConfig.vcSolarOptions, "efficiency", u);
  }, expression: "localConfig.vcSolarOptions.efficiency" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.vcSolar.costs")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "costs", dense: "" }, model: { value: n.localConfig.vcSolarOptions.costs, callback: function(u) {
    n.$set(n.localConfig.vcSolarOptions, "costs", u);
  }, expression: "localConfig.vcSolarOptions.costs" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.vcSolar.degradation")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "degradation", dense: "" }, model: { value: n.localConfig.vcSolarOptions.degradation, callback: function(u) {
    n.$set(n.localConfig.vcSolarOptions, "degradation", u);
  }, expression: "localConfig.vcSolarOptions.degradation" } })], 1)], 1), l("v-row", { attrs: { "no-gutters": "" } }, [l("v-col", [l("VcsLabel", { attrs: { dense: "" } }, [n._v(" " + n._s(n.$t("solarRevenue.config.vcSolar.kwpPerArea")) + " ")])], 1), l("v-col", [l("VcsTextField", { attrs: { id: "kwpPerArea", dense: "" }, model: { value: n.localConfig.vcSolarOptions.kwpPerArea, callback: function(u) {
    n.$set(n.localConfig.vcSolarOptions, "kwpPerArea", u);
  }, expression: "localConfig.vcSolarOptions.kwpPerArea" } })], 1)], 1)], 1)], 1)], 1);
}, Yo = [], No = /* @__PURE__ */ vt(
  Do,
  Xo,
  Yo,
  !1,
  null,
  null,
  null,
  null
);
const Ho = No.exports;
function Uo(v) {
  let n, l, u, b;
  const y = [], I = Ua(Et(), v);
  return {
    get name() {
      return At;
    },
    get version() {
      return Zs;
    },
    get mapVersion() {
      return Js;
    },
    get config() {
      return I;
    },
    get selectedModules() {
      return l;
    },
    get vcSolarInteraction() {
      return u;
    },
    get chartTheme() {
      return b;
    },
    initialize(A) {
      const T = "solar-revenue";
      n = A, l = Pe([]), b = Pe($i.framework.theme.dark ? "dark" : "light"), u = new _o(
        n,
        l,
        this.config.vcSolarOptions,
        this.config.globalSettings.solarLayerName
      );
      const z = n.windowManager.removed.addEventListener(
        ({ id: W }) => {
          W === It && (n == null || n.toolboxManager.remove("solarArea"), n == null || n.toolboxManager.remove("vcSolar"), n == null || n.windowManager.remove(T));
        }
      ), H = n.windowManager.added.addEventListener(
        ({ id: W }) => {
          if (W === It) {
            if (this.config.globalSettings.isVcSolar) {
              const j = Fo(
                n,
                u
              );
              y.push(j);
            }
            const B = zo(
              n,
              l,
              this.config.vcSolarOptions,
              this.config.globalSettings.isDebug
            );
            y.push(B);
          }
        }
      ), F = n.themeChanged.addEventListener(() => {
        b.value = $i.framework.theme.dark ? "dark" : "light";
      }), D = Oo(n);
      y.push(z), y.push(F), y.push(D), y.push(H);
    },
    getDefaultOptions: Et,
    toJSON() {
      return qa(Et(), I);
    },
    getConfigEditors() {
      return [
        {
          component: Ho,
          infoUrlCallback: n.getHelpUrlCallback(
            "/components/plugins/solarToolConfig.html"
          )
        }
      ];
    },
    destroy() {
      y.forEach((A) => A());
    },
    i18n: {
      de: Qs,
      en: tr
    }
  };
}
export {
  Uo as default
};
