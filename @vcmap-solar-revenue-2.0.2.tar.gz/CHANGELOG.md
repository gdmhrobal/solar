# v2.0.0

- updated to @vcmap/core and @vcmap/ui Version 6.0
- Standardizes the formats of the axis labels in the tables

# v1.0.0
